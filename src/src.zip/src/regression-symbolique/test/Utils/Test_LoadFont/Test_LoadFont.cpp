#include <QTest>
#include <QtGui/QFontDatabase>

#include "Utils/FileUtils.h"

class Test_LoadFont : public QObject
{
    Q_OBJECT

  public:
    Test_LoadFont();

  private slots:
    void loadFonts();
};

Test_LoadFont::Test_LoadFont() = default;

void Test_LoadFont::loadFonts()
{
    const QVector<int>& fontIds = utils::FileUtils::loadFonts(":/TestData/data");

    QStringList loadedFontFamilies;

    for (int fontId : fontIds) loadedFontFamilies.append(QFontDatabase::applicationFontFamilies(fontId));

    QVERIFY(loadedFontFamilies.contains("Handlee"));
    QVERIFY(loadedFontFamilies.contains("Roboto"));
    QVERIFY(loadedFontFamilies.contains("Libre Baskerville"));
}

QTEST_MAIN(Test_LoadFont)

#include "Test_LoadFont.moc"
