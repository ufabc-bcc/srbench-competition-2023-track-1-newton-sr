#include <QTest>

#include <cmath>
#include <QtGui/QFontDatabase>

#include "Utils/ComparisonUtils.h"

class Test_ComparisonUtils : public QObject
{
    Q_OBJECT

public:
    Test_ComparisonUtils();

private slots:
    void orderedDistancesDecreasingOrder();
};

Test_ComparisonUtils::Test_ComparisonUtils() = default;

void Test_ComparisonUtils::orderedDistancesDecreasingOrder()
{
    QMap<int, double> distances({{0, 5},
                                 {1, 1.2},
                                 {2, 2.2},
                                 {3, std::numeric_limits<double>::infinity()},
                                 {4, 4.5},
                                 {5, nan("")},
                                 {6, 0.5}});

    QList<QPair<int, double>> expectedResult({{6, 0.5},
                                              {1, 1.2},
                                              {2, 2.2},
                                              {4, 4.5},
                                              {0, 5},
                                              {5, nan("")},
                                              {3, std::numeric_limits<double>::infinity()}});

    QList<QPair<int, double>> actualResult = utils::orderDistancesDecreasingOrder(distances);

    QCOMPARE(actualResult.size(), expectedResult.size());
    for (int i = 0; i < actualResult.size(); ++i) {
        QCOMPARE(actualResult.value(i).first, expectedResult.value(i).first);
        QCOMPARE(actualResult.value(i).second, expectedResult.value(i).second);
    }
}

QTEST_MAIN(Test_ComparisonUtils)

#include "Test_ComparisonUtils.moc"
