#include <QTest>

#include "DataModel/EquationTree.h"
#include <DataModel/AbsoluteNode.h>
#include <DataModel/AdditionNode.h>
#include <DataModel/ConstantNode.h>
#include <DataModel/CosinusNode.h>
#include <DataModel/DivisionNode.h>
#include <DataModel/EquationTreeItem.h>
#include <DataModel/ExponentialNode.h>
#include <DataModel/LogarithmeNode.h>
#include <DataModel/MaxNode.h>
#include <DataModel/MinNode.h>
#include <DataModel/MultiplicationNode.h>
#include <DataModel/PowerNode.h>
#include <DataModel/SinusNode.h>
#include <DataModel/SoustractionNode.h>
#include <DataModel/SquareRootNode.h>
#include <DataModel/VariableNode.h>
#include <DataModel/NegativeNode.h>

#include <EquationEditors/EquationSimplifier.h>
#include <EquationEditors/EquationPrinter.h>

class Test_EquationSimplifier : public QObject
{
    Q_OBJECT

  public:
      Test_EquationSimplifier() = default;

  private:
      datamodel::EquationTreeItem _buildTestCaseXminusX();

  private slots:
      void equationSimplifier();
      void equationSimplifierAddition();
      void equationSimplifierMultiplication();
      void equationTreeSimplifier();
      void equationTreeItemSimplifier();
};

void Test_EquationSimplifier::equationSimplifier()
{
    //=============
    // Substraction
    //=============
    // 5 - 2 = 3
    uint nbVar = 0;
    datamodel::EquationTreeItem constantLeft( std::shared_ptr<datamodel::EquationNode>(new datamodel::ConstantNode(5)) );
    datamodel::EquationTreeItem constantRight( std::shared_ptr<datamodel::EquationNode>(new datamodel::ConstantNode(2)) );
    QList<datamodel::EquationTreeItem> arguments;
    arguments.append(constantLeft);
    arguments.append(constantRight);
    auto eqNode = std::shared_ptr<datamodel::EquationNode>(new datamodel::SoustractionNode());
    datamodel::EquationTreeItem equationTreeItemSubConst(eqNode);
    std::vector<datamodel::EquationTreeItem> vectArguments3;
    vectArguments3.reserve(arguments.size());
    std::copy(arguments.begin(), arguments.end(), std::back_inserter(vectArguments3));
    equationTreeItemSubConst.setArguments(vectArguments3);

    bool bRes = equationeditors::equationSimplifier(equationTreeItemSubConst, nbVar);
    QVERIFY2(bRes, "Substraction of constants");
    QString equationAfter = QString::fromStdString(equationeditors::equationToString(equationTreeItemSubConst, nbVar));
    QCOMPARE("3", equationAfter);

    // x - x = 0
    nbVar = 1;
    datamodel::EquationTreeItem variableSubLeft( std::shared_ptr<datamodel::EquationNode>(new datamodel::VariableNode(0)));
    datamodel::EquationTreeItem variableSubRight( std::shared_ptr<datamodel::EquationNode>(new datamodel::VariableNode(0)));
    arguments.clear();
    arguments.append(variableSubLeft);
    arguments.append(variableSubRight);
    datamodel::EquationTreeItem equationTreeItemSubVar(eqNode);
    std::vector<datamodel::EquationTreeItem> vectArguments4;
    vectArguments4.reserve(arguments.size());
    std::copy(arguments.begin(), arguments.end(), std::back_inserter(vectArguments4));
    equationTreeItemSubVar.setArguments(vectArguments4);

    bRes = equationeditors::equationSimplifier(equationTreeItemSubVar, nbVar);
    QVERIFY2(bRes, "Substraction of variable");
    equationAfter = QString::fromStdString(equationeditors::equationToString(equationTreeItemSubVar, nbVar));
    QCOMPARE("0", equationAfter);

    // sin(x) - 0 = sin(x)
    datamodel::EquationTreeItem constantZero( std::shared_ptr<datamodel::EquationNode>(new datamodel::ConstantNode(0)) );
    datamodel::EquationTreeItem variableSin( std::shared_ptr<datamodel::EquationNode>(new datamodel::VariableNode(0)) );
    auto sinVar = std::shared_ptr<datamodel::EquationNode>(new datamodel::SinusNode());
    datamodel::EquationTreeItem equationTreeItemSinVar(sinVar);
    equationTreeItemSinVar.setArguments(std::vector<datamodel::EquationTreeItem>{variableSin});
    arguments.clear();
    arguments.append(equationTreeItemSinVar);
    arguments.append(constantZero);
    datamodel::EquationTreeItem equationTreeItemSinSubZero(eqNode);
    std::vector<datamodel::EquationTreeItem> vectArguments5;
    vectArguments5.reserve(arguments.size());
    std::copy(arguments.begin(), arguments.end(), std::back_inserter(vectArguments5));
    equationTreeItemSinSubZero.setArguments(vectArguments5);

    bRes = equationeditors::equationSimplifier(equationTreeItemSinSubZero, nbVar);
    QVERIFY2(bRes, "sin(x) - 0");
    equationAfter = QString::fromStdString(equationeditors::equationToString(equationTreeItemSinSubZero, nbVar));
    QCOMPARE("sin(x0)", equationAfter);

    // 0 - sin(x) = -1 * sin(x)
    arguments.clear();
    arguments.append(constantZero);
    arguments.append(equationTreeItemSinVar);
    datamodel::EquationTreeItem equationTreeItemZeroSubSin(eqNode);
    std::vector<datamodel::EquationTreeItem> vectArguments6;
    vectArguments6.reserve(arguments.size());
    std::copy(arguments.begin(), arguments.end(), std::back_inserter(vectArguments6));
    equationTreeItemZeroSubSin.setArguments(vectArguments6);

    bRes = equationeditors::equationSimplifier(equationTreeItemZeroSubSin, nbVar);
    QVERIFY2(bRes, "0 - sin(x)");
    equationAfter = QString::fromStdString(equationeditors::equationToString(equationTreeItemZeroSubSin, nbVar));
    QCOMPARE("(-1 * sin(x0))", equationAfter);

    //=========
    // Division
    //=========
    // 5 / 2 = 2.5
    nbVar = 0;
    arguments.clear();
    arguments.append(constantLeft);
    arguments.append(constantRight);
    eqNode = std::shared_ptr<datamodel::EquationNode>(new datamodel::DivisionNode());
    datamodel::EquationTreeItem equationTreeItemDivConst(eqNode);
    std::vector<datamodel::EquationTreeItem> vectArguments11;
    vectArguments11.reserve(arguments.size());
    std::copy(arguments.begin(), arguments.end(), std::back_inserter(vectArguments11));
    equationTreeItemDivConst.setArguments(vectArguments11);

    bRes = equationeditors::equationSimplifier(equationTreeItemDivConst, nbVar);
    QVERIFY2(bRes, "Division of constants");
    equationAfter = QString::fromStdString(equationeditors::equationToString(equationTreeItemDivConst, nbVar));
    QCOMPARE("2.5", equationAfter);

    // x / 1 = x
    nbVar = 1;
    datamodel::EquationTreeItem constantOne( std::shared_ptr<datamodel::EquationNode>(new datamodel::ConstantNode(1)) );
    datamodel::EquationTreeItem variableDivLeft( std::shared_ptr<datamodel::EquationNode>(new datamodel::VariableNode(0)) );
    arguments.clear();
    arguments.append(variableDivLeft);
    arguments.append(constantOne);
    eqNode = std::shared_ptr<datamodel::EquationNode>(new datamodel::DivisionNode());
    datamodel::EquationTreeItem equationTreeItemDivOne(eqNode);
    std::vector<datamodel::EquationTreeItem> vectArguments12;
    vectArguments12.reserve(arguments.size());
    std::copy(arguments.begin(), arguments.end(), std::back_inserter(vectArguments12));
    equationTreeItemDivOne.setArguments(vectArguments12);

    bRes = equationeditors::equationSimplifier(equationTreeItemDivOne, nbVar);
    QVERIFY2(bRes, "Division by one");
    equationAfter = QString::fromStdString(equationeditors::equationToString(equationTreeItemDivOne, nbVar));
    QCOMPARE("x0", equationAfter);

    // x / x = 1
    datamodel::EquationTreeItem variableDivRight( std::shared_ptr<datamodel::EquationNode>(new datamodel::VariableNode(0)) );
    arguments.clear();
    arguments.append(variableDivLeft);
    arguments.append(variableDivRight);
    eqNode = std::shared_ptr<datamodel::EquationNode>(new datamodel::DivisionNode());
    datamodel::EquationTreeItem equationTreeItemDivVar(eqNode);
    std::vector<datamodel::EquationTreeItem> vectArguments13;
    vectArguments13.reserve(arguments.size());
    std::copy(arguments.begin(), arguments.end(), std::back_inserter(vectArguments13));
    equationTreeItemDivVar.setArguments(vectArguments13);
    bRes = equationeditors::equationSimplifier(equationTreeItemDivVar, nbVar);
    QVERIFY2(bRes, "Division of variable");
    equationAfter = QString::fromStdString(equationeditors::equationToString(equationTreeItemDivVar, nbVar));
    QCOMPARE("1", equationAfter);

    //====================
    // Cosinus of constant
    //====================
    // cos(0) = 1
    nbVar = 0;
    arguments.clear();
    arguments.append(constantZero);
    eqNode = std::shared_ptr<datamodel::EquationNode>(new datamodel::CosinusNode());
    datamodel::EquationTreeItem equationTreeItemCos(eqNode);
    std::vector<datamodel::EquationTreeItem> vectArguments14;
    vectArguments14.reserve(arguments.size());
    std::copy(arguments.begin(), arguments.end(), std::back_inserter(vectArguments14));
    equationTreeItemCos.setArguments(vectArguments14);

    bRes = equationeditors::equationSimplifier(equationTreeItemCos, nbVar);
    QVERIFY2(bRes, "Cosinus of constant");
    equationAfter = QString::fromStdString(equationeditors::equationToString(equationTreeItemCos, nbVar));
    QCOMPARE("1", equationAfter);

    //==================
    // Sinus of constant
    //==================
    // sin(0) = 0
    arguments.clear();
    arguments.append(constantZero);
    eqNode = std::shared_ptr<datamodel::EquationNode>(new datamodel::SinusNode());
    datamodel::EquationTreeItem equationTreeItemSin(eqNode);
    std::vector<datamodel::EquationTreeItem> vectArguments15;
    vectArguments15.reserve(arguments.size());
    std::copy(arguments.begin(), arguments.end(), std::back_inserter(vectArguments15));
    equationTreeItemSin.setArguments(vectArguments15);

    bRes = equationeditors::equationSimplifier(equationTreeItemSin, nbVar);
    QVERIFY2(bRes, "Sinus of constant");
    equationAfter = QString::fromStdString(equationeditors::equationToString(equationTreeItemSin, nbVar));
    QCOMPARE("0", equationAfter);

    //======
    // Power
    //======
    // 2 ^ 3 = 8
    //----------
    datamodel::EquationTreeItem constantPowLeft( std::shared_ptr<datamodel::EquationNode>(new datamodel::ConstantNode(2)) );
    datamodel::EquationTreeItem constantPowRight( std::shared_ptr<datamodel::EquationNode>(new datamodel::ConstantNode(3)) );
    arguments.clear();
    arguments.append(constantPowLeft);
    arguments.append(constantPowRight);
    eqNode = std::shared_ptr<datamodel::EquationNode>(new datamodel::PowerNode());
    datamodel::EquationTreeItem equationTreeItemPowConst(eqNode);
    std::vector<datamodel::EquationTreeItem> vectArguments16;
    vectArguments16.reserve(arguments.size());
    std::copy(arguments.begin(), arguments.end(), std::back_inserter(vectArguments16));
    equationTreeItemPowConst.setArguments(vectArguments16);

    bRes = equationeditors::equationSimplifier(equationTreeItemPowConst, nbVar);
    QVERIFY2(bRes, "Power - 2 ^ 3");
    equationAfter = QString::fromStdString(equationeditors::equationToString(equationTreeItemPowConst, nbVar));
    QCOMPARE("8", equationAfter);


    // sin(x) ^ 0 = 1
    //---------------
    nbVar = 1;
    arguments.clear();
    arguments.append(equationTreeItemSinVar);
    arguments.append(constantZero);
    eqNode = std::shared_ptr<datamodel::EquationNode>(new datamodel::PowerNode());
    datamodel::EquationTreeItem equationTreeItemPowZero(eqNode);
    std::vector<datamodel::EquationTreeItem> vectArguments17;
    vectArguments17.reserve(arguments.size());
    std::copy(arguments.begin(), arguments.end(), std::back_inserter(vectArguments17));
    equationTreeItemPowZero.setArguments(vectArguments17);

    bRes = equationeditors::equationSimplifier(equationTreeItemPowZero, nbVar);
    QVERIFY2(bRes, "Power of 0");
    equationAfter = QString::fromStdString(equationeditors::equationToString(equationTreeItemPowZero, nbVar));
    QCOMPARE("1", equationAfter);

    // sin(x) ^ 1 = sin(x)
    arguments.clear();
    arguments.append(equationTreeItemSinVar);
    arguments.append(constantOne);
    datamodel::EquationTreeItem equationTreeItemSinPowOne(eqNode);
    std::vector<datamodel::EquationTreeItem> vectArguments18;
    vectArguments18.reserve(arguments.size());
    std::copy(arguments.begin(), arguments.end(), std::back_inserter(vectArguments18));
    equationTreeItemSinPowOne.setArguments(vectArguments18);

    bRes = equationeditors::equationSimplifier(equationTreeItemSinPowOne, nbVar);
    QVERIFY2(bRes, "sin(x) ^ 1");
    equationAfter = QString::fromStdString(equationeditors::equationToString(equationTreeItemSinPowOne, nbVar));
    QCOMPARE("sin(x0)", equationAfter);

    //====================
    // Logarithm of constant
    //====================
    // ln(1) = 0
    nbVar = 0;
    arguments.clear();
    arguments.append(constantOne);
    eqNode = std::shared_ptr<datamodel::EquationNode>(new datamodel::LogarithmeNode());
    datamodel::EquationTreeItem equationTreeItemLn(eqNode);
    std::vector<datamodel::EquationTreeItem> vectArguments19;
    vectArguments19.reserve(arguments.size());
    std::copy(arguments.begin(), arguments.end(), std::back_inserter(vectArguments19));
    equationTreeItemLn.setArguments(vectArguments19);

    bRes = equationeditors::equationSimplifier(equationTreeItemLn, nbVar);
    QVERIFY2(bRes, "Logarithm of constant");
    equationAfter = QString::fromStdString(equationeditors::equationToString(equationTreeItemLn, nbVar));
    QCOMPARE("0", equationAfter);

    //====================
    // Exponential of constant
    //====================
    // exp(0) = 1
    arguments.clear();
    arguments.append(constantZero);
    eqNode = std::shared_ptr<datamodel::EquationNode>(new datamodel::ExponentialNode());
    datamodel::EquationTreeItem equationTreeItemExp(eqNode);
    std::vector<datamodel::EquationTreeItem> vectArguments20;
    vectArguments20.reserve(arguments.size());
    std::copy(arguments.begin(), arguments.end(), std::back_inserter(vectArguments20));
    equationTreeItemExp.setArguments(vectArguments20);

    bRes = equationeditors::equationSimplifier(equationTreeItemExp, nbVar);
    QVERIFY2(bRes, "Exponential of constant");
    equationAfter = QString::fromStdString(equationeditors::equationToString(equationTreeItemExp, nbVar));
    QCOMPARE("1", equationAfter);

    //==================
    // Square root of constant
    //==================
    // sqrt(1) = 1
    arguments.clear();
    arguments.append(constantOne);
    eqNode = std::shared_ptr<datamodel::EquationNode>(new datamodel::SquareRootNode());
    datamodel::EquationTreeItem equationTreeItemSqrt(eqNode);
    std::vector<datamodel::EquationTreeItem> vectArguments21;
    vectArguments21.reserve(arguments.size());
    std::copy(arguments.begin(), arguments.end(), std::back_inserter(vectArguments21));
    equationTreeItemSqrt.setArguments(vectArguments21);

    bRes = equationeditors::equationSimplifier(equationTreeItemSqrt, nbVar);
    QVERIFY2(bRes, "Square root of constant");
    equationAfter = QString::fromStdString(equationeditors::equationToString(equationTreeItemSqrt, nbVar));
    QCOMPARE("1", equationAfter);

    //====================
    // Minimum of constants
    //====================
    // min(1, -1) = -1
    datamodel::EquationTreeItem constantMinusOne( std::shared_ptr<datamodel::EquationNode>(new datamodel::ConstantNode(-1)) );
    arguments.clear();
    arguments.append(constantOne);
    arguments.append(constantMinusOne);
    eqNode = std::shared_ptr<datamodel::EquationNode>(new datamodel::MinNode());
    datamodel::EquationTreeItem equationTreeItemMin(eqNode);
    std::vector<datamodel::EquationTreeItem> vectArguments22;
    vectArguments22.reserve(arguments.size());
    std::copy(arguments.begin(), arguments.end(), std::back_inserter(vectArguments22));
    equationTreeItemMin.setArguments(vectArguments22);

    bRes = equationeditors::equationSimplifier(equationTreeItemMin, nbVar);
    QVERIFY2(bRes, "Min of 1, -1");
    equationAfter = QString::fromStdString(equationeditors::equationToString(equationTreeItemMin, nbVar));
    QCOMPARE("-1", equationAfter);

    //====================
    // Maximum of constants
    //====================
    // max(1, -1) = 1
    arguments.clear();
    arguments.append(constantOne);
    arguments.append(constantMinusOne);
    eqNode = std::shared_ptr<datamodel::EquationNode>(new datamodel::MaxNode());
    datamodel::EquationTreeItem equationTreeItemMax(eqNode);
    std::vector<datamodel::EquationTreeItem> vectArguments23;
    vectArguments23.reserve(arguments.size());
    std::copy(arguments.begin(), arguments.end(), std::back_inserter(vectArguments23));
    equationTreeItemMax.setArguments(vectArguments23);

    bRes = equationeditors::equationSimplifier(equationTreeItemMax, nbVar);
    QVERIFY2(bRes, "Max of 1, -1");
    equationAfter = QString::fromStdString(equationeditors::equationToString(equationTreeItemMax, nbVar));
    QCOMPARE("1", equationAfter);

    //==================
    // Absolute of constant
    //==================
    // abs(-1) = 1
    arguments.clear();
    arguments.append(constantMinusOne);
    eqNode = std::shared_ptr<datamodel::EquationNode>(new datamodel::AbsoluteNode());
    datamodel::EquationTreeItem equationTreeItemAbs(eqNode);
    std::vector<datamodel::EquationTreeItem> vectArguments24;
    vectArguments24.reserve(arguments.size());
    std::copy(arguments.begin(), arguments.end(), std::back_inserter(vectArguments24));
    equationTreeItemAbs.setArguments(vectArguments24);

    bRes = equationeditors::equationSimplifier(equationTreeItemAbs, nbVar);
    QVERIFY2(bRes, "Absolute of constant");
    equationAfter = QString::fromStdString(equationeditors::equationToString(equationTreeItemAbs, nbVar));
    QCOMPARE("1", equationAfter);
}

void Test_EquationSimplifier::equationSimplifierAddition()
{
    datamodel::EquationTreeItem constantMinus5(std::shared_ptr<datamodel::EquationNode>(new datamodel::ConstantNode(-5)));
    datamodel::EquationTreeItem constant0(std::shared_ptr<datamodel::EquationNode>(new datamodel::ConstantNode(0)));
    datamodel::EquationTreeItem constant2(std::shared_ptr<datamodel::EquationNode>(new datamodel::ConstantNode(2)));
    datamodel::EquationTreeItem constant3(std::shared_ptr<datamodel::EquationNode>(new datamodel::ConstantNode(3)));
    datamodel::EquationTreeItem constant5(std::shared_ptr<datamodel::EquationNode>(new datamodel::ConstantNode(5)));
    datamodel::EquationTreeItem variableNodeX0(std::shared_ptr<datamodel::EquationNode>(new datamodel::VariableNode(0)));
    datamodel::EquationTreeItem variableNodeX1(std::shared_ptr<datamodel::EquationNode>(new datamodel::VariableNode(1)));
    auto negativeNode = std::shared_ptr<datamodel::EquationNode>(new datamodel::NegativeNode());
    datamodel::EquationTreeItem negativeTree(negativeNode);
    negativeTree.setArguments(std::vector<datamodel::EquationTreeItem>{variableNodeX0});
    auto additionNode2Arg = std::shared_ptr<datamodel::EquationNode>(new datamodel::AdditionNode());
    auto additionNode3Arg = std::shared_ptr<datamodel::EquationNode>(new datamodel::AdditionNode(3));
    auto additionNode4Arg = std::shared_ptr<datamodel::EquationNode>(new datamodel::AdditionNode(4));

    //======================
    // Addition of constants
    //======================
    // 0 + 0 + 0
    uint nbVar = 0;
    datamodel::EquationTreeItem additionTree(additionNode3Arg);
    additionTree.setArguments(std::vector<datamodel::EquationTreeItem>{constant0, constant0, constant0});

    bool bRes = equationeditors::equationSimplifier(additionTree, nbVar);
    QVERIFY2(bRes, "Addition of zero constants");
    QString equationResult = QString::fromStdString(equationeditors::equationToString(additionTree, nbVar));
    QCOMPARE("0", equationResult);

    // 5 + 2 + 3 = 10
    additionTree.setCurrentNode(additionNode3Arg);
    additionTree.setArguments(std::vector<datamodel::EquationTreeItem>{constant5, constant2, constant3});

    bRes = equationeditors::equationSimplifier(additionTree, nbVar);
    QVERIFY2(bRes, "Addition of non-zero constants");
    equationResult = QString::fromStdString(equationeditors::equationToString(additionTree, nbVar));
    QCOMPARE("10", equationResult);

    //======================
    // Addition with 0
    //======================
    // x + 0 = x
    nbVar = 1;
    additionTree.setCurrentNode(additionNode2Arg);
    additionTree.setArguments(std::vector<datamodel::EquationTreeItem>{variableNodeX0, constant0});

    bRes = equationeditors::equationSimplifier(additionTree, nbVar);
    QVERIFY2(bRes, "x + 0");
    equationResult = QString::fromStdString(equationeditors::equationToString(additionTree, nbVar));
    QCOMPARE("x0", equationResult);

    // 0 + x = x
    additionTree.setCurrentNode(additionNode2Arg);
    additionTree.setArguments(std::vector<datamodel::EquationTreeItem>{constant0, variableNodeX0});

    bRes = equationeditors::equationSimplifier(additionTree, nbVar);
    QVERIFY2(bRes, "0 + x");
    equationResult = QString::fromStdString(equationeditors::equationToString(additionTree, nbVar));
    QCOMPARE("x0", equationResult);

    //======================
    // Addition with X + positive constant
    //======================
    // 2 + x + 5 = x + 7
    additionTree.setCurrentNode(additionNode3Arg);
    additionTree.setArguments(std::vector<datamodel::EquationTreeItem>{constant2, variableNodeX0, constant5});

    bRes = equationeditors::equationSimplifier(additionTree, nbVar);
    QVERIFY2(bRes, "2 + x + 5");
    equationResult = QString::fromStdString(equationeditors::equationToString(additionTree, nbVar));
    QCOMPARE("(x0 + 7)", equationResult);

    //======================
    // Addition with X + negative constant
    //======================
    // 2 + x + (-5) = x - 3
    additionTree.setCurrentNode(additionNode3Arg);
    additionTree.setArguments(std::vector<datamodel::EquationTreeItem>{constant2, variableNodeX0, constantMinus5});

    bRes = equationeditors::equationSimplifier(additionTree, nbVar);
    QVERIFY2(bRes, "2 + x + (-5)");
    equationResult = QString::fromStdString(equationeditors::equationToString(additionTree, nbVar));
    QCOMPARE("(x0 - 3)", equationResult);

    //======================
    // Addition with X + Y + negative constant
    //======================
    // 2 + x + y + (-5) = x - 3
    additionTree.setCurrentNode(additionNode4Arg);
    additionTree.setArguments(std::vector<datamodel::EquationTreeItem>{constant2, variableNodeX0, variableNodeX1, constantMinus5});

    bRes = equationeditors::equationSimplifier(additionTree, nbVar);
    QVERIFY2(bRes, "2 + x + y + (-5)");
    equationResult = QString::fromStdString(equationeditors::equationToString(additionTree, nbVar));
    QCOMPARE("((x0 + x1) - 3)", equationResult);

    //======================
    // Addition of multiple identical variables
    //======================
    // x + x + x = 3 * x
    additionTree.setCurrentNode(additionNode3Arg);
    additionTree.setArguments(std::vector<datamodel::EquationTreeItem>{variableNodeX0, variableNodeX0, variableNodeX0});

    bRes = equationeditors::equationSimplifier(additionTree, nbVar);
    QVERIFY2(bRes, "(x + x + x)");
    equationResult = QString::fromStdString(equationeditors::equationToString(additionTree, nbVar));
    QCOMPARE("(3 * x0)", equationResult);

    // x + x + x + 5 = (3 * x) + 5
    additionTree.setCurrentNode(additionNode4Arg);
    additionTree.setArguments(std::vector<datamodel::EquationTreeItem>{variableNodeX0, variableNodeX0, variableNodeX0, constant5});

    bRes = equationeditors::equationSimplifier(additionTree, nbVar);
    QVERIFY2(bRes, "(x + x + x + 5)");
    equationResult = QString::fromStdString(equationeditors::equationToString(additionTree, nbVar));
    QCOMPARE("((3 * x0) + 5)", equationResult);

    // (-x) + (-x) = (-2) * x
    additionTree.setCurrentNode(additionNode2Arg);
    additionTree.setArguments(std::vector<datamodel::EquationTreeItem>{negativeTree, negativeTree});

    bRes = equationeditors::equationSimplifier(additionTree, nbVar);
    QVERIFY2(bRes, "(-x) + (-x)");
    equationResult = QString::fromStdString(equationeditors::equationToString(additionTree, nbVar));
    QCOMPARE("(-2 * x0)", equationResult);

    //======================
    // Addition of inverse variables
    //======================
    // x + (-x) = 0
    additionTree.setCurrentNode(additionNode2Arg);
    additionTree.setArguments(std::vector<datamodel::EquationTreeItem>{variableNodeX0, negativeTree});

    bRes = equationeditors::equationSimplifier(additionTree, nbVar);
    QVERIFY2(bRes, "x + (-x)");
    equationResult = QString::fromStdString(equationeditors::equationToString(additionTree, nbVar));
    QCOMPARE("0", equationResult);

    // x + (-x) + x = x
    additionTree.setCurrentNode(additionNode3Arg);
    additionTree.setArguments(std::vector<datamodel::EquationTreeItem>{variableNodeX0, negativeTree, variableNodeX0});

    bRes = equationeditors::equationSimplifier(additionTree, nbVar);
    QVERIFY2(bRes, "x + (-x) + x");
    equationResult = QString::fromStdString(equationeditors::equationToString(additionTree, nbVar));
    QCOMPARE("x0", equationResult);

    // x + (-x) + x + 5 = x + 5
    additionTree.setCurrentNode(additionNode4Arg);
    additionTree.setArguments(std::vector<datamodel::EquationTreeItem>{variableNodeX0, negativeTree, variableNodeX0, constant5});

    bRes = equationeditors::equationSimplifier(additionTree, nbVar);
    QVERIFY2(bRes, "x + (-x) + x + 5");
    equationResult = QString::fromStdString(equationeditors::equationToString(additionTree, nbVar));
    QCOMPARE("(x0 + 5)", equationResult);
}

void Test_EquationSimplifier::equationSimplifierMultiplication()
{
    datamodel::EquationTreeItem constantMinus2(std::shared_ptr<datamodel::EquationNode>(new datamodel::ConstantNode(-2)));
    datamodel::EquationTreeItem constantMinus1(std::shared_ptr<datamodel::EquationNode>(new datamodel::ConstantNode(-1)));
    datamodel::EquationTreeItem constant0(std::shared_ptr<datamodel::EquationNode>(new datamodel::ConstantNode(0)));
    datamodel::EquationTreeItem constant1(std::shared_ptr<datamodel::EquationNode>(new datamodel::ConstantNode(1)));
    datamodel::EquationTreeItem constant2(std::shared_ptr<datamodel::EquationNode>(new datamodel::ConstantNode(2)));
    datamodel::EquationTreeItem constant5(std::shared_ptr<datamodel::EquationNode>(new datamodel::ConstantNode(5)));
    datamodel::EquationTreeItem variableNodeX0(std::shared_ptr<datamodel::EquationNode>(new datamodel::VariableNode(0)));
    datamodel::EquationTreeItem variableNodeX1(std::shared_ptr<datamodel::EquationNode>(new datamodel::VariableNode(1)));
    datamodel::EquationTreeItem negativeNodeX0(std::shared_ptr<datamodel::EquationNode>(new datamodel::NegativeNode()));
    negativeNodeX0.setArguments(std::vector<datamodel::EquationTreeItem>{variableNodeX0});
    datamodel::EquationTreeItem negativeNodeX1(std::shared_ptr<datamodel::EquationNode>(new datamodel::NegativeNode()));
    negativeNodeX1.setArguments(std::vector<datamodel::EquationTreeItem>{variableNodeX1});
    auto multiplicationNode2Arg = std::shared_ptr<datamodel::EquationNode>(new datamodel::MultiplicationNode());
    auto multiplicationNode3Arg = std::shared_ptr<datamodel::EquationNode>(new datamodel::MultiplicationNode(3));

    //===============
    // Multiplication by 0
    //===============
    // X * 5 * 0 = 0
    uint nbVar = 1;
    datamodel::EquationTreeItem multiplicationTree(multiplicationNode3Arg);
    multiplicationTree.setArguments(std::vector<datamodel::EquationTreeItem>{variableNodeX0, constant5, constant0});

    bool bRes = equationeditors::equationSimplifier(multiplicationTree, nbVar);
    QVERIFY2(bRes, "multiplication with zero constant");
    QString equationResult = QString::fromStdString(equationeditors::equationToString(multiplicationTree, nbVar));
    QCOMPARE("0", equationResult);

    //===============
    // Multiplication of constants only
    //===============
    // 5 * 2 = 10
    nbVar = 0;
    multiplicationTree.setCurrentNode(multiplicationNode2Arg);
    multiplicationTree.setArguments(std::vector<datamodel::EquationTreeItem>{constant5, constant2});

    bRes = equationeditors::equationSimplifier(multiplicationTree, nbVar);
    QVERIFY2(bRes, "Multiplication of constants only");
    equationResult = QString::fromStdString(equationeditors::equationToString(multiplicationTree, nbVar));
    QCOMPARE("10", equationResult);

    //===============
    // Multiplication by 1
    //===============
    // X * 1 = X
    nbVar = 1;
    multiplicationTree.setCurrentNode(multiplicationNode2Arg);
    multiplicationTree.setArguments(std::vector<datamodel::EquationTreeItem>{variableNodeX0, constant1});

    bRes = equationeditors::equationSimplifier(multiplicationTree, nbVar);
    QVERIFY2(bRes, "Multiplication by 1");
    equationResult = QString::fromStdString(equationeditors::equationToString(multiplicationTree, nbVar));
    QCOMPARE("x0", equationResult);

    //===============
    // Multiplication by -1
    //===============
    // X * (-1) = -X
    nbVar = 1;
    multiplicationTree.setCurrentNode(multiplicationNode2Arg);
    multiplicationTree.setArguments(std::vector<datamodel::EquationTreeItem>{variableNodeX0, constantMinus1});

    bRes = equationeditors::equationSimplifier(multiplicationTree, nbVar);
    QVERIFY2(bRes, "Multiplication by -1 with a positive");
    equationResult = QString::fromStdString(equationeditors::equationToString(multiplicationTree, nbVar));
    QCOMPARE("-(x0)", equationResult);

    // (-X) * (-1) = X
    nbVar = 1;
    multiplicationTree.setCurrentNode(multiplicationNode2Arg);
    multiplicationTree.setArguments(std::vector<datamodel::EquationTreeItem>{negativeNodeX0, constantMinus1});

    bRes = equationeditors::equationSimplifier(multiplicationTree, nbVar);
    QVERIFY2(bRes, "Multiplication by -1 with a negative");
    equationResult = QString::fromStdString(equationeditors::equationToString(multiplicationTree, nbVar));
    QCOMPARE("x0", equationResult);

    //===============
    // Multiplication with variables and constants
    //===============
    // 2 * X * 5 = 10 * X
    nbVar = 1;
    multiplicationTree.setCurrentNode(multiplicationNode3Arg);
    multiplicationTree.setArguments(std::vector<datamodel::EquationTreeItem>{constant2, variableNodeX0, constant5});

    bRes = equationeditors::equationSimplifier(multiplicationTree, nbVar);
    QVERIFY2(bRes, "Multiplication with variables and constants");
    equationResult = QString::fromStdString(equationeditors::equationToString(multiplicationTree, nbVar));
    QCOMPARE("(10 * x0)", equationResult);

    //===============
    // Multiplication of negatives
    //===============
    // (-X) * (-Y) = X * Y
    nbVar = 2;
    multiplicationTree.setCurrentNode(multiplicationNode2Arg);
    multiplicationTree.setArguments(std::vector<datamodel::EquationTreeItem>{negativeNodeX0, negativeNodeX1});

    bRes = equationeditors::equationSimplifier(multiplicationTree, nbVar);
    QVERIFY2(bRes, "Multiplication of negatives");
    equationResult = QString::fromStdString(equationeditors::equationToString(multiplicationTree, nbVar));
    QCOMPARE("(x0 * x1)", equationResult);

    //===============
    // Multiplication of same values
    //===============
    // (-X) * X = -(X ^ 2)
    nbVar = 1;
    multiplicationTree.setCurrentNode(multiplicationNode2Arg);
    multiplicationTree.setArguments(std::vector<datamodel::EquationTreeItem>{negativeNodeX0, variableNodeX0});

    bRes = equationeditors::equationSimplifier(multiplicationTree, nbVar);
    QVERIFY2(bRes, "Multiplication of same values with negative first value");
    equationResult = QString::fromStdString(equationeditors::equationToString(multiplicationTree, nbVar));
    QCOMPARE("-(x0) ^ 2", equationResult);

    // X * X = X ^ 2
    nbVar = 1;
    multiplicationTree.setCurrentNode(multiplicationNode2Arg);
    multiplicationTree.setArguments(std::vector<datamodel::EquationTreeItem>{variableNodeX0, variableNodeX0});

    bRes = equationeditors::equationSimplifier(multiplicationTree, nbVar);
    QVERIFY2(bRes, "Multiplication of same values with positive values");
    equationResult = QString::fromStdString(equationeditors::equationToString(multiplicationTree, nbVar));
    QCOMPARE("x0 ^ 2", equationResult);

    // (-X) * (-X) = X ^ 2
    nbVar = 1;
    multiplicationTree.setCurrentNode(multiplicationNode2Arg);
    multiplicationTree.setArguments(std::vector<datamodel::EquationTreeItem>{negativeNodeX0, negativeNodeX0});

    bRes = equationeditors::equationSimplifier(multiplicationTree, nbVar);
    QVERIFY2(bRes, "Multiplication of same values with negative values");
    equationResult = QString::fromStdString(equationeditors::equationToString(multiplicationTree, nbVar));
    QCOMPARE("x0 ^ 2", equationResult);

    // X * (-X) = -(X ^ 2)
    nbVar = 1;
    multiplicationTree.setCurrentNode(multiplicationNode2Arg);
    multiplicationTree.setArguments(std::vector<datamodel::EquationTreeItem>{variableNodeX0, negativeNodeX0});

    bRes = equationeditors::equationSimplifier(multiplicationTree, nbVar);
    QVERIFY2(bRes, "Multiplication of same values with negative last value");
    equationResult = QString::fromStdString(equationeditors::equationToString(multiplicationTree, nbVar));
    QCOMPARE("-(x0) ^ 2", equationResult);

    // X * X * 2 = 2 * (X ^ 2)
    nbVar = 1;
    multiplicationTree.setCurrentNode(multiplicationNode3Arg);
    multiplicationTree.setArguments(std::vector<datamodel::EquationTreeItem>{variableNodeX0, variableNodeX0, constant2});

    bRes = equationeditors::equationSimplifier(multiplicationTree, nbVar);
    QVERIFY2(bRes, "Multiplication of same values with a constant");
    equationResult = QString::fromStdString(equationeditors::equationToString(multiplicationTree, nbVar));
    QCOMPARE("(2 * x0 ^ 2)", equationResult);
}

datamodel::EquationTreeItem Test_EquationSimplifier::_buildTestCaseXminusX()
{
    // 7 + cos(x - x) = 8
    datamodel::EquationTreeItem variableSubLeft( std::shared_ptr<datamodel::EquationNode>(new datamodel::VariableNode(0)) );
    datamodel::EquationTreeItem variableSubRight( std::shared_ptr<datamodel::EquationNode>(new datamodel::VariableNode(0)) );
    auto eqSubNode = std::shared_ptr<datamodel::EquationNode>(new datamodel::SoustractionNode);
    datamodel::EquationTreeItem equationTreeItemSub(eqSubNode);
    equationTreeItemSub.setArguments(std::vector<datamodel::EquationTreeItem>{variableSubLeft, variableSubRight});

    auto eqCosNode = std::shared_ptr<datamodel::EquationNode>(new datamodel::CosinusNode());
    datamodel::EquationTreeItem equationTreeItemCos(eqCosNode);
    equationTreeItemCos.setArguments(std::vector<datamodel::EquationTreeItem>{equationTreeItemSub});

    datamodel::EquationTreeItem constantAddLeft( std::shared_ptr<datamodel::EquationNode>(new datamodel::ConstantNode(7)) );
    auto eqAddNode = std::shared_ptr<datamodel::EquationNode>(new datamodel::AdditionNode);
    datamodel::EquationTreeItem equationTreeItemAdd(eqAddNode);
    equationTreeItemAdd.setArguments(std::vector<datamodel::EquationTreeItem>{constantAddLeft, equationTreeItemCos});
    return equationTreeItemAdd;
}

void Test_EquationSimplifier::equationTreeSimplifier()
{
    // 7 + cos(x - x) = 8
    datamodel::EquationTreeItem equationTreeItemXminusX = _buildTestCaseXminusX();
    datamodel::EquationTree equationTree(equationTreeItemXminusX, 0);
    equationeditors::equationTreeSimplifier(equationTree);
    QVERIFY2(equationTree.root().currentNode()->type() == datamodel::EquationNode::Constant, "(7 + cos(x - x)) = 8 - Type");
    QVERIFY2(equationTree.root().currentNode()->value(std::vector<double>{0}) == 8, "(7 + cos(x - x)) = 8 - Value");
}

void Test_EquationSimplifier::equationTreeItemSimplifier()
{
    uint nbVar = 1;
    // 7 + cos(x - x) = 8
    datamodel::EquationTreeItem equationTreeItemXminusX = _buildTestCaseXminusX();
    equationeditors::equationTreeItemSimplifier(equationTreeItemXminusX, nbVar);
    QVERIFY2(equationTreeItemXminusX.currentNode()->type() == datamodel::EquationNode::Constant, "Item (7 + cos(x - x)) = 8 - Type");
    QVERIFY2(equationTreeItemXminusX.currentNode()->value(std::vector<double>{0}) == 8, "Item (7 + cos(x - x)) = 8 - Value");
}

QTEST_APPLESS_MAIN(Test_EquationSimplifier)

#include "Test_EquationSimplifier.moc"
