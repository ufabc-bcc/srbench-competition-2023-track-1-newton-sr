
#include <QTest>

#include <DataModel/AdditionNode.h>
#include <DataModel/ConstantNode.h>
#include <DataModel/CosinusNode.h>
#include <DataModel/DivisionNode.h>
#include <DataModel/EquationNode.h>
#include <DataModel/EquationTreeItem.h>
#include <DataModel/ExponentialNode.h>
#include <DataModel/LogarithmeNode.h>
#include <DataModel/MaxNode.h>
#include <DataModel/MinNode.h>
#include <DataModel/MultiplicationNode.h>
#include <DataModel/PowerNode.h>
#include <DataModel/SinusNode.h>
#include <DataModel/SoustractionNode.h>
#include <DataModel/SquareRootNode.h>
#include <DataModel/VariableNode.h>

#include "EquationEditors/EquationPrinter.h"

class Test_EquationPrinter : public QObject
{
    Q_OBJECT

  public:
      Test_EquationPrinter() = default;

  private slots:
      void findMatchingConstant();
      void equationToString_constant();
      void equationToLatex_namedConstants();
      void equationToString_variable();
      void equationToString_add();
      void equationToString_cos();
      void equationToString_complexeEquation();
      void equationToString_min();
      void equationToString_max();
      void equationToString_soustration();
      void equationToString_multiplication();
      void equationToString_division();
      void equationToString_sin();
      void equationToString_exp();
      void equationToString_ln();
      void equationToString_pow();
      void equationToString_sqrt();
      void equationToString_complexeMin();
      void equationToString_complexeMax();
};

void Test_EquationPrinter::findMatchingConstant()
{
  auto pi = equationeditors::findMatchingConstant(3.1415, equationeditors::namedConstants, 4);
  QCOMPARE(pi->string, "pi");

  auto not_pi = equationeditors::findMatchingConstant(3.1412, equationeditors::namedConstants, 4);
  QCOMPARE(not_pi, equationeditors::namedConstants.end());
}

void Test_EquationPrinter::equationToLatex_namedConstants() {
    uint nbVar = 0;
    auto constantEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::ConstantNode(M_PI/2));
    datamodel::EquationTreeItem constantTreeItem(constantEquationNode);

    QCOMPARE(QString::fromStdString(equationeditors::equationToLatexString(constantTreeItem, nbVar)), "\\frac{\\pi}{2}");
}

void Test_EquationPrinter::equationToString_complexeMin()
{
    uint nbVar = 1;
    auto minEquationNode = std::shared_ptr<datamodel::EquationNode>(new datamodel::MinNode());
    datamodel::EquationTreeItem minTreeItem(minEquationNode);

    auto additionEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::AdditionNode());
    datamodel::EquationTreeItem additionTreeItem(additionEquationNode);

    auto firstArgumentEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::VariableNode(0));
    datamodel::EquationTreeItem firstArgumentTreeItem(firstArgumentEquationNode);

    auto secondArgumentEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::ConstantNode(5));
    datamodel::EquationTreeItem secondArgumentTreeItem(secondArgumentEquationNode);

    additionTreeItem.setArguments(
        std::vector<datamodel::EquationTreeItem>{firstArgumentTreeItem, secondArgumentTreeItem});

    minTreeItem.setArguments(
        std::vector<datamodel::EquationTreeItem>{(additionTreeItem), secondArgumentTreeItem});

    QCOMPARE(QString::fromStdString(equationeditors::equationToString(minTreeItem, nbVar)), "min((x0 + 5),5)");
}

void Test_EquationPrinter::equationToString_complexeMax()
{
    uint nbVar = 1;
    auto maxEquationNode = std::shared_ptr<datamodel::EquationNode>(new datamodel::MaxNode());
    datamodel::EquationTreeItem maxTreeItem(maxEquationNode);

    auto additionEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::AdditionNode());
    datamodel::EquationTreeItem additionTreeItem(additionEquationNode);

    auto firstArgumentEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::VariableNode(0));
    datamodel::EquationTreeItem firstArgumentTreeItem(firstArgumentEquationNode);

    auto secondArgumentEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::ConstantNode(5));
    datamodel::EquationTreeItem secondArgumentTreeItem(secondArgumentEquationNode);

    additionTreeItem.setArguments(
        std::vector<datamodel::EquationTreeItem>{firstArgumentTreeItem, secondArgumentTreeItem});

    maxTreeItem.setArguments(
        std::vector<datamodel::EquationTreeItem>{additionTreeItem, secondArgumentTreeItem});

    QCOMPARE(QString::fromStdString(equationeditors::equationToString(maxTreeItem, nbVar)), "max((x0 + 5),5)");
}

void Test_EquationPrinter::equationToString_multiplication()
{
    uint nbVar = 1;
    auto multiplicationEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::MultiplicationNode());
    datamodel::EquationTreeItem multiplicationTreeItem(multiplicationEquationNode);

    auto firstArgumentEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::VariableNode(0));
    datamodel::EquationTreeItem firstArgumentTreeItem(firstArgumentEquationNode);

    auto secondArgumentEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::ConstantNode(1.2));
    datamodel::EquationTreeItem secondArgumentTreeItem(secondArgumentEquationNode);

    multiplicationTreeItem.setArguments(
        std::vector<datamodel::EquationTreeItem>{firstArgumentTreeItem, secondArgumentTreeItem});

    QCOMPARE(QString::fromStdString(equationeditors::equationToString(multiplicationTreeItem, nbVar)), "(x0 * 1.2)");
}

void Test_EquationPrinter::equationToString_division()
{
    uint nbVar = 1;
    auto divisionEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::DivisionNode());
    datamodel::EquationTreeItem divisionTreeItem(divisionEquationNode);

    auto firstArgumentEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::VariableNode(0));
    datamodel::EquationTreeItem firstArgumentTreeItem(firstArgumentEquationNode);

    auto secondArgumentEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::ConstantNode(1.2));
    datamodel::EquationTreeItem secondArgumentTreeItem(secondArgumentEquationNode);

    divisionTreeItem.setArguments(
        std::vector<datamodel::EquationTreeItem>{firstArgumentTreeItem, secondArgumentTreeItem});

    QCOMPARE(QString::fromStdString(equationeditors::equationToString(divisionTreeItem, nbVar)), "(x0 / 1.2)");
}

void Test_EquationPrinter::equationToString_soustration()
{
    uint nbVar = 1;
    auto soustractionEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::SoustractionNode());
    datamodel::EquationTreeItem soustractionTreeItem(soustractionEquationNode);

    auto firstArgumentEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::VariableNode(0));
    datamodel::EquationTreeItem firstArgumentTreeItem(firstArgumentEquationNode);

    auto secondArgumentEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::ConstantNode(3.5));
    datamodel::EquationTreeItem secondArgumentTreeItem(secondArgumentEquationNode);

    soustractionTreeItem.setArguments(
        std::vector<datamodel::EquationTreeItem>{firstArgumentTreeItem, secondArgumentTreeItem});

    QCOMPARE(QString::fromStdString(equationeditors::equationToString(soustractionTreeItem, nbVar)), "(x0 - 3.5)");
}

void Test_EquationPrinter::equationToString_min()
{
    uint nbVar = 1;

    auto minEquationNode = std::shared_ptr<datamodel::EquationNode>(new datamodel::MinNode());
    datamodel::EquationTreeItem minTreeItem(minEquationNode);

    auto firstArgumentEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::VariableNode(0));
    datamodel::EquationTreeItem firstArgumentTreeItem(firstArgumentEquationNode);

    auto secondArgumentEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::ConstantNode(5));
    datamodel::EquationTreeItem secondArgumentTreeItem(secondArgumentEquationNode);

    // format function min(a,b)

    minTreeItem.setArguments(
        std::vector<datamodel::EquationTreeItem>{firstArgumentTreeItem, secondArgumentTreeItem});

    QCOMPARE(QString::fromStdString(equationeditors::equationToString(minTreeItem, nbVar)), "min(x0,5)");
}

void Test_EquationPrinter::equationToString_max()
{
    uint nbVar = 0;
    auto maxEquationNode = std::shared_ptr<datamodel::EquationNode>(new datamodel::MaxNode());
    datamodel::EquationTreeItem maxTreeItem(maxEquationNode);

    auto firstArgumentEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::ConstantNode(-6));
    datamodel::EquationTreeItem firstArgumentTreeItem(firstArgumentEquationNode);

    auto secondArgumentEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::ConstantNode(-2));
    datamodel::EquationTreeItem secondArgumentTreeItem(secondArgumentEquationNode);

    // format function max(a,b)

    maxTreeItem.setArguments(
        std::vector<datamodel::EquationTreeItem>{firstArgumentTreeItem, secondArgumentTreeItem});

    QCOMPARE(QString::fromStdString(equationeditors::equationToString(maxTreeItem, nbVar)), "max(-6,-2)");
}

void Test_EquationPrinter::equationToString_constant()
{
    uint nbVar = 0;
    auto constantEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::ConstantNode(1.2));
    datamodel::EquationTreeItem constantTreeItem(constantEquationNode);

    QCOMPARE(QString::fromStdString(equationeditors::equationToString(constantTreeItem, nbVar)), "1.2");
}

void Test_EquationPrinter::equationToString_variable()
{
    uint nbVar = 1;
    auto constantEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::VariableNode(0));
    datamodel::EquationTreeItem constantTreeItem(constantEquationNode);

    QCOMPARE(QString::fromStdString(equationeditors::equationToString(constantTreeItem, nbVar)), "x0");
}

void Test_EquationPrinter::equationToString_add()
{
    uint nbVar = 1;
    auto additionEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::AdditionNode());
    datamodel::EquationTreeItem additionTreeItem(additionEquationNode);

    auto firstArgumentEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::VariableNode(0));
    datamodel::EquationTreeItem firstArgumentTreeItem(firstArgumentEquationNode);

    auto secondArgumentEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::ConstantNode(3.5));
    datamodel::EquationTreeItem secondArgumentTreeItem(secondArgumentEquationNode);

    additionTreeItem.setArguments(
        std::vector<datamodel::EquationTreeItem>{firstArgumentTreeItem, secondArgumentTreeItem});

    QCOMPARE(QString::fromStdString(equationeditors::equationToString(additionTreeItem, nbVar)), "(x0 + 3.5)");
}


void Test_EquationPrinter::equationToString_sin()
{
    uint nbVar = 1;

    auto sinusEquationNode = std::shared_ptr<datamodel::EquationNode>(new datamodel::SinusNode());
    datamodel::EquationTreeItem sinusTreeItem(sinusEquationNode);

    auto argumentEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::VariableNode(0));
    datamodel::EquationTreeItem argumentTreeItem(argumentEquationNode);

    sinusTreeItem.setArguments(std::vector<datamodel::EquationTreeItem>{argumentTreeItem});

    QCOMPARE(QString::fromStdString(equationeditors::equationToString(sinusTreeItem, nbVar)), "sin(x0)");
}

void Test_EquationPrinter::equationToString_cos()
{
    uint nbVar = 1;

    auto cosinusEquationNode = std::shared_ptr<datamodel::EquationNode>(new datamodel::CosinusNode());
    datamodel::EquationTreeItem cosinusTreeItem(cosinusEquationNode);

    auto argumentEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::VariableNode(0));
    datamodel::EquationTreeItem argumentTreeItem(argumentEquationNode);

    cosinusTreeItem.setArguments(std::vector<datamodel::EquationTreeItem>{argumentTreeItem});

    QCOMPARE(QString::fromStdString(equationeditors::equationToString(cosinusTreeItem, nbVar)), "cos(x0)");
}

void Test_EquationPrinter::equationToString_exp()
{
    uint nbVar = 1;

    auto expoEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::ExponentialNode());
    datamodel::EquationTreeItem expoTreeItem(expoEquationNode);

    auto argumentEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::VariableNode(0));
    datamodel::EquationTreeItem argumentTreeItem(argumentEquationNode);

    expoTreeItem.setArguments(std::vector<datamodel::EquationTreeItem>{argumentTreeItem});

    QCOMPARE(QString::fromStdString(equationeditors::equationToString(expoTreeItem, nbVar)), "exp(x0)");
}

void Test_EquationPrinter::equationToString_ln()
{
    uint nbVar = 1;
    auto logEquationNode = std::shared_ptr<datamodel::EquationNode>(new datamodel::LogarithmeNode());
    datamodel::EquationTreeItem logTreeItem(logEquationNode);

    auto argumentEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::VariableNode(0));
    datamodel::EquationTreeItem argumentTreeItem(argumentEquationNode);

    logTreeItem.setArguments(std::vector<datamodel::EquationTreeItem>{argumentTreeItem});

    QCOMPARE(QString::fromStdString(equationeditors::equationToString(logTreeItem, nbVar)), "ln(x0)");
}

void Test_EquationPrinter::equationToString_pow()
{
    uint nbVar = 1;

    auto powEquationNode = std::shared_ptr<datamodel::EquationNode>(new datamodel::PowerNode());
    datamodel::EquationTreeItem powTreeItem(powEquationNode);

    auto argumentEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::VariableNode(0));
    datamodel::EquationTreeItem argumentTreeItem(argumentEquationNode);

    auto secondArgumentEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::ConstantNode(3.5));
    datamodel::EquationTreeItem secondArgumentTreeItem(secondArgumentEquationNode);

    powTreeItem.setArguments(
        std::vector<datamodel::EquationTreeItem>{argumentTreeItem, secondArgumentTreeItem});

    QCOMPARE(QString::fromStdString(equationeditors::equationToString(powTreeItem, nbVar)), "x0 ^ 3.5");
}

void Test_EquationPrinter::equationToString_sqrt()
{
    uint nbVar = 1;
    auto sqrtEquationNode = std::shared_ptr<datamodel::EquationNode>(new datamodel::SquareRootNode());
    datamodel::EquationTreeItem sqrtTreeItem(sqrtEquationNode);

    auto argumentEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::VariableNode(0));
    datamodel::EquationTreeItem argumentTreeItem(argumentEquationNode);

    sqrtTreeItem.setArguments(std::vector<datamodel::EquationTreeItem>{argumentTreeItem});

    QCOMPARE(QString::fromStdString(equationeditors::equationToString(sqrtTreeItem, nbVar)), "sqrt(x0)");
}

void Test_EquationPrinter::equationToString_complexeEquation()
{
    uint nbVar = 1;

    auto cosinusEquationNode = std::shared_ptr<datamodel::EquationNode>(new datamodel::CosinusNode());
    datamodel::EquationTreeItem cosinusTreeItem(cosinusEquationNode);

    auto additionEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::AdditionNode());
    datamodel::EquationTreeItem additionTreeItem(additionEquationNode);

    auto firstArgumentEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::VariableNode(0));
    datamodel::EquationTreeItem firstArgumentTreeItem(firstArgumentEquationNode);

    auto secondArgumentEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::ConstantNode(42.42));
    datamodel::EquationTreeItem secondArgumentTreeItem(secondArgumentEquationNode);

    additionTreeItem.setArguments(
        std::vector<datamodel::EquationTreeItem>{firstArgumentTreeItem, secondArgumentTreeItem});

    cosinusTreeItem.setArguments(std::vector<datamodel::EquationTreeItem>{additionTreeItem});

    QCOMPARE(QString::fromStdString(equationeditors::equationToString(cosinusTreeItem, nbVar)), "cos((x0 + 42.42))");
}

QTEST_APPLESS_MAIN(Test_EquationPrinter)

#include "Test_EquationPrinter.moc"
