#include <QTest>

#include "DataModel/AdditionNode.h"
#include "DataModel/ConstantNode.h"
#include "DataModel/CosinusNode.h"
#include "DataModel/MaxNode.h"
#include "DataModel/MultiplicationNode.h"
#include "DataModel/VariableNode.h"
#include "EquationEditors/EquationCrossbreeder.h"
#include "EquationEditors/EquationPrinter.h"
#include "Logger_v2/Logger.h"

class Test_EquationCrossbreeder : public QObject
{
    Q_OBJECT

  public:
      Test_EquationCrossbreeder() = default;

  private slots:
      void randomTreeSubstitutionCrossbreeding();
      void constantDepthRandomNodeCrossbreeding();
      void constantDepthTreeSubstitution();
};

void Test_EquationCrossbreeder::randomTreeSubstitutionCrossbreeding()
{
    // Create the equation ( (4.6 + x))
    uint nbVar = 1;
    datamodel::EquationTreeItem fourDotSixEquation(
        std::shared_ptr<datamodel::EquationNode>(new datamodel::ConstantNode(4.6)));
    datamodel::EquationTreeItem variableEquation(
        std::shared_ptr<datamodel::EquationNode>(new datamodel::VariableNode(0)));

    datamodel::EquationTreeItem firstParentEquation(
        std::shared_ptr<datamodel::EquationNode>(new datamodel::AdditionNode()));
    firstParentEquation.setArguments({fourDotSixEquation, variableEquation});

    // Create the equation ( (1.2 * x))
    datamodel::EquationTreeItem oneDotTwoEquation(
        std::shared_ptr<datamodel::EquationNode>(new datamodel::ConstantNode(1.2)));
    datamodel::EquationTreeItem variableEquation2(
        std::shared_ptr<datamodel::EquationNode>(new datamodel::VariableNode(0)));

    datamodel::EquationTreeItem secondParentEquation(
        std::shared_ptr<datamodel::EquationNode>(new datamodel::MultiplicationNode()));
    secondParentEquation.setArguments({oneDotTwoEquation, variableEquation2});

    // All the possible results are : ( 4.6 + (1.2 * x)), (4.6 + 1.2), (4.6 + x), ((1.2 * x) + x), (1.2 + x), (x + x), (1.2*x), 1.2, x

    QList<datamodel::EquationTreeItem> possibleValues;

    QList<datamodel::EquationTreeItem> nodesOfSecondParent(
        {oneDotTwoEquation, variableEquation2, secondParentEquation});
    for (const datamodel::EquationTreeItem &nodeOfSecondParent : qAsConst(nodesOfSecondParent)) {
        datamodel::EquationTreeItem possibleEquation(firstParentEquation);
        possibleEquation.arguments()[0] = nodeOfSecondParent;
        possibleValues.append(possibleEquation);

        possibleEquation = firstParentEquation;
        possibleEquation.arguments()[1] = nodeOfSecondParent;
        possibleValues.append(possibleEquation);

        possibleEquation = nodeOfSecondParent;
        possibleValues.append(possibleEquation);
    }

    QList<datamodel::EquationTreeItem> actualvalues;

    equationeditors::EquationCrossbreeder equationCrossbreeder;
    equationCrossbreeder.setCrossbreedingMethod(
        equationparameters::EquationCrossbreedingParameters::RandomTreeSubstitution);

    for (int i = 0; i < 100; ++i) {
        datamodel::EquationTreeItem offspring
            = equationCrossbreeder.crossbreeds(firstParentEquation, secondParentEquation);

        if (!actualvalues.contains(offspring)) {
            actualvalues.append(offspring);
        }
    }

    QCOMPARE(actualvalues.size(), possibleValues.size());

    for (const datamodel::EquationTreeItem &actualvalue : actualvalues) {
        QVERIFY2(possibleValues.contains(actualvalue),
                 qUtf8Printable(
                     QStringLiteral("The actual node %1 is not in the list of possible nodes : ")
                         .arg(QString::fromStdString(equationeditors::equationToString(actualvalue, nbVar)))));
    }
}

void Test_EquationCrossbreeder::constantDepthRandomNodeCrossbreeding()
{
    // Create the equation ( (4.6 + x))
    uint nbVar = 1;
    datamodel::EquationTreeItem fourDotSixEquation(
        std::shared_ptr<datamodel::EquationNode>(new datamodel::ConstantNode(4.6)));
    datamodel::EquationTreeItem variableEquation(
        std::shared_ptr<datamodel::EquationNode>(new datamodel::VariableNode(0)));

    datamodel::EquationTreeItem firstParentEquation(
        std::shared_ptr<datamodel::EquationNode>(new datamodel::AdditionNode()));
    firstParentEquation.setArguments({fourDotSixEquation, variableEquation});

    // Create the equation ( (1.2 * x))
    datamodel::EquationTreeItem oneDotTwoEquation(
        std::shared_ptr<datamodel::EquationNode>(new datamodel::ConstantNode(1.2)));
    datamodel::EquationTreeItem variableEquation2(
        std::shared_ptr<datamodel::EquationNode>(new datamodel::VariableNode(0)));

    datamodel::EquationTreeItem secondParentEquation(
        std::shared_ptr<datamodel::EquationNode>(new datamodel::MultiplicationNode()));
    secondParentEquation.setArguments({oneDotTwoEquation, variableEquation2});

    QList<datamodel::EquationTreeItem> possibleValues;

    datamodel::EquationTreeItem possibleEquation;

    // All possibilities for addition
    possibleEquation.setCurrentNode(firstParentEquation.currentNode());
    possibleEquation.setArguments({fourDotSixEquation, variableEquation});
    possibleValues.append(possibleEquation);

    possibleEquation.setArguments({variableEquation, fourDotSixEquation});
    possibleValues.append(possibleEquation);

    possibleEquation.setArguments({oneDotTwoEquation, variableEquation});
    possibleValues.append(possibleEquation);

    possibleEquation.setArguments({variableEquation, oneDotTwoEquation});
    possibleValues.append(possibleEquation);

    possibleEquation.setArguments({variableEquation, variableEquation});
    possibleValues.append(possibleEquation);

    possibleEquation.setArguments({oneDotTwoEquation, fourDotSixEquation});
    possibleValues.append(possibleEquation);

    possibleEquation.setArguments({fourDotSixEquation, oneDotTwoEquation});
    possibleValues.append(possibleEquation);

    possibleEquation.setArguments({oneDotTwoEquation, oneDotTwoEquation});
    possibleValues.append(possibleEquation);

    possibleEquation.setArguments({fourDotSixEquation, fourDotSixEquation});
    possibleValues.append(possibleEquation);

    // All possibilities for multiplications
    possibleEquation.setCurrentNode(secondParentEquation.currentNode());

    possibleEquation.setArguments({fourDotSixEquation, variableEquation});
    possibleValues.append(possibleEquation);

    possibleEquation.setArguments({variableEquation, fourDotSixEquation});
    possibleValues.append(possibleEquation);

    possibleEquation.setArguments({oneDotTwoEquation, variableEquation});
    possibleValues.append(possibleEquation);

    possibleEquation.setArguments({variableEquation, oneDotTwoEquation});
    possibleValues.append(possibleEquation);

    possibleEquation.setArguments({variableEquation, variableEquation});
    possibleValues.append(possibleEquation);

    possibleEquation.setArguments({oneDotTwoEquation, fourDotSixEquation});
    possibleValues.append(possibleEquation);

    possibleEquation.setArguments({fourDotSixEquation, oneDotTwoEquation});
    possibleValues.append(possibleEquation);

    possibleEquation.setArguments({oneDotTwoEquation, oneDotTwoEquation});
    possibleValues.append(possibleEquation);

    possibleEquation.setArguments({fourDotSixEquation, fourDotSixEquation});
    possibleValues.append(possibleEquation);

    QList<datamodel::EquationTreeItem> actualvalues;

    equationeditors::EquationCrossbreeder equationCrossbreeder;
    equationCrossbreeder.setCrossbreedingMethod(
        equationparameters::EquationCrossbreedingParameters::ConstantDepthNodeSubstitution);

    for (int i = 0; i < 1000; ++i) {
        datamodel::EquationTreeItem offspring
            = equationCrossbreeder.crossbreeds(firstParentEquation, secondParentEquation);
        if (!actualvalues.contains(offspring)) {
            actualvalues.append(offspring);
        }
    }

    QCOMPARE(actualvalues.size(), possibleValues.size());

    for (const datamodel::EquationTreeItem &actualvalue : actualvalues) {
        QVERIFY2(possibleValues.contains(actualvalue),
                 qUtf8Printable(
                     QStringLiteral("The actual node %1 is not in the list of possible nodes : ")
                         .arg(QString::fromStdString(equationeditors::equationToString(actualvalue, nbVar)))));
    }
}

void Test_EquationCrossbreeder::constantDepthTreeSubstitution()
{
    // Create the equation ( (1.2 * 2.3) + (4.6 * x))
    uint nbVar = 1;
    datamodel::EquationTreeItem oneDotTwoEquation(
        std::shared_ptr<datamodel::EquationNode>(new datamodel::ConstantNode(1.2)));
    datamodel::EquationTreeItem twoDotThreeEquation(
        std::shared_ptr<datamodel::EquationNode>(new datamodel::ConstantNode(2.3)));
    datamodel::EquationTreeItem fourDotSixEquation(
        std::shared_ptr<datamodel::EquationNode>(new datamodel::ConstantNode(4.6)));
    datamodel::EquationTreeItem variableEquation(
        std::shared_ptr<datamodel::EquationNode>(new datamodel::VariableNode(0)));

    datamodel::EquationTreeItem firstArgumentFirstParent(
        std::shared_ptr<datamodel::EquationNode>(new datamodel::MultiplicationNode()));
    firstArgumentFirstParent.setArguments({oneDotTwoEquation, twoDotThreeEquation});

    datamodel::EquationTreeItem secondArgumentFirstParent(
        std::shared_ptr<datamodel::EquationNode>(new datamodel::MultiplicationNode()));
    secondArgumentFirstParent.setArguments({fourDotSixEquation, variableEquation});

    datamodel::EquationTreeItem firstParentEquation(
        std::shared_ptr<datamodel::EquationNode>(new datamodel::AdditionNode()));
    firstParentEquation.setArguments({firstArgumentFirstParent, secondArgumentFirstParent});

    // Create the equation ( cos(x) + max(11.6,x))
    datamodel::EquationTreeItem elevenDotSixEquation(
        std::shared_ptr<datamodel::EquationNode>(new datamodel::ConstantNode(11.6)));

    datamodel::EquationTreeItem firstArgumentSecondParent(
        std::shared_ptr<datamodel::EquationNode>(new datamodel::CosinusNode()));
    firstArgumentSecondParent.setArguments({variableEquation});

    datamodel::EquationTreeItem secondArgumentSecondParent(
        std::shared_ptr<datamodel::EquationNode>(new datamodel::MaxNode()));
    secondArgumentSecondParent.setArguments({elevenDotSixEquation, variableEquation});

    datamodel::EquationTreeItem secondParentEquation(
        std::shared_ptr<datamodel::EquationNode>(new datamodel::AdditionNode()));
    secondParentEquation.setArguments({firstArgumentSecondParent, secondArgumentSecondParent});

    QList<datamodel::EquationTreeItem> possibleValues;

    possibleValues.append(firstParentEquation);
    possibleValues.append(secondParentEquation);

    datamodel::EquationTreeItem possibleEquation(firstParentEquation);
    possibleEquation.arguments()[0] = secondParentEquation.arguments().at(0);
    possibleValues.append(possibleEquation);

    possibleEquation.arguments()[0] = secondParentEquation.arguments().at(1);
    possibleValues.append(possibleEquation);

    possibleEquation = firstParentEquation;
    possibleEquation.arguments()[1] = secondParentEquation.arguments().at(0);
    possibleValues.append(possibleEquation);

    possibleEquation.arguments()[1] = secondParentEquation.arguments().at(1);
    possibleValues.append(possibleEquation);

    for (uint i = 0; i < firstParentEquation.arguments().size(); ++i) {
        for (uint j = 0; j < firstParentEquation.arguments().at(i).arguments().size(); ++j) {
            possibleEquation = firstParentEquation;
            possibleEquation.arguments()[i].arguments()[j]
                = secondParentEquation.arguments().at(0).arguments().at(0);
            if (!possibleValues.contains(possibleEquation)) {
                possibleValues.append(possibleEquation);
            }

            possibleEquation = firstParentEquation;
            possibleEquation.arguments()[i].arguments()[j]
                = secondParentEquation.arguments().at(1).arguments().at(0);
            if (!possibleValues.contains(possibleEquation)) {
                possibleValues.append(possibleEquation);
            }

            possibleEquation = firstParentEquation;
            possibleEquation.arguments()[i].arguments()[j]
                = secondParentEquation.arguments().at(1).arguments().at(1);
            if (!possibleValues.contains(possibleEquation)) {
                possibleValues.append(possibleEquation);
            }
        }
    }

    QList<datamodel::EquationTreeItem> actualvalues;

    equationeditors::EquationCrossbreeder equationCrossbreeder;
    equationCrossbreeder.setCrossbreedingMethod(
        equationparameters::EquationCrossbreedingParameters::ConstantDepthTreeSubstitution);

    for (int i = 0; i < 1000; ++i) {
        datamodel::EquationTreeItem offspring
            = equationCrossbreeder.crossbreeds(firstParentEquation, secondParentEquation);
        if (!actualvalues.contains(offspring)) {
            actualvalues.append(offspring);
        }
    }

    for (const datamodel::EquationTreeItem &possibleValue : possibleValues) {
        if (!actualvalues.contains(possibleValue)) {
            //qDebug() << "Possible value : "
            //         << QString::fromStdString(equationeditors::equationToString(possibleValue, nbVar));
            std::string message_debug_possible_value = "Possible value : "
                    + equationeditors::equationToString(possibleValue, nbVar);
            logs::Logger::logDebug(message_debug_possible_value, {logs::LogTags::tests});
        }
    }

    QCOMPARE(actualvalues.size(), possibleValues.size());

    for (const datamodel::EquationTreeItem &actualvalue : actualvalues) {
        QVERIFY2(possibleValues.contains(actualvalue),
                 qUtf8Printable(
                     QStringLiteral("The actual node %1 is not in the list of possible nodes : ")
                         .arg(QString::fromStdString(equationeditors::equationToString(actualvalue, nbVar)))));
    }
}

QTEST_APPLESS_MAIN(Test_EquationCrossbreeder)

#include "Test_EquationCrossbreeder.moc"
