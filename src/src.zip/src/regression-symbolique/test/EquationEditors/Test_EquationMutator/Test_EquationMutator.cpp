#include <QTest>

#include "DataModel/AdditionNode.h"
#include "DataModel/SoustractionNode.h"
#include "DataModel/ConstantNode.h"
#include "DataModel/CosinusNode.h"
#include "DataModel/SinusNode.h"
#include "DataModel/MultiplicationNode.h"
#include "DataModel/VariableNode.h"
#include "DataModel/MinNode.h"
#include "DataModel/MaxNode.h"

#include "EquationEditors/EquationMutator.h"

class Test_EquationMutator : public QObject
{
    Q_OBJECT

  public:
      Test_EquationMutator() = default;

  private slots:
      void initTestCase();
      void mutateCommutativeNode();
      void mutateNonCommutativeNode();
      void mutateMinMaxNode();
      void mutateFunctionNode();
      void mutateTerminalNode();
  private:
    equationeditors::EquationMutator _equationMutator;
};

void Test_EquationMutator::initTestCase(){
    //Create equationMutator
    equationparameters::EquationGenerationParameters equationGenerationParameters;
    QSet<datamodel::EquationNode::NodeType> nodeTypes{
        datamodel::EquationNode::Constant,
        datamodel::EquationNode::Variable,
        datamodel::EquationNode::Addition,
        datamodel::EquationNode::Soustraction,
        datamodel::EquationNode::Multiplication,
        datamodel::EquationNode::Division,
        datamodel::EquationNode::Cosinus,
        datamodel::EquationNode::Sinus,
        datamodel::EquationNode::Logarithm,
        datamodel::EquationNode::Exponential,
        datamodel::EquationNode::Power,
        datamodel::EquationNode::SquareRoot,
        datamodel::EquationNode::Inverse,
        datamodel::EquationNode::Arctan,
        datamodel::EquationNode::Negative,
        datamodel::EquationNode::Min,
        datamodel::EquationNode::Max,
        datamodel::EquationNode::Absolute,
        datamodel::EquationNode::Tan
    };
    equationGenerationParameters.setSelectedNodesTypes(nodeTypes);
    _equationMutator.setEquationGenerationParameters(equationGenerationParameters);
}

void Test_EquationMutator::mutateCommutativeNode()
{
    //Create values needed by the future equations to test
    datamodel::EquationTreeItem constant1(std::shared_ptr<datamodel::EquationNode>(new datamodel::ConstantNode(1)));
    datamodel::EquationTreeItem constant2(std::shared_ptr<datamodel::EquationNode>(new datamodel::ConstantNode(2)));
    datamodel::EquationTreeItem variableNode(std::shared_ptr<datamodel::EquationNode>(new datamodel::VariableNode(0)));
    auto additionNode2Arg = std::shared_ptr<datamodel::EquationNode>(new datamodel::AdditionNode());
    auto additionNode3Arg = std::shared_ptr<datamodel::EquationNode>(new datamodel::AdditionNode(3));
    auto multiplicationNode2Arg = std::shared_ptr<datamodel::EquationNode>(new datamodel::MultiplicationNode());
    auto multiplicationNode3Arg = std::shared_ptr<datamodel::EquationNode>(new datamodel::MultiplicationNode(3));

    //===============
    // Case of addition with exactly two nodes
    //===============
    // Create the equation (1 + 2)
    datamodel::EquationTreeItem additionTree(additionNode2Arg);
    additionTree.setArguments(std::vector<datamodel::EquationTreeItem>{constant1, constant2});

    datamodel::EquationTreeItem equationToMutate = additionTree;
    unsigned int numberOfValidMutation = 0;
    //100 mutations should be sufficient to ensure everything is ok
    for (int i = 0; i < 100; ++i) {
        _equationMutator.mutateSingle(equationToMutate);

        //Case addition of a node after current one
        if(equationToMutate.arguments().size() == additionTree.arguments().size() + 1 &&
                equationToMutate.currentNode()->nbArguments() == equationToMutate.arguments().size() &&
                equationToMutate.arguments().back().currentNode()->category() == datamodel::EquationNode::NodeCategory::Terminal){
            numberOfValidMutation++;
        }
        //Case deletion of a node after current one
        else if(equationToMutate.currentNode() == additionTree.arguments().front().currentNode() ||
                equationToMutate.currentNode() == additionTree.arguments().back().currentNode()){
            numberOfValidMutation++;
        }
        //Case replacement of the current node
        else if(equationToMutate.arguments() == additionTree.arguments() &&
                equationToMutate.currentNode()->nbArguments() == additionTree.currentNode()->nbArguments() &&
                equationToMutate.currentNode()->category() == datamodel::EquationNode::NodeCategory::NonCommutative) {
            numberOfValidMutation++;
        //Case addition of a node before current one
        } else if(equationToMutate.currentNode()->category() != datamodel::EquationNode::NodeCategory::Terminal &&
                  equationToMutate.arguments().front() == additionTree){
            numberOfValidMutation++;
        //Case deletion of a node before current one
        } else if(equationToMutate == additionTree){
            numberOfValidMutation++;
        } else {
            //Invalid mutation
        }
        equationToMutate = additionTree;
    }
    QCOMPARE(numberOfValidMutation, 100);

    //===============
    // Case of addition with three nodes or more
    //===============
    // Create the equation (1 + 2 + x)
    additionTree.setCurrentNode(additionNode3Arg);
    additionTree.setArguments(std::vector<datamodel::EquationTreeItem>{constant1, constant2, variableNode});

    equationToMutate = additionTree;
    numberOfValidMutation = 0;
    //100 mutations should be sufficient to ensure everything is ok
    for (int i = 0; i < 100; ++i) {
        _equationMutator.mutateSingle(equationToMutate);

        //Case addition of a node after current one
        if(equationToMutate.arguments().size() == additionTree.arguments().size() + 1 &&
            equationToMutate.currentNode()->nbArguments() == equationToMutate.arguments().size() &&
            equationToMutate.arguments().back().currentNode()->category() == datamodel::EquationNode::NodeCategory::Terminal){
            numberOfValidMutation++;
        }
        //Case deletion of a node after current one
        else if (equationToMutate.arguments().size() == additionTree.arguments().size() - 1 &&
                 equationToMutate.currentNode()->type() == additionTree.currentNode()->type() &&
                 equationToMutate.currentNode()->nbArguments() == equationToMutate.arguments().size()){
            numberOfValidMutation++;
        //Case replacement of the current node
        } else if(equationToMutate.arguments() == additionTree.arguments() &&
                  equationToMutate.currentNode()->nbArguments() == additionTree.currentNode()->nbArguments() &&
                  equationToMutate.currentNode()->type() == datamodel::EquationNode::Multiplication) {
            numberOfValidMutation++;
        //Case addition of a node before current one
        } else if(equationToMutate.currentNode()->category() != datamodel::EquationNode::NodeCategory::Terminal &&
                  equationToMutate.arguments().front() == additionTree){
            numberOfValidMutation++;
        //Case deletion of a node before current one
        } else if(equationToMutate == additionTree){
            numberOfValidMutation++;
        } else {
            //Invalid mutation
        }
        equationToMutate = additionTree;
    }
    QCOMPARE(numberOfValidMutation, 100);

    //===============
    // Case of multiplication with exactly two nodes
    //===============
    // Create the equation (1 * 2)
    datamodel::EquationTreeItem multiplicationTree(multiplicationNode2Arg);
    multiplicationTree.setArguments(std::vector<datamodel::EquationTreeItem>{constant1, constant2});

    equationToMutate = multiplicationTree;
    numberOfValidMutation = 0;
    //100 mutations should be sufficient to ensure everything is ok
    for (int i = 0; i < 100; ++i) {
        _equationMutator.mutateSingle(equationToMutate);

        //Case addition of a node after current one
        if(equationToMutate.arguments().size() == multiplicationTree.arguments().size() + 1 &&
                equationToMutate.currentNode()->nbArguments() == equationToMutate.arguments().size() &&
                equationToMutate.arguments().back().currentNode()->category() == datamodel::EquationNode::NodeCategory::Terminal){
            numberOfValidMutation++;
        }
        //Case deletion of a node after current one
        else if(equationToMutate.currentNode() == multiplicationTree.arguments().front().currentNode() ||
                equationToMutate.currentNode() == multiplicationTree.arguments().back().currentNode()){
            numberOfValidMutation++;
        }
        //Case replacement of the current node
        else if(equationToMutate.arguments() == multiplicationTree.arguments() &&
                equationToMutate.currentNode()->nbArguments() == multiplicationTree.currentNode()->nbArguments() &&
                equationToMutate.currentNode()->category() == datamodel::EquationNode::NodeCategory::NonCommutative) {
            numberOfValidMutation++;
        //Case addition of a node before current one
        } else if(equationToMutate.currentNode()->category() != datamodel::EquationNode::NodeCategory::Terminal &&
                  equationToMutate.arguments().front() == multiplicationTree){
            numberOfValidMutation++;
        //Case deletion of a node before current one
        } else if(equationToMutate == multiplicationTree){
            numberOfValidMutation++;
        } else {
            //Invalid mutation
        }
        equationToMutate = multiplicationTree;
    }
    QCOMPARE(numberOfValidMutation, 100);

    //===============
    // Case of multiplication with three nodes or more
    //===============
    // Create the equation (1 * 2 * x)
    multiplicationTree.setCurrentNode(multiplicationNode3Arg);
    multiplicationTree.setArguments(std::vector<datamodel::EquationTreeItem>{constant1, constant2, variableNode});

    equationToMutate = multiplicationTree;
    numberOfValidMutation = 0;
    //100 mutations should be sufficient to ensure everything is ok
    for (int i = 0; i < 100; ++i) {
        _equationMutator.mutateSingle(equationToMutate);

        //Case addition of a node after current one
        if(equationToMutate.arguments().size() == multiplicationTree.arguments().size() + 1 &&
            equationToMutate.currentNode()->nbArguments() == equationToMutate.arguments().size() &&
            equationToMutate.arguments().back().currentNode()->category() == datamodel::EquationNode::NodeCategory::Terminal){
            numberOfValidMutation++;
        }
        //Case deletion of a node after current one
        else if (equationToMutate.arguments().size() == multiplicationTree.arguments().size() - 1 &&
                 equationToMutate.currentNode()->type() == multiplicationTree.currentNode()->type() &&
                 equationToMutate.currentNode()->nbArguments() == equationToMutate.arguments().size()){
            numberOfValidMutation++;
        //Case replacement of the current node
        } else if(equationToMutate.arguments() == multiplicationTree.arguments() &&
                  equationToMutate.currentNode()->nbArguments() == multiplicationTree.currentNode()->nbArguments() &&
                  equationToMutate.currentNode()->type() == datamodel::EquationNode::Addition) {
            numberOfValidMutation++;
        //Case addition of a node before current one
        } else if(equationToMutate.currentNode()->category() != datamodel::EquationNode::NodeCategory::Terminal &&
                  equationToMutate.arguments().front() == multiplicationTree){
            numberOfValidMutation++;
        //Case deletion of a node before current one
        } else if(equationToMutate == multiplicationTree){
            numberOfValidMutation++;
        } else {
            //Invalid mutation
        }
        equationToMutate = multiplicationTree;
    }
    QCOMPARE(numberOfValidMutation, 100);
}

void Test_EquationMutator::mutateNonCommutativeNode()
{
    //Create values needed by the future equations to test
    datamodel::EquationTreeItem constant1(std::shared_ptr<datamodel::EquationNode>(new datamodel::ConstantNode(1)));
    datamodel::EquationTreeItem variableNode(std::shared_ptr<datamodel::EquationNode>(new datamodel::VariableNode(0)));
    auto soustractionNode = std::shared_ptr<datamodel::EquationNode>(new datamodel::SoustractionNode());

    // Create the equation (X - 1)
    datamodel::EquationTreeItem soustractionTree(soustractionNode);
    soustractionTree.setArguments(std::vector<datamodel::EquationTreeItem>{variableNode, constant1});

    datamodel::EquationTreeItem equationToMutate = soustractionTree;
    unsigned int numberOfValidMutation = 0;
    //100 mutations should be sufficient to ensure everything is ok
    for (int i = 0; i < 100; ++i) {
        _equationMutator.mutateSingle(equationToMutate);

        //Case deletion of a node after current one
        if(equationToMutate.currentNode() == soustractionTree.arguments().front().currentNode() ||
                equationToMutate.currentNode() == soustractionTree.arguments().back().currentNode()){
            numberOfValidMutation++;
        }
        //Case replacement of the current node
        else if(equationToMutate.arguments() == soustractionTree.arguments() &&
                equationToMutate.currentNode()->nbArguments() == soustractionTree.currentNode()->nbArguments() &&
                equationToMutate.currentNode()->type() != soustractionTree.currentNode()->type() &&
                (equationToMutate.currentNode()->category() == datamodel::EquationNode::NodeCategory::NonCommutative ||
                 equationToMutate.currentNode()->category() == datamodel::EquationNode::NodeCategory::Commutative ||
                 equationToMutate.currentNode()->category() == datamodel::EquationNode::NodeCategory::MinMax)) {
            numberOfValidMutation++;
        //Case addition of a node before current one
        } else if(equationToMutate.currentNode()->category() != datamodel::EquationNode::NodeCategory::Terminal &&
                  equationToMutate.arguments().front() == soustractionTree){
            numberOfValidMutation++;
        //Case deletion of a node before current one
        } else if(equationToMutate == soustractionTree){
            numberOfValidMutation++;
        } else {
            //Invalid mutation
        }
        equationToMutate = soustractionTree;
    }
    QCOMPARE(numberOfValidMutation, 100);
}

void Test_EquationMutator::mutateMinMaxNode()
{
    //Create values needed by the future equations to test
    datamodel::EquationTreeItem constant1(std::shared_ptr<datamodel::EquationNode>(new datamodel::ConstantNode(1)));
    datamodel::EquationTreeItem variableNode(std::shared_ptr<datamodel::EquationNode>(new datamodel::VariableNode(0)));
    auto minNode = std::shared_ptr<datamodel::EquationNode>(new datamodel::MinNode());
    auto maxNode = std::shared_ptr<datamodel::EquationNode>(new datamodel::MaxNode());

    //===============
    // Case of min
    //===============
    // Create the equation min(X,1)
    datamodel::EquationTreeItem minTree(minNode);
    minTree.setArguments(std::vector<datamodel::EquationTreeItem>{variableNode, constant1});

    datamodel::EquationTreeItem equationToMutate = minTree;
    unsigned int numberOfValidMutation = 0;
    //100 mutations should be sufficient to ensure everything is ok
    for (int i = 0; i < 100; ++i) {
        _equationMutator.mutateSingle(equationToMutate);

        //Case deletion of a node after current one
        if(equationToMutate.currentNode() == minTree.arguments().front().currentNode() ||
                equationToMutate.currentNode() == minTree.arguments().back().currentNode()){
            numberOfValidMutation++;
        }
        //Case replacement of the current node
        else if(equationToMutate.arguments() == minTree.arguments() &&
                equationToMutate.currentNode()->nbArguments() == minTree.currentNode()->nbArguments() &&
                equationToMutate.currentNode()->type() != minTree.currentNode()->type() &&
                (equationToMutate.currentNode()->category() == datamodel::EquationNode::NodeCategory::NonCommutative ||
                 equationToMutate.currentNode()->category() == datamodel::EquationNode::NodeCategory::Commutative ||
                 equationToMutate.currentNode()->category() == datamodel::EquationNode::NodeCategory::MinMax)) {
            numberOfValidMutation++;
        //Case addition of a node before current one
        } else if(equationToMutate.currentNode()->category() != datamodel::EquationNode::NodeCategory::Terminal &&
                  equationToMutate.arguments().front() == minTree){
            numberOfValidMutation++;
        //Case deletion of a node before current one
        } else if(equationToMutate == minTree){
            numberOfValidMutation++;
        } else {
            //Invalid mutation
        }
        equationToMutate = minTree;
    }
    QCOMPARE(numberOfValidMutation, 100);

    //===============
    // Case of max
    //===============
    // Create the equation max(X,1)
    datamodel::EquationTreeItem maxTree(maxNode);
    maxTree.setArguments(std::vector<datamodel::EquationTreeItem>{variableNode, constant1});

    equationToMutate = maxTree;
    numberOfValidMutation = 0;
    //100 mutations should be sufficient to ensure everything is ok
    for (int i = 0; i < 100; ++i) {
        _equationMutator.mutateSingle(equationToMutate);

        //Case deletion of a node after current one
        if(equationToMutate.currentNode() == maxTree.arguments().front().currentNode() ||
                equationToMutate.currentNode() == maxTree.arguments().back().currentNode()){
            numberOfValidMutation++;
        }
        //Case replacement of the current node
        else if(equationToMutate.arguments() == maxTree.arguments() &&
                equationToMutate.currentNode()->nbArguments() == maxTree.currentNode()->nbArguments() &&
                equationToMutate.currentNode()->type() != maxTree.currentNode()->type() &&
                (equationToMutate.currentNode()->category() == datamodel::EquationNode::NodeCategory::NonCommutative ||
                 equationToMutate.currentNode()->category() == datamodel::EquationNode::NodeCategory::Commutative ||
                 equationToMutate.currentNode()->category() == datamodel::EquationNode::NodeCategory::MinMax)) {
            numberOfValidMutation++;
        //Case addition of a node before current one
        } else if(equationToMutate.currentNode()->category() != datamodel::EquationNode::NodeCategory::Terminal &&
                  equationToMutate.arguments().front() == maxTree){
            numberOfValidMutation++;
        //Case deletion of a node before current one
        } else if(equationToMutate == maxTree){
            numberOfValidMutation++;
        } else {
            //Invalid mutation
        }
        equationToMutate = maxTree;
    }
    QCOMPARE(numberOfValidMutation, 100);
}

void Test_EquationMutator::mutateFunctionNode()
{
    //Create values needed by the future equations to test
    datamodel::EquationTreeItem variableNode(std::shared_ptr<datamodel::EquationNode>(new datamodel::VariableNode(0)));
    auto cosinusNode = std::shared_ptr<datamodel::EquationNode>(new datamodel::CosinusNode());
    auto sinusNode = std::shared_ptr<datamodel::EquationNode>(new datamodel::SinusNode());

    //===============
    // Case of function with a single node
    //===============
    // Create the equation cos(X)
    datamodel::EquationTreeItem cosinusTree(cosinusNode);
    cosinusTree.setArguments(std::vector<datamodel::EquationTreeItem>{variableNode});

    datamodel::EquationTreeItem equationToMutate = cosinusTree;
    unsigned int numberOfValidMutation = 0;
    //100 mutations should be sufficient to ensure everything is ok
    for (int i = 0; i < 100; ++i) {
        _equationMutator.mutateSingle(equationToMutate);

        //Case addition of a node after current one
        //TODO: equationToMutate.currentNode() == cosinusTree.currentNode() should work but the shared_pointer change randomly thus invaliding the operator ==
        //      so we do the check manually with
        //      equationToMutate.currentNode()->type() == cosinusTree.currentNode()->type() &&
        //      equationToMutate.currentNode()->nbArguments() == cosinusTree.currentNode()->nbArguments() &&
        //      equationToMutate.currentNode()->toString() == cosinusTree.currentNode()->toString()
        if(equationToMutate.currentNode()->type() == cosinusTree.currentNode()->type() &&
                equationToMutate.currentNode()->nbArguments() == cosinusTree.currentNode()->nbArguments() &&
                equationToMutate.currentNode()->toString() == cosinusTree.currentNode()->toString() &&
                equationToMutate.arguments().size() == cosinusTree.arguments().size() &&
                equationToMutate.arguments().front().currentNode()->category() == datamodel::EquationNode::NodeCategory::Function &&
                equationToMutate.arguments().front().arguments().front() == cosinusTree.arguments().front()){
            numberOfValidMutation++;
        }
        //Case deletion of a node after current one
        else if(equationToMutate == cosinusTree){
            numberOfValidMutation++;
        }
        //Case replacement of the current node
        else if(equationToMutate.arguments() == cosinusTree.arguments() &&
                equationToMutate.currentNode()->nbArguments() == cosinusTree.currentNode()->nbArguments() &&
                equationToMutate.currentNode()->type() != cosinusTree.currentNode()->type() &&
                equationToMutate.currentNode()->category() == datamodel::EquationNode::NodeCategory::Function){
            numberOfValidMutation++;
        //Case addition of a node before current one
        } else if(equationToMutate.currentNode()->category() != datamodel::EquationNode::NodeCategory::Terminal &&
                  equationToMutate.arguments().front() == cosinusTree){
            numberOfValidMutation++;
        //Case deletion of a node before current one
        } else if(equationToMutate == cosinusTree){
            numberOfValidMutation++;
        } else {
            //Invalid mutation
        }
        equationToMutate = cosinusTree;
    }
    QCOMPARE(numberOfValidMutation, 100);

    //===============
    // Case of function with a multiple nodes
    //===============
    // Create the equation cos(sin(X))
    datamodel::EquationTreeItem sinusTree(sinusNode);
    sinusTree.setArguments(std::vector<datamodel::EquationTreeItem>{variableNode});
    cosinusTree.setArguments(std::vector<datamodel::EquationTreeItem>{sinusTree});

    equationToMutate = cosinusTree;
    numberOfValidMutation = 0;
    //100 mutations should be sufficient to ensure everything is ok
    for (int i = 0; i < 100; ++i) {
        _equationMutator.mutateSingle(equationToMutate);

        //Case addition of a node after current one
        //TODO: equationToMutate.currentNode() == cosinusTree.currentNode() should work but the shared_pointer change randomly thus invaliding the operator ==
        //      so we do the check manually with
        //      equationToMutate.currentNode()->type() == cosinusTree.currentNode()->type() &&
        //      equationToMutate.currentNode()->nbArguments() == cosinusTree.currentNode()->nbArguments() &&
        //      equationToMutate.currentNode()->toString() == cosinusTree.currentNode()->toString()
        if(equationToMutate.currentNode()->type() == cosinusTree.currentNode()->type() &&
                equationToMutate.currentNode()->nbArguments() == cosinusTree.currentNode()->nbArguments() &&
                equationToMutate.currentNode()->toString() == cosinusTree.currentNode()->toString() &&
                equationToMutate.arguments().size() == equationToMutate.arguments().size() &&
                equationToMutate.arguments().front().currentNode()->category() == datamodel::EquationNode::NodeCategory::Function &&
                equationToMutate.arguments().front().arguments().front() == cosinusTree.arguments().front()){
            numberOfValidMutation++;
        }
        //Case deletion of a node after current one
        //TODO: Same as precedent TODO
        else if(equationToMutate.currentNode()->type() == cosinusTree.currentNode()->type() &&
                equationToMutate.currentNode()->nbArguments() == cosinusTree.currentNode()->nbArguments() &&
                equationToMutate.currentNode()->toString() == cosinusTree.currentNode()->toString() &&
                equationToMutate.arguments().size() == equationToMutate.arguments().size() &&
                equationToMutate.arguments().front() == cosinusTree.arguments().front().arguments().front()){
            numberOfValidMutation++;
        }
        //Case replacement of the current node
        else if(equationToMutate.arguments() == cosinusTree.arguments() &&
                equationToMutate.currentNode()->nbArguments() == cosinusTree.currentNode()->nbArguments() &&
                equationToMutate.currentNode()->type() != cosinusTree.currentNode()->type() &&
                equationToMutate.currentNode()->category() == datamodel::EquationNode::NodeCategory::Function){
            numberOfValidMutation++;
        //Case addition of a node before current one
        } else if(equationToMutate.currentNode()->category() != datamodel::EquationNode::NodeCategory::Terminal &&
                  equationToMutate.arguments().front() == cosinusTree){
            numberOfValidMutation++;
        //Case deletion of a node before current one
        } else if(equationToMutate == cosinusTree){
            numberOfValidMutation++;
        } else {
            //Invalid mutation
        }
        equationToMutate = cosinusTree;
    }
    QCOMPARE(numberOfValidMutation, 100);
}

void Test_EquationMutator::mutateTerminalNode()
{
    //Create values needed by the future equations to test
    datamodel::EquationTreeItem variableNode(std::shared_ptr<datamodel::EquationNode>(new datamodel::VariableNode(0)));
    datamodel::EquationTreeItem constantNode(std::shared_ptr<datamodel::EquationNode>(new datamodel::ConstantNode(0)));
    auto cosinusNode = std::shared_ptr<datamodel::EquationNode>(new datamodel::CosinusNode());
    datamodel::EquationTreeItem cosinusTree(cosinusNode);

    //===============
    // Case of simple variable X (No parent)
    //===============
    datamodel::EquationTreeItem equationToMutate = variableNode;
    unsigned int numberOfValidMutation = 0;
    //100 mutations should be sufficient to ensure everything is ok
    for (int i = 0; i < 100; ++i) {
        _equationMutator.mutateEquations(equationToMutate, 1);

        //Case addition of a node before current one
        if(equationToMutate.currentNode()->category() != datamodel::EquationNode::NodeCategory::Terminal &&
                equationToMutate.arguments().front() == variableNode &&
                equationToMutate.arguments().back().currentNode()->category() == datamodel::EquationNode::NodeCategory::Terminal){
            numberOfValidMutation++;
        }
        //Case deletion of a node before current one
        else if(equationToMutate == variableNode){
            numberOfValidMutation++;
        }
        //Case replacement of the current node
        else if(equationToMutate.currentNode()->type() == datamodel::EquationNode::Constant){
            numberOfValidMutation++;
        } else {
            //Invalid mutation
        }
        equationToMutate = variableNode;
    }
    QCOMPARE(numberOfValidMutation, 100);

    //===============
    // Case of simple constant 0 (No parent)
    //===============
    equationToMutate = constantNode;
    numberOfValidMutation = 0;
    //100 mutations should be sufficient to ensure everything is ok
    for (int i = 0; i < 100; ++i) {
        _equationMutator.mutateEquations(equationToMutate, 1);

        //Case addition of a node before current one
        if(equationToMutate.currentNode()->category() != datamodel::EquationNode::NodeCategory::Terminal &&
                equationToMutate.arguments().front() == constantNode &&
                equationToMutate.arguments().back().currentNode()->category() == datamodel::EquationNode::NodeCategory::Terminal){
            numberOfValidMutation++;
        }
        //Case deletion of a node before current one
        else if(equationToMutate == constantNode){
            numberOfValidMutation++;
        }
        //Case replacement of the current node
        else if(equationToMutate.currentNode()->type() == datamodel::EquationNode::Variable){
            numberOfValidMutation++;
        } else {
            //Invalid mutation
        }
        equationToMutate = constantNode;
    }
    QCOMPARE(numberOfValidMutation, 100);
}


QTEST_APPLESS_MAIN(Test_EquationMutator)

#include "Test_EquationMutator.moc"
