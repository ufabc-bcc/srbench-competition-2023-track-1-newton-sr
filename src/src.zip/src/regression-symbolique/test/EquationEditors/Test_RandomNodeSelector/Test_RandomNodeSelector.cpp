#include <QTest>

#include "DataModel/AdditionNode.h"
#include "DataModel/ConstantNode.h"
#include "DataModel/MultiplicationNode.h"
#include "DataModel/VariableNode.h"
#include "EquationEditors/EquationPrinter.h"
#include "EquationEditors/randomNodeSelector.h"
#include "Logger_v2/Logger.h"

class Test_RandomNodeSelector : public QObject
{
    Q_OBJECT

  public:
      Test_RandomNodeSelector() = default;

  private slots:
      void selectRandomArgument_emptyEquation();
      void selectRandomArgument_multipleNodes();
      void selectRandomNode_emptyEquation();
      void selectRandomNode_multipleNodes();
};

void Test_RandomNodeSelector::selectRandomArgument_emptyEquation()
{
    datamodel::EquationTreeItem equation;

    datamodel::EquationTreeItem selectedArgument = equationeditors::selectRandomArgument(equation);

    QVERIFY(selectedArgument.isEmpty());
}

void Test_RandomNodeSelector::selectRandomArgument_multipleNodes()
{
    // Create the equation ( (1.2 * 2.3) + (4.6 * x))
    datamodel::EquationTreeItem oneDotTwoEquation(
        std::shared_ptr<datamodel::EquationNode>(new datamodel::ConstantNode(1.2)));
    datamodel::EquationTreeItem twoDotThreeEquation(
        std::shared_ptr<datamodel::EquationNode>(new datamodel::ConstantNode(2.3)));
    datamodel::EquationTreeItem fourDotSixEquation(
        std::shared_ptr<datamodel::EquationNode>(new datamodel::ConstantNode(4.6)));
    datamodel::EquationTreeItem variableEquation(
        std::shared_ptr<datamodel::EquationNode>(new datamodel::VariableNode(0)));

    datamodel::EquationTreeItem firstArgument(
        std::shared_ptr<datamodel::EquationNode>(new datamodel::MultiplicationNode()));
    firstArgument.setArguments({oneDotTwoEquation, twoDotThreeEquation});

    datamodel::EquationTreeItem secondArgument(
        std::shared_ptr<datamodel::EquationNode>(new datamodel::MultiplicationNode()));
    secondArgument.setArguments({fourDotSixEquation, variableEquation});

    datamodel::EquationTreeItem finalEquation(
        std::shared_ptr<datamodel::EquationNode>(new datamodel::AdditionNode()));
    finalEquation.setArguments({firstArgument, secondArgument});

    QList<datamodel::EquationTreeItem> possiblesNodes = QList<datamodel::EquationTreeItem>(
        {firstArgument, secondArgument});

    // Test non const version
    QList<datamodel::EquationTreeItem> actualNodes;

    // Copy yo check that the function do not modify the equation
    datamodel::EquationTreeItem startingFinalEquation(finalEquation);

    for (int i = 0; i < 10; ++i) {
        datamodel::EquationTreeItem &selectedArgument = equationeditors::selectRandomArgument(
            finalEquation);
        if (!actualNodes.contains(selectedArgument)) {
            actualNodes.append(selectedArgument);
        }

        QCOMPARE(finalEquation, startingFinalEquation);
    }

    QCOMPARE(actualNodes.size(), possiblesNodes.size());

    for (const datamodel::EquationTreeItem &actualNode : qAsConst(actualNodes)) {
        QVERIFY(possiblesNodes.contains(actualNode));
    }

    // Test const version
    actualNodes.clear();

    for (int i = 0; i < 10; ++i) {
        datamodel::EquationTreeItem selectedArgument = equationeditors::selectRandomArgument(
            qAsConst(finalEquation));
        if (!actualNodes.contains(selectedArgument)) {
            actualNodes.append(selectedArgument);
        }

        QCOMPARE(finalEquation, startingFinalEquation);
    }

    QCOMPARE(actualNodes.size(), possiblesNodes.size());

    for (const datamodel::EquationTreeItem &actualNode : qAsConst(actualNodes)) {
        QVERIFY(possiblesNodes.contains(actualNode));
    }
}

void Test_RandomNodeSelector::selectRandomNode_emptyEquation()
{
    datamodel::EquationTreeItem equation;

    datamodel::EquationTreeItem selectedArgument = equationeditors::selectRandomNode(equation);

    QVERIFY(selectedArgument.isEmpty());
}

void Test_RandomNodeSelector::selectRandomNode_multipleNodes()
{
    // Create the equation ( (1.2 * 2.3) + (4.6 * x))
    datamodel::EquationTreeItem oneDotTwoEquation(
        std::shared_ptr<datamodel::EquationNode>(new datamodel::ConstantNode(1.2)));
    datamodel::EquationTreeItem twoDotThreeEquation(
        std::shared_ptr<datamodel::EquationNode>(new datamodel::ConstantNode(2.3)));
    datamodel::EquationTreeItem fourDotSixEquation(
        std::shared_ptr<datamodel::EquationNode>(new datamodel::ConstantNode(4.6)));
    datamodel::EquationTreeItem variableEquation(
        std::shared_ptr<datamodel::EquationNode>(new datamodel::VariableNode(0)));

    datamodel::EquationTreeItem firstArgument(
        std::shared_ptr<datamodel::EquationNode>(new datamodel::MultiplicationNode()));
    firstArgument.setArguments({oneDotTwoEquation, twoDotThreeEquation});

    datamodel::EquationTreeItem secondArgument(
        std::shared_ptr<datamodel::EquationNode>(new datamodel::MultiplicationNode()));
    secondArgument.setArguments({fourDotSixEquation, variableEquation});

    datamodel::EquationTreeItem finalEquation(
        std::shared_ptr<datamodel::EquationNode>(new datamodel::AdditionNode()));
    finalEquation.setArguments({firstArgument, secondArgument});

    QList<datamodel::EquationTreeItem> possiblesNodes = QList<datamodel::EquationTreeItem>(
        {oneDotTwoEquation,
         twoDotThreeEquation,
         fourDotSixEquation,
         variableEquation,
         firstArgument,
         secondArgument,
         finalEquation});

    // Test non const version
    QList<datamodel::EquationTreeItem> actualNodes;

    // Copy yo check that the function do not modify the equation
    datamodel::EquationTreeItem startingFinalEquation(finalEquation);

    uint nbVar = 1;
    for (int i = 0; i < 100; ++i) {
        datamodel::EquationTreeItem &selectedArgument = equationeditors::selectRandomNode(
            finalEquation);
        //qDebug() << "Selected argument : "
        //         << QString::fromStdString(equationeditors::equationToString(selectedArgument, nbVar));
        std::string message_debug_selected_argument = "Selected argument : "
                + equationeditors::equationToString(selectedArgument, nbVar);
        logs::Logger::logDebug(message_debug_selected_argument, {logs::LogTags::tests});
        if (!actualNodes.contains(selectedArgument)) {
            actualNodes.append(selectedArgument);
        }
    }

    QCOMPARE(actualNodes.size(), possiblesNodes.size());

    for (const datamodel::EquationTreeItem &actualNode : qAsConst(actualNodes)) {
        QVERIFY2(possiblesNodes.contains(actualNode),
                 qUtf8Printable(
                     QStringLiteral("The actual node %1 is not in the list of possible nodes : ")
                         .arg(QString::fromStdString(equationeditors::equationToString(actualNode, nbVar)))));
    }

    // Test const version
    actualNodes.clear();

    for (int i = 0; i < 100; ++i) {
        datamodel::EquationTreeItem selectedArgument = equationeditors::selectRandomNode(
            qAsConst(finalEquation));
        if (!actualNodes.contains(selectedArgument)) {
            actualNodes.append(selectedArgument);
        }

        QCOMPARE(finalEquation, startingFinalEquation);
    }

    QCOMPARE(actualNodes.size(), possiblesNodes.size());

    for (const datamodel::EquationTreeItem &actualNode : qAsConst(actualNodes)) {
        QVERIFY2(possiblesNodes.contains(actualNode),
                 qUtf8Printable(
                     QStringLiteral("The actual node %1 is not in the list of possible nodes : ")
                         .arg(QString::fromStdString(equationeditors::equationToString(actualNode,nbVar)))));
    }

    // Test with only (4.6 * x)

    possiblesNodes = QList<datamodel::EquationTreeItem>(
        {fourDotSixEquation, variableEquation, secondArgument});

    // Test non const version
    actualNodes.clear();

    for (int i = 0; i < 100; ++i) {
        datamodel::EquationTreeItem &selectedArgument = equationeditors::selectRandomNode(
            secondArgument);
        if (!actualNodes.contains(selectedArgument)) {
            actualNodes.append(selectedArgument);
        }
    }

    QCOMPARE(actualNodes.size(), possiblesNodes.size());

    for (const datamodel::EquationTreeItem &actualNode : qAsConst(actualNodes)) {
        QVERIFY2(possiblesNodes.contains(actualNode),
                 qUtf8Printable(
                     QStringLiteral("The actual node %1 is not in the list of possible nodes : ")
                         .arg(QString::fromStdString(equationeditors::equationToString(actualNode, nbVar)))));
    }

    // Test const version
    actualNodes.clear();

    for (int i = 0; i < 100; ++i) {
        datamodel::EquationTreeItem selectedArgument = equationeditors::selectRandomNode(
            qAsConst(secondArgument));
        if (!actualNodes.contains(selectedArgument)) {
            actualNodes.append(selectedArgument);
        }

        QCOMPARE(finalEquation, startingFinalEquation);
    }

    QCOMPARE(actualNodes.size(), possiblesNodes.size());

    for (const datamodel::EquationTreeItem &actualNode : qAsConst(actualNodes)) {
        QVERIFY2(possiblesNodes.contains(actualNode),
                 qUtf8Printable(
                     QStringLiteral("The actual node %1 is not in the list of possible nodes : ")
                         .arg(QString::fromStdString(equationeditors::equationToString(actualNode, nbVar)))));
    }
}

QTEST_APPLESS_MAIN(Test_RandomNodeSelector)

#include "Test_RandomNodeSelector.moc"
