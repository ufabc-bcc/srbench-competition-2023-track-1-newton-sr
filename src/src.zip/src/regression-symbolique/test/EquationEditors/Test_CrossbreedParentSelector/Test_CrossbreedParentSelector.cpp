#include <QDebug>
#include <QTest>

#include "DataModel/ConstantNode.h"
#include "DataModel/EquationTreeItem.h"
#include "DataModel/EquationTree.h"
#include "EquationEditors/CrossbreedParentSelector.h"

class Test_CrossbreedParentSelector : public QObject {
  Q_OBJECT

public:
  Test_CrossbreedParentSelector() = default;


  private slots:
      void parentsSelection_SelectFollowing();
      void parentsSelection_SelectRandomly();
      void parentsSelection_SelectTournament();
};

void Test_CrossbreedParentSelector::parentsSelection_SelectFollowing() {
//  QMap<int, double> values{{0, 1},   {1, 2.5}, {2, 1.2}, {3, 1.1},
//                           {4, 5.5}, {5, 4.3}, {6, 4.2}, {7, 50.5}};

//  datamodel::Equations equations;

//  for (auto valuesIterator = values.constBegin();
//       valuesIterator != values.constEnd(); ++valuesIterator) {
//    auto equationNode = QSharedPointer<datamodel::EquationNode>(
//        new datamodel::ConstantNode(valuesIterator.key()));
//    datamodel::EquationTreeItem equationTreeItem(equationNode);
//    equations.insert(valuesIterator.key(),
//                     {equationTreeItem, valuesIterator.value()});
//  }

//  equationeditors::CrossbreedParentSelector crossbreedSelector(
//      equations, equationparameters::EquationCrossbreedingParameters::Tournament, equationparameters::EquationCrossbreedingParameters::Distance);

//  QList<QPair<datamodel::EquationTreeItem, datamodel::EquationTreeItem>>
//      parentsSelected = crossbreedSelector.parentsSelection();

//  QList<QPair<int, int>> expectedParents(
//      {{0, 3}, {3, 2}, {2, 1}, {1, 6}, {6, 5}, {5, 4}, {4, 7}});

//  QCOMPARE(parentsSelected.size(), expectedParents.size());

//  for (int i = 0; i < parentsSelected.size(); ++i) {
//    QCOMPARE(parentsSelected.at(i).first.value(0), expectedParents.at(i).first);
//    QCOMPARE(parentsSelected.at(i).second.value(0),
//             expectedParents.at(i).second);
//  }
}

void Test_CrossbreedParentSelector::parentsSelection_SelectRandomly() {
//  QMap<int, double> values{{0, 1},   {1, 2.5}, {2, 1.2}, {3, 1.1},
//                           {4, 5.5}, {5, 4.3}, {6, 4.2}, {7, 50.5}};

//  datamodel::Equations equations;

//  for (auto valuesIterator = values.constBegin();
//       valuesIterator != values.constEnd(); ++valuesIterator) {
//    auto equationNode = QSharedPointer<datamodel::EquationNode>(
//        new datamodel::ConstantNode(valuesIterator.key()));
//    datamodel::EquationTreeItem equationTreeItem(equationNode);
//    equations.insert(valuesIterator.key(),
//                     {equationTreeItem, valuesIterator.value()});
//  }

//  equationeditors::CrossbreedParentSelector crossbreedSelector(
//      equations, equationparameters::EquationCrossbreedingParameters::Tournament, equationparameters::EquationCrossbreedingParameters::Distance);

//  QList<QPair<datamodel::EquationTreeItem, datamodel::EquationTreeItem>>
//      parentsSelected = crossbreedSelector.parentsSelection();

//  QCOMPARE(parentsSelected.size(), values.size());

//  for (int i = 0; i < values.size(); ++i) {
//    QCOMPARE(parentsSelected.at(i).first.value(0), i);
//    values.contains(parentsSelected.at(i).second.value(0));
//  }

//  QList<QPair<datamodel::EquationTreeItem, datamodel::EquationTreeItem>>
//      parentsSelected2 = crossbreedSelector.parentsSelection();

//  // Randomly chosen second values, so its very very unlikely we got exactly the
//  // same list
//  QVERIFY(parentsSelected != parentsSelected2);
}

void Test_CrossbreedParentSelector::parentsSelection_SelectTournament()
{
//    QMap<int, double>
//        values{{0, 1}, {1, 2.5}, {2, 1.2}, {3, 1.1}, {4, 5.5}, {5, 4.3}, {6, 4.2}, {7, 50.5}};

//    datamodel::Equations equations;

//    for (auto valuesIterator = values.constBegin(); valuesIterator != values.constEnd();
//         ++valuesIterator) {
//        auto equationNode = QSharedPointer<datamodel::EquationNode>(
//            new datamodel::ConstantNode(valuesIterator.key()));
//        datamodel::EquationTreeItem equationTreeItem(equationNode);
//        equations.insert(valuesIterator.key(), {equationTreeItem, valuesIterator.value()});
//    }

//    equationeditors::CrossbreedParentSelector
//        crossbreedSelector(equations, equationparameters::EquationCrossbreedingParameters::Tournament, equationparameters::EquationCrossbreedingParameters::Distance, 5);

//    QList<QPair<datamodel::EquationTreeItem, datamodel::EquationTreeItem>> parentsSelected
//        = crossbreedSelector.parentsSelection();

//    QCOMPARE(parentsSelected.size(), values.size());

//    for (int i = 0; i < values.size(); ++i) {
//        QCOMPARE(parentsSelected.at(i).first.value(0), i);
//        values.contains(parentsSelected.at(i).second.value(0));
//    }

//    QList<QPair<datamodel::EquationTreeItem, datamodel::EquationTreeItem>> parentsSelected2
//        = crossbreedSelector.parentsSelection();

//    // Randomly chosen second values, so its very very unlikely we got exactly the same list
//    QVERIFY(parentsSelected != parentsSelected2);
}

QTEST_APPLESS_MAIN(Test_CrossbreedParentSelector)

#include "Test_CrossbreedParentSelector.moc"
