#include <QDebug>
#include <QTest>

#include "DataModel/EquationTreeItem.h"
#include "EquationEditors/EquationGenerator.h"

class Test_EquationGenerator : public QObject
{
    Q_OBJECT

  public:
      Test_EquationGenerator() = default;

  private slots:
      void generateEquation_differentDepth();
      void generateEquation_differentSelectedNodesTypes();
};

void Test_EquationGenerator::generateEquation_differentDepth()
{
    equationeditors::EquationGenerator equationGenerator;
    equationGenerator.setMaxDepth(0);

    QSet<datamodel::EquationNode::NodeType> nodeTypes;
    for (int nodeType = 0; nodeType <= datamodel::EquationNode::Last; ++nodeType) {
        nodeTypes.insert(datamodel::EquationNode::NodeType(nodeType));
    }

    equationGenerator.setSelectedNodesTypes(nodeTypes);

    for (int i = 0; i < 10; ++i) {
        QCOMPARE(equationGenerator.generateEquation().depth(), 0);
    }

    // Try with an equation of depth 3
    equationGenerator.setMaxDepth(3);

    QSet<datamodel::EquationNode::NodeType> nodesTypesGenerated;
    QSet<int> depths;
    for (int i = 0; i < 100; ++i) {
        auto equationGenerated = equationGenerator.generateEquation();
        QVERIFY(equationGenerated.depth() <= 3);
        nodesTypesGenerated.insert(equationGenerated.currentNode()->type());
        depths.insert(equationGenerated.depth());
    }

    // Check that at least 2 different root nodes are generated
    QVERIFY(nodesTypesGenerated.size() > 2);
    QVERIFY(depths.size() > 2);

    // Try with an equation of depth 5
    equationGenerator.setMaxDepth(5);

    nodesTypesGenerated.clear();
    depths.clear();
    for (int i = 0; i < 100; ++i) {
        auto equationGenerated = equationGenerator.generateEquation();
        QVERIFY(equationGenerated.depth() <= 5);
        nodesTypesGenerated.insert(equationGenerated.currentNode()->type());
        depths.insert(equationGenerated.depth());
    }

    // Check that at least 2 different root nodes are generated
    QVERIFY(nodesTypesGenerated.size() > 2);
    QVERIFY(depths.size() > 2);
}

void Test_EquationGenerator::generateEquation_differentSelectedNodesTypes()
{
    equationeditors::EquationGenerator equationGenerator;
    equationGenerator.setMaxDepth(3);

    QSet<datamodel::EquationNode::NodeType> nodeTypes{datamodel::EquationNode::Constant,
                                                      datamodel::EquationNode::Variable,
                                                      datamodel::EquationNode::Addition,
                                                      datamodel::EquationNode::Cosinus};

    equationGenerator.setSelectedNodesTypes(nodeTypes);

    QSet<datamodel::EquationNode::NodeType> nodesTypesGenerated;
    QSet<int> depths;
    for (int i = 0; i < 100; ++i) {
        auto equationGenerated = equationGenerator.generateEquation();
        QVERIFY(equationGenerated.depth() <= 3);
        nodesTypesGenerated.insert(equationGenerated.currentNode()->type());
        depths.insert(equationGenerated.depth());
    }

    // Check that at least 2 different root nodes are generated
    QVERIFY(nodesTypesGenerated.size() > 2);

    // All the generated nodes are includes in the list of selected nodes
    QVERIFY(nodeTypes.contains(nodesTypesGenerated));
}

QTEST_APPLESS_MAIN(Test_EquationGenerator)

#include "Test_EquationGenerator.moc"
