#include <QMap>
#include <QTest>

#include "AlgorithmControllers/EquationMutation.h"
#include "EquationEditors/EquationGenerator.h"

class Test_EquationMutation : public QObject {
  Q_OBJECT

public:
  Test_EquationMutation() = default;

private slots:
  // Check that the map return contains all the mutated equations, and that the
  // others are not mutated
  //void mutateEquations();
  //void generateMutatedEquations();
};

//void Test_EquationMutation::mutateEquations() {
//  equationparameters::EquationGenerationParameters equationGenerationParameters;
//  equationGenerationParameters.setEquationMaxDepth(5);
//  equationGenerationParameters.setEquationNumber(10);

//  QSet<datamodel::EquationNode::NodeType> nodeTypes;
//  for (int nodeType = 0; nodeType <= datamodel::EquationNode::Last;
//       ++nodeType) {
//    nodeTypes.insert(datamodel::EquationNode::NodeType(nodeType));
//  }

//  equationGenerationParameters.setSelectedNodesTypes(nodeTypes);

//  equationeditors::EquationGenerator equationGenerator;
//  equationGenerator.setMaxDepth(
//      equationGenerationParameters.equationMaxDepth());
//  equationGenerator.setSelectedNodesTypes(
//      equationGenerationParameters.selectedNodesTypes());

//  datamodel::Equations equations;

//  for (int i = 0; i < 100; ++i) {
//    auto equationGenerated = equationGenerator.generateEquation();
//    equations.insert(i, {equationGenerated, 0});
//  }

//  datamodel::Equations startingEquations(equations);

//  equationparameters::EquationMutationParameters equationMutationParameters;
//  equationMutationParameters.setEquationGenerationParameters(
//      equationGenerationParameters);
//  equationMutationParameters.setMutationRate(0);

//  algorithmcontroller::EquationMutation equationMutation;
//  equationMutation.setEquationMutationParameters(equationMutationParameters);

//  auto mutatedEquations = equationMutation.mutateEquations(equations);

//  QVERIFY(mutatedEquations.isEmpty());
//  // All the equations are the same
//  QCOMPARE(equations, startingEquations);

//  equationMutationParameters.setMutationRate(1);
//  equationMutation.setEquationMutationParameters(equationMutationParameters);

//  mutatedEquations = equationMutation.mutateEquations(equations);

//  // All the equations are muted
//  QCOMPARE(mutatedEquations.size(), startingEquations.size());

//  int numberOfMutatedEquations = 0;
//  for (auto iterator = equations.constBegin(); iterator != equations.constEnd();
//       ++iterator) {
//    // If the muted equation is different than the equation at the beginning
//    if (iterator.value().root() !=
//        startingEquations.value(iterator.key()).root()) {
//      ++numberOfMutatedEquations;
//    }
//  }

//  // Take a huge marging because some equations can be the same (muted to the
//  // same node for example);
//  QVERIFY2(numberOfMutatedEquations > 70,
//           qUtf8Printable(QStringLiteral("Only %1 equations mutated")
//                              .arg(numberOfMutatedEquations)));

//  equationMutationParameters.setMutationRate(0.64);
//  equationMutation.setEquationMutationParameters(equationMutationParameters);

//  QList<int> mutatedEquationsSizeList;
//  QList<int> numberOfMutedEquationsList;

//  for (int i = 0; i < 100; ++i) {
//    startingEquations = equations;
//    QCOMPARE(startingEquations, equations);
//    mutatedEquations = equationMutation.mutateEquations(equations);

//    mutatedEquationsSizeList.append(mutatedEquations.size());

//    int numberOfMutatedEquations = 0;
//    for (auto iterator = equations.constBegin();
//         iterator != equations.constEnd(); ++iterator) {
//      // If the muted equation is different than the equation at the beginning
//      if (iterator.value().root() !=
//          startingEquations.value(iterator.key()).root()) {
//        ++numberOfMutatedEquations;
//      }
//    }

//    numberOfMutedEquationsList.append(numberOfMutatedEquations);
//  }

//  double meanMutatedEquationsSize =
//      std::accumulate(mutatedEquationsSizeList.constBegin(),
//                      mutatedEquationsSizeList.constEnd(), .0) /
//      mutatedEquationsSizeList.size();
//  double meanNumberOfMutedEquationsList =
//      std::accumulate(numberOfMutedEquationsList.constBegin(),
//                      numberOfMutedEquationsList.constEnd(), .0) /
//      numberOfMutedEquationsList.size();

//  QVERIFY(60 < meanMutatedEquationsSize && meanMutatedEquationsSize < 70);
//  QVERIFY(30 < meanNumberOfMutedEquationsList &&
//          meanNumberOfMutedEquationsList < meanMutatedEquationsSize);
//}

//void Test_EquationMutation::generateMutatedEquations() {
//    equationparameters::EquationGenerationParameters equationGenerationParameters;
//    equationGenerationParameters.setEquationMaxDepth(5);
//    equationGenerationParameters.setEquationNumber(10);

//    QSet<datamodel::EquationNode::NodeType> nodeTypes;
//    for (int nodeType = 0; nodeType <= datamodel::EquationNode::Last;
//         ++nodeType) {
//      nodeTypes.insert(datamodel::EquationNode::NodeType(nodeType));
//    }

//    equationGenerationParameters.setSelectedNodesTypes(nodeTypes);

//    equationeditors::EquationGenerator equationGenerator;
//    equationGenerator.setMaxDepth(
//        equationGenerationParameters.equationMaxDepth());
//    equationGenerator.setSelectedNodesTypes(
//        equationGenerationParameters.selectedNodesTypes());

//    datamodel::Equations equations;

//    for (int i = 0; i < 100; ++i) {
//      auto equationGenerated = equationGenerator.generateEquation();
//      equations.insert(i, {equationGenerated, 0});
//    }

//    equationparameters::EquationMutationParameters equationMutationParameters;
//    equationMutationParameters.setEquationGenerationParameters(
//        equationGenerationParameters);

//    equationMutationParameters.setMutationRate(0.64);
//    algorithmcontroller::EquationMutation equationMutation;
//    equationMutation.setEquationMutationParameters(equationMutationParameters);

//    datamodel::Equations mutated = equationMutation.generateMutatedEquations(equations);
//    QVERIFY(60 < mutated.size() && mutated.size() < 70);
//}

QTEST_APPLESS_MAIN(Test_EquationMutation)

#include "Test_EquationMutation.moc"
