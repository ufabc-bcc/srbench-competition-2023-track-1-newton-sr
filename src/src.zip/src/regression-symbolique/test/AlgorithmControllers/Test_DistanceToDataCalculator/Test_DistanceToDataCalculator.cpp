#include <QTest>

#include "AlgorithmControllers/DistanceToDataCalculator.h"
#include "DataModel/AdditionNode.h"
#include "DataModel/ConstantNode.h"
#include "DataModel/VariableNode.h"

#include <QtMath>

class Test_DistanceToDataCalculator : public QObject
{
    Q_OBJECT

  public:
      Test_DistanceToDataCalculator() = default;

  private slots:
      void calculatedCumulatedDistanceToData();
      void calculatedCumulatedDistanceToDataWithVariables();
};

void Test_DistanceToDataCalculator::calculatedCumulatedDistanceToData()
{
    auto constantEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::ConstantNode(42.3));
    datamodel::EquationTreeItem constantTreeItem(constantEquationNode);

    std::vector<datamodel::DataPoint> datas;

    datamodel::DataPoint data;
    data.setParameterList(std::vector<double>{1});
    data.setResult(42.3);
    datas.push_back(data);

    data.setParameterList(std::vector<double>{1.5});
    datas.push_back(data);

    data.setParameterList(std::vector<double>{2});
    datas.push_back(data);

    data.setParameterList(std::vector<double>{3});
    datas.push_back(data);

    data.setParameterList(std::vector<double>{50});
    datas.push_back(data);

    double cumulatedDistance = algorithmcontroller::DistanceToDataCalculator::
        calculateCumulatedDistanceToData(constantTreeItem, datas);

    QCOMPARE(cumulatedDistance, 0);

    auto variableEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::VariableNode(0));
    datamodel::EquationTreeItem variableTreeItem(variableEquationNode);

    cumulatedDistance = algorithmcontroller::DistanceToDataCalculator::
        calculateCumulatedDistanceToData(variableTreeItem, datas);

    QCOMPARE(cumulatedDistance, 33.88);

    datas[0].setResult(12.5);
    datas[1].setResult(32.5);
    datas[2].setResult(64);

    cumulatedDistance = algorithmcontroller::DistanceToDataCalculator::
        calculateCumulatedDistanceToData(variableTreeItem, datas);

    QCOMPARE(cumulatedDistance, 30.3);
}

void Test_DistanceToDataCalculator::calculatedCumulatedDistanceToDataWithVariables()
{
    // x0 + x1
    auto additionNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::AdditionNode());
    datamodel::EquationTreeItem additionTreeItem(additionNode);

    auto firstVariable = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::VariableNode(0));
    datamodel::EquationTreeItem firstArgumentTreeItem(firstVariable);

    auto secondVariable = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::VariableNode(1));
    datamodel::EquationTreeItem secondArgumentTreeItem(secondVariable);

    additionTreeItem.setArguments(
                std::vector<datamodel::EquationTreeItem>{firstArgumentTreeItem, secondArgumentTreeItem});

    std::vector<datamodel::DataPoint> datas;

    datamodel::DataPoint point1;
    point1.setParameterList(std::vector<double>{1,2});
    point1.setResult(1.8);
    datas.push_back(point1);

    datamodel::DataPoint point2;
    point2.setParameterList(std::vector<double>{2,3});
    point2.setResult(3.1);
    datas.push_back(point2);

    datamodel::DataPoint point3;
    point3.setParameterList(std::vector<double>{4,5});
    point3.setResult(8.5);
    datas.push_back(point3);

    double cumulatedDistance = algorithmcontroller::DistanceToDataCalculator::
        calculateCumulatedDistanceToData(additionTreeItem, datas);

    QCOMPARE(cumulatedDistance, 1.2);
}
QTEST_APPLESS_MAIN(Test_DistanceToDataCalculator)

#include "Test_DistanceToDataCalculator.moc"
