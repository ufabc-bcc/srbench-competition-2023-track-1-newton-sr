#include <QMap>
#include <QTest>

#include "AlgorithmControllers/EquationFiltor.h"
#include "DataModel/ConstantNode.h"
#include "DataModel/EquationTreeItem.h"

class Test_EquationFiltor : public QObject {
  Q_OBJECT

public:
  Test_EquationFiltor() = default;

private slots:
  void filterEquations();
};

void Test_EquationFiltor::filterEquations() {
//  equationparameters::EquationFilterParameters equationFilterParameters;
//  equationFilterParameters.setFromEquation(1);
//  equationFilterParameters.setNumberOfEquationsSelected(5);

//  QMap<int, double> values{{0, 1},   {1, 2.5}, {2, 1.2}, {3, 1.1},
//                           {4, 5.5}, {5, 4.3}, {6, 4.2}, {7, 50.5}};

//  datamodel::Equations equations;

//  QMapIterator<int, double> valuesIterator(values);

//  while (valuesIterator.hasNext()) {
//    valuesIterator.next();

//    auto equationNode = std::shared_ptr<datamodel::EquationNode>(
//        new datamodel::ConstantNode(valuesIterator.key()));
//    datamodel::EquationTreeItem equationTreeItem(equationNode);
//    equations.insert(valuesIterator.key(),
//                     {equationTreeItem, valuesIterator.value()});
//  }

//  algorithmcontroller::EquationFiltor equationFiltor;
//  equationFiltor.setEquationFilterParameters(equationFilterParameters);

//  QMap<int, double> expectedValues(
//      {{0, 1}, {1, 2.5}, {2, 1.2}, {3, 1.1}, {6, 4.2}});

//  auto actualEquations = equationFiltor.filterEquations(equations);

//  QCOMPARE(actualEquations.size(), expectedValues.size());

//  valuesIterator = expectedValues;
//  while (valuesIterator.hasNext()) {
//    valuesIterator.next();

//    QVERIFY2(actualEquations.contains(valuesIterator.key()),
//             qUtf8Printable(QStringLiteral("Actual values do not contains : %1")
//                                .arg(valuesIterator.key())));
//    QCOMPARE(actualEquations.value(valuesIterator.key()).root().value(0),
//             valuesIterator.key());
//    QCOMPARE(actualEquations.value(valuesIterator.key()).distance(),
//             valuesIterator.value());
//  }

//  // Filter again to ensure it will not change the map
//  actualEquations = equationFiltor.filterEquations(equations);

//  valuesIterator = expectedValues;
//  while (valuesIterator.hasNext()) {
//    valuesIterator.next();

//    QVERIFY(actualEquations.contains(valuesIterator.key()));
//    QCOMPARE(actualEquations.value(valuesIterator.key()).root().value(0),
//             valuesIterator.key());
//    QCOMPARE(actualEquations.value(valuesIterator.key()).distance(),
//             valuesIterator.value());
//  }

//  // Test with empty map to check it will not crash

//  datamodel::Equations emptyMap;

//  actualEquations = equationFiltor.filterEquations(emptyMap);

//  QCOMPARE(actualEquations, emptyMap);
}

QTEST_APPLESS_MAIN(Test_EquationFiltor)

#include "Test_EquationFiltor.moc"
