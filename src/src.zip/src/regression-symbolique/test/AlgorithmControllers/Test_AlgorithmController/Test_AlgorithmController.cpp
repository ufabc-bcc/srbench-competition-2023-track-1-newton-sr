#include <QTest>

#include "AlgorithmControllers/AlgorithmController.h"
#include "AlgorithmControllers/DistanceToDataCalculator.h"
#include "FileReaderWriter/InputDataReader.h"

class Test_AlgorithmController : public QObject {
  Q_OBJECT

public:
  Test_AlgorithmController() = default;

private slots:
  void initTestCase();
  void onInputDataSelected();
  void onEquationGenerationRequired();
  void onGenerationCyclingRequired();

private:
  equationparameters::EquationGenerationParameters equationGenerationParameters();
  equationparameters::EquationFilterParameters equationFilterParameters();
  equationparameters::EquationCrossbreedingParameters equationCrossBreedingParameters();
  equationparameters::EquationMutationParameters equationMutationParameters();
  equationparameters::EquationGenerationCyclingParameters
  equationGenerationCyclingParameters();
  equationparameters::EquationDistanceParameters equationDistanceParameters();

  datamodel::EquationTree* _equations;
  QTemporaryDir _tempDir;
  algorithmcontroller::AlgorithmController _algorithmController;
};

void Test_AlgorithmController::initTestCase() {
  QVERIFY(_tempDir.isValid());
  _algorithmController.inputFileManager()->setApplicationDataFolder(
      _tempDir.path());

  QFile inputFile(":/TestData/x.csv");
  QVERIFY(inputFile.open(QIODevice::ReadOnly));
  filereaderwriter::InputDataReader inputReader(inputFile.fileName().toStdString());
  std::vector<datamodel::DataPoint> inputData = inputReader.readDataFile();
  inputFile.close();

  QVariantList inputVariantList;

  for (const auto &data : inputData) {
    inputVariantList.append(QVariant::fromValue(data));
  }

  _algorithmController.onInputDataSelected(":/TestData/x.csv",
                                           inputVariantList);

  _algorithmController.onEquationGenerationRequired(
              equationGenerationParameters(),
              equationDistanceParameters()
              );
  _equations = _algorithmController.equationsArray();
}

void Test_AlgorithmController::onInputDataSelected() {
  QFile inputFile(":/TestData/x.csv");
  QVERIFY(inputFile.open(QIODevice::ReadOnly));
  filereaderwriter::InputDataReader inputReader(inputFile.fileName().toStdString());
  std::vector<datamodel::DataPoint> inputData = inputReader.readDataFile();
  inputFile.close();

  QVariantList inputVariantList;

  for (const datamodel::DataPoint &data : qAsConst(inputData)) {
    inputVariantList.append(QVariant::fromValue(data));
  }

  // Clear the data
  _algorithmController.onInputDataSelected("", QVariant());

  QVERIFY(_algorithmController.inputFileManager()->inputDatas().empty());

  _algorithmController.onInputDataSelected(":/TestData/x.csv",
                                           inputVariantList);

  QCOMPARE(_algorithmController.inputFileManager()->inputDatas(), inputData);

  algorithmcontroller::AlgorithmController algorithmController2;

  algorithmController2.inputFileManager()->setApplicationDataFolder(
      _tempDir.path());
  algorithmController2.inputFileManager()->loadDefaultInputFile();

  QCOMPARE(algorithmController2.inputFileManager()->inputDatas(), inputData);
}

void Test_AlgorithmController::onEquationGenerationRequired() {
//  QBENCHMARK {
//    _algorithmController.onEquationGenerationRequired(
//        equationGenerationParameters());
//  }

//  QCOMPARE(_algorithmController.equations().size(),
//           equationGenerationParameters().equationNumber());

//  QMapIterator<int, datamodel::EquationTree>
//      equationsIterator(_algorithmController.equations());
//  while (equationsIterator.hasNext()) {
//    equationsIterator.next();
//    double distanceToData = algorithmcontroller::DistanceToDataCalculator::
//        calculateCumulatedDistanceToData(
//            equationsIterator.value().root(),
//            _algorithmController.inputFileManager()->inputDatas());
//    QCOMPARE(equationsIterator.value().distance(), distanceToData);
//  }
}

void Test_AlgorithmController::onGenerationCyclingRequired() {
//  QBENCHMARK {
//    _algorithmController.setEquations(_equations);
//    _algorithmController.onGenerationCyclingRequired(
//        equationGenerationCyclingParameters());
//  }

//  QCOMPARE(_algorithmController.equations().size(),
//           equationFilterParameters().numberOfEquationsSelected());

//  QMapIterator<int, datamodel::EquationTree>
//      equationsIterator(_algorithmController.equations());
//  while (equationsIterator.hasNext()) {
//    equationsIterator.next();
//    double distanceToData = algorithmcontroller::DistanceToDataCalculator::
//        calculateCumulatedDistanceToData(
//            equationsIterator.value().root(),
//            _algorithmController.inputFileManager()->inputDatas());
//    QCOMPARE(equationsIterator.value().distance(), distanceToData);
//  }
}

equationparameters::EquationGenerationParameters
Test_AlgorithmController::equationGenerationParameters() {
  equationparameters::EquationGenerationParameters equationGenerationParameters;
  equationGenerationParameters.setEquationMaxDepth(5);
  equationGenerationParameters.setEquationNumber(100);

  QSet<datamodel::EquationNode::NodeType> nodeTypes;
  for (int nodeType = 0; nodeType <= datamodel::EquationNode::Last;
       ++nodeType) {
    nodeTypes.insert(datamodel::EquationNode::NodeType(nodeType));
  }

  equationGenerationParameters.setSelectedNodesTypes(nodeTypes);

  return equationGenerationParameters;
}

equationparameters::EquationDistanceParameters
Test_AlgorithmController::equationDistanceParameters() {
  equationparameters::EquationDistanceParameters equationDistanceParameters;
  equationDistanceParameters.setEquationDistance(equationparameters::EquationDistanceParameters::R2);

  return equationDistanceParameters;
}

equationparameters::EquationFilterParameters
Test_AlgorithmController::equationFilterParameters() {
  equationparameters::EquationFilterParameters equationFilterParameters;
  equationFilterParameters.setFromEquation(1);
  equationFilterParameters.setNumberOfEquationsSelected(50);
  return equationFilterParameters;
}

equationparameters::EquationCrossbreedingParameters
Test_AlgorithmController::equationCrossBreedingParameters() {
  equationparameters::EquationCrossbreedingParameters equationCrossBreedingParameters;
  equationCrossBreedingParameters.setParentSelectionStrategy(
      equationparameters::EquationCrossbreedingParameters::Tournament);
  equationCrossBreedingParameters.setCrossbreedingMethod(
      equationparameters::EquationCrossbreedingParameters::
          ConstantDepthTreeSubstitution);

  return equationCrossBreedingParameters;
}

equationparameters::EquationMutationParameters
Test_AlgorithmController::equationMutationParameters() {
  equationparameters::EquationMutationParameters equationMutationParameters;
  equationMutationParameters.setMutationRate(0.35);
  equationMutationParameters.setEquationGenerationParameters(
      equationGenerationParameters());

  return equationMutationParameters;
}

equationparameters::EquationGenerationCyclingParameters
Test_AlgorithmController::equationGenerationCyclingParameters() {
  equationparameters::EquationGenerationCyclingParameters
      equationGenerationCyclingParameters;
  equationGenerationCyclingParameters.setNumberOfGenerations(10);
  equationGenerationCyclingParameters.setEquationFilterParameters(
      equationFilterParameters());
  equationGenerationCyclingParameters.setEquationMutationParameters(
      equationMutationParameters());
  equationGenerationCyclingParameters.setEquationCrossbreedingParameters(
      equationCrossBreedingParameters());

  return equationGenerationCyclingParameters;
}

QTEST_APPLESS_MAIN(Test_AlgorithmController)

#include "Test_AlgorithmController.moc"
