//#include <QTest>

//#include "Logger/LogFile.h"

/*class Test_LogFile : public QObject
{
    Q_OBJECT

  public:
    Test_LogFile();

  private slots:
    void readLogFile();
    void writLogFile();
};*/

/*Test_LogFile::Test_LogFile() = default;

void Test_LogFile::readLogFile()
{
    logger::LogFile logFile(":/Test_LogFile/TreeGeneticProgramming_20190520_082136452.log");

    QVERIFY2(logFile.exists(), qPrintable("Cannot find the file : " + QFileInfo(logFile).absolutePath()));

    QCOMPARE(QDateTime::fromString("20190520_082136452", logger::LogFile::LOG_DATE_FORMAT).toString(),
             logFile.getLogDate().toString());
}
*/
/*void Test_LogFile::writLogFile()
{
    QTemporaryDir output;
    QVERIFY(output.isValid());

    logger::LogFile logFile(QDir(output.path()));

    if (logFile.open(QIODevice::WriteOnly))
    {
        logFile.write("Whatever");
        logFile.close();
    }

    QVERIFY(QFile::exists(logFile.fileName()));
    QVERIFY(logFile.getLogDate().msecsTo(QDateTime::currentDateTime()) < 100);

    QCOMPARE(QFileInfo(logFile).fileName(),
             qPrintable("TreeGeneticProgramming_" + logFile.getLogDate().toString(logger::LogFile::LOG_DATE_FORMAT) + ".log"));
}

QTEST_APPLESS_MAIN(Test_LogFile)

#include "Test_LogFile.moc"
*/
