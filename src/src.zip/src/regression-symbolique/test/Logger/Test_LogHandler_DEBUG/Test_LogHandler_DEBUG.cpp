//#include <QTest>

//#include "Logger/LogFile.h"
//#include "Logger/LogHandler.h"

/*class Test_LogHandler_DEBUG : public QObject
{
    Q_OBJECT

  public:
    Test_LogHandler_DEBUG() = default;

  private slots:
    void writeLog();
};*/

/*void Test_LogHandler_DEBUG::writeLog()
{
    QTemporaryDir output;
    QVERIFY(output.isValid());
    QDir outputDir(output.path());

    logger::LogHandler::buildInstance(outputDir);

    qInstallMessageHandler(logger::LogHandler::messageHandler);

    //qDebug("Hello");
    //qInfo("Some info");
    //qWarning("is there in the log");
    //qCritical("you need ot read it");

    QFile logFile(output.path() + "/" + outputDir.entryList().at(2));
    QVERIFY2(logFile.exists(), qPrintable("Cannot find the log file : " + QFileInfo(logFile).fileName()));

    if (logFile.open(QIODevice::ReadOnly))
    {
        QString log1(logFile.readLine());
        QString log2(logFile.readLine());
        QString log3(logFile.readLine());
        QString log4(logFile.readLine());

        QVERIFY(log1.startsWith("[Debug]") && log1.contains(" : \"Hello\" ")
                && (log1.contains("Logger\\Test_LogHandler_DEBUG\\Test_LogHandler_DEBUG.cpp:28")
                    || log1.contains("Logger/Test_LogHandler_DEBUG/Test_LogHandler_DEBUG.cpp:28")));
        QVERIFY(log2.startsWith("[Info]") && log2.contains(" : \"Some info\" ")
                && (log2.contains("Logger\\Test_LogHandler_DEBUG\\Test_LogHandler_DEBUG.cpp:29")
                    || log2.contains("Logger/Test_LogHandler_DEBUG/Test_LogHandler_DEBUG.cpp:29")));
        QVERIFY(log3.startsWith("[Warning]") && log3.contains(" : \"is there in the log\" ")
                && (log3.contains("Logger\\Test_LogHandler_DEBUG\\Test_LogHandler_DEBUG.cpp:30")
                    || log3.contains("Logger/Test_LogHandler_DEBUG/Test_LogHandler_DEBUG.cpp:30")));
        QVERIFY(log4.startsWith("[Critical]") && log4.contains(" : \"you need ot read it\" ")
                && (log4.contains("Logger\\Test_LogHandler_DEBUG\\Test_LogHandler_DEBUG.cpp:31")
                    || log4.contains("Logger/Test_LogHandler_DEBUG/Test_LogHandler_DEBUG.cpp:31")));
    }
    else
    {
        QFAIL("Cannot open the log file to read");
    }

    //logger::LogHandler::deleteInstance();
}

QTEST_APPLESS_MAIN(Test_LogHandler_DEBUG)

#include "Test_LogHandler_DEBUG.moc"
*/
