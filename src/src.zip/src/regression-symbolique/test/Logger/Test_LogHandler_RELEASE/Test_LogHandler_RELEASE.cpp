#include <QDebug>
#include <QTest>

#include "Logger/LogFile.h"
#include "Logger/LogHandler.h"

class Test_LogHandler_RELEASE : public QObject
{
    Q_OBJECT

  public:
    Test_LogHandler_RELEASE();

  private slots:
    void writeLog();
};

Test_LogHandler_RELEASE::Test_LogHandler_RELEASE() = default;

void Test_LogHandler_RELEASE::writeLog()
{
    QTemporaryDir output;
    QVERIFY(output.isValid());
    QDir outputDir(output.path());

    logger::LogHandler::buildInstance(outputDir);

    qInstallMessageHandler(logger::LogHandler::messageHandler);

    QFile logFile(output.path() + "/" + outputDir.entryList().at(2));
    QVERIFY2(logFile.exists(), qPrintable("Cannot find the log file : " + QFileInfo(logFile).fileName()));

    if (logFile.open(QIODevice::ReadOnly))
    {
        QString log1(logFile.readLine());
        QString log2(logFile.readLine());
        QString log3(logFile.readLine());

        QVERIFY(
            log1.startsWith("[Info]") && log1.contains(" : \"Some info\"")
            && !(
                log1.contains("Logger\\Test_LogHandler_RELEASE\\Test_LogHandler_RELEASE.cpp:30")
                || log1.contains("Logger/Test_LogHandler_RELEASE/Test_LogHandler_RELEASE.cpp:30")));
        QVERIFY(
            log2.startsWith("[Warning]") && log2.contains(" : \"is there in the log\"")
            && !(
                log2.contains("Logger\\Test_LogHandler_RELEASE\\Test_LogHandler_RELEASE.cpp:31")
                || log2.contains("Logger/Test_LogHandler_RELEASE/Test_LogHandler_RELEASE.cpp:31")));
        QVERIFY(
            log3.startsWith("[Critical]") && log3.contains(" : \"you need ot read it\"")
            && !(
                log3.contains("Logger\\Test_LogHandler_RELEASE\\Test_LogHandler_RELEASE.cpp:32")
                || log3.contains("Logger/Test_LogHandler_RELEASE/Test_LogHandler_RELEASE.cpp:32")));
    }
    else
    {
        QFAIL("Cannot open the log file to read");
    }

    logger::LogHandler::deleteInstance();
}

QTEST_APPLESS_MAIN(Test_LogHandler_RELEASE)

#include "Test_LogHandler_RELEASE.moc"
