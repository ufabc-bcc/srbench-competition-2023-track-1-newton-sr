#include <QTest>

#include "DataModel/ConstantNode.h"
#include "DataModel/EquationTreeItem.h"
#include "ViewControllers/EquationsListController.h"
#include <cmath>

class Test_EquationListController : public QObject {
  Q_OBJECT

public:
  Test_EquationListController() = default;

private slots:
  void orderOfEquations();

private:
  void compareDataAtIndex(
      const viewcontroller::EquationsListController *equationListController,
      QList<int> index, int identifier, QString equationValue, double distance);
};

void Test_EquationListController::orderOfEquations() {
//  datamodel::Equations equationsData({
//      {0,
//       {datamodel::EquationTreeItem(std::shared_ptr<datamodel::EquationNode>(
//            new datamodel::ConstantNode(0))),
//        3.5}},
//      {1,
//       {datamodel::EquationTreeItem(std::shared_ptr<datamodel::EquationNode>(
//            new datamodel::ConstantNode(1))),
//        4.5}},
//      {2,
//       {datamodel::EquationTreeItem(std::shared_ptr<datamodel::EquationNode>(
//            new datamodel::ConstantNode(2))),
//        std::numeric_limits<double>::infinity()}},
//      {3,
//       {datamodel::EquationTreeItem(std::shared_ptr<datamodel::EquationNode>(
//            new datamodel::ConstantNode(3))),
//        1.3}},
//      {4,
//       {datamodel::EquationTreeItem(std::shared_ptr<datamodel::EquationNode>(
//            new datamodel::ConstantNode(4))),
//        15}},
//      {5,
//       {datamodel::EquationTreeItem(std::shared_ptr<datamodel::EquationNode>(
//            new datamodel::ConstantNode(5))),
//        9}},
//      {6,
//       {datamodel::EquationTreeItem(std::shared_ptr<datamodel::EquationNode>(
//            new datamodel::ConstantNode(6))),
//        nan("")}},
//      {7,
//       {datamodel::EquationTreeItem(std::shared_ptr<datamodel::EquationNode>(
//            new datamodel::ConstantNode(7))),
//        nan("")}},
//      {8,
//       {datamodel::EquationTreeItem(std::shared_ptr<datamodel::EquationNode>(
//            new datamodel::ConstantNode(8))),
//        15}},
//      {9,
//       {datamodel::EquationTreeItem(std::shared_ptr<datamodel::EquationNode>(
//            new datamodel::ConstantNode(9))),
//        std::numeric_limits<double>::infinity()}},
//  });

//  viewcontroller::EquationsListController equationListController;
//  equationListController.onEquationsDataChanged(equationsData);

//  compareDataAtIndex(&equationListController, {0}, 3, "3", 1.3);
//  compareDataAtIndex(&equationListController, {1}, 0, "0", 3.5);
//  compareDataAtIndex(&equationListController, {2}, 1, "1", 4.5);
//  compareDataAtIndex(&equationListController, {3}, 5, "5", 9);
//  compareDataAtIndex(&equationListController, {4, 5}, 4, "4", 15);
//  compareDataAtIndex(&equationListController, {4, 5}, 8, "8", 15);
//  compareDataAtIndex(&equationListController, {6, 7}, 6, "6", nan(""));
//  compareDataAtIndex(&equationListController, {6, 7}, 7, "7", nan(""));
//  compareDataAtIndex(&equationListController, {8, 9}, 2, "2",
//                     std::numeric_limits<double>::infinity());
//  compareDataAtIndex(&equationListController, {8, 9}, 9, "9",
//                     std::numeric_limits<double>::infinity());
}

void Test_EquationListController::compareDataAtIndex(
    const viewcontroller::EquationsListController *equationListController,
    QList<int> indexes, int identifier, QString equationValue,
    double distance) {
  int indexFound = -1;
  QString indexesString("{");
  for (int index : indexes) {
    indexesString.append(QString::number(index));
    if (equationListController->data(
            equationListController->index(index),
            viewcontroller::EquationsListController::Identifier) ==
        identifier) {
      indexFound = index;
      break;
    }
  }

  indexesString.append("}");

  QString message = QString("Cannot find a value with the given identifier %1 "
                            "in the list of indexes %2")
                        .arg(identifier)
                        .arg(indexesString);

  QVERIFY2(indexFound != -1, qUtf8Printable(message));

  QCOMPARE(equationListController->data(
               equationListController->index(indexFound),
               viewcontroller::EquationsListController::Equation),
           equationValue);

  QCOMPARE(equationListController
               ->data(equationListController->index(indexFound),
                      viewcontroller::EquationsListController::DistanceR2)
               .toDouble(),
           distance);
}

QTEST_APPLESS_MAIN(Test_EquationListController)

#include "Test_EquationListController.moc"
