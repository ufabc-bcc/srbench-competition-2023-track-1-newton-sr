#include <QTest>

#include "FileReaderWriter/InputDataReader.h"

class Test_InputDataReader : public QObject
{
    Q_OBJECT

  public:
      Test_InputDataReader() = default;

  private slots:
      void parseInvalidFile();
      void parseEmptyFile();
      void parseCompleteFile();
};

void Test_InputDataReader::parseInvalidFile()
{
    QFile file(":/TestData/InvalidFile.csv");

    QVERIFY(file.exists());
    QVERIFY(file.open(QIODevice::ReadOnly));

    filereaderwriter::InputDataReader inputDataReader(file.fileName().toStdString());

    std::vector<datamodel::DataPoint> datas = inputDataReader.readDataFile();
    QCOMPARE(datas.size(), 0);
    QVERIFY(inputDataReader.error());
}

void Test_InputDataReader::parseEmptyFile()
{
    QFile file(":/TestData/EmptyInput.csv");

    QVERIFY(file.exists());
    QVERIFY(file.open(QIODevice::ReadOnly));

    filereaderwriter::InputDataReader inputDataReader(file.fileName().toStdString());

    std::vector<datamodel::DataPoint> datas = inputDataReader.readDataFile();
    QCOMPARE(datas.size(), 0);
    QVERIFY(inputDataReader.error());
}

void Test_InputDataReader::parseCompleteFile()
{
    QFile file(":/TestData/CompleteInput.csv");
    QFileInfo fileInfo("CompleteInput.csv");

    QVERIFY(file.exists());
    QVERIFY(file.open(QIODevice::ReadOnly));

    //TODO: Figure how to pass the right path in parameter to make the test working correctly
    filereaderwriter::InputDataReader inputDataReader(fileInfo.fileName().toStdString());

    std::vector<datamodel::DataPoint> datas = inputDataReader.readDataFile();
    QCOMPARE(datas.size(), 10);
    QVERIFY(!inputDataReader.error());
}

QTEST_MAIN(Test_InputDataReader)

#include "Test_InputDataReader.moc"
