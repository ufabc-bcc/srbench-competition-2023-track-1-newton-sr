#include <QTest>

#include <DataModel/AdditionNode.h>
#include <DataModel/ConstantNode.h>
#include <DataModel/VariableNode.h>

class Test_AdditionNode : public QObject
{
    Q_OBJECT

  public:
      Test_AdditionNode() = default;

  private slots:
      void calculateValue();

};



void Test_AdditionNode::calculateValue()
{
    auto currentEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::AdditionNode(3));
    datamodel::EquationTreeItem currentTreeItem(currentEquationNode);
	
	auto variableNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::VariableNode(0));
    datamodel::EquationTreeItem variableTreeItem(variableNode);

    auto constantNode7 = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::ConstantNode(7));
    datamodel::EquationTreeItem constantTreeItem7(constantNode7);

    auto constantNode2 = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::ConstantNode(2));
    datamodel::EquationTreeItem constantTreeItem2(constantNode2);

    currentTreeItem.setArguments(std::vector<datamodel::EquationTreeItem>{constantTreeItem2, variableTreeItem, constantTreeItem7});
	
    // compare

    QCOMPARE(currentTreeItem.value(std::vector<double>{21}), 30);

}

QTEST_APPLESS_MAIN(Test_AdditionNode)

#include "Test_AdditionNode.moc"
