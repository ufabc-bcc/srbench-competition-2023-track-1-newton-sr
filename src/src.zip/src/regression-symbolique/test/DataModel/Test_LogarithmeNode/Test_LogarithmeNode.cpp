#include <QDebug>
#include <QList>
#include <QTest>
#include <QtGlobal>
#include <DataModel/LogarithmeNode.h>

#include <DataModel/AdditionNode.h>
#include <DataModel/ConstantNode.h>
#include <DataModel/CosinusNode.h>
#include <DataModel/DivisionNode.h>
#include <DataModel/EquationTreeItem.h>
#include <DataModel/ExponentialNode.h>
#include <DataModel/LogarithmeNode.h>
#include <DataModel/MaxNode.h>
#include <DataModel/MinNode.h>
#include <DataModel/MultiplicationNode.h>
#include <DataModel/PowerNode.h>
#include <DataModel/SinusNode.h>
#include <DataModel/SoustractionNode.h>
#include <DataModel/SquareRootNode.h>
#include <DataModel/VariableNode.h>

#include <QtMath>
#include <cmath>

class Test_LogarithmeNode : public QObject
{
    Q_OBJECT

  public:
      Test_LogarithmeNode() = default;

  private slots:
      void calculateValue();

};



void Test_LogarithmeNode::calculateValue()
{
    auto currentEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::LogarithmeNode());
    datamodel::EquationTreeItem currentTreeItem(currentEquationNode);
	
	auto variableNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::VariableNode(0));
    datamodel::EquationTreeItem variableTreeItem(variableNode);

    currentTreeItem.setArguments(std::vector<datamodel::EquationTreeItem>{variableTreeItem});

    // When we have no arguments then the depth is 0

    QCOMPARE(currentTreeItem.value(std::vector<double>{5}), std::log(5));

}

QTEST_APPLESS_MAIN(Test_LogarithmeNode)

#include "Test_LogarithmeNode.moc"
