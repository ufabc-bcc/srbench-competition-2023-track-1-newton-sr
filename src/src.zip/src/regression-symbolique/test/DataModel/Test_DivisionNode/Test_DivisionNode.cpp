#include <QDebug>
#include <QList>
#include <QTest>
#include <QtGlobal>
#include <DataModel/MultiplicationNode.h>

#include <DataModel/AdditionNode.h>
#include <DataModel/ConstantNode.h>
#include <DataModel/CosinusNode.h>
#include <DataModel/DivisionNode.h>
#include <DataModel/EquationTreeItem.h>
#include <DataModel/ExponentialNode.h>
#include <DataModel/LogarithmeNode.h>
#include <DataModel/MinNode.h>
#include <DataModel/MaxNode.h>
#include <DataModel/PowerNode.h>
#include <DataModel/SinusNode.h>
#include <DataModel/SoustractionNode.h>
#include <DataModel/SquareRootNode.h>
#include <DataModel/VariableNode.h>

#include <QtMath>
#include <cmath>

class Test_DivisionNode : public QObject
{
    Q_OBJECT

  public:
      Test_DivisionNode() = default;

  private slots:
      void calculateValue();

};



void Test_DivisionNode::calculateValue()
{
    auto currentEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::DivisionNode());
    datamodel::EquationTreeItem currentTreeItem(currentEquationNode);
	
	auto variableNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::VariableNode(0));
    datamodel::EquationTreeItem variableTreeItem(variableNode);

	auto constantNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::ConstantNode(10));
    datamodel::EquationTreeItem constantTreeItem(constantNode);

    currentTreeItem.setArguments(std::vector<datamodel::EquationTreeItem>{variableTreeItem, constantTreeItem});

    // compare

    QCOMPARE(currentTreeItem.value(std::vector<double>{500}), 50);

}

QTEST_APPLESS_MAIN(Test_DivisionNode)

#include "Test_DivisionNode.moc"
