#include <QDebug>
#include <QList>
#include <QTest>
#include <QtGlobal>

#include <DataModel/AdditionNode.h>
#include <DataModel/ConstantNode.h>
#include <DataModel/CosinusNode.h>
#include <DataModel/DivisionNode.h>
#include <DataModel/EquationTreeItem.h>
#include <DataModel/ExponentialNode.h>
#include <DataModel/LogarithmeNode.h>
#include <DataModel/MaxNode.h>
#include <DataModel/MinNode.h>
#include <DataModel/MultiplicationNode.h>
#include <DataModel/PowerNode.h>
#include <DataModel/SinusNode.h>
#include <DataModel/SoustractionNode.h>
#include <DataModel/SquareRootNode.h>
#include <DataModel/VariableNode.h>

#include <QtMath>

class Test_EquationTreeItem : public QObject
{
    Q_OBJECT

  public:
      Test_EquationTreeItem() = default;

  private slots:
      void setArguments();
      void isEmpty();
      void isValid();
      void value_constant();
      void value_variable();
      void value_division();
      void value_multiplication();
      void value_soustraction();
      void value_addition();
      void value_power();
      void value_rootsquare();
      void value_min();
      void value_max();
      void value_equation();
      void value_invalidParametersNumber();
      void value_infOrNan();
      void findParent();
};

void Test_EquationTreeItem::setArguments()
{
    auto currentEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::ConstantNode(0));
    datamodel::EquationTreeItem currentTreeItem(currentEquationNode);

    // When we have no arguments then the depth is 0

    QCOMPARE(currentTreeItem.depth(), 0);

    // Current item have one argument so the depth is 1

    datamodel::EquationTreeItem argumentThreeItem(currentEquationNode);
    std::vector<datamodel::EquationTreeItem>{argumentThreeItem};

    currentTreeItem.setArguments(std::vector<datamodel::EquationTreeItem>{argumentThreeItem});

    QCOMPARE(currentTreeItem.depth(), 1);

    // Current node have one argument and the argument have one argument so the depth is 2

    datamodel::EquationTreeItem argumentThreeItem2(currentEquationNode);
    argumentThreeItem.setArguments(std::vector<datamodel::EquationTreeItem>{argumentThreeItem2});
    currentTreeItem.setArguments(std::vector<datamodel::EquationTreeItem>{argumentThreeItem});

    QCOMPARE(currentTreeItem.depth(), 2);
}

void Test_EquationTreeItem::isEmpty()
{
    datamodel::EquationTreeItem equationTreeItem;
    QVERIFY(equationTreeItem.isEmpty());

    equationTreeItem.setCurrentNode(
        std::shared_ptr<datamodel::EquationNode>(new datamodel::ConstantNode(1.2)));

    QVERIFY(!equationTreeItem.isEmpty());

    equationTreeItem.setCurrentNode(std::shared_ptr<datamodel::EquationNode>());

    QVERIFY(equationTreeItem.isEmpty());

    datamodel::EquationTreeItem argumentTreeItem(
        std::shared_ptr<datamodel::EquationNode>(new datamodel::ConstantNode(1.2)));
    equationTreeItem.setArguments({argumentTreeItem});

    QVERIFY(!equationTreeItem.isEmpty());

    equationTreeItem.setArguments({});

    QVERIFY(equationTreeItem.isEmpty());
}

void Test_EquationTreeItem::isValid()
{
    datamodel::EquationTreeItem equationTreeItem;
    QVERIFY(!equationTreeItem.isValid(std::vector<double>{0}));

    // Create the equation ( (1.2 * 2.3) + (4.6 * x))
    datamodel::EquationTreeItem oneDotTwoEquation(
        std::shared_ptr<datamodel::EquationNode>(new datamodel::ConstantNode(1.2)));
    datamodel::EquationTreeItem twoDotThreeEquation(
        std::shared_ptr<datamodel::EquationNode>(new datamodel::ConstantNode(2.3)));
    datamodel::EquationTreeItem fourDotSixEquation(
        std::shared_ptr<datamodel::EquationNode>(new datamodel::ConstantNode(4.6)));
    datamodel::EquationTreeItem variableEquation(
        std::shared_ptr<datamodel::EquationNode>(new datamodel::VariableNode(0)));

    datamodel::EquationTreeItem firstArgument(
        std::shared_ptr<datamodel::EquationNode>(new datamodel::MultiplicationNode()));
    firstArgument.setArguments({oneDotTwoEquation, twoDotThreeEquation});

    datamodel::EquationTreeItem secondArgument(
        std::shared_ptr<datamodel::EquationNode>(new datamodel::MultiplicationNode()));
    secondArgument.setArguments({fourDotSixEquation, variableEquation});

    datamodel::EquationTreeItem finalEquation(
        std::shared_ptr<datamodel::EquationNode>(new datamodel::AdditionNode()));
    finalEquation.setArguments({firstArgument, secondArgument});

    QVERIFY(finalEquation.isValid(std::vector<double>{0}));

    finalEquation.arguments()[0].setArguments(
        {oneDotTwoEquation, twoDotThreeEquation, equationTreeItem});

    QVERIFY(!finalEquation.isValid(std::vector<double>{0}));

    finalEquation.arguments()[0].setArguments({});

    QVERIFY(!finalEquation.isValid(std::vector<double>{0}));

    finalEquation.arguments()[0].setArguments({oneDotTwoEquation, twoDotThreeEquation});

    QVERIFY(finalEquation.isValid(std::vector<double>{0}));

    finalEquation.setArguments({firstArgument, secondArgument, equationTreeItem});

    QVERIFY(!finalEquation.isValid(std::vector<double>{0}));

    finalEquation.setArguments({});

    QVERIFY(!finalEquation.isValid(std::vector<double>{0}));

    finalEquation.setArguments({firstArgument, secondArgument});

    QVERIFY(finalEquation.isValid(std::vector<double>{0}));
}

void Test_EquationTreeItem::value_constant()
{
    auto currentEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::ConstantNode(1.2));
    datamodel::EquationTreeItem currentTreeItem(currentEquationNode);

    QCOMPARE(currentTreeItem.value(std::vector<double>{0}), 1.2);
}

void Test_EquationTreeItem::value_variable()
{
    auto currentEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::VariableNode( 0));
    datamodel::EquationTreeItem currentTreeItem(currentEquationNode);

    QCOMPARE(currentTreeItem.value(std::vector<double>{1.2}), 1.2);
}

void Test_EquationTreeItem::value_equation()
{
    // Simple equation : x + 3.5

    auto additionEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::AdditionNode());
    datamodel::EquationTreeItem additionTreeItem(additionEquationNode);

    auto firstArgumentEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::VariableNode(0));
    datamodel::EquationTreeItem firstArgumentTreeItem(firstArgumentEquationNode);

    auto secondArgumentEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::ConstantNode(3.5));
    datamodel::EquationTreeItem secondArgumentTreeItem(secondArgumentEquationNode);

    additionTreeItem.setArguments(
        std::vector<datamodel::EquationTreeItem>{firstArgumentTreeItem, secondArgumentTreeItem});

    QCOMPARE(additionTreeItem.value(std::vector<double>{1.2}), 4.7);

    // More complexe equation cos(x+0.25)

    auto cosinusEquationNode = std::shared_ptr<datamodel::EquationNode>(new datamodel::CosinusNode());
    datamodel::EquationTreeItem cosinusTreeItem(cosinusEquationNode);

    secondArgumentTreeItem.setCurrentNode(
        std::shared_ptr<datamodel::EquationNode>(new datamodel::ConstantNode(0.25)));

    additionTreeItem.setArguments(
        std::vector<datamodel::EquationTreeItem>({firstArgumentTreeItem, secondArgumentTreeItem}));
    cosinusTreeItem.setArguments(std::vector<datamodel::EquationTreeItem>{additionTreeItem});

    double value = cosinusTreeItem.value(std::vector<double>{0.75});

    QVERIFY(qAbs(value - 0.540302) < 0.00001);

    // More complexe equation sin(x+0.25)

    auto sinusEquationNode = std::shared_ptr<datamodel::EquationNode>(new datamodel::SinusNode());
    datamodel::EquationTreeItem sinusTreeItem(sinusEquationNode);

    additionTreeItem.setArguments(
        std::vector<datamodel::EquationTreeItem>{firstArgumentTreeItem, secondArgumentTreeItem});
    sinusTreeItem.setArguments(std::vector<datamodel::EquationTreeItem>{additionTreeItem});

    double value2 = sinusTreeItem.value(std::vector<double>{0.5});

    QVERIFY(qAbs(value2 - 0.68163876002) < 0.00001);
}

void Test_EquationTreeItem::value_invalidParametersNumber()
{
    // Addition with no argument
    auto additionEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::AdditionNode());
    datamodel::EquationTreeItem additionTreeItem(additionEquationNode);

    QCOMPARE(additionTreeItem.value(std::vector<double>{1.2}), nan(""));

    // Addition with only 1 argument

    auto firstArgumentEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::VariableNode(0));
    datamodel::EquationTreeItem firstArgumentTreeItem(firstArgumentEquationNode);

    additionTreeItem.setArguments(std::vector<datamodel::EquationTreeItem>{firstArgumentTreeItem});

    QCOMPARE(additionTreeItem.value(std::vector<double>{1.2}), nan(""));

    // Variable with one argument

    auto variableEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::VariableNode(0));
    datamodel::EquationTreeItem variableTreeItem(variableEquationNode);

    variableTreeItem.setArguments(std::vector<datamodel::EquationTreeItem>{firstArgumentTreeItem});

    QCOMPARE(variableTreeItem.value(std::vector<double>{1.2}), nan(""));
}

void Test_EquationTreeItem::value_infOrNan()
{
    auto cosinusEquationNode = std::shared_ptr<datamodel::EquationNode>(new datamodel::CosinusNode());
    datamodel::EquationTreeItem cosinusTreeItem(cosinusEquationNode);

    auto divisionEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::DivisionNode());
    datamodel::EquationTreeItem divisionTreeItem(divisionEquationNode);

    auto denominatorNode = std::shared_ptr<datamodel::EquationNode>(new datamodel::VariableNode(0));
    datamodel::EquationTreeItem denominatorTreeItem(denominatorNode);

    auto numeratorNode = std::shared_ptr<datamodel::EquationNode>(new datamodel::ConstantNode(4));
    datamodel::EquationTreeItem numeratorTreeItem(numeratorNode);

    divisionTreeItem.setArguments(
        std::vector<datamodel::EquationTreeItem>{numeratorTreeItem, denominatorTreeItem});

    cosinusTreeItem.setArguments(std::vector<datamodel::EquationTreeItem>{divisionTreeItem});

    QCOMPARE(divisionTreeItem.value(std::vector<double>{std::numeric_limits<double>::infinity()}), nan(""));

    QCOMPARE(divisionTreeItem.value(std::vector<double>{0}), nan(""));
}

void Test_EquationTreeItem::value_division()
{
    auto divisionEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::DivisionNode());
    datamodel::EquationTreeItem divisionTreeItem(divisionEquationNode);

    auto denominatorNode = std::shared_ptr<datamodel::EquationNode>(new datamodel::VariableNode(0));
    datamodel::EquationTreeItem denominatorTreeItem(denominatorNode);

    auto numeratorNode = std::shared_ptr<datamodel::EquationNode>(new datamodel::ConstantNode(4));
    datamodel::EquationTreeItem numeratorTreeItem(numeratorNode);

    divisionTreeItem.setArguments(
        std::vector<datamodel::EquationTreeItem>{numeratorTreeItem, denominatorTreeItem});

    QCOMPARE(divisionTreeItem.value(std::vector<double>{2}), 2);

    QCOMPARE(divisionTreeItem.value(std::vector<double>{0}), nan(""));
}

void Test_EquationTreeItem::value_multiplication()
{
    // equation 2 * 0.5
    auto multiplicationEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::MultiplicationNode());
    datamodel::EquationTreeItem multiplicationTreeItem(multiplicationEquationNode);

    auto firstArgumentEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::VariableNode(0));
    datamodel::EquationTreeItem firstArgumentTreeItem(firstArgumentEquationNode);

    auto secondArgumentEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::ConstantNode(0.5));
    datamodel::EquationTreeItem secondArgumentTreeItem(secondArgumentEquationNode);

    multiplicationTreeItem.setArguments(
        std::vector<datamodel::EquationTreeItem>{firstArgumentTreeItem, secondArgumentTreeItem});

    QCOMPARE(multiplicationTreeItem.value(std::vector<double>{2}), 1);
}

void Test_EquationTreeItem::value_soustraction()
{
    // Simple equation : x - 3.14

    auto soustractionEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::SoustractionNode());
    datamodel::EquationTreeItem soustractionTreeItem(soustractionEquationNode);

    auto firstArgumentEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::VariableNode(0));
    datamodel::EquationTreeItem firstArgumentTreeItem(firstArgumentEquationNode);

    auto secondArgumentEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::ConstantNode(3.14));
    datamodel::EquationTreeItem secondArgumentTreeItem(secondArgumentEquationNode);

    soustractionTreeItem.setArguments(
        std::vector<datamodel::EquationTreeItem>{firstArgumentTreeItem, secondArgumentTreeItem});

    QCOMPARE(soustractionTreeItem.value(std::vector<double>{2}), -1.14);
}

void Test_EquationTreeItem::value_addition()
{
    // Simple equation : x + 3.5

    auto additionEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::AdditionNode());
    datamodel::EquationTreeItem additionTreeItem(additionEquationNode);

    auto firstArgumentEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::VariableNode(0));
    datamodel::EquationTreeItem firstArgumentTreeItem(firstArgumentEquationNode);

    auto secondArgumentEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::ConstantNode(3.5));
    datamodel::EquationTreeItem secondArgumentTreeItem(secondArgumentEquationNode);

    additionTreeItem.setArguments(
        std::vector<datamodel::EquationTreeItem>{firstArgumentTreeItem, secondArgumentTreeItem});

    QCOMPARE(additionTreeItem.value(std::vector<double>{1.2}), 4.7);
}

void Test_EquationTreeItem::value_power()
{
    auto powerEquationNode = std::shared_ptr<datamodel::EquationNode>(new datamodel::PowerNode());
    datamodel::EquationTreeItem powerTreeItem(powerEquationNode);

    auto firstArgumentEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::VariableNode(0));
    datamodel::EquationTreeItem firstArgumentTreeItem(firstArgumentEquationNode);

    auto secondArgumentEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::ConstantNode(3));
    datamodel::EquationTreeItem secondArgumentTreeItem(secondArgumentEquationNode);

    powerTreeItem.setArguments(
        std::vector<datamodel::EquationTreeItem>{firstArgumentTreeItem, secondArgumentTreeItem});

    QCOMPARE(powerTreeItem.value(std::vector<double>{2}), 8);
}

void Test_EquationTreeItem::value_rootsquare()
{
    auto rootsquareEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::SquareRootNode());
    datamodel::EquationTreeItem rootsquareTreeItem(rootsquareEquationNode);

    auto firstArgumentEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::VariableNode(0));
    datamodel::EquationTreeItem firstArgumentTreeItem(firstArgumentEquationNode);

    rootsquareTreeItem.setArguments(std::vector<datamodel::EquationTreeItem>{firstArgumentTreeItem});

    QCOMPARE(rootsquareTreeItem.value(std::vector<double>{9}), 3);
}

void Test_EquationTreeItem::value_min()
{
    auto minEquationNode = std::shared_ptr<datamodel::EquationNode>(new datamodel::MinNode());
    datamodel::EquationTreeItem minTreeItem(minEquationNode);

    auto firstArgumentEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::VariableNode(0));
    datamodel::EquationTreeItem firstArgumentTreeItem(firstArgumentEquationNode);

    auto secondArgumentEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::ConstantNode(-13));
    datamodel::EquationTreeItem secondArgumentTreeItem(secondArgumentEquationNode);

    minTreeItem.setArguments(
        std::vector<datamodel::EquationTreeItem>{firstArgumentTreeItem, secondArgumentTreeItem});

    QCOMPARE(minTreeItem.value(std::vector<double>{-2.5}), -13);
}

void Test_EquationTreeItem::value_max()
{
    auto maxEquationNode = std::shared_ptr<datamodel::EquationNode>(new datamodel::MaxNode());
    datamodel::EquationTreeItem maxTreeItem(maxEquationNode);

    auto firstArgumentEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::VariableNode(0));
    datamodel::EquationTreeItem firstArgumentTreeItem(firstArgumentEquationNode);

    auto secondArgumentEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::ConstantNode(2));
    datamodel::EquationTreeItem secondArgumentTreeItem(secondArgumentEquationNode);

    maxTreeItem.setArguments(
        std::vector<datamodel::EquationTreeItem>{firstArgumentTreeItem, secondArgumentTreeItem});

    QCOMPARE(maxTreeItem.value(std::vector<double>{-50}), 2);
}

void Test_EquationTreeItem::findParent(){
    //Create values needed by the future equations to test
    datamodel::EquationTreeItem constant1(std::shared_ptr<datamodel::EquationNode>(new datamodel::ConstantNode(1)));
    datamodel::EquationTreeItem variableNode(std::shared_ptr<datamodel::EquationNode>(new datamodel::VariableNode(0)));
    auto additionNode2Arg = std::shared_ptr<datamodel::EquationNode>(new datamodel::AdditionNode());

    // Create the equation (1 + X)
    datamodel::EquationTreeItem additionTree(additionNode2Arg);
    additionTree.setArguments(std::vector<datamodel::EquationTreeItem>{constant1, variableNode});

    datamodel::EquationTreeItem* parent = additionTree.findParent(variableNode.currentNode());

    QCOMPARE(*parent, additionTree);
}

QTEST_APPLESS_MAIN(Test_EquationTreeItem)

#include "Test_EquationTreeItem.moc"
