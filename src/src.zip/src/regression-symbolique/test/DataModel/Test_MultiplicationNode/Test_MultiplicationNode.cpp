#include <QTest>

#include <DataModel/MultiplicationNode.h>
#include <DataModel/ConstantNode.h>
#include <DataModel/VariableNode.h>

class Test_MultiplicationNode : public QObject
{
    Q_OBJECT

  public:
      Test_MultiplicationNode() = default;

  private slots:
      void calculateValue();

};



void Test_MultiplicationNode::calculateValue()
{
    auto currentEquationNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::MultiplicationNode(3));
    datamodel::EquationTreeItem currentTreeItem(currentEquationNode);
	
	auto variableNode = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::VariableNode(0));
    datamodel::EquationTreeItem variableTreeItem(variableNode);

    auto constantNode10 = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::ConstantNode(10));
    datamodel::EquationTreeItem constantTreeItem10(constantNode10);

    auto constantNode2 = std::shared_ptr<datamodel::EquationNode>(
        new datamodel::ConstantNode(2));
    datamodel::EquationTreeItem constantTreeItem2(constantNode2);

    currentTreeItem.setArguments(std::vector<datamodel::EquationTreeItem>{constantTreeItem2, variableTreeItem, constantTreeItem10});

    // compare

    QCOMPARE(currentTreeItem.value(std::vector<double>{5}), 100);

}

QTEST_APPLESS_MAIN(Test_MultiplicationNode)

#include "Test_MultiplicationNode.moc"
