#include "EquationTree.h"
#include "Utils/ComparisonUtils.h"
#include <QDebug>
namespace datamodel {
EquationTree::EquationTree() {}

EquationTree::EquationTree(const EquationTreeItem root, double distanceR2, double distanceMSE,
                           std::string structureIdHash, int totalNode, int paretoLevel)
    : _root(root),
      _distanceR2(distanceR2),
      _distanceMSE(distanceMSE),
      _structureIdHash(structureIdHash),
      _totalNode(totalNode),
      _paretoLevel(paretoLevel),
      _was_fitted(false)
{
}
EquationTree::EquationTree(const EquationTree &other)
    : _root(other._root),
      _distanceToUse(other._distanceToUse),
      _distanceR2(other._distanceR2),
      _distanceMSE(other._distanceMSE),
      _structureIdHash(other._structureIdHash),
      _totalNode(other._totalNode),
      _complexity(other._complexity),
      _age(other._age),
      _paretoLevel(other._paretoLevel),
      _generation(other._generation),
      _was_fitted(other._was_fitted),
      _is_simple(other._is_simple),
      _is_stat_simple(other._is_stat_simple),
      _nbVar(other._nbVar),
      _efficiency(other._efficiency)
{
}

bool EquationTree::operator==(const EquationTree &other) const {
  return root() == other.root() && distanceMSE() == other.distanceMSE() && distanceR2() == other.distanceR2() &&
         totalNode() == other.totalNode() && structureIdHash() == other.structureIdHash();
}

bool EquationTree::operator!=(const EquationTree &other) const {
  return !operator==(other);
}

EquationTreeItem EquationTree::root() const { return _root; }

EquationTreeItem &EquationTree::rootRef() { return _root; }

double EquationTree::distance() const
{
    switch(_distanceToUse){
        case equationparameters::EquationDistanceParameters::R2:
            return distanceR2();
        case equationparameters::EquationDistanceParameters::MSE:
            return distanceMSE();
        default:
            return distanceR2();
    }
}

equationparameters::EquationDistanceParameters::EquationDistance EquationTree::distanceToUse() const
{
    return _distanceToUse;
}

void EquationTree::setDistanceToUse(equationparameters::EquationDistanceParameters::EquationDistance distanceToUse)
{
    _distanceToUse = distanceToUse;
}

double EquationTree::distanceR2() const { return _distanceR2; }

double EquationTree::distanceMSE() const { return _distanceMSE; }

void EquationTree::setDistanceR2(double distanceR2) { _distanceR2 = distanceR2; }

void EquationTree::setDistanceMSE(double distanceMSE) { _distanceMSE = distanceMSE; }

int EquationTree::generation() const { return _generation; }

void EquationTree::setGeneration(int gen) { _generation = gen; }

std::string EquationTree::structureIdHash() const { return _structureIdHash; }

void EquationTree::setStructureIdHash(std::string structureIdHash) { _structureIdHash = structureIdHash; }

int EquationTree::totalNode() const { return _totalNode; }

int EquationTree::complexity() const { return _complexity; }

void EquationTree::setTotalNode(int totalNode) { _totalNode = totalNode; }

void EquationTree::setComplexity(int complexity) { _complexity = complexity; }

int EquationTree::paretoLevel() const { return _paretoLevel; }

void EquationTree::setParetoLevel(int paretoLevel) { _paretoLevel = paretoLevel; }

double EquationTree::age() const { return _age; }

void EquationTree::setAge(double age) { _age = age; }

uint EquationTree::numberOfVariables() const { return _nbVar; }

void EquationTree::setNumberOfVariables(uint nbVar) { _nbVar = nbVar; }

double EquationTree::efficiency() const { return _efficiency; }

void EquationTree::setEfficiency(double efficiency) { _efficiency = efficiency; }

void EquationTree::setFitted(bool fitted) {
    _was_fitted = fitted;
}

bool EquationTree::compareDistance(const EquationTree& other) const {
    if(utils::lessThan(this->distance(),other.distance())){
        return true;
    }else if(this->distance() == other.distance()){
        if(utils::lessThan(this->complexity(),other.complexity())){
            return true;
        }else if(this->complexity() == other.complexity()){
            return this->paretoLevel() < other.paretoLevel();
        }
        return false;
    }
    return false;
}

bool EquationTree::compareParetoComplexity(const EquationTree& other) const {
    if(utils::lessThan(this->complexity(), other.complexity())){
        return true;
    }else if(this->complexity() == other.complexity()){
        if(this->paretoLevel() < other.paretoLevel()){
            return true;
        }else if(this->paretoLevel() == other.paretoLevel()){
            return utils::lessThan(this->distance(),other.distance());
        }
        return false;
    }
    return false;
}

bool EquationTree::compareParetoDistance(const EquationTree& other) const {
    if(this->paretoLevel() < other.paretoLevel()){
        return true;
    }else if(this->paretoLevel() == other.paretoLevel()){
        if(utils::lessThan(this->distance(),other.distance())){
            return true;
        }else if(this->distance() == other.distance()){
            return utils::lessThan(this->complexity(), other.complexity());
        }
        return false;
    }
    return false;
}

bool EquationTree::compareParetoAge(const EquationTree& other) const {
    if(utils::lessThan(this->age(), other.age())){
        return true;
    }else if(this->age() == other.age()){
        if(this->paretoLevel() < other.paretoLevel()){
            return true;
        }else if(this->paretoLevel() == other.paretoLevel()){
            return utils::lessThan(this->distance(),other.distance());
        }
        return false;
    }
    return false;
}
EquationTree& EquationTree::operator=(const EquationTree &other) {//L-value
    this->_root = other._root;
    this->_distanceToUse = other._distanceToUse;
    this->_distanceR2 = other._distanceR2;
    this->_distanceMSE = other._distanceMSE;
    this->_structureIdHash = other._structureIdHash;
    this->_totalNode = other._totalNode;
    this->_complexity = other._complexity;
    this->_age = other._age;
    this->_paretoLevel = other._paretoLevel;
    this->_generation = other._generation;
    this->_was_fitted = other._was_fitted;
    this->_is_simple = other._is_simple;
    this->_is_stat_simple = other._is_stat_simple;
    this->_nbVar = other._nbVar;
    this->_efficiency = other._efficiency;
    return *this;
}

EquationTree& EquationTree::operator=(EquationTree &&other) noexcept {//R-value
    if (&other != this) {
        this->_root = std::move(other._root);
        this->_distanceToUse = other._distanceToUse;
        this->_distanceR2 = other._distanceR2;
        this->_distanceMSE = other._distanceMSE;
        this->_structureIdHash = std::move(other._structureIdHash);
        this->_totalNode = other._totalNode;
        this->_complexity = other._complexity;
        this->_age = other._age;
        this->_paretoLevel = other._paretoLevel;
        this->_generation = other._generation;
        this->_was_fitted = other._was_fitted;
        this->_is_simple = other._is_simple;
        this->_is_stat_simple = other._is_stat_simple;
        this->_nbVar = other._nbVar;
        this->_efficiency = other._efficiency;
    }
    return *this;
}

}  // namespace datamodel
