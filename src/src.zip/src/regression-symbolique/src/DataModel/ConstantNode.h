
#pragma once

#include "EquationNode.h"

namespace datamodel
{
/**
 * @brief The ConstantNode class ??
 */
class ConstantNode : public EquationNode
{
   public:
    ConstantNode(double value);
    ~ConstantNode() override = default;

    // setter
    void setValue(double value);

    // see EquationNode.h definition
    unsigned short int nbArguments() const override;
    NodeType type() const override;
    NodeCategory category() const override;
    std::shared_ptr<EquationNode> clone() const override;
    bool operator==(const EquationNode &other) const override;
    bool operator!=(const EquationNode &other) const override;
    std::string toString() const override;
    std::string toLabel() override;

   protected:
    // see EquationNode.h definition
    double calculateValue(const std::vector<double> &variableValues, const std::vector<EquationTreeItem> &arguments) const override;

   private:
    //Q_DISABLE_COPY_MOVE(ConstantNode)
    /**
     * @brief The constant value
     */
    double _value;
};
}  // namespace datamodel
