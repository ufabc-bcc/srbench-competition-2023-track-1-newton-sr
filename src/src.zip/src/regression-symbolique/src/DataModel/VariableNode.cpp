#include "VariableNode.h"
#include "FileReaderWriter/FileReaderWriter_global.h"

namespace datamodel {

VariableNode::VariableNode(uint index) : _varIndex(index) {}

unsigned short int VariableNode::nbArguments() const { return 0; }

EquationNode::NodeType VariableNode::type() const { return NodeType::Variable; }

EquationNode::NodeCategory VariableNode::category() const { return NodeCategory::Terminal; }

std::shared_ptr<EquationNode> VariableNode::clone() const {
    return std::shared_ptr<EquationNode>(new VariableNode(_varIndex));
}

std::string VariableNode::toString() const {
    return std::string("x") + std::to_string(_varIndex);
}

std::string VariableNode::toLabel() {
    if(_varIndex < g_lineData.size())
        return g_lineData[_varIndex];
    else
        return toString();
}

double VariableNode::calculateValue(const std::vector<double> &variableValues,
                                    const std::vector<EquationTreeItem> &arguments) const {
    (void)variableValues;
    (void)arguments;
    return variableValues.at(_varIndex);
}

} // namespace datamodel
