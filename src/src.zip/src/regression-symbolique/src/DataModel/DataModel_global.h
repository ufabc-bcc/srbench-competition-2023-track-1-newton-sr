#pragma once

#include <QtCore/qglobal.h>

//namespace datamodel
//{
//namespace global
//{
      // kDefaultEquationNumber ne semble pas être utilisé
//    constexpr int kDefaultEquationNumber = 500;
//}
//}
