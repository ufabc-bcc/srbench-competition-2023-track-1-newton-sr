#include "MultiplicationNode.h"

namespace datamodel {

MultiplicationNode::MultiplicationNode(const unsigned short int &nbArguments) :
    _nbArguments{nbArguments}
{}

unsigned short int MultiplicationNode::nbArguments() const {
    return _nbArguments;
}

void MultiplicationNode::setNbArguments(const unsigned short int &nbArguments) {
    _nbArguments = nbArguments;
}

EquationNode::NodeType MultiplicationNode::type() const {
    return NodeType::Multiplication;
}

EquationNode::NodeCategory MultiplicationNode::category() const { return NodeCategory::Commutative; }

std::shared_ptr<EquationNode> MultiplicationNode::clone() const {
    return std::shared_ptr<EquationNode>(new MultiplicationNode(_nbArguments));
}

std::string MultiplicationNode::toString() const { return "*"; }
std::string MultiplicationNode::toLabel() { return "*"; }

double MultiplicationNode::calculateValue(const std::vector<double> &variableValues,
                                          const std::vector<EquationTreeItem> &arguments) const {
    double value = 1.;
    for(const EquationTreeItem& argument : arguments)
        value *= argument.value(variableValues);
    return value;
}

} // namespace datamodel
