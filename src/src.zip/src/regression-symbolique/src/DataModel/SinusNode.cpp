#include "SinusNode.h"

#include <cmath>

namespace datamodel {
unsigned short int SinusNode::nbArguments() const { return 1; }

EquationNode::NodeType SinusNode::type() const { return NodeType::Sinus; }

EquationNode::NodeCategory SinusNode::category() const { return NodeCategory::Function; }

std::shared_ptr<EquationNode> SinusNode::clone() const {
    return std::shared_ptr<EquationNode>(new SinusNode());
}

std::string SinusNode::toString() const { return "sin"; }
std::string SinusNode::toLabel() { return "sin"; }

double SinusNode::calculateValue(const std::vector<double> &variableValues,
                                 const std::vector<EquationTreeItem> &arguments) const {
    return sin(arguments.at(0).value(variableValues));
}

} // namespace datamodel
