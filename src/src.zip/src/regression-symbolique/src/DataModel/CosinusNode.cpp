#include "CosinusNode.h"

#include <cmath>

namespace datamodel
{
unsigned short int CosinusNode::nbArguments() const { return 1; }

EquationNode::NodeType CosinusNode::type() const { return NodeType::Cosinus; }

EquationNode::NodeCategory CosinusNode::category() const { return NodeCategory::Function; }

std::shared_ptr<EquationNode> CosinusNode::clone() const {
    return std::shared_ptr<EquationNode>(new CosinusNode());
}

std::string CosinusNode::toString() const { return "cos"; }
std::string CosinusNode::toLabel() { return "cos"; }

double CosinusNode::calculateValue(const std::vector<double> &variableValues,
                                   const std::vector<EquationTreeItem> &arguments) const {
    return cos(arguments.at(0).value(variableValues));//refactoring
}
}  // namespace datamodel
