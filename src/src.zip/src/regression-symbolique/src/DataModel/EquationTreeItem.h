
#pragma once

#include <QSharedData>

#include <memory>
#include <unordered_map>


namespace datamodel
{
class EquationNode;
class EquationTreeItemData;

/*!
 * @brief The class representing an equation. An equation is represented by it's current node and his arguments list (his children).
 * This objects are share a lot in the application so to optimize
 * performances we use the qt implicit sharing mecanism, it will simplify a lot the management of the data
 */
class EquationTreeItem
{
   public:
    /*!
     * @brief Create a new instance of an empty equation tree item
     */
    EquationTreeItem();

    /*!
     * @brief Create a new instance of equation tree item and set the given node as current node
     * @param currentNode the node to set as current
     */
    explicit EquationTreeItem(const std::shared_ptr<EquationNode> &currentNode);

    /*!
     * @brief Create a new instance of equation tree item by copying the given equation tree item, the current node
     * is clone so the pointer is not shared
     * @param other the equation tree item to copy
     */
    EquationTreeItem(const EquationTreeItem &other);

    /*!
     *  Destructor
     */
    ~EquationTreeItem() = default;

    /*!
     * @brief Copy the given equation tree item into this, the current node is clone so the pointer is not shared
     * @param other the equation tree item to copy
     * @return a reference on the copied object
     */
    EquationTreeItem &operator=(const EquationTreeItem &other);
    EquationTreeItem &operator=(EquationTreeItem &&other) noexcept;

    bool operator==(const EquationTreeItem &other) const;
    bool operator!=(const EquationTreeItem &other) const;

    std::shared_ptr<EquationNode> currentNode() const;
    void setCurrentNode(const std::shared_ptr<EquationNode> &currentNode);

    int depth() const;

    float variance();
    void setVariance(const float variance);

    const std::vector<EquationTreeItem> &arguments() const;
    std::vector<EquationTreeItem> &arguments();
    void setArguments(const std::vector<EquationTreeItem> &arguments);

    double value(const std::vector<double> &variableValues) const;

    bool isEmpty() const;
    double totalConstantValue();
    bool isValid(const std::vector<double> &variableValues) const;
    bool containsDivision(const std::vector<double> &variableValues) const;

    /**
     * @brief findParent Find the parent of the datamodel::EquationTreeItem node
     * @param node The node that will have his parent found
     * @return The parent of the node, if the parent is not found return nullptr
     */
    datamodel::EquationTreeItem* findParent(const std::shared_ptr<datamodel::EquationNode>& node);


   private:
    /* Cas particulier de QSharedDataPointer& de QSharedData
     * *****************************************************
     *
     * Se référer à la documentation RefactorisationQSharedDataPointer.docx
     * se trouvant à l'emplacement réseau dossier Thomas de Coincy
     *
     * \\sf1coeur\SHT-RD-PRODUCTION\Production\RnI_Maint_Pred\05-Espace_contributeurs\2022\Thomas de Coincy\refactoring_QSharedDataPointer
     */

    QSharedDataPointer<EquationTreeItemData> _sharedDataPointer;
};

class EquationTreeItemData : public QSharedData
{
   public:
    EquationTreeItemData();
    explicit EquationTreeItemData(const std::shared_ptr<EquationNode> &currentNode);
    EquationTreeItemData(const EquationTreeItemData &other);

    EquationTreeItemData &operator=(const EquationTreeItemData &other);

    ~EquationTreeItemData() = default;

    std::shared_ptr<EquationNode> currentNode;
    std::vector<EquationTreeItem> arguments;

    int depth = 0;
    float variance = 1.0;
};
}  // namespace datamodel
