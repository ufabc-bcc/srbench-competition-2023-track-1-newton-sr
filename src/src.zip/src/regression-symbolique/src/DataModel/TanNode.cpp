#include "TanNode.h"
#include "EquationTreeItem.h"

//refactoring #include <QtMath>
#include <cmath> //refactoring

namespace datamodel {
unsigned short int TanNode::nbArguments() const { return 1; }

EquationNode::NodeType TanNode::type() const { return NodeType::Tan; }

EquationNode::NodeCategory TanNode::category() const { return NodeCategory::Function; }

std::shared_ptr<EquationNode> TanNode::clone() const {
    return std::shared_ptr<EquationNode>(new TanNode());
}

std::string TanNode::toString() const { return "tan"; }
std::string TanNode::toLabel() { return "tan"; }

double TanNode::calculateValue(const std::vector<double> &variableValues,
                               const std::vector<EquationTreeItem> &arguments) const {
    return tan(arguments.at(0).value(variableValues));
}

} // namespace datamodel
