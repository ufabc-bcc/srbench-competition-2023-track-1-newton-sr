#include "AbsoluteNode.h"

#include <cmath>

namespace datamodel
{
unsigned short int AbsoluteNode::nbArguments() const { return 1; }

EquationNode::NodeType AbsoluteNode::type() const { return NodeType::Absolute; }

EquationNode::NodeCategory AbsoluteNode::category() const { return NodeCategory::Function; }

std::shared_ptr<EquationNode> AbsoluteNode::clone() const {
    return std::shared_ptr<EquationNode>(new AbsoluteNode());
}

std::string AbsoluteNode::toString() const { return "Abs"; }
std::string AbsoluteNode::toLabel() { return "Abs"; }

double AbsoluteNode::calculateValue(const std::vector<double> &variableValues,
                                    const std::vector<EquationTreeItem> &arguments) const {
    return fabs(arguments.at(0).value(variableValues));
}

}  // namespace datamodel
