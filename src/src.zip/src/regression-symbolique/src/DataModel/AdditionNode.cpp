#include "AdditionNode.h"

namespace datamodel {

AdditionNode::AdditionNode(const unsigned short int &nbArguments) :
    _nbArguments{nbArguments}
{}

unsigned short int AdditionNode::nbArguments() const {
    return _nbArguments;
}

void AdditionNode::setNbArguments(const unsigned short int &nbArguments)
{
    _nbArguments = nbArguments;
}

EquationNode::NodeType AdditionNode::type() const { return NodeType::Addition; }

EquationNode::NodeCategory AdditionNode::category() const { return NodeCategory::Commutative; }

std::shared_ptr<EquationNode> AdditionNode::clone() const {
    return std::shared_ptr<EquationNode>(new AdditionNode(_nbArguments));
}

std::string AdditionNode::toString() const { return "+"; }
std::string AdditionNode::toLabel() { return "+"; }

double AdditionNode::calculateValue(const std::vector<double> &variableValues,
                                    const std::vector<EquationTreeItem> &arguments) const {
    double value = 0.;
    for(const EquationTreeItem& argument : arguments)
        value += argument.value(variableValues);
    return value;
}

} // namespace datamodel
