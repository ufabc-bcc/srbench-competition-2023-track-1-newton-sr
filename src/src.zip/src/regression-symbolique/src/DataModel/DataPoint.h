
#pragma once

#include <QMetaType>

#include "DataModel_global.h"

#include <vector>
#include <cmath>


namespace datamodel
{
/**
 * @brief The DataPoint class
 */
class DataPoint
{
   public:
    // constructors
    DataPoint() = default;
    DataPoint(std::vector<double> parameterList, double result);

    // getter / setter
    std::vector<double> parameterList() const;
    double parameterList(const int position) const;
    void setParameterList(const std::vector<double> parameterList);
    double parameterValue(const int position) const;
    void addToParameterValue(double parameterList);
    double result() const;
    void setResult(double result);

    uint getNumberOfVariables() const;
    // comparison operators
    bool operator==(const DataPoint &dataPoint) const;
    bool operator!=(const DataPoint &dataPoint) const;

   private:
    /**
     * @brief ??
     */
    std::vector<double> _parameterList;
    /**
     * @brief ??
     */
    double _result = nan("");
    /**
     * @brief ??
     */
};
}  // namespace datamodel

Q_DECLARE_METATYPE(datamodel::DataPoint)
