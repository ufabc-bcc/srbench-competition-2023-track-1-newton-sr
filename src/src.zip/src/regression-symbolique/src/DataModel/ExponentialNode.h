
#pragma once

#include "EquationNode.h"

namespace datamodel
{
/**
 * @brief The ExponentialNode class handle the exponentielle nodes
 */
class ExponentialNode : public EquationNode
{
   public:
    ExponentialNode() = default;
    ~ExponentialNode() override = default;

    // see EquationNode.h definition
    unsigned short int nbArguments() const override;
    NodeType type() const override;
    NodeCategory category() const override;
    std::shared_ptr<EquationNode> clone() const override;
    std::string toString() const override;
    std::string toLabel() override;

   protected:
    // see EquationNode.h definition
    double calculateValue(const std::vector<double> &variableValues, const std::vector<EquationTreeItem> &arguments) const override;

   private:
    ////Q_DISABLE_COPY_MOVE(ExponentialNode)
};
}  // namespace datamodel
