#pragma once

#include "EquationNode.h"

namespace datamodel
{
/**
 * @brief The AdditionNode handle the addition
 */
class AdditionNode : public EquationNode
{
   public:
    AdditionNode() = default;
    AdditionNode(const unsigned short int &nbArguments);
    ~AdditionNode() override = default;

    // see EquationNode.h definition
    unsigned short int nbArguments() const override;
    void setNbArguments(const unsigned short int &nbArguments) override;
    NodeType type() const override;
    NodeCategory category() const override;
    std::shared_ptr<EquationNode> clone() const override;
    std::string toString() const override;
    std::string toLabel() override;

   protected:
    // see EquationNode.h definition
    double calculateValue(const std::vector<double> &variableValues, const std::vector<EquationTreeItem> &arguments) const override;

   private:
    unsigned short int _nbArguments{2};
    //Q_DISABLE_COPY_MOVE(AdditionNode)
};
}  // namespace datamodel
