#include "ArctanNode.h"

#include <cmath>

namespace datamodel
{
unsigned short int ArctanNode::nbArguments() const { return 1; }

EquationNode::NodeType ArctanNode::type() const { return NodeType::Arctan; }

EquationNode::NodeCategory ArctanNode::category() const { return NodeCategory::Function; }

std::shared_ptr<EquationNode> ArctanNode::clone() const {
    return std::shared_ptr<EquationNode>(new ArctanNode());
}

std::string ArctanNode::toString() const { return "atan"; }
std::string ArctanNode::toLabel() { return "atan"; }

double ArctanNode::calculateValue(const std::vector<double> &variableValues,
                                  const std::vector<EquationTreeItem> &arguments) const {
    return atan(arguments.at(0).value(variableValues));
}

}  // namespace datamodel
