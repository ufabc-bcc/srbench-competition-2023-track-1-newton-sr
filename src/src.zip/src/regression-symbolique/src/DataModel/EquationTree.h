#pragma once

#include "EquationTreeItem.h"
#include "EquationParameters/EquationDistanceParameters.h"

// STL
#include <vector>
#include <array>
#include <memory>

namespace datamodel {

/*!
 * @brief The class representing a complete equation and extra data about it
 */
class EquationTree {
 public:
  EquationTree();
  EquationTree(const EquationTreeItem root, double distanceR2 = 0, double distanceMSE = 0,
               std::string structureIdHash = "", int totalNode = 0, int paretoLevel = -2);
  EquationTree(const EquationTree &other);
  ~EquationTree() = default;
  bool operator==(const EquationTree &other) const;
  bool operator!=(const EquationTree &other) const;
  EquationTreeItem root() const;
  EquationTreeItem &rootRef();

  /**
   * @brief This function return the distance depending of the user selected option
   * @return the distance selected by the user
   */
  double distance() const;
  equationparameters::EquationDistanceParameters::EquationDistance distanceToUse() const;
  void setDistanceToUse(equationparameters::EquationDistanceParameters::EquationDistance distanceToUse);
  double distanceR2() const;
  void setDistanceR2(double distanceR2);
  double distanceMSE() const;
  void setDistanceMSE(double distanceMSE);
  int generation() const;
  void setGeneration(int gen);
  std::string structureIdHash() const;
  void setStructureIdHash(std::string structureIdHash);
  int totalNode() const;
  int complexity() const;
  void setTotalNode(int totalNode);
  void setComplexity(int complexity);
  int paretoLevel() const;
  void setParetoLevel(int paretoLevel);
  double age() const;
  void setAge(double age);
  uint numberOfVariables() const;
  void setNumberOfVariables(uint nbVar);
  double efficiency() const;
  void setEfficiency(double efficiency);

  bool was_fitted() const noexcept {
      return _was_fitted;
  }
  bool& was_fitted() noexcept {
      return _was_fitted;
  }

  void setFitted(bool fitted);

  // simple as in simplified (ie : <non simple> (((x + 3) - x) + 2) == (x + 5) <simple>)
  bool is_simple() const noexcept {
      return _is_simple;
  }
  bool& is_simple() noexcept {
      return _is_simple;
  }

  // stat_simple as in statistics simplification (ie : <non simple> (((x + 3) - x) + 2) == (x + 5) <simple>)
  bool is__stat_simple() const noexcept {
      return _is_stat_simple;
  }
  bool& is_stat_simple() noexcept {
      return _is_stat_simple;
  }

  /**
   * @brief Compare two equations with their distance
   * @param other equation to compare with
   * @return true if this distance is less than other distance
   */
  bool compareDistance(const EquationTree& other) const;

  /**
   * @brief Compare two equations with their complexity
   * @param other equation to compare with
   * @return true if this complexity is less than other complexity
   */
  bool compareParetoComplexity(const EquationTree& other) const;

  /**
   * @brief Compare two equations with their pareto level
   * @param other equation to compare with
   * @return true if this pareto level is less than other pareto level
   */
  bool compareParetoDistance(const EquationTree& other) const;

  /**
   * @brief Compare two equations with their age generation
   * @param other equation to compare with
   * @return true if this age is less than other age
   */
  bool compareParetoAge(const EquationTree& other) const;

  EquationTree& operator=(const EquationTree &other); //L-value
  EquationTree& operator=(EquationTree &&other) noexcept; //R-value

 private:
  EquationTreeItem _root;
  equationparameters::EquationDistanceParameters::EquationDistance _distanceToUse{equationparameters::EquationDistanceParameters::R2};
  double _distanceR2 = 0;
  double _distanceMSE = 0;
  std::string _structureIdHash = "";
  int _totalNode = 0;
  double _complexity = 0;
  double _age = 0;
  int _paretoLevel = -2;
  int _generation = 0;
  bool _was_fitted = false;
  bool _is_simple = false; // simple as in simplified (ie : <non simple> (((x + 3) - x) + 2) == (x + 5) <simple>
  bool _is_stat_simple = false;
  uint _nbVar = 0; // number of different variables in the equation
  double _efficiency = 1.0;
};

/**
 * @brief Equations convenient typedef, a map of the identifier of the equations
 * (to be able to follow their evolution) and the equation
 */
typedef std::vector<EquationTree> Equations;

}  // namespace datamodel
