#include "SquareRootNode.h"

#include <cmath>

namespace datamodel {
unsigned short int SquareRootNode::nbArguments() const { return 1; }

EquationNode::NodeType SquareRootNode::type() const { return NodeType::SquareRoot; }

EquationNode::NodeCategory SquareRootNode::category() const { return NodeCategory::Function; }

std::shared_ptr<EquationNode> SquareRootNode::clone() const {
    return std::shared_ptr<EquationNode>(new SquareRootNode());
}

std::string SquareRootNode::toString() const { return "sqrt"; }
std::string SquareRootNode::toLabel() { return "sqrt"; }

double SquareRootNode::calculateValue(const std::vector<double> &variableValues,
                                      const std::vector<EquationTreeItem> &arguments) const {
    return sqrt(arguments.at(0).value(variableValues));
}

}// namespace datamodel
