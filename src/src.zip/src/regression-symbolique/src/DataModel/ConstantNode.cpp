#include "ConstantNode.h"

namespace datamodel {

ConstantNode::ConstantNode(double value) : _value(value) {}

unsigned short int ConstantNode::nbArguments() const { return 0; }

EquationNode::NodeType ConstantNode::type() const {
    return NodeType::Constant;
}

EquationNode::NodeCategory ConstantNode::category() const { return NodeCategory::Terminal; }

void ConstantNode::setValue(double value) {
    _value = value;
}

std::shared_ptr<EquationNode> ConstantNode::clone() const {
    return std::shared_ptr<EquationNode>(new ConstantNode(_value));
}

std::string ConstantNode::toString() const { return std::to_string(_value); }
std::string ConstantNode::toLabel() { return std::to_string(_value); }

bool ConstantNode::operator==(const EquationNode &other) const {
    return EquationNode::operator==(other)
           && _value == static_cast<const ConstantNode &>(other)._value;
}

bool ConstantNode::operator!=(const EquationNode &other) const {
    return !operator==(other);
}

double ConstantNode::calculateValue(const std::vector<double> &variableValues,
                                    const std::vector<EquationTreeItem> &arguments) const {
//    Q_UNUSED(variableValues)
//    Q_UNUSED(arguments)
    (void)variableValues;
    (void)arguments;
    return _value;
}

} // namespace datamodel
