#pragma once

#include <vector>
#include <memory>
#include "EquationTreeItem.h"

namespace datamodel
{
/*!
 * @brief Abstract class defining an equation node, a node is defined by a type, a value and a number of arguments
 */
class EquationNode
{   
   public:
    /**
     * @brief All the possible node types
     * Always put Last = <thelastvalue> in this way we can always know the number of defined node type and add new
     * node without changing all the code
     */
    enum NodeType
    {
        Variable = 0,
        Constant,
        Addition,
        Soustraction,
        Multiplication,
        Division,
        Cosinus,
        Sinus,
        Logarithm,
        Exponential,
        Power,
        SquareRoot,
        Inverse,
        Arctan,
        Negative,
        Min,
        Max,
        Absolute,
        Tan,
        Last = Tan
    };

    /**
     * @brief The Category enum regroup node types in their specific category
     */
    enum class NodeCategory
    {
        Terminal = 0,
        Commutative,
        NonCommutative,
        MinMax,
        Function,
        Last = Function
    };


    EquationNode() = default;
    virtual ~EquationNode() = default;

    /**
     * @brief Provide the number of argument of the node (E.g: 2 arguments for an soustraction node)
     * @return The number of arguments
     */
    virtual unsigned short int nbArguments() const = 0;

    /**
     * @brief setNbArguments set the number of argument of the node, usefull for addition and multiplication
     * @param nbArguments The number of arguments the node will have
     */
    virtual void setNbArguments(const unsigned short int &nbArguments) {(void)nbArguments;throw std::runtime_error("We should not have to call setNbArguments on this node -> " + toString());};

    /**
     * @brief Provide the type of the node
     * @return Value contained by the NodeType enum
     */
    virtual NodeType type() const = 0;

    /**
     * @brief Provide the category of the node
     * @return Value contained by the Category enum
     */
    virtual NodeCategory category() const = 0;

    /**
     * @brief Create a new EquationNode subclass object
     * @return The shared pointer of the created equation node
     */
    virtual std::shared_ptr<EquationNode> clone() const = 0;

    /**
     * @brief Provide the value of the equation depending on arguments
     * @param variableValue ??
     * @param arguments A list of arguments
     * @return The value of the equation node
     */
    double value(const std::vector<double> &variableValues, const std::vector<EquationTreeItem> &arguments = std::vector<EquationTreeItem>()) const;

    // comparaison operators
    virtual bool operator==(const EquationNode &other) const;
    virtual bool operator!=(const EquationNode &other) const;

    /**
     * @brief Return the symbol of the node
     * @return Node symbol as a string
     */
    virtual std::string toString() const = 0;
    /**
     * @brief Return the label of the node
     * @return Node symbol as a string
     */
    virtual std::string toLabel() = 0;

    protected:
    /**
     * @brief Compute the value for the current equation node
     * @param variableValue ??
     * @param arguments A list of equation tree
     * @return The computed value
     */
    virtual double calculateValue(const std::vector<double> &variableValues, const std::vector<EquationTreeItem> &arguments) const = 0;


   private:
    //Q_DISABLE_COPY_MOVE(EquationNode)

};
}  // namespace datamodel
