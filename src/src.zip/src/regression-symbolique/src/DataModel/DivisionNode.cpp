#include "DivisionNode.h"

#include <cmath>

namespace datamodel {
unsigned short int DivisionNode::nbArguments() const { return 2; }

EquationNode::NodeType DivisionNode::type() const {
    return NodeType::Division;
}

EquationNode::NodeCategory DivisionNode::category() const { return NodeCategory::NonCommutative; }

std::shared_ptr<EquationNode> DivisionNode::clone() const {
    return std::shared_ptr<EquationNode>(new DivisionNode());
}

std::string DivisionNode::toString() const {
    return "/";
}
std::string DivisionNode::toLabel() {
    return "/";
}

double DivisionNode::calculateValue(const std::vector<double> &variableValues,
                                    const std::vector<EquationTreeItem> &arguments) const {
    double denominator = arguments.at(1).value(variableValues);
    if (denominator != 0) {
        return arguments.at(0).value(variableValues) / denominator;
    } else {
        return nan("");
    }
}

} // namespace datamodel
