#pragma once

#include "EquationNode.h"

namespace datamodel
{
/**
 * @brief The TanNode class handle the tan nodes
 */
class TanNode : public EquationNode
{
   public:
    TanNode() = default;
    ~TanNode() override = default;

    // see EquationNode.h definition
    unsigned short int nbArguments() const override;
    NodeType type() const override;
    NodeCategory category() const override;
    std::shared_ptr<EquationNode> clone() const override;
    std::string toString() const override;
    std::string toLabel() override;

   protected:
    // see EquationNode.h definition
    double calculateValue(const std::vector<double> &variableValues, const std::vector<EquationTreeItem> &arguments) const override;

   private:
    //Q_DISABLE_COPY_MOVE(TanNode)
};
}  // namespace datamodel


