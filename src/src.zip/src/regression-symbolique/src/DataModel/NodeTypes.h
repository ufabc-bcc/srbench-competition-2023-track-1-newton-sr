#ifndef TREEGENETICPROGRAMMING_NODETYPES_H
#define TREEGENETICPROGRAMMING_NODETYPES_H

#include "AbsoluteNode.h"
#include "AdditionNode.h"
#include "ArctanNode.h"
#include "TanNode.h"
#include "ConstantNode.h"
#include "CosinusNode.h"
#include "DivisionNode.h"
#include "ExponentialNode.h"
#include "InverseNode.h"
#include "LogarithmeNode.h"
#include "MaxNode.h"
#include "MinNode.h"
#include "MultiplicationNode.h"
#include "NegativeNode.h"
#include "PowerNode.h"
#include "SinusNode.h"
#include "SoustractionNode.h"
#include "SquareRootNode.h"
#include "VariableNode.h"

#endif  // TREEGENETICPROGRAMMING_NODETYPES_H
