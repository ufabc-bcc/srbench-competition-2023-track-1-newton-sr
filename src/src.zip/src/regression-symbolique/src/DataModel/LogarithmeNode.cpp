#include "LogarithmeNode.h"

#include <cmath>

namespace datamodel {
unsigned short int LogarithmeNode::nbArguments() const { return 1; }

EquationNode::NodeType LogarithmeNode::type() const { return NodeType::Logarithm; }

EquationNode::NodeCategory LogarithmeNode::category() const { return NodeCategory::Function; }

std::shared_ptr<EquationNode> LogarithmeNode::clone() const {
    return std::shared_ptr<EquationNode>(new LogarithmeNode());
}

std::string LogarithmeNode::toString() const { return "log"; }
std::string LogarithmeNode::toLabel() { return "log"; }

double LogarithmeNode::calculateValue(const std::vector<double> &variableValues,
                                      const std::vector<EquationTreeItem> &arguments) const {
    return log(arguments.at(0).value(variableValues));
}

} // namespace datamodel
