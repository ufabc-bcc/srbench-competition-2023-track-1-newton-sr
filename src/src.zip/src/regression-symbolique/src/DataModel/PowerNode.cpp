#include "PowerNode.h"

#include <cmath>

namespace datamodel {
unsigned short int PowerNode::nbArguments() const { return 2; }

EquationNode::NodeType PowerNode::type() const { return NodeType::Power; }

EquationNode::NodeCategory PowerNode::category() const { return NodeCategory::NonCommutative; }

std::shared_ptr<EquationNode> PowerNode::clone() const {
    return std::shared_ptr<EquationNode>(new PowerNode());
}

std::string PowerNode::toString() const { return "**"; }
std::string PowerNode::toLabel() { return "**"; }

double PowerNode::calculateValue(const std::vector<double> &variableValues,
                                 const std::vector<EquationTreeItem> &arguments) const {
    return pow(arguments.at(0).value(variableValues), arguments.at(1).value(variableValues));
}

} // namespace datamodel

