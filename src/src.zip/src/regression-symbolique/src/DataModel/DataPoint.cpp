#include "DataPoint.h"

namespace datamodel {

DataPoint::DataPoint(std::vector<double> parameterList, double result)
    : _parameterList(parameterList), _result(result)
{}

double DataPoint::result() const { return _result; }

void DataPoint::setResult(double result) { _result = result; }

std::vector<double> DataPoint::parameterList() const { return _parameterList; }

// Assume that every DataPoint of the list as the number of variables
uint DataPoint::getNumberOfVariables() const{
    return _parameterList.size();
}

double DataPoint::parameterValue(const int position) const { return _parameterList[position]; }

void DataPoint::setParameterList(const std::vector<double> parameterList) { _parameterList = parameterList; }

void DataPoint::addToParameterValue(double parameterValue) { _parameterList.push_back(parameterValue); }

bool DataPoint::operator==(const DataPoint &dataPoint) const
{
    if (this->_parameterList.size() != dataPoint._parameterList.size())
    {
        return false;
    }

    for (uint i = 0; i < _parameterList.size(); i++)
    {
        if (!qFuzzyCompare(_parameterList[i], dataPoint._parameterList[i]))
        {
            return false;
        }

        if (!qFuzzyCompare(_result, dataPoint._result))
        {
            return false;
        }
    }
    return true;
}

bool DataPoint::operator!=(const DataPoint &dataPoint) const { return !operator==(dataPoint); }

}  // namespace datamodel
