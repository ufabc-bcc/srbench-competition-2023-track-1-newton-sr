#include "MaxNode.h"

#include <cmath>

namespace datamodel {
unsigned short int MaxNode::nbArguments() const { return 2; }

EquationNode::NodeType MaxNode::type() const { return NodeType::Max; }

EquationNode::NodeCategory MaxNode::category() const { return NodeCategory::MinMax; }

std::shared_ptr<EquationNode> MaxNode::clone() const {
    return std::shared_ptr<EquationNode>(new MaxNode());
}

std::string MaxNode::toString() const { return "Max"; }
std::string MaxNode::toLabel() { return "Max"; }

double MaxNode::calculateValue(const std::vector<double> &variableValues,
                               const std::vector<EquationTreeItem> &arguments) const {
    return fmax(arguments.at(0).value(variableValues), arguments.at(1).value(variableValues));
}

} // namespace datamodel
