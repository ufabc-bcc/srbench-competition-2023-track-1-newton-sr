#include "NegativeNode.h"

namespace datamodel
{
unsigned short int NegativeNode::nbArguments() const { return 1; }

EquationNode::NodeType NegativeNode::type() const { return NodeType::Negative; }

EquationNode::NodeCategory NegativeNode::category() const { return NodeCategory::Function; }

std::shared_ptr<EquationNode> NegativeNode::clone() const {
    return std::shared_ptr<EquationNode>(new NegativeNode());
}

std::string NegativeNode::toString() const { return "-"; }
std::string NegativeNode::toLabel() { return "-"; }

double NegativeNode::calculateValue(const std::vector<double> &variableValues,
                                    const std::vector<EquationTreeItem> &arguments) const {
    return (- 1) * (arguments.at(0).value(variableValues));
}

}  // namespace datamodel
