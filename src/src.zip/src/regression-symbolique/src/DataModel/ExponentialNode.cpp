#include "ExponentialNode.h"

#include <cmath>

namespace datamodel {
unsigned short int ExponentialNode::nbArguments() const { return 1; }

EquationNode::NodeType ExponentialNode::type() const {
    return NodeType::Exponential;
}

EquationNode::NodeCategory ExponentialNode::category() const { return NodeCategory::Function; }

std::shared_ptr<EquationNode> ExponentialNode::clone() const {
    return std::shared_ptr<EquationNode>(new ExponentialNode());
}

std::string ExponentialNode::toString() const { return "exp"; }
std::string ExponentialNode::toLabel() { return "exp"; }

double ExponentialNode::calculateValue(const std::vector<double> &variableValues,
                                       const std::vector<EquationTreeItem> &arguments) const {
    return exp(arguments.at(0).value(variableValues));
}

} // namespace datamodel
