#include "SoustractionNode.h"

namespace datamodel {
unsigned short int SoustractionNode::nbArguments() const { return 2; }

EquationNode::NodeType SoustractionNode::type() const { return NodeType::Soustraction; }

EquationNode::NodeCategory SoustractionNode::category() const { return NodeCategory::NonCommutative; }

std::shared_ptr<EquationNode> SoustractionNode::clone() const {
    return std::shared_ptr<EquationNode>(new SoustractionNode()); }

std::string SoustractionNode::toString() const { return "-"; }
std::string SoustractionNode::toLabel() { return "-"; }

double SoustractionNode::calculateValue(const std::vector<double> &variableValues,
                                        const std::vector<EquationTreeItem> &arguments) const {
    return arguments.at(0).value(variableValues) - arguments.at(1).value(variableValues);
}

} // namespace datamodel
