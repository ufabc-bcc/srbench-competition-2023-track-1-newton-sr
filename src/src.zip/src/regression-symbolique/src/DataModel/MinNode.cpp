#include "MinNode.h"

#include <cmath>

namespace datamodel {
unsigned short int MinNode::nbArguments() const { return 2; }

EquationNode::NodeType MinNode::type() const { return NodeType::Min; }

EquationNode::NodeCategory MinNode::category() const { return NodeCategory::MinMax; }

std::shared_ptr<EquationNode> MinNode::clone() const {
    return std::shared_ptr<EquationNode>(new MinNode()); }

std::string MinNode::toString() const { return "Min"; }
std::string MinNode::toLabel() { return "Min"; }


double MinNode::calculateValue(const std::vector<double> &variableValues,
                               const std::vector<EquationTreeItem> &arguments) const {
    return fmin(arguments.at(0).value(variableValues), arguments.at(1).value(variableValues));
}

} // namespace datamodel
