#include "InverseNode.h"

#include <cmath>

namespace datamodel
{
unsigned short int InverseNode::nbArguments() const { return 1; }

EquationNode::NodeType InverseNode::type() const { return NodeType::Inverse; }

EquationNode::NodeCategory InverseNode::category() const { return NodeCategory::Function; }

std::shared_ptr<EquationNode> InverseNode::clone() const {
    return std::shared_ptr<EquationNode>(new InverseNode());
}

std::string InverseNode::toString() const { return "1 / "; }
std::string InverseNode::toLabel() { return "1 / "; }

double InverseNode::calculateValue(const std::vector<double> &variableValues,
                                   const std::vector<EquationTreeItem> &arguments) const {
    double denominator = arguments.at(0).value(variableValues);
    if (denominator != 0) {
        return 1 / denominator;
    } else {
        return nan("");
    }
}
}  // namespace datamodel
