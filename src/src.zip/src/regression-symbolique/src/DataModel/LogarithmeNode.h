
#pragma once

#include "EquationNode.h"

namespace datamodel
{
/**
 * @brief The LogarithmeNode class handle the logarithme nodes
 */
class LogarithmeNode : public EquationNode
{
   public:
    LogarithmeNode() = default;
    ~LogarithmeNode() override = default;

    unsigned short int nbArguments() const override;
    NodeType type() const override;
    NodeCategory category() const override;

    std::shared_ptr<EquationNode> clone() const override;
    std::string toString() const override;
    std::string toLabel() override;

   protected:
    double calculateValue(const std::vector<double> &variableValues, const std::vector<EquationTreeItem> &arguments) const override;

   private:
    //Q_DISABLE_COPY_MOVE(LogarithmeNode)
};
}  // namespace datamodel
