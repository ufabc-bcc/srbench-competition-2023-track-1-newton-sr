#include <QDebug>

#include "EquationTreeItem.h"
#include "ConstantNode.h"
#include "EquationNode.h"
#include "Logger_v2/Logger.h"
#include <cmath>
#include <utility>

#include <iostream>

namespace datamodel {

EquationTreeItemData::EquationTreeItemData() : QSharedData() {}

EquationTreeItemData::EquationTreeItemData(const std::shared_ptr<EquationNode> &currentNode)
    : QSharedData(), currentNode(currentNode) {}

EquationTreeItemData::EquationTreeItemData(const EquationTreeItemData &other)
    : QSharedData(other), arguments(other.arguments), depth(other.depth), variance(other.variance)
{
    if (other.currentNode) {
        currentNode = other.currentNode->clone();
    }
}

EquationTreeItemData &EquationTreeItemData::operator=(const EquationTreeItemData &other) {
    if (&other != this) {
        if (other.currentNode) {
            currentNode = other.currentNode->clone();
        }
        arguments = other.arguments;
    }
    return *this;
}

EquationTreeItem::EquationTreeItem() : _sharedDataPointer(new EquationTreeItemData()) {}

EquationTreeItem::EquationTreeItem(const std::shared_ptr<EquationNode> &currentNode)
    : _sharedDataPointer(new EquationTreeItemData(currentNode)) {}

EquationTreeItem::EquationTreeItem(const EquationTreeItem &other)
    : _sharedDataPointer(other._sharedDataPointer) {}

EquationTreeItem &EquationTreeItem::operator=(const EquationTreeItem &other) {
    if (&other != this) {
        _sharedDataPointer = other._sharedDataPointer;
    }
    return *this;
}

EquationTreeItem &EquationTreeItem::operator=(EquationTreeItem &&other) noexcept {
    if (&other != this) {
        _sharedDataPointer = std::move(other._sharedDataPointer);
    }
    return *this;
}

bool EquationTreeItem::operator==(const EquationTreeItem &other) const {
    bool nodesAreTheSame = false;
    if (!currentNode() && !other.currentNode()) {
        nodesAreTheSame = true;
    } else if (!currentNode() || !other.currentNode()) {
        nodesAreTheSame = false;
    } else {
        nodesAreTheSame = *currentNode() == *other.currentNode();
    }
    return nodesAreTheSame && arguments() == other.arguments() && depth() == other.depth();
}

bool EquationTreeItem::operator!=(const EquationTreeItem &other) const {
    return !operator==(other);
}

std::shared_ptr<EquationNode> EquationTreeItem::currentNode() const {
    return _sharedDataPointer->currentNode;
}

void EquationTreeItem::setCurrentNode(const std::shared_ptr<EquationNode> &currentNode) {
    _sharedDataPointer->currentNode = currentNode;
}

int EquationTreeItem::depth() const {
    if (_sharedDataPointer->arguments.empty()) {
        return 0;
    } else {
        std::vector<int> depths;

        for (const EquationTreeItem &argument : qAsConst(_sharedDataPointer->arguments)) {
            depths.push_back(argument.depth());
        }

        auto max_element = std::max_element(depths.cbegin(), depths.cend());
        if (max_element != depths.cbegin()) {
            return *max_element + 1;
        } else {
            return 0;
        }
    }
}

float EquationTreeItem::variance() {
    return _sharedDataPointer->variance;
}

void EquationTreeItem::setVariance(const float variance) {
    _sharedDataPointer->variance = variance;
}

const std::vector<EquationTreeItem> &EquationTreeItem::arguments() const {
    return _sharedDataPointer->arguments;
}

std::vector<EquationTreeItem> &EquationTreeItem::arguments() {
    return _sharedDataPointer->arguments;
}

void EquationTreeItem::setArguments(const std::vector<EquationTreeItem> &arguments) {
    _sharedDataPointer->arguments = std::vector<EquationTreeItem>(arguments.begin(), arguments.end());
}

double EquationTreeItem::value(const std::vector<double> &variableValues) const {
    if (_sharedDataPointer->currentNode==nullptr) { //if (_sharedDataPointer->currentNode.isNull()) {
        //qWarning() << "Cannot calculate the value of an equation without current node";
        logs::Logger::logWarning("Cannot calculate the value of an equation without current node", {logs::LogTags::algorithm});
        return nan("");
    }

    if (_sharedDataPointer->currentNode->nbArguments() != _sharedDataPointer->arguments.size()) {
        std::string message_warning_equation_different_argument = "Cannot calculate the value of an equation with different number of arguments "
                + std::to_string(_sharedDataPointer->currentNode->nbArguments())
                + " then expected "
                + std::to_string(_sharedDataPointer->arguments.size());
        logs::Logger::logWarning(message_warning_equation_different_argument, {logs::LogTags::algorithm});
        return nan("");
    }

    for(const double &var : variableValues){
        if (std::isnan(var) || std::isinf(var)) {
            return nan("");
        }
    }

    return _sharedDataPointer->currentNode->value(variableValues, _sharedDataPointer->arguments);
}

bool EquationTreeItem::isEmpty() const {
    return currentNode()==nullptr  && arguments().empty() && depth() == 0; //return currentNode().isNull()  && arguments().isEmpty() && depth() == 0;
}

bool EquationTreeItem::isValid(const std::vector<double> &variableValues) const {
    if (!_sharedDataPointer->currentNode) {
        return false;
    }
    if (_sharedDataPointer->currentNode->nbArguments() != _sharedDataPointer->arguments.size()) {
        return false;
    }
    if (_sharedDataPointer->currentNode->type() == datamodel::EquationNode::NodeType::Constant) {
        double value = _sharedDataPointer->currentNode->value(variableValues);
        if (std::isnan(value) || !std::isfinite(value)) {
            return false;
        }
    }
    for (const EquationTreeItem &argument : arguments()) {
        if (!argument.isValid(variableValues)) {
            return false;
        }
    }
    return true;
}

bool EquationTreeItem::containsDivision(const std::vector<double> &variableValues) const {
    if (_sharedDataPointer->currentNode->type() == datamodel::EquationNode::NodeType::Division) {
        if(arguments().at(0).currentNode()->type() == datamodel::EquationNode::NodeType::Variable
                && arguments().at(1).currentNode()->type() == datamodel::EquationNode::NodeType::Constant){
            return true;
        }
    }
    for (const EquationTreeItem &argument : arguments()) {
        if (argument.containsDivision(variableValues)) {
            return true;
        }
    }
    return false;
}

datamodel::EquationTreeItem* EquationTreeItem::findParent(const std::shared_ptr<datamodel::EquationNode>& node){
    //Check validity of the search
    if(!node || !currentNode() || currentNode() == node) return nullptr;

    for(const datamodel::EquationTreeItem &argument : arguments())
        if(argument.currentNode() == node) return this;

    //This node is not the parent so we iterate through his children
    for(datamodel::EquationTreeItem &argument : arguments()){
        datamodel::EquationTreeItem* parent = argument.findParent(node);

        //Parent found
        if(parent) return parent;
    }

    //Node parent not found at the end of the current equation
    return nullptr;
}

double EquationTreeItem::totalConstantValue() {
    if(!currentNode()) return 0;
    if (_sharedDataPointer->currentNode->type() == datamodel::EquationNode::NodeType::Constant) {
        const std::vector<double> empty;
        return this->value(empty);
    }
    double tot = 0;
    for(datamodel::EquationTreeItem &argument : arguments()) {
        tot += argument.totalConstantValue();
    }
    return tot;
}

} // namespace datamodel
