#include "EquationNode.h"
#include "Logger_v2/Logger.h"
#include <cmath>

namespace datamodel {

double EquationNode::value(const std::vector<double> &variableValues,
                           const std::vector<EquationTreeItem> &arguments) const {
    if(nbArguments() != arguments.size()) {
        std::string message_critical = "Try to calculate value for the node : "
                + std::to_string(type())
                + ", with "
                + std::to_string(arguments.size())
                + " arguments when "
                + std::to_string(nbArguments())
                + " are expected";
        logs::Logger::logCritical(message_critical, {logs::LogTags::algorithm});
        return nan("");
    }
    else {
        double value = calculateValue(variableValues, arguments);
        return value;
    }
}

bool EquationNode::operator==(const EquationNode &other) const {
    return type() == other.type() && nbArguments() == other.nbArguments() && toString() == other.toString();
}

bool EquationNode::operator!=(const EquationNode &other) const {
    return !operator==(other);
}

}  // namespace datamodel
