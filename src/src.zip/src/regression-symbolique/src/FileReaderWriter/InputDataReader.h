#pragma once

#include <string>
#include "DataModel/DataPoint.h"

namespace filereaderwriter
{
/**
 * @brief The InputDataReader class handle the parsing of input files
 */
class InputDataReader
{
public:
    // constructors
    InputDataReader(const std::string &filePath);

    /**
     * @brief Read an input data file
     * @return A list of points
     */
    std::vector<datamodel::DataPoint> readDataFile();

    /**
     * @brief Read the header of a data file
     * @param delimiter
     * @return the header
     */
    std::vector<std::string> readHeaderLine(const char &delimiter);

    /**
     * @brief Read a line of a data file
     * @param delimiter
     * @return The point from a line
     */
    datamodel::DataPoint readDataLine(const std::string &line, const char &delimiter);

    /**
     * @brief Check if a error happened during file parsing
     * @return Return true if a error happened during file parsing, false otherwise
     */
    bool error();

    /**
     * @brief Check what is teh error state and tranform it into string
     * @return Return the error in string
     */
    std::string errorString();
private:
    enum class ErrorCode{
        NoError = 0,
        UnsupportedExtension,
        CantOpenFile,
        NoHeader,
        InvalidHeader,
        InvalidDataHeader
    };

    ErrorCode _errorCode{ErrorCode::NoError};
    std::string _fileExtension{""};
    std::string _fileName{""};
    std::string _filePath{""};
};
}  // namespace filereaderwriter
