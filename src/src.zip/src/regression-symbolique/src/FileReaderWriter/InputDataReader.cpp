#include "InputDataReader.h"
#include "InputDataDefinitions.h"
#include "Logger_v2/Logger.h"
#include "Utils/StringUtils.h"

#define CSV "csv"
#define TSV "tsv"

#include <vector>
#include <string>
#include <sstream>
#include <fstream>

std::vector<std::string> g_lineData;

// DEFAULT AUTHORIZED FILE EXTENSION IS CSV

namespace filereaderwriter
{
InputDataReader::InputDataReader(const std::string &filePath):
    _filePath{filePath}
{
    size_t fileNameStart = filePath.find_last_of("/\\");
    if(fileNameStart != std::string::npos){
        std::string temp = filePath.substr(fileNameStart+1);
        size_t suffixStart = temp.rfind(".");
        if (suffixStart != std::string::npos){
            _fileName = temp.substr(0, suffixStart);
            _fileExtension = temp.substr(suffixStart + 1, temp.size() - 1);
        }
    }
}

std::vector<datamodel::DataPoint> InputDataReader::readDataFile()
{
    _errorCode = ErrorCode::NoError;
    std::vector<datamodel::DataPoint> datas;
    std::fstream file(_filePath, std::ios::in);
    if(file.is_open()){
        if (_fileExtension == CSV){
            // Get Variables's label
            g_lineData = readHeaderLine(CSV_DELIMITER);
            if(_errorCode != ErrorCode::NoHeader && _errorCode != ErrorCode::InvalidHeader){
                // Get DataPoints
                datamodel::DataPoint dataPoint;
                std::string line{""};
                while (getline(file, line))
                {
                    dataPoint = readDataLine(line, CSV_DELIMITER);
                    if (!std::isnan(dataPoint.result())){
                        datas.push_back(dataPoint);
                    }
                }
            } else {
                logs::Logger::logError("Error when reading header", {logs::LogTags::fileReaderWriter});
            }
        } else if(_fileExtension == TSV){
            // Get Variables's label
            g_lineData = readHeaderLine(TSV_DELIMITER);
            if(_errorCode != ErrorCode::NoHeader && _errorCode != ErrorCode::InvalidHeader){
                // Get DataPoints
                datamodel::DataPoint dataPoint;
                std::string line{""};
                while (getline(file, line))
                {
                    dataPoint = readDataLine(line, TSV_DELIMITER);
                    if (!std::isnan(dataPoint.result())){
                        datas.push_back(dataPoint);
                    }
                }
            } else {
                logs::Logger::logError("Error when reading header", {logs::LogTags::fileReaderWriter});
            }
        } else {
            logs::Logger::logError("Only csv and tsv files are supproted", {logs::LogTags::fileReaderWriter});
            _errorCode = ErrorCode::UnsupportedExtension;
        }
    } else {
        logs::Logger::logError("Could not open file ", {logs::LogTags::fileReaderWriter});
        _errorCode = ErrorCode::CantOpenFile;
    }
    file.close();
    return datas;
}

std::vector<std::string> InputDataReader::readHeaderLine(const char &delimiter)
{
    std::vector<std::string> labels;
    std::fstream file(_filePath, std::ios::in);
    if(file.is_open()){
        std::string cell{""};
        double tempVar;
        std::string header{""};
        std::string line{""};
        while(getline(file, line)){
            std::stringstream lineStream(line);
            getline(lineStream, cell, delimiter);
            if (std::istringstream(cell) >> tempVar) break;
            else header = line;
        }
        if(header != ""){
            std::stringstream headerStream(header);
            while(getline(headerStream, cell, delimiter)){
                if(!(std::istringstream(cell) >> tempVar)){
                    cell = utils::StringUtils::trim(cell, " \t\r\n");
                    labels.push_back(cell);
                } else {
                    logs::Logger::logError("Header can't contain values", {logs::LogTags::fileReaderWriter});
                    _errorCode = ErrorCode::InvalidHeader;
                    file.close();
                    return std::vector<std::string>();
                }
            }
            if(labels.size() < 2){
                logs::Logger::logError("Header need at least two elements", {logs::LogTags::fileReaderWriter});
                _errorCode = ErrorCode::InvalidHeader;
            }
        } else {
            logs::Logger::logError("File has no header", {logs::LogTags::fileReaderWriter});
            _errorCode = ErrorCode::NoHeader;
        }
    } else {
        logs::Logger::logError("Could not open file " + _fileName, {logs::LogTags::fileReaderWriter});
        _errorCode = ErrorCode::CantOpenFile;
    }
    file.close();
    return labels;
}

static bool convertToDouble(std::string inputData, double &outputData)
{
    for(char& c : inputData){
        if(c == ','){
            c = '.';
            break;
        }
    }

    try{
        outputData = std::stod(inputData);
    } catch (const std::invalid_argument&){
        logs::Logger::logWarning("No conversion could be performed", {logs::LogTags::fileReaderWriter});
        return false;
    } catch (const std::out_of_range&){
        logs::Logger::logWarning("Could not convert string to double, value falls out of range", {logs::LogTags::fileReaderWriter});
        return false;
    }

    return true;
}

// Return the object that represent the multivariable datapoint
datamodel::DataPoint InputDataReader::readDataLine(const std::string &line, const char &delimiter)
{
    std::string cell;
    std::stringstream lineStream(line);
    std::vector<double> parameterList;
    parameterList.reserve(g_lineData.size());
    double value{0.};
    while(getline(lineStream, cell, delimiter)){
        if(convertToDouble(cell, value))
             parameterList.push_back(value);
        else
           return datamodel::DataPoint();
    } 

    if(parameterList.size() != g_lineData.size()){
        logs::Logger::logWarning("Row don't have the same number of values than header", {logs::LogTags::fileReaderWriter});
        _errorCode = ErrorCode::InvalidDataHeader;
        return datamodel::DataPoint();
    }

    double result = parameterList.back();
    parameterList.pop_back();
    return datamodel::DataPoint(parameterList, result);
}

bool InputDataReader::error()
{
    return _errorCode != ErrorCode::NoError;
}

std::string InputDataReader::errorString(){
    switch (_errorCode) {
    case ErrorCode::NoError:
        return "No error";
    case ErrorCode::CantOpenFile:
        return "File could not be opened";
    case ErrorCode::NoHeader:
        return "File has no header";
    case ErrorCode::InvalidHeader:
        return "File has an invalid header";
    case ErrorCode::UnsupportedExtension:
        return "File has an unsupported extension";
    case ErrorCode::InvalidDataHeader:
        return "File has datas which mismatch header";
    default:
        return "Unknow error state";
    }
}



}  // namespace filereaderwriter
