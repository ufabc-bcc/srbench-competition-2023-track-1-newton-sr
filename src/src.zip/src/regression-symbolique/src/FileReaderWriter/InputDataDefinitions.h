
#pragma once

#include <QString>

const QString DATAS_ELEMENT = QStringLiteral("Datas");
const QString DATA_ELEMENT = QStringLiteral("Data");
const QString PARAMETER_ELEMENT = QStringLiteral("Parameter");
const QString RESULT_ELEMENT = QStringLiteral("Result");

const char CSV_DELIMITER = ';';
const char TSV_DELIMITER = '\t';
const QString PARAMETER_ELEMENT_CSV = "Parameter";
const QString RESULT_ELEMENT_CSV = "Result";
