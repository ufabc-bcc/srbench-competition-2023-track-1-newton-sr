#pragma once

#include <QtCore/qglobal.h>
#include <vector>
#include <string>

// global variable used to display variable's labels
extern std::vector<std::string> g_lineData;
