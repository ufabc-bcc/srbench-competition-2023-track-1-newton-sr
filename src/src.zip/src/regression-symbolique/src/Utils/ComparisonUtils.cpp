#include "ComparisonUtils.h"

#include <cmath>


#include <QMapIterator>

namespace utils {

bool lessThan(double first, double second)
{
    // inf is always the biggest
    if (std::isinf(first)) {
        return false;
    }

    if (std::isnan(first)) {
        if (std::isinf(second)) {
            return true;
        } else {
            return false;
        }
    }

    if (std::isinf(second) || std::isnan(second)) {
        return true;
    }

    return first < second;
}

bool moreThan(double first, double second)
{
    if (first == second) {
        return false;
    } else {
        return !lessThan(first, second);
    }
}

QList<QPair<int, double>> orderDistancesDecreasingOrder(const QMap<int, double> &distances)
{
    QList<QPair<int, double>> distancesOrdered;
    QMapIterator<int, double> distancesIterator(distances);
    while (distancesIterator.hasNext()) {
        distancesIterator.next();

        int positionToInsert = 0;
        for (int i = 0; i < distancesOrdered.size(); ++i) {
            if (utils::moreThan(distancesIterator.value(), distancesOrdered.at(i).second)) {
                positionToInsert = i + 1;
            } else {
                break;
            }
        }

        distancesOrdered.insert(positionToInsert,
                                {distancesIterator.key(), distancesIterator.value()});
    }

    return distancesOrdered;
}

} // namespace utils
