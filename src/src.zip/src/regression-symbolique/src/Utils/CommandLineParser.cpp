#include "CommandLineParser.h"
#include "Settings.h"
#include <sstream>
#include "Logger_v2/Logger.h"

namespace utils
{
CommandLineParser::CommandLineParser() {}

void CommandLineParser::ParseCommandLine()
{
    // Creating the parser.
    QCommandLineParser parser;

    // Add basic settings to the parser.
    parser.setSingleDashWordOptionMode(QCommandLineParser::ParseAsLongOptions);
    parser.setApplicationDescription("Symbolic regression");
    parser.addHelpOption();
    parser.addVersionOption();

    // Add every option we need to the parser.
    // Default values are defined here.
    QCommandLineOption help(
        QStringList() << "h"
                      << "help",
        QCoreApplication::translate("main",
                                    "Displays help on commandline options."));
    QCommandLineOption startSilent(
        QStringList() << "s"
                      << "start-silent",
        QCoreApplication::translate("main",
                                    "If set, the program starts without UI, generates equations and cycle on them "
                                    "based on the passed or default parameters."));

    QString fileName = Settings::instance()->value("InputData/FileName", "no_file").toString();
    QCommandLineOption inputDataPath(QStringList() << "i"
                                                   << "input-path",
                                     QCoreApplication::translate("main", "!MANDATORY! Path of the input file."),
                                     QCoreApplication::translate("main", "inputPath"),
                                     QCoreApplication::translate("main", fileName.toStdString().c_str()));

    int populationSetting = Settings::instance()->value("EquationGeneration/Population", 100).toInt();
    QCommandLineOption basePopulationSize(
        QStringList() << "p"
                      << "population-size",
        QCoreApplication::translate("main", "Size of the base population. default is 100"),
        QCoreApplication::translate("main", "population"),
        QCoreApplication::translate("main", QString::number(populationSetting).toStdString().c_str()));

    QCommandLineOption operationsNotToUse(
        QStringList() << "o"
                      << "operations",
        QCoreApplication::translate("main", "List of operations not usable to generate equations."),
        QCoreApplication::translate("main", "operations"), QCoreApplication::translate("main", ""));

    QCommandLineOption numberOfGenerations(
        QStringList() << "g"
                      << "generation-amount",
        QCoreApplication::translate("main", "Amount of generations to process. default is 100"),
        QCoreApplication::translate("main", "generation"), QCoreApplication::translate("main", "100"));

    //Ajout du parametre de distance
    QCommandLineOption activateDistanceMin(
                QStringList() << "a"
                              << "activate-distance",
                QCoreApplication::translate("main","Activation of distance stop(Disable (0), Enable(1), Zero(2)). default is Disable"),
                QCoreApplication::translate("main","distance"),QCoreApplication::translate("main","0"));

    double crossBreedingRateSetting =
        Settings::instance()->value("EquationCrossBreeding/CrossBreedingRate", 20).toInt() / 100.;
    QCommandLineOption crossbreedingRate(
        QStringList() << "c"
                      << "crossbreeding-rate",
        QCoreApplication::translate("main", "Crossbreeding rate(between 0 and 1) to apply to the parents. default is 0.2."),
        QCoreApplication::translate("main", "crossbreeding"),
        QCoreApplication::translate("main", QString::number(crossBreedingRateSetting).toStdString().c_str()));

    double mutationRateSetting = Settings::instance()->value("EquationMutation/MutationRate", 25).toInt() / 100.;
    QCommandLineOption mutationRate(
        QStringList() << "m"
                      << "mutation-rate",
        QCoreApplication::translate("main", "Mutation rate(between 0 and 1) to apply to the offsprings. default is 0.25."),
        QCoreApplication::translate("main", "mutation"),
        QCoreApplication::translate("main", QString::number(mutationRateSetting).toStdString().c_str()));

    int nbOfMutationsSetting = Settings::instance()->value("EquationMutation/NbOfMutations", 1).toInt();
    QCommandLineOption nbOfMutations(
        QStringList() << "nm"
                      << "number-mutations",
        QCoreApplication::translate("main",
                                    "Number of mutations used for the offsprings. default is 1."),
        QCoreApplication::translate("main", "numberOfMutations"),
        QCoreApplication::translate("main", QString::number(nbOfMutationsSetting).toStdString().c_str()));

    int maxDepthSetting = Settings::instance()->value("EquationGeneration/MaxDepth", 5).toInt();
    QCommandLineOption equationTreeMaximumDepth(
        QStringList() << "e"
                      << "equations-depth",
        QCoreApplication::translate("main", "Maximum depth of the tree. default is 5."),
        QCoreApplication::translate("main", "treeDepth"),
        QCoreApplication::translate("main", QString::number(maxDepthSetting).toStdString().c_str()));

    int tournamentSizeSetting = Settings::instance()->value("EquationCrossBreeding/TournamentSize", 5).toInt();
    QCommandLineOption tournamentSize(
        QStringList() << "t"
                      << "tournament-size",
        QCoreApplication::translate("main", "Size of tournament used for parent selection. default is 5."),
        QCoreApplication::translate("main", "tournamentSize"),
        QCoreApplication::translate("main", QString::number(tournamentSizeSetting).toStdString().c_str()));

    int filterFromSetting = Settings::instance()->value("EquationFilter/FilterFrom", 1).toInt();
    QCommandLineOption filterFrom(
        QStringList() << "f"
                      << "filter-origin",
        QCoreApplication::translate("main",
                                    "Value from which we keep best equations to avoid keeping non representative "
                                    "lucky best. default is 1."),
        QCoreApplication::translate("main", "filterOrigin"),
        QCoreApplication::translate("main", QString::number(filterFromSetting).toStdString().c_str()));

    int selectedEquationsNumberSetting =
        Settings::instance()->value("EquationFilter/SelectedEquations", 100).toInt();
    QCommandLineOption numberOfEquationsSelected(
        QStringList() << "n"
                      << "numbeof-equations",
        QCoreApplication::translate("main", "Number of equations kept in filtering."),
        QCoreApplication::translate("main", "numberOfEquations"),
        QCoreApplication::translate("main",
                                    QString::number(selectedEquationsNumberSetting).toStdString().c_str()));

    QCommandLineOption startParallel(
        QStringList() << "pl"
                      << "start-parallel",
        QCoreApplication::translate("main",
                                    "If set, the program use parallels threads."));


    int fitDurationFromSetting =
        Settings::instance()->value("EquationGeneration/FitDuration", 1).toInt();
    QCommandLineOption fitDuration(
        QStringList() << "fd"
                      << "fit-duration",
        QCoreApplication::translate("main", "Time (ms) taken by the fit."),
        QCoreApplication::translate("main", "fitDuration"),
        QCoreApplication::translate("main",
                                     QString::number(fitDurationFromSetting).toStdString().c_str()));

    int fitPopulationPeriodFromSetting =
        Settings::instance()->value("EquationGeneration/FitPopulationPeriod", 1).toInt();
    QCommandLineOption fitPopulationPeriod(
        QStringList() << "fp"
                      << "fit-popperiod",
        QCoreApplication::translate("main", "Population period of the fit."),
        QCoreApplication::translate("main", "fitPopulationPeriod"),
        QCoreApplication::translate("main",
                                     QString::number(fitPopulationPeriodFromSetting).toStdString().c_str()));

    int numberOfThreadsFromSetting =
        Settings::instance()->value("EquationGeneration/NumberOfThreads ", 1).toInt();
    QCommandLineOption numberOfThreads(
        QStringList() << "nt"
                      << "number-threads",
        QCoreApplication::translate("main", "Number of threads use during parallel computation."),
        QCoreApplication::translate("main", "numberOfThreads"),
        QCoreApplication::translate("main",
                                     QString::number(numberOfThreadsFromSetting).toStdString().c_str()));

    std::string distanceToUseSetting =
        Settings::instance()->value("EquationDistance/Distance ", "R2").toString().toStdString();
    QCommandLineOption distanceToUse(
        QStringList() << "dist"
                      << "distance",
        QCoreApplication::translate("main", "Distance to use in computation. Valid values are \"R2\" and \"MSE\""),
        QCoreApplication::translate("main", "distanceToUse"),
        QCoreApplication::translate("main", distanceToUseSetting.c_str()));

    parser.addOption(basePopulationSize);
    parser.addOption(numberOfGenerations);
    parser.addOption(crossbreedingRate);
    parser.addOption(mutationRate);
    parser.addOption(nbOfMutations);
    parser.addOption(operationsNotToUse);
    parser.addOption(equationTreeMaximumDepth);
    parser.addOption(inputDataPath);
    parser.addOption(tournamentSize);
    parser.addOption(filterFrom);
    parser.addOption(startSilent);
    parser.addOption(numberOfEquationsSelected);
    parser.addOption(activateDistanceMin);
    parser.addOption(startParallel);
    parser.addOption(fitDuration);
    parser.addOption(fitPopulationPeriod);
    parser.addOption(numberOfThreads);
    parser.addOption(distanceToUse);

    // Parse the command line.
    parser.parse(QCoreApplication::arguments());

    // Put the result in the variables.
    _startSilent = parser.isSet(startSilent);
    _activateDistanceMin = parser.value(activateDistanceMin).toInt();
    _mutationRate = parser.value(mutationRate).toDouble();
    _nbMutationPossible = parser.value(nbOfMutations).toInt();
    _basePopulation = parser.value(basePopulationSize).toInt();
    _crossbreedingRate = parser.value(crossbreedingRate).toDouble();
    _numberOfGenerations = parser.value(numberOfGenerations).toInt();
    _tournamentSize = parser.value(tournamentSize).toInt();
    _equationMaximumDepth = parser.value(equationTreeMaximumDepth).toInt();
    _inputDataPath = parser.value(inputDataPath);
    _filterFrom = parser.value(filterFrom).toInt();
    _numberOfEquationsSelected = parser.value(numberOfEquationsSelected).toInt();
    _startParallel = parser.isSet(startParallel);
    _fitDuration = parser.value(fitDuration).toInt();
    _fitPopulationPeriod = parser.value(fitPopulationPeriod).toInt();
    if (_fitPopulationPeriod == 0){
        _fitPopulationPeriod = 1; // value 0 is forbidden (division by 0) -> reset by the default value (1)
    }
    _numberOfThreads = parser.value(numberOfThreads).toInt();
    _maxNode = Settings::instance()->value("EquationGeneration/MaxNodes", 15).toInt();
    _realNumberPrecision = Settings::instance()->value("EquationGeneration/NumberPrecision", 6).toInt();
    _distanceToUse = parser.value(distanceToUse).toStdString();

    QString operationsToRemove = parser.value(operationsNotToUse);

    QStringList operationToRemoveList = operationsToRemove.split(QLatin1Char(','), Qt::SkipEmptyParts);

    QStringList operationList =
            {"variable",
             "constant",
             "addition", "soustraction", "multiplication", "division", "cosinus",
             "sinus", "logarithm", "exponential", "power", "squareroot",
             "inverse", "arctan", "negative", "min", "max",
             "absolute","tangent"};

    for(auto& op : operationToRemoveList){
        operationList.removeAll(op.toLower());
    }

    for (QString operation : operationList)
    {
        if (operation.toLower() == "absolute")
        {
            _operatorsList.insert(datamodel::EquationNode::Absolute);
        }
        else if (operation.toLower() == "addition")
        {
            _operatorsList.insert(datamodel::EquationNode::Addition);
        }
        else if (operation.toLower() == "constant")
        {
            _operatorsList.insert(datamodel::EquationNode::Constant);
        }
        else if (operation.toLower() == "cosinus")
        {
            _operatorsList.insert(datamodel::EquationNode::Cosinus);
        }
        else if (operation.toLower() == "division")
        {
            _operatorsList.insert(datamodel::EquationNode::Division);
        }
        else if (operation.toLower() == "exponential")
        {
            _operatorsList.insert(datamodel::EquationNode::Exponential);
        }
        else if (operation.toLower() == "logarithm")
        {
            _operatorsList.insert(datamodel::EquationNode::Logarithm);
        }
        else if (operation.toLower() == "max")
        {
            _operatorsList.insert(datamodel::EquationNode::Max);
        }
        else if (operation.toLower() == "min")
        {
            _operatorsList.insert(datamodel::EquationNode::Min);
        }
        else if (operation.toLower() == "multiplication")
        {
            _operatorsList.insert(datamodel::EquationNode::Multiplication);
        }
        else if (operation.toLower() == "power")
        {
            _operatorsList.insert(datamodel::EquationNode::Power);
        }
        else if (operation.toLower() == "sinus")
        {
            _operatorsList.insert(datamodel::EquationNode::Sinus);
        }
        else if (operation.toLower() == "soustraction")
        {
            _operatorsList.insert(datamodel::EquationNode::Soustraction);
        }
        else if (operation.toLower() == "squareroot")
        {
            _operatorsList.insert(datamodel::EquationNode::SquareRoot);
        }
        else if (operation.toLower() == "variable")
        {
            _operatorsList.insert(datamodel::EquationNode::Variable);
        }
        else if(operation.toLower() == "inverse")
        {
            _operatorsList.insert(datamodel::EquationNode::Inverse);
        }
        else if(operation.toLower() == "negative")
        {
            _operatorsList.insert(datamodel::EquationNode::Negative);
        }
        else if(operation.toLower() == "arctan")
        {
            _operatorsList.insert(datamodel::EquationNode::Arctan);
        }
        else if(operation.toLower() == "tangent")
        {
            _operatorsList.insert(datamodel::EquationNode::Tan);
        }
        else
        {
            qErrnoWarning("operation passed is not a valid operation :", operation.toStdString().c_str());
        }
    }

    if (_startSilent && !parser.isSet(inputDataPath))
    {
        qErrnoWarning("Input file path is mandatory. See help below.");
        parser.showHelp();
    }
    if (parser.isSet(help))
    {
        parser.showHelp();
    }
}

QString CommandLineParser::nodeTypeName(datamodel::EquationNode::NodeType nodeType)
{
    switch (nodeType)
    {
        case datamodel::EquationNode::Variable:
            return QString();
        case datamodel::EquationNode::Constant:
            return QString();
        case datamodel::EquationNode::Addition:
            return "Addition";
        case datamodel::EquationNode::Soustraction:
            return "Substraction";
        case datamodel::EquationNode::Multiplication:
            return "Multiplication";
        case datamodel::EquationNode::Division:
            return "Division";
        case datamodel::EquationNode::Exponential:
            return "Exponential";
        case datamodel::EquationNode::Logarithm:
            return "Logarithm ln";
        case datamodel::EquationNode::Min:
            return "Min";
        case datamodel::EquationNode::Max:
            return "Max";
        case datamodel::EquationNode::Inverse:
            return "Inverse";
        case datamodel::EquationNode::Arctan:
            return "Arctan";
        case datamodel::EquationNode::Negative:
            return "Negative";
        case datamodel::EquationNode::Cosinus:
            return "Cosinus";
        case datamodel::EquationNode::Sinus:
            return "Sinus";
        case datamodel::EquationNode::Tan:
            return "Tangent";
        case datamodel::EquationNode::SquareRoot:
            return "SquareRoot";
        case datamodel::EquationNode::Power:
            return "Power";
        case datamodel::EquationNode::Absolute:
            return "Absolute";
    }

    return QString();
}

void CommandLineParser::DisplayParametersAtInit(){
    std::stringstream ss;

    ss << "Application initialised with the following settings:" << std::endl;
    ss << std::endl << "[InputData]" << std::endl;
    ss << "FileName=" << _inputDataPath.toStdString() << std::endl;

    ss << std::endl << "[EquationGeneration]" << std::endl;
    ss << "Population=" << _basePopulation << std::endl;
    ss << "MaxDepth=" << _equationMaximumDepth << std::endl;
    ss << "MaxNodes=" << _maxNode << std::endl;
    ss << "NumberPrecision=" << _realNumberPrecision << std::endl;
    ss << "PopulationFitPeriod=" << _fitPopulationPeriod << std::endl;
    ss << "FitDuration=" << _fitDuration << "ms" << std::endl;

    ss << std::endl << "[NodeDefaultSelection]" << std::endl;
    for (int nodeType = datamodel::EquationNode::Addition; nodeType <= datamodel::EquationNode::Last; ++nodeType) {
        bool selected;
        if (utils::CommandLineParser::getStartSilent()) {
            // case command in line : info to be got from _operatorsList
            selected = true;
            QSet<datamodel::EquationNode::NodeType>::iterator it = _operatorsList.find(static_cast<datamodel::EquationNode::NodeType>(nodeType));
            if (it == _operatorsList.constEnd()){
                selected = false;
            }
        } else {
            // case GUI : info to be got from settings.ini
            selected = Settings::instance()->value("NodeDefaultSelection/" +
                                                nodeTypeName(static_cast<datamodel::EquationNode::NodeType>(nodeType)),true).toBool();
        }
        ss << nodeTypeName(static_cast<datamodel::EquationNode::NodeType>(nodeType)).toStdString() << "=" << (selected ? "true" : "false") << std::endl;
    }

    ss << std::endl << "[EquationFilter]" << std::endl;
    ss << "FilterFrom=" << _filterFrom << std::endl;
    ss << "SelectedEquations=" << _numberOfEquationsSelected << std::endl;

    ss << std::endl << "[EquationCrossBreeding]" << std::endl;
    auto parentSelectionStrategySetting =
        Settings::instance()->value("EquationCrossBreeding/ParentSelectionStrategy", "Tournament").toString();
    if (parentSelectionStrategySetting.compare("Tournament", Qt::CaseSensitivity::CaseInsensitive) == 0) {
        ss << "ParentSelectionStrategy=" << parentSelectionStrategySetting.toStdString() << std::endl;
    }
    ss << "TournamentSize=" << _tournamentSize << std::endl;
    auto parentSelectionCriteriaSetting =
        Settings::instance()->value("EquationCrossBreeding/ParentSelectionCriteria", "Distance").toString();
    if (
        (parentSelectionCriteriaSetting.compare("Distance", Qt::CaseSensitivity::CaseInsensitive) == 0) or
        (parentSelectionCriteriaSetting.compare("Pareto", Qt::CaseSensitivity::CaseInsensitive) == 0) or
        (parentSelectionCriteriaSetting.compare("Complexity", Qt::CaseSensitivity::CaseInsensitive) == 0) or
        (parentSelectionCriteriaSetting.compare("Age", Qt::CaseSensitivity::CaseInsensitive) == 0)
       ) {
        ss << "ParentSelectionCriteria=" << parentSelectionCriteriaSetting.toStdString() << std::endl;
    }
    auto crossBreedingStrategySetting =
        Settings::instance()->value("EquationCrossBreeding/CrossBreedingStrategy", "Random").toString();
    if (crossBreedingStrategySetting.compare("Random", Qt::CaseSensitivity::CaseInsensitive) == 0) {
        ss << "CrossBreedingStrategy=" << crossBreedingStrategySetting.toStdString() << std::endl;
    }
    ss << "CrossBreedingRate=" << (int)(_crossbreedingRate*100) << "%" << std::endl;

    ss << std::endl << "[EquationMutation]" << std::endl;
    ss << "MutationRate=" << (int)(_mutationRate*100) << "%" << std::endl;
    ss << "NbMutationPossible=" << _nbMutationPossible << std::endl;

    ss << std::endl << "[Interface]" << std::endl;
    ss << "MaxParetoSeries=" << Settings::instance()->value("Interface/MaxParetoSeries", 3).toInt() << std::endl;

    ss << std::endl << "[General]" << std::endl;
    ss << "EquationListRefreshRate=" << Settings::instance()->value("EquationListRefreshRate", 1).toInt() << std::endl;
    ss << "FitnessRefreshRate=" << Settings::instance()->value("FitnessRefreshRate", 1).toInt() << std::endl;
    ss << "ParetoRefreshRate=" << Settings::instance()->value("ParetoRefreshRate", 1).toInt() << std::endl;

    ss << "NbOfGenerations=" << _numberOfGenerations << std::endl;
    if (_activateDistanceMin > (int)EnableDistMin::Zero) {
        _activateDistanceMin = 0;
    }
    ss << "EnableDistanceMin=";
    if (_activateDistanceMin == (int)EnableDistMin::Disable) {/* Disable */
        ss << "Disable" << std::endl;
    } else if (_activateDistanceMin == (int)EnableDistMin::Enable) {/* Enable */
        ss << "Enable" << std::endl;
    } else {/* Zero */
        ss << "Zero" << std::endl;
    }

    ss << std::endl << "[EquationDistance]" << std::endl;
    ss << "Distance=" << Settings::instance()->value("Distance", "R2").toString().toStdString() << std::endl;


    logs::Logger::logInfo(ss.str(), {logs::LogTags::algorithm, logs::LogTags::settings});
}

double CommandLineParser::getMutationRate() { return _mutationRate; }

int CommandLineParser::getNbMutationPossible() { return _nbMutationPossible; }

int CommandLineParser::getBasePopulation() { return _basePopulation; }

double CommandLineParser::getCrossbreedingRate() { return _crossbreedingRate; }

int CommandLineParser::getNumberOfGenerations() { return _numberOfGenerations; }

double CommandLineParser::getDistanceMinimum() { return _distanceMinimum; }

int CommandLineParser::getTournamentSize() { return _tournamentSize; }

int CommandLineParser::getEquationMaximumDepth() { return _equationMaximumDepth; }

const QSet<datamodel::EquationNode::NodeType> &CommandLineParser::getOperatorsList() { return _operatorsList; }

bool CommandLineParser::getStartSilent() { return _startSilent; }

bool CommandLineParser::getHelpRequired() { return _helpRequired; }

int CommandLineParser::getNumberOfEquationSelected() { return _numberOfEquationsSelected; }

int CommandLineParser::getFilterFrom() { return _filterFrom; }

const QString &CommandLineParser::getInputDataFilePath() { return _inputDataPath; }

int CommandLineParser::getActivateDistanceMin() { return _activateDistanceMin; }

int CommandLineParser::getTimeSelected() { return _timeSelected;}

bool CommandLineParser::getStartParallel() { return _startParallel; }

int CommandLineParser::getFitDuration() { return _fitDuration; }

int CommandLineParser::getFitPopulationPeriod() { return _fitPopulationPeriod; }

int CommandLineParser::getNumberOfThreads() { return _numberOfThreads; }

int CommandLineParser::getMaxNode() { return _maxNode; }

int CommandLineParser::getRealNumberPrecision() { return _realNumberPrecision; }

std::string CommandLineParser::getDistanceToUse()
{
    return _distanceToUse;
}

// Static variables must be declared as global variable in a .cpp file.
double CommandLineParser::_mutationRate;
int CommandLineParser::_nbMutationPossible{1};
int CommandLineParser::_basePopulation;
double CommandLineParser::_crossbreedingRate;
int CommandLineParser::_numberOfGenerations;
double CommandLineParser::_distanceMinimum;
int CommandLineParser::_tournamentSize;
int CommandLineParser::_equationMaximumDepth;
QSet<datamodel::EquationNode::NodeType> CommandLineParser::_operatorsList;
int CommandLineParser::_filterFrom;
QString CommandLineParser::_inputDataPath;
bool CommandLineParser::_startSilent = false;
bool CommandLineParser::_helpRequired = false;
int CommandLineParser::_numberOfEquationsSelected;
int CommandLineParser::_activateDistanceMin;
int CommandLineParser::_timeSelected;
bool CommandLineParser::_startParallel= false;
int CommandLineParser::_fitDuration;
int CommandLineParser::_fitPopulationPeriod;
int CommandLineParser::_numberOfThreads;
int CommandLineParser::_maxNode;
int CommandLineParser::_realNumberPrecision;
std::string CommandLineParser::_distanceToUse;

}  // namespace utils
