#include "AppFileSystem.h"

#include <QDebug>
#include <QDir>
#include <QStandardPaths>

#include "FileUtils.h"

namespace utils
{
QString AppFileSystem::sourceApplicationFolder()
{
#ifdef DATA_PATH
    return QStringLiteral(DATA_PATH);
#else
    return QString(_dataPath.c_str());
#endif
}

QString AppFileSystem::logFolder()
{
    return sourceApplicationFolder() + QStringLiteral("/log/");
}

QString AppFileSystem::dataFolder()
{    
    return sourceApplicationFolder() + QStringLiteral("/data/");
}

QString AppFileSystem::importFolder()
{
    return sourceApplicationFolder() + QStringLiteral("/import/");
}
void AppFileSystem::createFolders(std::string dataPath)
{
    _dataPath = dataPath;
    utils::FileUtils::createFolder(sourceApplicationFolder());
    utils::FileUtils::createFolder(logFolder());
    utils::FileUtils::createFolder(dataFolder());
    utils::FileUtils::createFolder(importFolder());
}

std::string AppFileSystem::_dataPath = "";

}    // namespace utils
