#pragma once

#include <QSettings>

#include "Utils_global.h"

class Settings : public QSettings
{
   public:
    explicit Settings(QObject* parent = nullptr);
    static Settings* instance();

   protected:
    Settings(const QString fileName, QObject* parent = nullptr);

   private:
    static Settings* _instance;
};
