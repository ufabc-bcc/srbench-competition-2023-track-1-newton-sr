
#pragma once

#include "Utils_global.h"
#include <QList>

namespace utils {
/*!
 * @brief Specific comparison function to compare double then nan and inf (double < nan < inf) 
 */
bool lessThan(double first, double second);

/*!
 * @brief Specific comparison function to compare double then nan and inf (inf > nan > double) 
 */
bool moreThan(double first, double second);

QList<QPair<int, double>> orderDistancesDecreasingOrder(
    const QMap<int, double> &distances);
} // namespace utils


