#include "FileUtils.h"
#include "Logger_v2/Logger.h"
#include <QDebug>
#include <QDir>
#include <QJsonDocument>
#include <QtGui/QFontDatabase>
#include "Logger_v2/Logger.h"

#ifdef Q_OS_ANDROID
#include <QtAndroid>
#endif

namespace utils
{
void FileUtils::createFolder(const QString& folderPath)
{
    QDir folder(folderPath);

    if (!folder.exists())
    {
        if (!folder.mkpath(QStringLiteral("."))) {
            //qCritical() << "Cannot create folder in : " << folderPath;
            logs::Logger::logCritical("The folder cannot be create",{logs::LogTags::utils},std::invalid_argument(folderPath.toStdString()));
        }else
        {
            //qInfo() << "Created folder : " << folderPath;
            std::string message_info_create_folder = "Created folder : "
                    + folderPath.toStdString();
            logs::Logger::logInfo(message_info_create_folder,{logs::LogTags::utils});
        }
    }
}

QVector<int> FileUtils::loadFonts(const QString& sourceFolder)
{
    QDir sourceDirectory(sourceFolder);
    QVector<int> fontIdList;

    QFileInfoList fontsToLoad =
      sourceDirectory.entryInfoList(QStringList() << QStringLiteral("*.ttf"), QDir::Files);
    fontIdList.reserve(fontsToLoad.size());
    for (const QFileInfo& fontFile : qAsConst(fontsToLoad))
    { fontIdList.append(QFontDatabase::addApplicationFont(fontFile.filePath())); }

    sourceDirectory.setFilter(QDir::Dirs);

    const QStringList& subdirs(sourceDirectory.entryList());
    for (const QString& subdir : subdirs)
    {
        QVector<int> subFontIdList = loadFonts(sourceDirectory.absolutePath() + QDir::separator() + subdir);
        for (int subIds : qAsConst(subFontIdList)) fontIdList.append(subIds);
    }
    return fontIdList;
}
}    // namespace utils
