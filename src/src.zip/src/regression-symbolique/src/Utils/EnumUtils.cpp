#include "EnumUtils.h"

#include "Logger_v2/Logger.h"

std::string utils::EnumUtils::categoryToString(const datamodel::EquationNode::NodeCategory& category)
{
    switch(category){
        case datamodel::EquationNode::NodeCategory::Commutative:
            return "Commutative";
        case datamodel::EquationNode::NodeCategory::Terminal:
            return "Terminal";
        case datamodel::EquationNode::NodeCategory::NonCommutative:
            return "NonCommutative";
        case datamodel::EquationNode::NodeCategory::MinMax:
            return "MinMax";
        case datamodel::EquationNode::NodeCategory::Function:
            return "Function";
        default:
            logs::Logger::logError("Unknown category", {logs::LogTags::utils});
            return "";
    }
}

std::string utils::EnumUtils::typeToString(const datamodel::EquationNode::NodeType& type)
{
    switch(type){
        case datamodel::EquationNode::Variable:
            return "Variable";
        case datamodel::EquationNode::Constant:
            return "Constant";
        case datamodel::EquationNode::Addition:
            return "Addition";
        case datamodel::EquationNode::Soustraction:
            return "Soustraction";
        case datamodel::EquationNode::Multiplication:
            return "Multiplication";
        case datamodel::EquationNode::Division:
            return "Division";
        case datamodel::EquationNode::Cosinus:
            return "Cosinus";
        case datamodel::EquationNode::Sinus:
            return "Sinus";
        case datamodel::EquationNode::Logarithm:
            return "Logarithm";
        case datamodel::EquationNode::Exponential:
            return "Exponential";
        case datamodel::EquationNode::Power:
            return "Power";
        case datamodel::EquationNode::SquareRoot:
            return "SquareRoot";
        case datamodel::EquationNode::Inverse:
            return "Inverse";
        case datamodel::EquationNode::Arctan:
            return "Arctan";
        case datamodel::EquationNode::Negative:
            return "Negative";
        case datamodel::EquationNode::Min:
            return "Min";
        case datamodel::EquationNode::Max:
            return "Max";
        case datamodel::EquationNode::Absolute:
            return "Absolute";
        case datamodel::EquationNode::Tan:
            return "Tan";
        default:
            logs::Logger::logError("Unknown type", {logs::LogTags::utils});
            return "";
    }
}
