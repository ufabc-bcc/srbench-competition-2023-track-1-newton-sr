#pragma once

#include <string>
#include <DataModel/EquationNode.h>

namespace utils
{
class EnumUtils
{
public:
    /**
     * @brief Transform the enum value of category into string
     * @return the string of the NodeCategory category
     */
    static std::string categoryToString(const datamodel::EquationNode::NodeCategory& category);

    /**
     * @brief Transform the enum value of type into string
     * @return the string of the NodeType category
     */
    static std::string typeToString(const datamodel::EquationNode::NodeType& type);

};
} //namespace utils
