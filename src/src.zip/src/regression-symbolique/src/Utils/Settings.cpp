#include "Settings.h"

Settings* Settings::_instance = nullptr;

Settings::Settings(QObject* parent) : QSettings{parent} {}

Settings::Settings(QString fileName, QObject* parent) : QSettings(fileName, Format::IniFormat, parent) {}

Settings* Settings::instance()
{
    if (_instance == nullptr)
    {
        _instance = new Settings("settings.ini");
    }
    return _instance;
}
