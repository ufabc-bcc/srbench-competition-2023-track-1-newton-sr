#include "StringUtils.h"

std::string utils::StringUtils::trim(const std::string &str, const std::string &whitespace)
{
    const auto strBegin = str.find_first_not_of(whitespace);
    if (strBegin == std::string::npos)
        return ""; // no content

    const auto strEnd = str.find_last_not_of(whitespace);
    const auto strRange = strEnd - strBegin + 1;

    return str.substr(strBegin, strRange);
}

bool utils::StringUtils::isEqualCaseInsensitve(const std::string &str1, const std::string &str2)
{
    if(str1.size() != str2.size())
        return false;

    for(size_t i = 0; i < str1.size(); ++i)
        if(std::tolower(str1[i]) != std::tolower(str2[i]))
            return false;

    return true;
}
