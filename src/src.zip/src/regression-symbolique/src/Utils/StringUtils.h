#pragma once

#include <string>

namespace utils
{
class StringUtils
{
public:
    static std::string trim(const std::string& str,
                            const std::string& whitespace = " \t");

    static bool isEqualCaseInsensitve(const std::string &str1, const std::string &str2);
};
} //namespace utils
