#pragma once

#include <QDebug>
#include <QCommandLineParser>
#include <QString>
#include <QSet>
#include <QMetaEnum>
#include "Utils_global.h"
#include "DataModel/EquationNode.h"

namespace utils
{
    enum class EnableDistMin { Disable, Enable, Zero};
    class CommandLineParser
    {
    public:
        /*!
         * @brief Manage the parsing and the holding of the command line paramters.
         */
        CommandLineParser();

        /*!
         * @brief Method to parse the command line. Called once in the main.cpp.
         */
        static void ParseCommandLine();
        /*!
         * @brief Method to display the parameters at initialization. Called once in the main.cpp.
         */
        static void DisplayParametersAtInit();

        // Getters for the parameters.
        static double getMutationRate();
        static int getNbMutationPossible();
        static int getBasePopulation();
        static double getCrossbreedingRate();
        static int getNumberOfGenerations();
        static double getDistanceMinimum();
        static int getTournamentSize();
        static int getEquationMaximumDepth();
        static int getFilterFrom();
        static const QString &getInputDataFilePath();
        static const QSet<datamodel::EquationNode::NodeType> &getOperatorsList();
        static bool getStartSilent();
        static bool getHelpRequired();
        static bool getStartParallel();
        static int getNumberOfEquationSelected();
        static int getActivateDistanceMin();
        static int getTimeSelected();
        static int getFitDuration();
        static int getFitPopulationPeriod();
        static int getNumberOfThreads();
        static int getMaxNode();
        static int getRealNumberPrecision();
        static QString nodeTypeName(datamodel::EquationNode::NodeType nodeType);
        static std::string getDistanceToUse();


    private:
        static double _mutationRate;
        static int _nbMutationPossible;
        static int _basePopulation;
        static double _crossbreedingRate;
        static int _numberOfGenerations;
        static double _distanceMinimum;
        static int _tournamentSize;
        static int _equationMaximumDepth;
        static QSet<datamodel::EquationNode::NodeType> _operatorsList;
        static int _filterFrom;
        static QString _inputDataPath;
        static bool _startSilent;
        static bool _helpRequired;
        static int _numberOfEquationsSelected;
        static int _activateDistanceMin;
        static int _timeSelected;
        static bool _startParallel;
        static int _fitDuration;
        static int _fitPopulationPeriod;
        static int _numberOfThreads;
        static int _maxNode;
        static int _realNumberPrecision;
        static std::string _distanceToUse;

    };
}
