#pragma once

#include <QCryptographicHash>

#include <functional>
#include <mutex>
#include <unordered_set>

#include "DataModel/EquationTree.h"
#include "DataModel/DataPoint.h"


namespace algorithmcontroller {

class EquationTransformation {
public:
    EquationTransformation();
    static std::string computeHash(datamodel::EquationTreeItem equation);

protected:
    static void simplify(datamodel::EquationTree &equation);

    //static void evaluate(datamodel::EquationTree &equation, const QList<datamodel::DataPoint> inputDatas);
    static void evaluate(datamodel::EquationTree &equation, const std::vector<datamodel::DataPoint> inputDatas);

    bool applyEquationTransformation(datamodel::EquationTree &equation,
                                     const std::vector<datamodel::DataPoint> inputDatas,
                                     std::unordered_set<std::string> &equationsStructuresHash,
                                     int maxNumberOfNodes,
                                     int generation) const;
private:
    mutable std::mutex mtx; // mutex for critical section
};

} // namespace algorithmcontroller
