#pragma once

#include "DataModel/EquationTreeItem.h"

namespace algorithmcontroller {

/**
 * @brief The EquationStructureCalculator class
 */
class EquationStructureCalculator {

 public:
  /**
   * @brief Returns a string representing the structure of an equation
   * @param equation
   * @return String
   */
  static std::string getEquationStructure(const datamodel::EquationTreeItem &root);
};

}  // namespace algorithmcontroller
