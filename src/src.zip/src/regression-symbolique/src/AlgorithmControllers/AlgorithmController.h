#pragma once

#include <QMap>
#include <QObject>
#include <QThread>
#include <QVariant>
#include <QtCharts/QBarSet>
#include <QMutex>

#include "DataModel/DataPoint.h"
#include "EquationParameters/EquationGenerationCyclingParameters.h"
#include "EquationParameters/EquationGenerationParameters.h"
#include "DataModel/EquationTree.h"
#include "EquationEditors/EquationGenerator.h"
#include "InputFileManager.h"
#include "EquationFit.h"
#include "libev3/parser.h"

#include <memory>
#include <unordered_set>

namespace algorithmcontroller
{

using QtCharts::QBarSet;

constexpr double MAX_COMPUTE_TIME = 60000;
constexpr int INIT_POPULATION_SIZE = 10000;
constexpr double VARIANCE_THRESHOLD = 0.0001;
constexpr double COEFF_THRESHOLD = 0.001;
/**
 * @brief The AlgorithmController class handle the manipulation of equations
 *        Meaning cross breading, mutation, cycle of generation, etc
 */
class AlgorithmController : public QObject
{
    Q_OBJECT
   public:
    /**
     * @brief Default constructor
     * @param parent, used for garbage collector
     */
    explicit AlgorithmController(QObject *parent = nullptr);

    ~AlgorithmController();

    // getter / setter
    InputFileManager *inputFileManager();
    EquationFit *getFitController();
    std::unordered_set<std::string> *getEquationsStructuresHash();
    datamodel::EquationTree* equationsArray();
    uint getEquationsArraySize();

    bool getProcessBenchmark();
    bool getDisplaySignalsBench();
    bool getPreviousDisplaySignalsBench();
    bool getDisplayFitnessBench();
    bool getPreviousDisplayFitnessBench();
    equationparameters::EquationGenerationParameters getGenerationParameterCache() const;
    equationparameters::EquationGenerationCyclingParameters getCurrentGenerationCyclingParameters() const;

    void reallocEquationTree(uint newSize);

    /**
     * @brief generateSingleEquation Generate a single equation with user's setted parameters
     * @param equationGenerator Handle the generation of an equation
     * @param equationDistanceParameters Parameters to choose between the differents distences implemented
     * @return a fully builded equation
     */
    datamodel::EquationTree generateSingleEquation(const equationeditors::EquationGenerator &equationGenerator,
                                                   const equationparameters::EquationDistanceParameters &equationDistanceParameters);


public slots:

    /**
     * @brief Mostly called after all work has been done by the qthread
     */
    void actualizeViews();

    /**
     * @brief Called when the reset button is clicked in the ParametersController
     */
    void resetGeneration();

    /**
     * @brief Called when the init button is clicked in the ParametersController
     *
     */
    void onEquationCycledGenerated(int generationNumber, int breedAndMutationRate = 0);

    /**
     * @brief Called when the pause button is clicked in the ParametersController
     */
    void onStopEquationsGeneration();

    /**
     * @brief   Called when the continue button is clicked in the ParametersController
     */

    void continueGeneration(bool infiniteGeneration, int nomberOfGeneration, double distanceMinimum, int activateDistanceMin, int timeSelected);


    /**
     * @brief Called when the start button is clicked in the ParametersController
     *
     * @param equationGenerationParameters          Parameters for the init generation (if needed)
     * @param equationGenerationCyclingParameters   Parameters for the cycling generation
     */
    void onStartGeneration(equationparameters::EquationGenerationParameters equationGenerationParameters,
                           equationparameters::EquationGenerationCyclingParameters equationGenerationCyclingParameters);

    /**
     * @brief Generate all the equations depending on parameters
     * @param equationGenerationParameters used to generate equations
     */
    void onEquationGenerationRequired(equationparameters::EquationGenerationParameters equationGenerationParameters,
                                      equationparameters::EquationDistanceParameters equationDistanceParameters);
    /**
     * @brief Launch a new cycle that will create a new equation generation
     * @param equationGenerationCyclingParameters
     */
    void onGenerationCyclingRequired(
        equationparameters::EquationGenerationCyclingParameters equationGenerationCyclingParameters);

    /**
     * @brief Update the equations depending on a new input data file
     *        Use QVariant because this slot is conneted to qml signal
     * @param inputFilePath
     * @param inputDatas
     */
    void onInputDataSelected(const QString &inputFilePath, const QVariant &inputDatas);
    void onInputDataChanged(const QList<datamodel::DataPoint> inputDatas);


    /**
     * @brief remove duplicates in offspring
     * @param offspring
     * @param equations
     */
    static void removeDuplicates(datamodel::Equations &equations, datamodel::Equations &newEquations);

    /**
     * @brief remove cases of division by 0
     * @param equationsArray
     * @param equationsArraySize
     * @param nbVariables
     */
    static void removeDivisionByZero(datamodel::EquationTree* equationsArray, const uint equationsArraySize, int nbVariables);

    /**
     * @brief remove duplicates a list of equations
     * @param equations
     */
    static int removeDuplicates(datamodel::EquationTree* equationsToFilter, uint equationsToFilterSize);



    void onSilentProcessDone();
    void forwardElapsedGenTimeEvent(const QString &value);
    void forwardBenchmarkUpdate( int max_time, int  generationValue);
    void forwardBenchmarkInit(QBarSet *crossbreeding, QBarSet *mutation, QBarSet *filter, QBarSet *pareto, QBarSet *process_clean_and_new_equation, QBarSet *signals_process, QBarSet *fitness, QBarSet *simplification);
    void forwardBenchmarkReset();
    void processBenchmarkChanged(bool value1, bool value2, bool value3);


signals:

    void setRedDistance();
    void setRedNumberOfGenerations();
    void setRedTime();
    void generationElapsedTimeUpdated(const QString &value);
    void resetGenForGenProcessTime();
    void benchmarkUpdated(int max_time, int  generationValue);
    void benchmarkInit(QBarSet *crossbreeding, QBarSet *mutation, QBarSet *filter, QBarSet *pareto, QBarSet *process_clean_and_new_equation, QBarSet *signals_process, QBarSet *fitness, QBarSet *simplification);
    void benchmarkReset();
    void instantRefreshEquationListControler();
    void instantRefreshFitness();
    void instantRefreshParetoControler(const datamodel::EquationTree* equationsArray, uint equationsArraySize);
    void clearRefreshEquationListControler();
    void updateBestEfficiencyEquation(datamodel::EquationTree equation); // Best Equation Efficiency dans l'UI

    /**
     * @brief   This signal is raised to notify the ParametersController that we
     *          sucessfully generated n generations and to refresh the buttons (put the pause button into start
     * again)
     */
    void nonInfiniteGenerationComplete();

    /**
     * @brief   The signal is raised when we want to reset the Equation Plotter
     */
    void clearEquationPlotter();

    /**
     * @brief   The signal is raised for when we want to clear the Pareto graph
     */
    void clearParetoRequest();

    /**
     * @brief   This signal is connected to the QThread and will tell him to stop
     *          it's current work. It'll still finish the current generation it's on.
     */
    void stopGenerationThread();

    /**
     * @brief Signal sent to the QThread doing the work
     */
    void generationCycling(algorithmcontroller::AlgorithmController *,
                           equationparameters::EquationGenerationCyclingParameters);

    /**
     * @brief Triggered when the list of equation has been changed
     */
    void equationsDataChanged(const datamodel::EquationTree* equationsArray, uint equationsArraySize);

    /**
     * @brief Triggered when a new equation generation has been created
     */
    void generationCreated(const datamodel::EquationTree* equationsArray, const uint equationsArraySize, int breedAndMutationRate = 0);

    /**
     * @brief Triggered when a the number of generation changed
     */
    void generationCountChanged(int generationNumber);

    void silentProcessDone(int returnCode);


   private:
    Q_DISABLE_COPY_MOVE(AlgorithmController)

    /*!
     * @brief List of the equations evolved by the genetic algorithm (= the population)
     */

    datamodel::EquationTree* _equationsArray = nullptr;
    uint _equationsArraySize = 0;


    /**
     * @brief Manager allowing to handle input files as input data
     */
    InputFileManager _inputFileManager;

    QThread _workerThread;
    bool _resetGeneration = false;
    bool _workEnded = true;
    bool processBenchmark = false;
    bool previousDisplaySignalsBench  = false;
    bool displaySignalsBench = false;
    bool previousDisplayFitnessBench  = false;
    bool displayFitnessBench = false;

    equationparameters::EquationGenerationCyclingParameters _currentGenerationCyclingParameters;
    equationparameters::EquationGenerationParameters _generationParameterCache;
    EquationFit _fitController;
    std::unordered_set<std::string> _equationsStructuresHash;
};

class WorkerGenerationCycling : public QObject
{
    Q_OBJECT

   public slots:

    void doWorkParallel(algorithmcontroller::AlgorithmController *algorithmController,
                equationparameters::EquationGenerationCyclingParameters params);

    /**
     * @brief stat based editing of equations
     * @param equationsArray
     * @param equationsArraySize
     * @param points
     */
    void statBasedEquationEdition(datamodel::EquationTree* equationsArray,
                                                    const uint equationsArraySize,
                                                    const std::vector<datamodel::DataPoint> &points,
                                                    std::unordered_set<std::string> &hashTable);


    void stopWorking();
    /**
     * @brief Reset _previousCpt value use to process the duration to generate a generation
     * @param None
     */
    void resetGenForGenProcessTime();


   signals:
    void generationCompleted(int generationNumber, int breedAndMutationRate = 0);
    void nonInfiniteGenerationCompleted();

    /**
     * @brief Can be called either by completing the task, or leaving it early
     */
    void workEnded();

   private:

    void simplifyAllEquations(const std::vector<datamodel::DataPoint> &points, datamodel::EquationTree* &equationsArray, const uint equationsArraySize, std::unordered_set<std::string> &hashTable);

    void fitAllEquations(EquationFit* fitController,
                         const std::vector<datamodel::DataPoint> &points,
                         datamodel::EquationTree* equationsArray,
                         const uint equationsArraySize,
                         std::unordered_set<std::string> &hashTable);
    

    std::atomic_bool _working{false};

    QMutex mutex;
    int _cpt =1;
    int _previousCpt=0;
    QBarSet *crossbreeding = new QBarSet("Crossbreeding");
    QBarSet *mutation = new QBarSet("Mutation");
    QBarSet *filter = new QBarSet("Filter");
    QBarSet *pareto = new QBarSet("Pareto");
    QBarSet *process_clean_and_new_equation= new QBarSet("New equation");
    QBarSet *fitness = new QBarSet("Fitness");
    QBarSet *signals_process = new QBarSet("Signals");
    QBarSet *simplification = new QBarSet("Simplification");


};
}  // namespace algorithmcontroller
