#pragma once

#include "DataModel/DataPoint.h"
#include "DataModel/EquationTreeItem.h"
#include "DataModel/EquationTree.h"

namespace algorithmcontroller
{
/**
 * @brief The DistanceToDataCalculator class
 */
class DistanceToDataCalculator
{
   public:
    // Do not use reference there for the parameters, to be able to run safely the calculations in a thread its
    // better to copy the values
    /**
     * @brief Compute the sum error/distance between input data and a tree, "moindre carré" method
     * @param equationTreeItem The tree
     * @param inputDatas The data used in input
     * @return The value of the error/distance
     */
    static double calculateCumulatedDistanceToData(datamodel::EquationTreeItem equationTreeItem,
                                                   std::vector<datamodel::DataPoint> inputDatas);



    /**
     * @brief Compute the average value of the inputData \bar{y} = \frac{1}{n} \sum_i y_i
     * @param inputDatas The data used in input
     * @return The values of the average
     */
    static double calculateAveragedInputDataValues(std::vector<datamodel::DataPoint> inputDatas);


    /**
     * @brief Compute the R2 as defined in https://en.wikipedia.org/wiki/Coefficient_of_determination
     * SSres = \sum_i (y_i - f_i)^2  (y is data set and f is equation eval)
     * SStot = \sum_i (y_i - \bar{y})^2  (\bar(y) is y averaged)
     * R2 = Sres/Stot
     * @param inputDatas The data used in input
     * @return The value of R2
     */
    static double calculateRSquared(datamodel::EquationTreeItem equationTreeItem, std::vector<datamodel::DataPoint> inputDatas);

    /**
     * @brief Compute the sum error/distance between a list input data and a list of tree
     * @param equations A list of equations
     * @param inputDatas The data used in input
     * @param concurrentCalculation
     * @return A list of errors/distances
     */
    static std::map<int, double> calculateDistancesToData(const QMap<int, datamodel::EquationTreeItem> &equations,
                                                      const std::vector<datamodel::DataPoint> &inputDatas,
                                                      bool concurrentCalculation);


    /**
     * @brief Compute the "Coefficient of determination" usually called Rsquared (https://en.wikipedia.org/wiki/Coefficient_of_determination) (threaded)
     * \bar{y} = averaged y
     * Sres = \sum_i (y_i - f_i)
     * Stot = \sum_i (y_i-\bar{y})
     * R2 = 1 - Sres/Stot
     * @param equations A list of equations
     * @param inputDatas The data used in input
     * @param concurrentCalculation
     * @return A list of errors/distances
     */
    static std::map<int, double> calculateRSquaredCoeff(QMap<int, datamodel::EquationTreeItem> &equations,
                                                    const std::vector<datamodel::DataPoint> &inputDatas,
                                                    bool concurrentCalculation);


    // TODO evaluate if it's relevent
    /**
     * @brief Compute the sum error/distance between input data and a tree, "moindre carré" method, threaded
     * @param equations A list of equations
     * @param inputDatas The data used in input
     * @return The value of the error/distance
     */
    static std::map<int, double> calculateDistancesToDataConcurrent(
        const QMap<int, datamodel::EquationTreeItem> &equations, const std::vector<datamodel::DataPoint> &inputDatas);

    // TODO evaluate if it's relevent
    /**
     * @brief Compute the sum error/distance between a list input data and a list of tree, threaded
     * @param equations A list of equations
     * @param inputDatas The data used in input
     * @return A list of errors/distances
     */
    static std::map<int, double> calculateDistancesToDataNonConcurrent(
        const QMap<int, datamodel::EquationTreeItem> &equations, const std::vector<datamodel::DataPoint> &inputDatas);


    /**
     * @brief Compute the "Coefficient of determination" usually called Rsquared (https://en.wikipedia.org/wiki/Coefficient_of_determination) (threaded)
     * \bar{y} = averaged y
     * Sres = \sum_i (y_i - f_i)
     * Stot = \sum_i (y_i-\bar{y})
     * R2 = 1 - Sres/Stot
     * @param equations A list of equations
     * @param inputDatas The data used in input
     * @return A list of errors/distances
     */
    static std::map<int, double> calculateRSquaredCoeffConcurrent(
            QMap<int, datamodel::EquationTreeItem> &equations, const std::vector<datamodel::DataPoint> &inputDatas);


    /**
     * @brief Compute the "Coefficient of determination" usually called Rsquared (https://en.wikipedia.org/wiki/Coefficient_of_determination)
     * \bar{y} = averaged y
     * Sres = \sum_i (y_i - f_i)
     * Stot = \sum_i (y_i-\bar{y})
     * R2 = 1 - Sres/Stot
     * @param equations A list of equations
     * @param inputDatas The data used in input
     * @return A list of errors/distances
     */
    static std::map<int, double> calculateRSquaredCoeffNonConcurrent(
            QMap<int, datamodel::EquationTreeItem> &equations, const std::vector<datamodel::DataPoint> &inputDatas);

    /**
     * @brief Compute the distance depending of the user settings
     * @param equationTree An equation
     * @param inputDatas The data used in input
     * @return the distance (R2 or MSE)
     */
    static double computeDistance(const datamodel::EquationTree equationTree,
                                  std::vector<datamodel::DataPoint> inputDatas);
};
}  // namespace algorithmcontroller
