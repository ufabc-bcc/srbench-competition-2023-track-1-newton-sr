#pragma once

#include <QList>
#include <QObject>

#include "DataModel/DataPoint.h"

namespace algorithmcontroller {


/**
 * @brief The InputFileManager class handle the input files
 */
class InputFileManager : public QObject {
   Q_OBJECT
   public:
    /**
     * @brief Constructor
     * @param used for garbage collector
     */
    InputFileManager(QObject *parent = nullptr);

    /**
     * @brief Update the existing input data with a new list of data
     * @param inputFilePath File containing the data
     * @param inputDatas The data (list of points)
     */
    void inputDataSelected(QVariant inputFilePath, QVariant inputDatas);

    /**
     * @brief Load the default input file depending on the INPUT_DATA_FILE_NAME constant
     */
    void loadDefaultInputFile();

    // getter / setter
    const std::vector<datamodel::DataPoint> &inputDatas() const;
    QString applicationDataFolder() const;
    void setApplicationDataFolder(const QString &applicationDataFolder);

    uint getNumberOfVariables();

   signals:
    /**
     * @brief Triggered when the input data has been changed
     * @param inputDatas simple list of points
     */
    void inputDatasChanged(QList<datamodel::DataPoint> inputDatas);
    void inputDatasChangedResetWindow();
    void inputDatasChangedInitStartButton();
    void resetButtonClicked();

   private:
    Q_DISABLE_COPY_MOVE(InputFileManager)

    /**
     * @brief The input data, came from files, a simple list of points
     */
    std::vector<datamodel::DataPoint> _inputDatas;

    /**
     * @brief  The folder where we stock the data files (appFolder/data/)
     */
    QString _applicationDataFolder;

    /**
     * @brief The default input data file name
     */
    static const QString INPUT_DATA_FILE_NAME_CSV;
    static const QString INPUT_DATA_FILE_NAME_TSV;
};

}  // namespace algorithmcontroller
