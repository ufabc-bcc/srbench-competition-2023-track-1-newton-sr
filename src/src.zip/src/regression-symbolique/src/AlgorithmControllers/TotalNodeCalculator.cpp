#include "TotalNodeCalculator.h"
#include "DataModel/EquationNode.h"
#include <map>
#include <regex>
#include <cmath>

namespace algorithmcontroller {
int TotalNodeCalculator::calculateTotalNode(
    const datamodel::EquationTreeItem &root) {
   int totalNode;

  if (root.isEmpty()) return 0;

  totalNode = 1;

  for (auto iterator = root.arguments().cbegin();
       iterator != root.arguments().cend(); ++iterator) {
      totalNode += calculateTotalNode(*iterator);
  }

  return totalNode;
}

double TotalNodeCalculator::calculateTotalNodeDouble(
    const datamodel::EquationTreeItem &root, uint nbVar) {
    double totalNode = 1.;

    if (root.isEmpty()) return 0.;

    if (root.currentNode()->type() == datamodel::EquationNode::NodeType::Constant)
    {
        double v = root.currentNode()->value(std::vector<double>(nbVar,0.));

        std::regex sci_form("([1-9])(.([0-9]+))?(e[+|-]([0-9]+)?)?");
        std::cmatch m;
        std::string value = std::to_string(v);
        bool match = std::regex_match(value.c_str(), m, sci_form, std::regex_constants::match_not_null);

        if (match) {
            if (m.length() > 3 && m[3] != ""){
                int digitsAfterFloatingPoints = m[3].str().length();
                totalNode += digitsAfterFloatingPoints*0.001;
            }

            if (m.length() > 5 && m[5] != "") {
                int expPart = std::stoi(m[5].str());
                totalNode += expPart*0.001;
            }
        }
    }

    for (auto iterator = root.arguments().cbegin();
         iterator != root.arguments().cend(); ++iterator) {
         totalNode += calculateTotalNodeDouble(*iterator, nbVar);
    }

    return totalNode;
}

void calculateComplexityRecursive(const datamodel::EquationTreeItem &root,
                                  std::map<datamodel::EquationNode::NodeType,double>& occurences,
                                  uint nbVar) {
    if(!root.isEmpty()){
        auto i = occurences.find(root.currentNode()->type());
        if (i != occurences.end()) {
            if(i->first == datamodel::EquationNode::Constant){
                // multiplication instead of addition -> log(a*b) = log(a) + log(b)
                double nodeValue = root.currentNode()->value(std::vector<double>(nbVar,0.));
                i->second += 0.5 * log2(1. + nodeValue * nodeValue);

            }else{
                i->second++;
            }
        }else{
            if(root.currentNode()->type() == datamodel::EquationNode::Constant){
                double nodeValue = root.currentNode()->value(std::vector<double>(nbVar,0.));
                double v = 0.5 * log2(1. + nodeValue * nodeValue);

                occurences.insert({root.currentNode()->type(),v});
            }else{
                occurences.insert({root.currentNode()->type(),1});
            }
        }
        for (auto iterator = root.arguments().cbegin();
             iterator != root.arguments().cend(); ++iterator) {
             calculateComplexityRecursive(*iterator, occurences, nbVar);
        }
    }
}

double TotalNodeCalculator::calculateComplexity(const datamodel::EquationTreeItem &root, uint nbVar) {
    std::map<datamodel::EquationNode::NodeType,double> occurences;
    double complexity = 0.;

    calculateComplexityRecursive(root, occurences, nbVar);
    auto constantExist = occurences.find(datamodel::EquationNode::Constant);
    if (constantExist != occurences.end()) {
        if(constantExist->second != 0){
            complexity += constantExist->second;
        }
        occurences.erase(constantExist);
    }
    double n = occurences.size();
    double k = 0.;
    for (auto i = occurences.begin(); i != occurences.end(); ++i){
        k += i->second;
    }

    if(occurences.size() != 0){
        complexity += k * log2(n);
    }
    return complexity;
}
}  // namespace algorithmcontroller
