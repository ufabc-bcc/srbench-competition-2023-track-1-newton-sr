#include "EquationCrossbreeding.h"

#include <QMap>
#include <QtConcurrent/QtConcurrent>
#include "EquationEditors/CrossbreedParentSelector.h"
#include "EquationEditors/EquationCrossbreeder.h"
#include <EquationEditors/EquationSimplifier.h>

#include <QDebug>
#include <iostream>

namespace algorithmcontroller
{

std::pair<datamodel::EquationTree*, uint> EquationCrossbreeding::crossbreeds(const datamodel::EquationTree* equations,
                                                                              uint equationsSize,
                                                                              const std::vector<datamodel::DataPoint> inputDatas,
                                                                              std::unordered_set<std::string> &equationsStructuresHash,
                                                                              int maxNumberOfNodes,
                                                                              int generation) const
{

    uint nbVar = 0;
    equationparameters::EquationDistanceParameters::EquationDistance distanceToUse{equationparameters::EquationDistanceParameters::R2};
    if(equationsSize > 0){
        nbVar = equations[0].numberOfVariables();
        distanceToUse = equations[0].distanceToUse();
    }
    // Initializing the crossbreed parent selector with parent selection strategy and tournament size
    // in case tournament is the chosen strategy.
    equationeditors::CrossbreedParentSelector crossbreedParentSelector(
        equations,
        equationsSize,
        _equationCrossBreadingParameters.getParentSelectionStrategy(),
        _equationCrossBreadingParameters.getParentSelectionCriteria(),
        _equationCrossBreadingParameters.getCrossbreedingRate(),
        _equationCrossBreadingParameters.getTournamentSize());

    // Initializing an equation crossbreeder with the crossbreeding method chosen.
    equationeditors::EquationCrossbreeder equationCrossbreeder;
    equationCrossbreeder.setCrossbreedingMethod(_equationCrossBreadingParameters.getCrossbreedingMethod());

    // Creating a list of parent couples using the crossbreed parent selector.
    uint offspringsSize = (equationsSize * _equationCrossBreadingParameters.getCrossbreedingRate());
    if (offspringsSize % 2 != 0)
    {
        ++offspringsSize;
    }
    uint parentSelectedSize = offspringsSize / 2;

    std::pair<datamodel::EquationTreeItem, datamodel::EquationTreeItem>* parentsSelected = crossbreedParentSelector.parentsSelection(parentSelectedSize);
//    for(int i = 0; i < parentSelectedSize; i++){
//        auto eq = equationeditors::equationToString(parentsSelected[i].first, "x");
//        std::string utf8_text = eq.toUtf8().constData();

//        auto eq2 = equationeditors::equationToString(parentsSelected[i].second, "x");
//        std::string utf8_text2 = eq2.toUtf8().constData();
//    }
    // Initializing the list of equation holding offsprings of the parents' crossbreeding.
    datamodel::EquationTree* offsprings = new datamodel::EquationTree[offspringsSize];
    // For each parent pair in the list of parent couples.
    // if tuning the +2 away, ensure hardware_concurrency does not return 0. thread_count >= 2 is assumed later on this code
//    unsigned int thread_count = std::thread::hardware_concurrency() - 2;
//    if(thread_count < 0){
//        thread_count = 1;
//   }

    uint thread_count = utils::CommandLineParser::getNumberOfThreads();

    uint work_per_thread = parentSelectedSize / thread_count;
    auto worker = [this, &parentsSelected, &equationCrossbreeder, &inputDatas, generation, maxNumberOfNodes, &equationsStructuresHash, &offsprings, nbVar, distanceToUse](unsigned int begin, unsigned int end) {
        for (; begin < end ; ++begin) {
            // seul le randomTreeSubstitution est corrigé pour créer 2 enfants à l'issue du croisement
            if(equationCrossbreeder.crossbreedingMethod()==equationparameters::EquationCrossbreedingParameters::RandomTreeSubstitution)
            {
                std::pair<datamodel::EquationTreeItem,datamodel::EquationTreeItem> offspring_twoChildren =
                        equationCrossbreeder.randomTreeSubstitutionCrossbreeding_twoChildrenParallel(parentsSelected[begin].first, parentsSelected[begin].second);

                datamodel::EquationTree firstChild(offspring_twoChildren.first);
                firstChild.setNumberOfVariables(nbVar);
                firstChild.setDistanceToUse(distanceToUse);
                datamodel::EquationTree secondChild(offspring_twoChildren.second);
                secondChild.setNumberOfVariables(nbVar);
                secondChild.setDistanceToUse(distanceToUse);

                bool isFirstChildCreated = applyEquationTransformation(firstChild, inputDatas,
                                                                       equationsStructuresHash, maxNumberOfNodes,generation);


                bool isSecondChildCreated = applyEquationTransformation(secondChild, inputDatas,
                                                                        equationsStructuresHash, maxNumberOfNodes,generation);

                offsprings[begin*2] = firstChild;
                if(!isFirstChildCreated){
                    offsprings[begin*2].rootRef().setCurrentNode(nullptr);
                }

                offsprings[begin*2 + 1] = secondChild;
                if(!isSecondChildCreated){
                    offsprings[begin*2 + 1].rootRef().setCurrentNode(nullptr);
                }
            }
            else
            {
                datamodel::EquationTreeItem offspring(equationCrossbreeder.crossbreeds(parentsSelected[begin].first, parentsSelected[begin].second));

                datamodel::EquationTree newEquation(offspring);
                bool isCreated = applyEquationTransformation(newEquation, inputDatas,
                                                             equationsStructuresHash, maxNumberOfNodes,generation);
                offsprings[begin] = newEquation;
                if(!isCreated){
                    offsprings[begin].rootRef().setCurrentNode(nullptr);
                }
            }
        }
    };
    std::thread* workers = new std::thread[thread_count];
    for (auto i = 0u ; i < thread_count - 1 ; ++i) {
        workers[i] =  std::thread(worker, i * work_per_thread, (i + 1) * work_per_thread);
    }
    workers[thread_count - 1] = std::thread(worker, (thread_count - 1) * work_per_thread, parentSelectedSize);

    for (uint j = 0; j < thread_count; j++) {
        workers[j].join();
    }

    delete [] parentsSelected;
    delete [] workers;
    return std::pair<datamodel::EquationTree*, uint>(offsprings, offspringsSize);
}

const equationparameters::EquationCrossbreedingParameters &EquationCrossbreeding::getEquationCrossBreadingParameters() const
{
    return _equationCrossBreadingParameters;
}

void EquationCrossbreeding::setEquationCrossBreedingParameters(
    const equationparameters::EquationCrossbreedingParameters &value)
{
    _equationCrossBreadingParameters = value;
}

uint EquationCrossbreeding::getCrossbreedingSize(uint equationsSize){
    double crossbreedingRate = _equationCrossBreadingParameters.getCrossbreedingRate();
    return equationsSize * crossbreedingRate;
}

}  // namespace algorithmcontroller
