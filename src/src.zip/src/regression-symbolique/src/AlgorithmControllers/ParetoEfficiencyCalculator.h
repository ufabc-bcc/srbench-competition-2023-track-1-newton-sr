#pragma once

#include <QDebug>
#include <QElapsedTimer>

#include <cmath>
#include <algorithm>
#include <iostream>

#include "DataModel/EquationTree.h"
#include <EquationEditors/EquationPrinter.h>

namespace algorithmcontroller {
/**
 * @brief The TotalNodeCalculator class
 */
class ParetoEfficiencyCalculator {
  Q_GADGET
 public:
  enum ParetoStatus { NOT_SET = -2, DOMINATED };
  Q_ENUM(ParetoStatus)

  /**
   * @brief Compute the pareto level of a list of equations
   * @param equations
   */
  static void identifyParetoFrontier(datamodel::EquationTree* equations, uint size);

  /**
   * @brief find best equation
   * @param equations
   * @return best equation
   */
  static datamodel::EquationTree getBestEquation(datamodel::EquationTree* equations, uint size);

  /**
   * @brief get pareto front 0 equations
   * @param equations
   * @return pareto front 0 equations
   */
  static QList<datamodel::EquationTree> getParetoEquations(datamodel::EquationTree* equations, uint size);
};

}  // namespace algorithmcontroller
