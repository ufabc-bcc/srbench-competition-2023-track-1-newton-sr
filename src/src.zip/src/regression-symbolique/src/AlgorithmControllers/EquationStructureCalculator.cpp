#include "EquationStructureCalculator.h"

#include "DataModel/EquationNode.h"

namespace algorithmcontroller {
std::string EquationStructureCalculator::getEquationStructure(
    const datamodel::EquationTreeItem &root) {

  if (root.isEmpty()) return "";

  datamodel::EquationNode::NodeType nodeType = root.currentNode()->type();
  std::string equationStructureAsString;
  if(nodeType == datamodel::EquationNode::Variable){
      equationStructureAsString = root.currentNode()->toString() + ";";
  }else{
      equationStructureAsString = std::to_string(static_cast<int>(nodeType)) + ";";
  }

  for (auto iterator = root.arguments().cbegin();
       iterator != root.arguments().cend(); ++iterator) {
      equationStructureAsString += getEquationStructure(*iterator);
  }

  return equationStructureAsString;
}
}  // namespace algorithmcontroller
