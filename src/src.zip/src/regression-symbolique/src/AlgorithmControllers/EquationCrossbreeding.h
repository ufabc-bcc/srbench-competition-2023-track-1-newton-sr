#pragma once

#include "EquationParameters/EquationCrossbreedingParameters.h"
#include "DataModel/EquationTree.h"
#include "equationtransformation.h"

namespace algorithmcontroller
{
/**
 * @brief Handle the cross breading between equations into the same generation
 */
class EquationCrossbreeding : EquationTransformation
{
   public:
    /*!
     * @brief Crossbreads the given equation with the strategy defined in the current
     * EquationCrossbreedingParameters and return a map of the offsprings generated
     * @param equations the equations to crossbreeds
     * @return a map of the offsprings generated
     */
    std::pair<datamodel::EquationTree*, uint> crossbreeds(const datamodel::EquationTree* equations,
                                                            uint equationsSize,
                                                            const std::vector<datamodel::DataPoint> inputDatas,
                                                            std::unordered_set<std::string>& equationsStructuresHash,
                                                            int maxNumberOfNodes,
                                                            int generation) const;

    // getter / setter
    const equationparameters::EquationCrossbreedingParameters &getEquationCrossBreadingParameters() const;
    void setEquationCrossBreedingParameters(const equationparameters::EquationCrossbreedingParameters &value);

    uint getCrossbreedingSize(uint equationsSize);
   private:
    /**
     * @brief Cross breading paramaters (parent stategy and a cross breading method)
     */
    equationparameters::EquationCrossbreedingParameters _equationCrossBreadingParameters;
    mutable std::mutex loopMutex;

};
}  // namespace algorithmcontroller
