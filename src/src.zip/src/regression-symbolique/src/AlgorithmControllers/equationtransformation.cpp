#include "equationtransformation.h"
#include <EquationEditors/EquationSimplifier.h>
#include <AlgorithmControllers/EquationStructureCalculator.h>
#include <AlgorithmControllers/DistanceToDataCalculator.h>
#include <AlgorithmControllers/TotalNodeCalculator.h>

namespace algorithmcontroller {
    EquationTransformation::EquationTransformation() {}

    std::string EquationTransformation::computeHash(datamodel::EquationTreeItem equation){
        std::string equationStructure = EquationStructureCalculator::getEquationStructure(equation);
        return QCryptographicHash::hash(QString::fromStdString(equationStructure).toUtf8(),QCryptographicHash::Sha1).toHex().toStdString();
    }


    void EquationTransformation::evaluate(datamodel::EquationTree& equation, const std::vector<datamodel::DataPoint> inputDatas){
        equation.setDistanceR2(DistanceToDataCalculator::calculateRSquared(equation.root(), inputDatas));
        equation.setDistanceMSE(DistanceToDataCalculator::calculateCumulatedDistanceToData(equation.root(), inputDatas));
    }


    bool EquationTransformation::applyEquationTransformation(datamodel::EquationTree& equation,
                                                             const std::vector<datamodel::DataPoint> inputDatas,
                                                             std::unordered_set<std::string>& equationsStructuresHash,
                                                             int maxNumberOfNodes,
                                                             int generation)  const{
        uint nbVar = equation.numberOfVariables();
        equationeditors::equationTreeItemSimplifier(equation.rootRef(),nbVar);

        if(!equation.root().isValid(std::vector<double>(nbVar,0.))){
            return false;
        }
        std::string hashValue = computeHash(equation.root());

        mtx.lock();
        bool notFound = equationsStructuresHash.find(hashValue) == equationsStructuresHash.end();
        mtx.unlock();
        if(notFound){
            if(!equation.root().isValid(std::vector<double>(nbVar,0.))){
                return false;
            }
            int equationTotalNode = TotalNodeCalculator::calculateTotalNode(equation.root());
            if(equationTotalNode > maxNumberOfNodes){
                return false;
            }

            std::vector<datamodel::DataPoint> inputDatas_v(inputDatas.begin(), inputDatas.end());
            evaluate(equation, inputDatas_v);
            if((!std::isfinite(equation.distance())) || std::isnan(equation.distance())){
                return false;
            }

            equation.setTotalNode(equationTotalNode);
            equation.setComplexity(TotalNodeCalculator::calculateComplexity(equation.root(), nbVar));
            equation.setGeneration(generation);
            equation.setStructureIdHash(hashValue);

            mtx.lock();
            equationsStructuresHash.insert(hashValue);
            mtx.unlock();

            return true;
        }
        return false;
        // nan and if are already treated
    }

}
