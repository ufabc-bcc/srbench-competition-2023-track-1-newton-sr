#include "InputFileManager.h"

#include <QDir>
#include <QFile>
#include <QFileInfo>
#include <QVariant>
#include "FileReaderWriter/InputDataReader.h"
#include "Utils/CommandLineParser.h"
#include <QTime>
#include "Logger_v2/Logger.h"


#define CSV "csv"
#define TSV "tsv"

namespace algorithmcontroller {

const QString InputFileManager::INPUT_DATA_FILE_NAME_CSV = QStringLiteral("InputDataFile.csv");
const QString InputFileManager::INPUT_DATA_FILE_NAME_TSV = QStringLiteral("InputDataFile.tsv");


InputFileManager::InputFileManager(QObject *parent) : QObject(parent){}

void InputFileManager::inputDataSelected(QVariant inputFilePath, QVariant inputDatas) {
    QList<QVariant> variantList = inputDatas.toList();
    _inputDatas.clear();

    for (const auto &variant : variantList) {
        if (variant.canConvert<datamodel::DataPoint>()) {
            _inputDatas.push_back(variant.value<datamodel::DataPoint>());
        }
        else {
            std::string inputada(variant.typeName());
            std::string message_warning_DataSelected = "Received inputData of unexpected type : " + inputada;
            logs::Logger::logWarning(message_warning_DataSelected, {logs::LogTags::algorithmController});
        }
    }
    // If the input file changes, we'll reset the window through the following line
    emit inputDatasChangedResetWindow();
    emit inputDatasChangedInitStartButton();
    QList<datamodel::DataPoint> inputDatas_qt(_inputDatas.begin(), _inputDatas.end());
    emit inputDatasChanged(inputDatas_qt);

    if (!_applicationDataFolder.isEmpty()) {
        // Remove InputDataFile.[csv, tsv] if they exist
        if (QDir(_applicationDataFolder).exists(INPUT_DATA_FILE_NAME_CSV))
            QFile::remove(_applicationDataFolder + INPUT_DATA_FILE_NAME_CSV);

        if (QDir(_applicationDataFolder).exists(INPUT_DATA_FILE_NAME_TSV))
            QFile::remove(_applicationDataFolder + INPUT_DATA_FILE_NAME_TSV);

        QString suffix = inputFilePath.toString().toLower().split('.').last();
        QString destination{""};
        if(suffix == CSV )
            destination = _applicationDataFolder + INPUT_DATA_FILE_NAME_CSV;
        else if(suffix == TSV )
            destination = _applicationDataFolder + INPUT_DATA_FILE_NAME_TSV;
        else
            logs::Logger::logCritical("Only csv and tsv files are supported");
        QFile::copy(inputFilePath.toString(), destination);
    }
    else {
        logs::Logger::logWarning("Application data folder is not set, impossible to save input file", {logs::LogTags::algorithmController});
    }

}

void InputFileManager::loadDefaultInputFile() {
    QString inputFilePath = "";

    if (utils::CommandLineParser::getStartSilent()) {
        inputFilePath = utils::CommandLineParser::getInputDataFilePath();
        QString suffix = inputFilePath.toLower().split('.').last();
        if(suffix != CSV && suffix != TSV){
            logs::Logger::logCritical("Only csv and tsv files are supported", {logs::LogTags::algorithmController});
            throw std::runtime_error("Only csv and tsv files are supported");
        }
    }
    else {
        if (!_applicationDataFolder.isEmpty()) {
            if(QDir(_applicationDataFolder).exists(INPUT_DATA_FILE_NAME_CSV))
                inputFilePath = _applicationDataFolder + INPUT_DATA_FILE_NAME_CSV;
            else if(QDir(_applicationDataFolder).exists(INPUT_DATA_FILE_NAME_TSV))
                inputFilePath = _applicationDataFolder + INPUT_DATA_FILE_NAME_TSV;
            else
                logs::Logger::logWarning("Application data folder is set but default file was not found", {logs::LogTags::algorithmController});
        }
        else {
            logs::Logger::logWarning("Application data folder is not set, impossible to load the default input file", {logs::LogTags::algorithmController});
        }
    }
    QFile selectedFile(inputFilePath);

    if (selectedFile.open(QIODevice::ReadOnly)) {
        filereaderwriter::InputDataReader inputReader(inputFilePath.toStdString());
        _inputDatas = inputReader.readDataFile();
        QList<datamodel::DataPoint> inputDatas_qt(_inputDatas.begin(), _inputDatas.end());
        emit inputDatasChanged(inputDatas_qt);
        logs::Logger::logInfo("Input data file loaded : " + selectedFile.fileName().toStdString()
                              , {logs::LogTags::algorithmController});
    } else {
        logs::Logger::logWarning("Input data file do not exists or cannot be opened"
                                 , {logs::LogTags::algorithmController}
                                 ,std::invalid_argument(selectedFile.fileName().toStdString()));
    }
}

const std::vector<datamodel::DataPoint> &InputFileManager::inputDatas() const{
        return _inputDatas;
}

QString InputFileManager::applicationDataFolder() const{
    return _applicationDataFolder;
}

void InputFileManager::setApplicationDataFolder(const QString &applicationDataFolder) {
    _applicationDataFolder = applicationDataFolder;
}

uint InputFileManager::getNumberOfVariables(){
    if(_inputDatas.empty()){
        return 0;
    }
    return _inputDatas.front().getNumberOfVariables();
}


}  // namespace algorithmcontroller
