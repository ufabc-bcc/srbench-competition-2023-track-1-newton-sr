#include "ParetoEfficiencyCalculator.h"
#include <limits>


namespace algorithmcontroller {

void ParetoEfficiencyCalculator::identifyParetoFrontier(datamodel::EquationTree* equations, uint size) {
    QMultiMap<int,QList<double>> Data;
    QMultiMap<int,QList<double>> DataTriees;

    QVector<int> indexToIgnore;
    QVector<int> buffer;

    // Reset all Pareto levels and configure data
    int count = 0;

    std::for_each(equations, equations+size, [&Data, &count](datamodel::EquationTree& equation){
        equation.setParetoLevel(NOT_SET);

        // save in Data
        QList<double> list = { equation.distance(),  double(count)};
        Data.insert(equation.totalNode(),list);
        count++;
    });

    // tri des Datas
    QList<int> complexites = Data.uniqueKeys();

    QList<int>::iterator itComplexite;

    for( itComplexite = complexites.begin(); itComplexite != complexites.end(); ++itComplexite) {
        QList< QList<double>> valuesComplexite = Data.values(*itComplexite);

        int tailleListeValeur = valuesComplexite.size();
        std::sort(valuesComplexite.begin(),valuesComplexite.end(),[](QList<double> data1, QList<double> data2){return (data1[0] < data2[0]);});

        for(int i = 0;i <tailleListeValeur; i++) {
            DataTriees.insert(*itComplexite,valuesComplexite.at(i));
        }
    }

    int level = 0;
    while(!DataTriees.empty()) {
        double distance = std::numeric_limits<double>::max();
        QList<int> complexityKey = DataTriees.uniqueKeys();
        QList<int>::iterator itComplexity;

        for( itComplexity = complexityKey.begin(); itComplexity != complexityKey.end(); ++itComplexity) {
            QList< QList<double>> nComplexityValues = DataTriees.values(*itComplexity);
            if(!nComplexityValues.isEmpty()) {
                QList<double> nComplexityMinDistance = nComplexityValues.last();

                if (nComplexityMinDistance.at(0) <= distance) {
                    distance = nComplexityMinDistance.at(0);
                    int numEquation = int(nComplexityMinDistance.at(1));
                    equations[numEquation].setParetoLevel(level);
                    nComplexityValues.removeLast();
                    DataTriees.remove(*itComplexity);
                    if(!nComplexityValues.isEmpty()) {
                        QList<QList <double>>::reverse_iterator itvalues;
                        for (itvalues = nComplexityValues.rbegin();itvalues != nComplexityValues.rend();++itvalues) {
                            DataTriees.insert(*itComplexity,*itvalues);
                        }
                    }
                }
            }
        }
        level++;
    }
}

datamodel::EquationTree ParetoEfficiencyCalculator::getBestEquation(
        datamodel::EquationTree* equations, uint size){

    // ajout de l'efficiency à chaque équation pour la colonne Efficiency
    datamodel::EquationTree bestEquation = equations[0];
    double bestEfficiency = 0.0;

    for(uint cpt = 0; cpt < size; cpt++){
        datamodel::EquationTree equation = equations[cpt];
        if (equation.paretoLevel() > 0)
            continue;
        double equationEfficiency;
        equationEfficiency = std::abs((log(equation.distance())) / (equation.totalNode()));

        // ajout de l'efficiency à chaque équation pour la colonne Efficiency
        equations[cpt].setEfficiency(equationEfficiency);

        if(equationEfficiency > bestEfficiency){
            bestEfficiency = equationEfficiency;
            bestEquation = equation;
        }
    }

    return bestEquation;
}

QList<datamodel::EquationTree> ParetoEfficiencyCalculator::getParetoEquations(
        datamodel::EquationTree* equations, uint size) {

    // boucle dans les equations et retourne une QList des equation du front 0 de pareto
    
    QList<datamodel::EquationTree> paretoEquations;

    for(uint cpt = 0; cpt < size; cpt++){
        datamodel::EquationTree equation = equations[cpt];
        if (equation.paretoLevel() == 0) {
            paretoEquations.append(equations[cpt]);
        }
    }
    return paretoEquations;
}


}  // namespace algorithmcontroller
