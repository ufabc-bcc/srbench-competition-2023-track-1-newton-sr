#pragma once
#include "EquationParameters/EquationFilterParameters.h"
#include "DataModel/EquationTree.h"

#include <unordered_set>
namespace algorithmcontroller
{
/**
 * @brief The EquationFiltor class filter the x best equation computed
 */
class EquationFiltor
{
    public:
    /**
     * @brief
     * @param equations Array of equations
     * @param equationsSize Size of the array
     */
    void sortEquations(datamodel::EquationTree* equations, uint equationsSize);

    /**
     * @brief
     * @param equations
     * @return
     */
    void filterEquations(datamodel::Equations &equations);

    /**
     * @brief
     * @param equations Array of equations after the filtering
     * @param equationsSize Size of the array
     * @param equationsToFilter Array of equations to filter
     * @param equationsToFilterSize Size of the array
     * @param hashTable Hash table including equations structure
     */
    void filterEquations(datamodel::EquationTree* equations, uint equationsSize,
                         datamodel::EquationTree* equationsToFilter, uint equationsToFilterSize,
                         std::unordered_set<std::string> &hashTable);

    /**
     * @brief
     * @return
     */
    const equationparameters::EquationFilterParameters &equationFilterParameters() const;

    /**
     * @brief
     * @param equationFilterParameters
     */
    void setEquationFilterParameters(const equationparameters::EquationFilterParameters &equationFilterParameters);

   private:
    /**
     * @brief Filter parameter for equations (from index and number of equations to handle)
     */
    equationparameters::EquationFilterParameters _equationFilterParameters;
};

}  // namespace algorithmcontroller
