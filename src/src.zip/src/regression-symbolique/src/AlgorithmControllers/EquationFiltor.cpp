#include "EquationFiltor.h"

// STL
#include <algorithm>

namespace algorithmcontroller {


const equationparameters::EquationFilterParameters &EquationFiltor::equationFilterParameters() const {
    return _equationFilterParameters;
}

void EquationFiltor::setEquationFilterParameters(const equationparameters::EquationFilterParameters &equationFilterParameters) {
    _equationFilterParameters = equationFilterParameters;
}

void EquationFiltor::filterEquations(datamodel::Equations &equations)
{
    equationparameters::EquationFilterParameters::EquationsFilterCriteria criteria = _equationFilterParameters.getEquationsFilterCriteria();

    switch (criteria)
    {
    // Tri uniquement sur la distance
    case equationparameters::EquationFilterParameters::Distance:
        std::sort(equations.begin(), equations.end(),
                  [&](const datamodel::EquationTree& equation1, const datamodel::EquationTree& equation2)
        {
           return equation1.compareDistance(equation2);
        });
        break;
    // Double tri Pareto puis complexité
    case equationparameters::EquationFilterParameters::Complexity:
        std::sort(equations.begin(), equations.end(),
                  [&](const datamodel::EquationTree& equation1, const datamodel::EquationTree& equation2)
        {
            return equation1.compareParetoComplexity(equation2);
        });
        break;
    // Double tri Pareto puis distance
    case equationparameters::EquationFilterParameters::Pareto:
        std::sort(equations.begin(), equations.end(),
                  [&](const datamodel::EquationTree& equation1, const datamodel::EquationTree& equation2)
        {
            return equation1.compareParetoDistance(equation2);
        });
        break;
    // Double tri Pareto puis Age
    case equationparameters::EquationFilterParameters::Age:
        std::sort(equations.begin(), equations.end(),
                  [&](const datamodel::EquationTree& equation1, const datamodel::EquationTree& equation2)
        {
            return equation1.compareParetoAge(equation2);
        });
        break;
    }

    // TODO : vérifier les indices

    std::size_t startingIndex = _equationFilterParameters.fromEquation() - 1;

    std::size_t endingIndex = startingIndex + _equationFilterParameters.numberOfEquationsSelected();

    equations = datamodel::Equations(equations.begin() + startingIndex,
                                     equations.begin() + endingIndex);

}

void EquationFiltor::sortEquations(datamodel::EquationTree* equations, uint equationsSize)
{
    if(equationsSize != 0){
        equationparameters::EquationFilterParameters::EquationsFilterCriteria criteria = _equationFilterParameters.getEquationsFilterCriteria();

        switch (criteria)
        {
        // Tri uniquement sur la distance
        case equationparameters::EquationFilterParameters::Distance:
            std::sort(equations, equations+equationsSize,
                      [&](const datamodel::EquationTree& equation1, const datamodel::EquationTree& equation2)
            {
               return equation1.compareDistance(equation2);
            });
            break;
        // Double tri Pareto puis complexité
        case equationparameters::EquationFilterParameters::Complexity:
            std::sort(equations, equations+equationsSize,
                      [&](const datamodel::EquationTree& equation1, const datamodel::EquationTree& equation2)
            {
                return equation1.compareParetoComplexity(equation2);
            });
            break;
        // Double tri Pareto puis distance
        case equationparameters::EquationFilterParameters::Pareto:
            std::sort(equations, equations+equationsSize,
                      [&](const datamodel::EquationTree& equation1, const datamodel::EquationTree& equation2)
            {
                return equation1.compareParetoDistance(equation2);
            });
            break;
        // Double tri Pareto puis age
        case equationparameters::EquationFilterParameters::Age:
            std::sort(equations, equations+equationsSize,
                      [&](const datamodel::EquationTree& equation1, const datamodel::EquationTree& equation2)
            {
                return equation1.compareParetoAge(equation2);
            });
            break;
        }
    }

}

void EquationFiltor::filterEquations(datamodel::EquationTree* equations, uint equationsSize,
                                     datamodel::EquationTree* equationsToFilter, uint equationsToFilterSize,
                                     std::unordered_set<std::string> &hashTable) {
    equationparameters::EquationFilterParameters::EquationsFilterCriteria criteria = _equationFilterParameters.getEquationsFilterCriteria();

    switch (criteria) {
    // Tri uniquement sur la distance
    case equationparameters::EquationFilterParameters::Distance:
        std::sort(equationsToFilter,
                  equationsToFilter+equationsToFilterSize,
                  [&](const datamodel::EquationTree& equation1,
                  const datamodel::EquationTree& equation2)
        {
           return equation1.compareDistance(equation2);
        });
        break;
    // Double tri Pareto puis complexité
    case equationparameters::EquationFilterParameters::Complexity:
        std::sort(equationsToFilter,
                  equationsToFilter+equationsToFilterSize,
                  [&](const datamodel::EquationTree& equation1,
                  const datamodel::EquationTree& equation2)
        {
            return equation1.compareParetoComplexity(equation2);
        });
        break;
    // Double tri Pareto puis distance
    case equationparameters::EquationFilterParameters::Pareto:
        std::sort(equationsToFilter,
                  equationsToFilter+equationsToFilterSize,
                  [&](const datamodel::EquationTree& equation1,
                  const datamodel::EquationTree& equation2)
        {
            return equation1.compareParetoDistance(equation2);
        });
        break;
    // Double tri Pareto puis age
    case equationparameters::EquationFilterParameters::Age:
        std::sort(equationsToFilter,
                  equationsToFilter+equationsToFilterSize,
                  [&](const datamodel::EquationTree& equation1,
                  const datamodel::EquationTree& equation2)
        {
            return equation1.compareParetoAge(equation2);
        });
        break;
    }

    // Copy Best Equation
    assert(equationsSize <= equationsToFilterSize);
    std::copy(equationsToFilter,equationsToFilter+equationsSize,equations);

    hashTable.clear();
    std::for_each(equations, equations+equationsSize, [&hashTable](datamodel::EquationTree& equation){
        hashTable.insert(equation.structureIdHash());
    });
    // TODO : modify the array, size and map
    // TODO : vérifier les indices

//    std::size_t startingIndex = _equationFilterParameters.fromEquation() - 1;

//    std::size_t endingIndex = startingIndex + _equationFilterParameters.numberOfEquationsSelected();

//    equations = datamodel::Equations(equations.begin() + startingIndex,
//                                     equations.begin() + endingIndex);
//    return size;

}
}  // namespace algorithmcontroller
