#include "EquationMutation.h"

#include "EquationEditors/EquationMutator.h"
#include <EquationEditors/EquationSimplifier.h>
#include <EquationEditors/RandomGenerator.h>

// STL
#include <algorithm>
#include <random>
#include <vector>
#include <iostream>
#include <thread>
#include <mutex>

namespace algorithmcontroller
{

    std::pair<datamodel::EquationTree*, uint> EquationMutation::generateMutatedEquations(
            const datamodel::EquationTree* equations,
            uint equationsSize,
            const std::vector<datamodel::DataPoint> inputDatas,
            std::unordered_set<std::string>  &equationsStructuresHash,
            int maxNumberOfNodes,
            int generation) const
    {
        // Initializing equation mutator with equation mutator parameters.

        equationeditors::EquationMutator equationMutator;
        uint nbVariables = 0;
        if(equationsSize > 0){
            nbVariables = equations[0].numberOfVariables();
        }
        equationparameters::EquationGenerationParameters equationGenerationParams = _equationMutationParameters.equationGenerationParameters();
        equationGenerationParams.setNumberOfVariables(nbVariables);
        equationMutator.setEquationGenerationParameters(equationGenerationParams);

        // Calculating the number of equations we have to mutate.
        uint numberOfEquationsToMutate = equationsSize * _equationMutationParameters.mutationRate();

        datamodel::EquationTree* mutatedEquations/*(numberOfEquationsToMutate)*/;


        // Check it the mutation rate is valid, if not: error message + returning empty list.
        if(_equationMutationParameters.mutationRate() < 0 || _equationMutationParameters.mutationRate() > 1) {
            qErrnoWarning("Mutation rate is invalid, it should be contained between 0 and 1 and it is: %f", _equationMutationParameters.mutationRate());
            return std::pair<datamodel::EquationTree*, uint>(mutatedEquations,0);
        }

        mutatedEquations = new datamodel::EquationTree[numberOfEquationsToMutate];

        uint* indices = new uint[equationsSize];
        std::iota(indices,indices+equationsSize,0);
        std::mt19937 g;
        g.seed(equationeditors::RandomGenerator().getRngGenerator().generate());
        std::shuffle(indices, indices+equationsSize, g);

        // Taking the number-of-equations-to-mutate firsts in the shuffled equations' indices,
        // and mutate A CLONE of the corresponding equations in "equations".
        //    // if tuning the +2 away, ensure hardware_concurrency does not return 0. thread_count >= 2 is assumed later on this code
        //        int thread_count = std::thread::hardware_concurrency() - 2;
        //        if(thread_count < 0){
        //            thread_count = 1;
        //        }

        uint thread_count = utils::CommandLineParser::getNumberOfThreads();

        uint work_per_thread = numberOfEquationsToMutate / thread_count;

        auto worker = [this, &equations, &indices, &equationMutator, &mutatedEquations, &inputDatas,
                generation, maxNumberOfNodes, &equationsStructuresHash, &nbVariables](unsigned int begin, unsigned int end) {
            for (; begin < end ; ++begin) {

                datamodel::EquationTreeItem equationToMutate(equations[indices[begin]].root());
                equationMutator.mutateEquations(equationToMutate,_equationMutationParameters.nbMutationPossible());

                datamodel::EquationTree result(equationToMutate);
                result.setNumberOfVariables(nbVariables);
                result.setDistanceToUse(equations[indices[begin]].distanceToUse());
                bool isCreated = applyEquationTransformation(result, inputDatas,
                                                             equationsStructuresHash, maxNumberOfNodes, generation);
                mutatedEquations[begin] = result;

                if(!isCreated){
                    mutatedEquations[begin].rootRef().setCurrentNode(nullptr);
                }
            }
        };

        std::thread* workers = new std::thread[thread_count];

        for (auto i = 0u ; i < thread_count - 1 ; ++i) {
            workers[i] =  std::thread(worker, i * work_per_thread, (i + 1) * work_per_thread);
        }
        workers[thread_count - 1] = std::thread(worker, (thread_count - 1) * work_per_thread, numberOfEquationsToMutate);

        for (uint j = 0; j < thread_count; j++) {
            workers[j].join();
        }

        delete [] indices;
        delete [] workers;

        // Return the list of mutated equations.
        return std::pair<datamodel::EquationTree*, uint>(mutatedEquations,numberOfEquationsToMutate);
    }

    equationparameters::EquationMutationParameters EquationMutation::equationMutationParameters() const {
        return _equationMutationParameters;
    }

    void EquationMutation::setEquationMutationParameters(
        const equationparameters::EquationMutationParameters &equationMutationParameters) {
        _equationMutationParameters = equationMutationParameters;
    }

}  // namespace algorithmcontroller
