#pragma once
#include "DataModel/DataPoint.h"
#include "EquationParameters/EquationFitParameters.h"
#include "DataModel/EquationTree.h"

#include "alglib/ap.h"

#include <assert.h>

class EquationFit {

public:
    /**
     * @brief Python environment must be initialized prior to a call to this function
     * @return true if the given equation has been updated (pareto and distance might need to be updated)
     * @see Py_Initialize()
     */
    EquationFit();
    bool fitEquation(datamodel::EquationTree &equation) const;
    void updateInputData(const std::list<datamodel::DataPoint> &points);

    // getter / setter
    equationparameters::EquationFitParameters equationFitParameters() const;
    void setEquationFitParameters(const equationparameters::EquationFitParameters &equationFitParameters);

private:
    alglib::real_2d_array xs;
    alglib::real_1d_array ys;

    /**
     * @brief The equation fit parameters containing a duration and a generation paramater
     */
    equationparameters::EquationFitParameters _equationFitParameters;
};
