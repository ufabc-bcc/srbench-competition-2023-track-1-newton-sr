#pragma once

#include "DataModel/EquationTreeItem.h"

namespace algorithmcontroller {
/**
 * @brief The TotalNodeCalculator class
 */
class TotalNodeCalculator {
 public:
  /**
   * @brief Compute the number of node in a tree
   * @param equation
   * @return Number of node in a tree
   */
  static int calculateTotalNode(const datamodel::EquationTreeItem &root);


  /**
   * @brief Compute the number of node in a tree with decimal
   * @param equation
   * @param nbVar
   * @return Number of node in a tree
   */
  static double calculateTotalNodeDouble(const datamodel::EquationTreeItem &root, uint nbVar);

  /**
   * @brief Compute the complexity of an equation (see article AI Freynman)
   * @param equation
   * @param nbVar
   * @return Number of node in a tree
   */
  static double calculateComplexity(const datamodel::EquationTreeItem &root, uint nbVar);

};

}  // namespace algorithmcontroller
