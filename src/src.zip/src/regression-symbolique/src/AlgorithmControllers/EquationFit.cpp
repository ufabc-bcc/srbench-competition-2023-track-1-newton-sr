#include "EquationFit.h"

#include "DataModel/ConstantNode.h"
#include "EquationEditors/EquationPrinter.h"
#include "Logger_v2/Logger.h"

#include "alglib/interpolation.h"

namespace
{

bool set_parameters_impl(const alglib::real_1d_array &params, datamodel::EquationTreeItem &tree, int &idx) {
    if (tree.currentNode()->type() == datamodel::EquationNode::NodeType::Constant) {
        auto *value_node = dynamic_cast<datamodel::ConstantNode *>(tree.currentNode().get());//auto *value_node = dynamic_cast<datamodel::ConstantNode *>(tree.currentNode().data());
        assert(value_node != nullptr);
        value_node->setValue(params[idx++]);
        if (idx == params.length()) {
            return false;
        }
    }
    for (auto &subtree : tree.arguments()) {
        if (!set_parameters_impl(params, subtree, idx)) {
            return false;
        }
    }
    return true;
}

void set_parameters(const alglib::real_1d_array &params, datamodel::EquationTree &tree) {
    if (params.length() == 0) {
        //qWarning("Empty parameter list");
        logs::Logger::logWarning("Empty parameter list");
        return;
    }
    int shared_idx = 0;
    set_parameters_impl(params, tree.rootRef(), shared_idx);
}

void extract_parameters_impl(const datamodel::EquationTreeItem &tree, std::vector<double> &values) {
    if (tree.currentNode()->type() == datamodel::EquationNode::NodeType::Constant) {
        values.emplace_back(tree.value(values));
//        Q_ASSERT(tree.value(0) == tree.value(137));
    }

    for (const datamodel::EquationTreeItem &child : tree.arguments()) {
        extract_parameters_impl(child, values);
    }
}

alglib::real_1d_array extract_parameters(const datamodel::EquationTree &tree) {
    std::vector<double> values;
    values.reserve(tree.totalNode() / 2 + 1);
    extract_parameters_impl(tree.root(), values);

    alglib::real_1d_array ans;
    ans.setcontent(values.size(), values.data());
    return ans;
}

}  // anonymous namespace

EquationFit::EquationFit() {}

bool EquationFit::fitEquation(datamodel::EquationTree &equation) const {
    if(_equationFitParameters.duration() == 0){
        return false;
    }
    auto eval = [](const alglib::real_1d_array &params, const alglib::real_1d_array &x, double &value, void *data) {
        auto &equation = *reinterpret_cast<datamodel::EquationTree *>(data);
        uint nbVar = equation.numberOfVariables();

        set_parameters(params, equation);
        value = equation.rootRef().value(std::vector<double>(x.getcontent(), x.getcontent()+nbVar));
        if (!std::isfinite(value)) {
            value = std::numeric_limits<double>::max();
        }
    };

    if (equation.was_fitted()) {
        return false;
    }

    alglib::real_1d_array parameters = extract_parameters(equation);
    if (parameters.length() == 0) {
        equation.was_fitted() = true;
        return false;
    }

    try {
        std::chrono::milliseconds max_time{_equationFitParameters.duration()};
        alglib::lsfitstate state{};

        alglib::lsfitcreatef(xs, ys, parameters,
                             0.025,  // TODO : Magic number >> as setting ?
                             state);
        alglib::lsfitsetcond(state, 0., 500);

        alglib::ae_int_t info{};
        alglib::lsfitreport rep{};

        auto parameters_copy = parameters;
        auto starting_time = std::chrono::system_clock::now();
        do {
            alglib::lsfitfit(state, eval, nullptr, &equation);
            alglib::lsfitresults(state, info, parameters, rep);
            equation.was_fitted() = parameters.length() == parameters_copy.length() &&
                    std::equal(parameters.getcontent(), parameters.getcontent() + parameters.length(),
                               parameters_copy.getcontent());
        } while (info >= 0 && !equation.was_fitted() && (std::chrono::system_clock::now() - starting_time) < max_time);

        // Others cases inable
        if (info < 0 && info > -8) {
            //qDebug() << "Alglib returned with status "
            //         <<info << " for the equation "
            //         << QString::fromStdString(equationeditors::equationToString(equation.root(),1));
            std::string message_debug_algib_status = "Alglib returned with status "
                    + std::to_string(info)
                    + " for the equation "
                    + equationeditors::equationToString(equation.root(),1);
            logs::Logger::logDebug(message_debug_algib_status, {logs::LogTags::algorithm, logs::LogTags::algorithmController});
            set_parameters(parameters_copy, equation);
            equation.was_fitted() = true;
            return false;
        }
        // Unable to process equations
        else if (info == -8)
        {
            equation.was_fitted() = true;
            return false;
        }
        // Able to process equations
        else {
            set_parameters(parameters, equation);
            return true;
        }
    }
    catch (alglib::ap_error &err) {
        std::string eq = equationeditors::equationToString(equation.root(), equation.numberOfVariables());
        std::string fmt = err.msg + " with parameters  : ";
        for (int i = 0; i < parameters.length(); ++i) {
            fmt += std::to_string(i+1) + ")"+ std::to_string(parameters[i]) +  +"| ";
        }
        std::string message = fmt + " for equation " + eq + " and the distance is " + std::to_string(equation.distance());
        // Debug case but the construction of QDebug makes it impossible to put 4 tags
        //qInfo("%s for equation %s and the distance is %f", fmt.c_str(),eq.c_str(), equation.distance());
        logs::Logger::logDebugDetail(message,{logs::LogTags::fitting, logs::LogTags::algorithmController});
        return false;
    }
}

void EquationFit::updateInputData(const std::list<datamodel::DataPoint> &points) {
    auto element_count = std::count_if(points.begin(), points.end(),
                                       [](const datamodel::DataPoint &pt) { return std::isfinite(pt.result()); });

    uint nbVar = 0;
    if(element_count > 0){
        nbVar = points.front().getNumberOfVariables();
    }

    xs.setlength(element_count, nbVar);
    ys.setlength(element_count);
    int skipped = 0;
    int i = 0;
    for (auto& point : points) {
        if (!std::isfinite(point.result())) {
            ++skipped;
            continue;
        }
        for(uint j = 0; j < point.parameterList().size(); j++) {
            xs[i - skipped][j] = point.parameterList().at(j);
        }
//        xs[i - skipped][1] = 0;
        ys[i - skipped] = point.result();
        i++;
    }
}

equationparameters::EquationFitParameters EquationFit::equationFitParameters() const {
    return _equationFitParameters;
}

void EquationFit::setEquationFitParameters(
        const equationparameters::EquationFitParameters &equationFitParameters) {
    _equationFitParameters = equationFitParameters;
}
