run 1:
09:44:98
20:16:27.797 [Info] (algorithm) Best equations of Generation 50
- Equation 0, (R2: 0.00633149, MSE: 0.154852, complexity : 85.5112, efficiency : 0.253111) : ((2197.34*cos((cos(sin(((0.155324*cos(Parameter))-1.53745e+08)))-445.545)))-exp(-((cos(Parameter)-3.66586))))
> Equation 1, (R2: 0.00841521, MSE: 0.162734, complexity : 43.9132, efficiency : 0.281042) : (exp((0.87427*(sin(cos(cos((cos((cos(Parameter)-2.60826))-442.299))))--4.45008)))-78.4859)
- Equation 2, (R2: 0.0321238, MSE: 0.321554, complexity : 33.8661, efficiency : 0.264474) : (exp((2.01798*cos((5.11603*cos((cos(Parameter)-442.377))))))-1.29117)
- Equation 3, (R2: 0.0782648, MSE: 0.526999, complexity : 33.5358, efficiency : 0.212305) : ((9.15868*cos((cos((Parameter+sin(Parameter)))-442.46)))--8.17813)
- Equation 4, (R2: 0.0857133, MSE: 0.52515, complexity : 28.8005, efficiency : 0.223341) : ((cos(Parameter)-0.641622)*(exp(sin(cos(Parameter)))**3.60052))
- Equation 5, (R2: 0.141207, MSE: 0.686144, complexity : 21.3641, efficiency : 0.195753) : (exp((9.51279*(sin(cos(Parameter))+-0.626584)))-0.274268)
- Equation 6, (R2: 0.151937, MSE: 0.728126, complexity : 18.1119, efficiency : 0.209365) : (exp((6.31141*(cos(Parameter)+-0.670827)))-0.275606)
- Equation 7, (R2: 0.152688, MSE: 0.713266, complexity : 19.0065, efficiency : 0.23492) : exp((10.2462*(sin(cos(Parameter))-0.645049)))
- Equation 8, (R2: 0.163341, MSE: 0.752288, complexity : 14.5535, efficiency : 0.258845) : exp((6.7801*(cos(Parameter)-0.698217)))
- Equation 9, (R2: 0.363299, MSE: 1.17233, complexity : 19.2701, efficiency : 0.168755) : tan((exp(cos(Parameter))+202.947))
- Equation 10, (R2: 0.411292, MSE: 1.08911, complexity : 9.20395, efficiency : 0.177691) : 1 / ((1.14808-cos(Parameter)))
- Equation 11, (R2: 0.51313, MSE: 1.2548, complexity : 8, efficiency : 0.166807) : exp(tan(cos(Parameter)))
- Equation 12, (R2: 0.696599, MSE: 1.44227, complexity : 4.75489, efficiency : 0.120515) : exp(cos(Parameter))
- Equation 13, (R2: 0.902554, MSE: 1.55975, complexity : 2, efficiency : 0.0512632) : cos(Parameter)
- Equation 14, (R2: 1, MSE: 1.59929, complexity : 0.5, efficiency : 0) : 0.744437

run 2
11:07:90
20:28:45.345 [Info] (algorithm) Best equations of Generation 50
- Equation 0, (R2: 0.000391348, MSE: 0.0377284, complexity : 52.6357, efficiency : 0.392296) : (3.16967*(cos(-(Parameter))--0.905176))
- Equation 1, (R2: 0.00176393, MSE: 0.0809469, complexity : 45.5129, efficiency : 0.333695) : (13.7843*(cos(Parameter)-0.615277))
- Equation 2, (R2: 0.00554192, MSE: 0.144447, complexity : 44.2364, efficiency : 0.288634) : (26.3719*(cos(Parameter)+0.183877))
- Equation 3, (R2: 0.00634291, MSE: 0.147168, complexity : 53.6643, efficiency : 0.337361) : (-39.8304*(sin((exp(sin(((0.673439*cos(Parameter))-871.433)))+803.478))-0.954529))
> Equation 4, (R2: 0.00870158, MSE: 0.159508, complexity : 44.5918, efficiency : 0.395354) : (-45.6376*(sin((sin((cos(Parameter)-871.255))+805.156))-0.962498))
- Equation 5, (R2: 0.0944991, MSE: 0.574747, complexity : 27.8161, efficiency : 0.21447) : ((21.4644**cos(Parameter))*sin(sin((cos(Parameter)-0.628976))))
- Equation 6, (R2: 0.0966104, MSE: 0.581418, complexity : 27.6695, efficiency : 0.233707) : ((21.1278**cos(Parameter))*sin((cos(Parameter)-0.629574)))
- Equation 7, (R2: 0.100809, MSE: 0.592098, complexity : 22.6631, efficiency : 0.254948) : ((20.7505**cos(Parameter))*(cos(Parameter)+-0.629463))
- Equation 8, (R2: 0.151937, MSE: 0.728126, complexity : 17.5479, efficiency : 0.235536) : (0.0144962*((550.823**cos(Parameter))-19.0122))
- Equation 9, (R2: 0.152688, MSE: 0.713266, complexity : 21.6777, efficiency : 0.26848) : (28174.8**(sin(cos(Parameter))-0.645049))
- Equation 10, (R2: 0.163341, MSE: 0.752288, complexity : 10.5491, efficiency : 0.301986) : (880.159**(cos(Parameter)+-0.698217))
- Equation 11, (R2: 0.339598, MSE: 1.01154, complexity : 17.3036, efficiency : 0.215999) : tan((cos(Parameter)+631.888))
- Equation 12, (R2: 0.51313, MSE: 1.2548, complexity : 8, efficiency : 0.166807) : exp(tan(cos(Parameter)))
- Equation 13, (R2: 0.696599, MSE: 1.44227, complexity : 4.75489, efficiency : 0.120515) : exp(cos(Parameter))
- Equation 14, (R2: 0.902554, MSE: 1.55975, complexity : 2, efficiency : 0.0512632) : cos(Parameter)
- Equation 15, (R2: 1, MSE: 1.59929, complexity : 0.5, efficiency : 0) : 0.744437

run 3
10:29:54
20:40:11.596 [Info] (algorithm) Best equations of Generation 50
- Equation 0, (R2: 0.000845479, MSE: 0.0461491, complexity : 63.7757, efficiency : 0.3724) : (34.2905*((cos(Parameter)-(1.17095*tan(sin((cos((sin(cos(Parameter))-893.447))-898.643)))))+0.185272))
- Equation 1, (R2: 0.00387624, MSE: 0.12024, complexity : 58.1826, efficiency : 0.326641) : (15.5438*((cos((cos(Parameter)-827.212))-(-0.620928*tan(sin((Parameter-896.925)))))+0.495259))
> Equation 2, (R2: 0.00870158, MSE: 0.15951, complexity : 42.4361, efficiency : 0.395354) : (45.6377*(0.962498-sin((cos((cos(Parameter)-454.994))+385.508))))
- Equation 3, (R2: 0.121455, MSE: 0.615092, complexity : 24.7844, efficiency : 0.191655) : (exp((2.54581-sin((exp(cos(Parameter))+0.428341))))+-5.69464)
- Equation 4, (R2: 0.145246, MSE: 0.689107, complexity : 23.3022, efficiency : 0.192933) : (7.52013*(0.8222-sin((exp(cos(Parameter))--0.43189))))
- Equation 5, (R2: 0.148106, MSE: 0.693459, complexity : 29.9889, efficiency : 0.212203) : (5567.27**atan((sin(tan(cos(Parameter)))-0.775476)))
- Equation 6, (R2: 0.152688, MSE: 0.713266, complexity : 12.7657, efficiency : 0.26848) : (28174.8**(sin(cos(Parameter))+-0.645049))
- Equation 7, (R2: 0.152688, MSE: 0.713266, complexity : 30.5428, efficiency : 0.23492) : (28174.8**(sin(cos(-(Parameter)))-0.645049))
- Equation 8, (R2: 0.163341, MSE: 0.752288, complexity : 9.1014, efficiency : 0.301986) : (880.158**(cos(Parameter)+-0.698217))
- Equation 9, (R2: 0.339597, MSE: 1.01158, complexity : 8.0611, efficiency : 0.215999) : tan((cos(Parameter)+0.427452))
- Equation 10, (R2: 0.51313, MSE: 1.2548, complexity : 8, efficiency : 0.166807) : exp(tan(cos(Parameter)))
- Equation 11, (R2: 0.696599, MSE: 1.44227, complexity : 4.75489, efficiency : 0.120515) : exp(cos(Parameter))
- Equation 12, (R2: 0.902554, MSE: 1.55975, complexity : 2, efficiency : 0.0512632) : cos(Parameter)
- Equation 13, (R2: 1, MSE: 1.59929, complexity : 0.5, efficiency : 0) : 0.744437

run4
21:39:59.886 [Info] (algorithm) Best equations of Generation 50
> Equation 0, (R2: 0.00178658, MSE: 0.0738544, complexity : 53.0754, efficiency : 0.333024) : (-0.0996532*((exp(cos((exp((0.253497*cos(Parameter)))+1.49969)))**(tan(cos(Parameter))-6.52169))-175.857))
- Equation 1, (R2: 0.00870158, MSE: 0.159501, complexity : 65.8482, efficiency : 0.316283) : ((-45.6367*-(-(cos(-((17807.2-sin((cos(Parameter)-940.37))))))))+43.9252)
- Equation 2, (R2: 0.0191298, MSE: 0.257921, complexity : 39.3342, efficiency : 0.304347) : ((1007.65**exp(sin((cos((cos(Parameter)-2.58915))-26.0558))))-14.1892)
- Equation 3, (R2: 0.0828009, MSE: 0.517077, complexity : 32.0746, efficiency : 0.20761) : (cos((cos(Parameter)+4.07067))*(exp(sin(cos(Parameter)))**3.61973))
- Equation 4, (R2: 0.0857133, MSE: 0.52515, complexity : 27.4167, efficiency : 0.223341) : ((cos(Parameter)-0.641622)*(exp(sin(cos(Parameter)))**3.60052))
- Equation 5, (R2: 0.141404, MSE: 0.687754, complexity : 23.222, efficiency : 0.195613) : ((exp((atan(cos(Parameter))-0.593276))**10.6595)+-0.275581)
- Equation 6, (R2: 0.145269, MSE: 0.683707, complexity : 27.2148, efficiency : 0.214352) : (4.93905*atan((72881.4**(cos(Parameter)-0.869432))))
- Equation 7, (R2: 0.151937, MSE: 0.728126, complexity : 19.4263, efficiency : 0.235536) : ((550.823**(cos(Parameter)-0.670827))-0.275606)
- Equation 8, (R2: 0.152996, MSE: 0.715279, complexity : 26.6427, efficiency : 0.268192) : (96708.4**(atan(cos(Parameter))-0.609756))
- Equation 9, (R2: 0.163341, MSE: 0.752288, complexity : 17.3735, efficiency : 0.301986) : (880.159**(cos(Parameter)-0.698217))
- Equation 10, (R2: 0.51313, MSE: 1.2548, complexity : 8, efficiency : 0.166807) : exp(tan(cos(Parameter)))
- Equation 11, (R2: 0.51313, MSE: 1.2548, complexity : 11.6096, efficiency : 0.133445) : exp(tan(cos(-(Parameter))))
- Equation 12, (R2: 0.696599, MSE: 1.44227, complexity : 4.75489, efficiency : 0.120515) : exp(cos(Parameter))
- Equation 13, (R2: 0.902554, MSE: 1.55975, complexity : 2, efficiency : 0.0512632) : cos(Parameter)
- Equation 14, (R2: 1, MSE: 1.59929, complexity : 0.5, efficiency : 0) : 0.744437


sans

run 1
09:37:02
20:52:05.779 [Info] (algorithm) Best equations of Generation 50
- Equation 0, (R2: 0.0234269, MSE: 0.279783, complexity : 72.6849, efficiency : 0.197572) : (sqrt(1 / (exp((-8.04614-tan(sin((sin(sin((tan(sin(cos(Parameter)))+771.876)))+828.334)))))))+-27.1934)
- Equation 1, (R2: 0.0613889, MSE: 0.429087, complexity : 53.7319, efficiency : 0.174408) : (exp(((3.30675-sin((Parameter-944.049)))-tan(sin((cos(Parameter)+798.855)))))-10.9487)
- Equation 2, (R2: 0.0784101, MSE: 0.479323, complexity : 45.9462, efficiency : 0.16972) : (exp(atan((cos(Parameter)/0.0987073)))*tan(sin((109.631-cos((1.99256*Parameter))))))
- Equation 3, (R2: 0.110711, MSE: 0.577281, complexity : 43.8526, efficiency : 0.157203) : (exp(tan(cos(Parameter)))*tan(sin(exp((1.6249-sin((Parameter-940.907)))))))
- Equation 4, (R2: 0.136969, MSE: 0.633093, complexity : 32.2235, efficiency : 0.165667) : (2.56032*exp(cos(Parameter)))
- Equation 5, (R2: 0.14753, MSE: 0.696217, complexity : 25.6763, efficiency : 0.173975) : (0.000635054*exp((-9.24278*sin((-0.0319766-tan(cos(Parameter)))))))
- Equation 6, (R2: 0.150747, MSE: 0.722106, complexity : 20.1202, efficiency : 0.189215) : (exp((-6.39884*sin((0.67024-cos(Parameter)))))-0.281861)
- Equation 7, (R2: 0.162596, MSE: 0.748243, complexity : 15.6878, efficiency : 0.227061) : (967.384**-(cos((cos(Parameter)+0.872313))))
> Equation 8, (R2: 0.162596, MSE: 0.748236, complexity : 15.8783, efficiency : 0.259498) : (967.057**cos((-10.2971-cos(Parameter))))
- Equation 9, (R2: 0.362302, MSE: 1.0979, complexity : 13.4953, efficiency : 0.169213) : 1 / ((1.67079-tan(cos(Parameter))))
- Equation 10, (R2: 0.411292, MSE: 1.08911, complexity : 8.60647, efficiency : 0.177691) : 1 / ((1.14808-cos(Parameter)))
- Equation 11, (R2: 0.51313, MSE: 1.2548, complexity : 8, efficiency : 0.166807) : exp(tan(cos(Parameter)))
- Equation 12, (R2: 0.696599, MSE: 1.44227, complexity : 4.75489, efficiency : 0.120515) : exp(cos(Parameter))
- Equation 13, (R2: 0.902554, MSE: 1.55975, complexity : 2, efficiency : 0.0512632) : cos(Parameter)
- Equation 14, (R2: 1, MSE: 1.59929, complexity : 0.5, efficiency : 0) : 0.744437

run 2
09:54:48
21:02:55.568 [Info] (algorithm) Best equations of Generation 50
- Equation 0, (R2: 0.00775352, MSE: 0.171292, complexity : 61.0585, efficiency : 0.24298) : (exp((exp(cos((-359687-exp(cos(Parameter)))))+0.628455))-((-36.1706*exp((0.431928*cos(Parameter))))--52.0525))
> Equation 1, (R2: 0.00870158, MSE: 0.159502, complexity : 31.9747, efficiency : 0.395354) : ((-45.6369*cos((sin((cos(Parameter)+42.9486))+6.94582)))+43.9255)
- Equation 2, (R2: 0.0966104, MSE: 0.581418, complexity : 31.5234, efficiency : 0.212461) : (sin((cos(Parameter)-44.6119))*exp((3.05059*cos(Parameter))))
- Equation 3, (R2: 0.143566, MSE: 0.670141, complexity : 18.0546, efficiency : 0.194096) : exp((exp(exp(cos((cos(Parameter)-1.04502))))-13.2049))
- Equation 4, (R2: 0.150747, MSE: 0.722104, complexity : 28.6992, efficiency : 0.210239) : ((601.098**sin((cos(Parameter)-44.6525)))-0.281868)
- Equation 5, (R2: 0.151937, MSE: 0.728126, complexity : 18.4792, efficiency : 0.235536) : ((550.823**(cos(Parameter)+-0.670827))-0.275606)
- Equation 6, (R2: 0.162596, MSE: 0.748242, complexity : 26.9863, efficiency : 0.259498) : (967.34**sin((cos(Parameter)-44.6808)))
- Equation 7, (R2: 0.339597, MSE: 1.01167, complexity : 15.3235, efficiency : 0.215999) : tan((cos(Parameter)-159.794))
- Equation 8, (R2: 0.51313, MSE: 1.2548, complexity : 8, efficiency : 0.166807) : exp(tan(cos(Parameter)))
- Equation 9, (R2: 0.696599, MSE: 1.44227, complexity : 4.75489, efficiency : 0.120515) : exp(cos(Parameter))
- Equation 10, (R2: 0.902554, MSE: 1.55975, complexity : 2, efficiency : 0.0512632) : cos(Parameter)
- Equation 11, (R2: 1, MSE: 1.59929, complexity : 0.5, efficiency : 0) : 0.744437

run 3
09:41:34
21:11:41.287 [Info] (algorithm) Best equations of Generation 50
- Equation 0, (R2: 0.00894288, MSE: 0.18221, complexity : 57.4116, efficiency : 0.294806) : (exp((exp(cos((822.006-exp(sin(-((cos(Parameter)+752.948)))))))+3.15066))-35.5734)
- Equation 1, (R2: 0.0861624, MSE: 0.510867, complexity : 30.2699, efficiency : 0.188579) : ((exp(cos(Parameter))-1.85738)*(exp(exp(sin(cos(Parameter))))-1.79199))
- Equation 2, (R2: 0.123464, MSE: 0.658272, complexity : 28.6104, efficiency : 0.174317) : (exp((exp(cos((821.101-exp(cos(Parameter)))))--1.89407))-10.4188)
- Equation 3, (R2: 0.145692, MSE: 0.665638, complexity : 31.3372, efficiency : 0.175115) : exp((exp(exp(sin((sin(cos(Parameter))+31.9538))))-12.4697))
- Equation 4, (R2: 0.148703, MSE: 0.715355, complexity : 26.2682, efficiency : 0.19058) : ((98.2973**(exp(sin(cos(Parameter)))-1.86973))+-0.276651)
- Equation 5, (R2: 0.152536, MSE: 0.711913, complexity : 28.9283, efficiency : 0.208929) : (exp(sin((sin(cos(Parameter))-556.707)))**-10.3198)
- Equation 6, (R2: 0.160131, MSE: 0.740411, complexity : 23.7576, efficiency : 0.22897) : (141.061**(exp(sin(cos(Parameter)))+-1.90882))
- Equation 7, (R2: 0.162596, MSE: 0.748219, complexity : 26.7029, efficiency : 0.259498) : (966.362**cos((cos(Parameter)-756.251)))
> Equation 8, (R2: 0.163341, MSE: 0.752288, complexity : 17.565, efficiency : 0.301986) : (880.159**(cos(Parameter)+-0.698217))
- Equation 9, (R2: 0.339597, MSE: 1.01164, complexity : 17.913, efficiency : 0.215999) : tan((cos(Parameter)-964.042))
- Equation 10, (R2: 0.51313, MSE: 1.2548, complexity : 8, efficiency : 0.166807) : exp(tan(cos(Parameter)))
- Equation 11, (R2: 0.696599, MSE: 1.44227, complexity : 4.75489, efficiency : 0.120515) : exp(cos(Parameter))
- Equation 12, (R2: 0.902554, MSE: 1.55975, complexity : 2, efficiency : 0.0512632) : cos(Parameter)
- Equation 13, (R2: 1, MSE: 1.59929, complexity : 0.5, efficiency : 0) : 0.744437

run 4
21:24:16.937 [Info] (algorithm) Best equations of Generation 50
> Equation 0, (R2: 1.81195e-05, MSE: 0.00812124, complexity : 62.133, efficiency : 0.606585) : (exp((sin((sin((cos(Parameter)-480.496))-((-0.905829*cos(Parameter))-383.65)))+3.72219))-51.8835)
- Equation 1, (R2: 9.72325e-05, MSE: 0.0161087, complexity : 51.1416, efficiency : 0.5774) : (exp((sin((sin((cos(Parameter)-480.497))-(-0.905621*cos(Parameter))))+4.06488))-50.3827)
- Equation 2, (R2: 0.00870158, MSE: 0.159508, complexity : 34.4817, efficiency : 0.395354) : (45.6375*(sin((sin((cos(Parameter)-478.556))+-0.908161))+0.962498))
- Equation 3, (R2: 0.121455, MSE: 0.615092, complexity : 24.7547, efficiency : 0.191655) : (exp((sin((exp(cos(Parameter))-2.71325))+2.54581))-5.69464)
- Equation 4, (R2: 0.141939, MSE: 0.661928, complexity : 30.0536, efficiency : 0.195236) : (exp((sin((cos(Parameter)-477.017))-0.941105))**33.6904)
- Equation 5, (R2: 0.148388, MSE: 0.693808, complexity : 21.7095, efficiency : 0.211992) : (exp((sin(sin(cos(Parameter)))-0.602106))**13.9044)
- Equation 6, (R2: 0.152688, MSE: 0.713266, complexity : 19.1246, efficiency : 0.23492) : (exp((sin(cos(Parameter))-0.645049))**10.2462)
- Equation 7, (R2: 0.163341, MSE: 0.752288, complexity : 14.4417, efficiency : 0.258845) : exp((-6.7801*(0.698217-cos(Parameter))))
- Equation 8, (R2: 0.339597, MSE: 1.01167, complexity : 8.00154, efficiency : 0.215999) : tan((cos(Parameter)+0.427421))
- Equation 9, (R2: 0.51313, MSE: 1.2548, complexity : 8, efficiency : 0.166807) : exp(tan(cos(Parameter)))
- Equation 10, (R2: 0.696599, MSE: 1.44227, complexity : 4.75489, efficiency : 0.120515) : exp(cos(Parameter))
- Equation 11, (R2: 0.902554, MSE: 1.55975, complexity : 2, efficiency : 0.0512632) : cos(Parameter)
- Equation 12, (R2: 1, MSE: 1.59929, complexity : 0.5, efficiency : 0) : 0.744437