#pragma once

#include <QElapsedTimer>

#include "EquationParameters/EquationMutationParameters.h"
#include "equationtransformation.h"

namespace algorithmcontroller
{

/**
 * @brief The EquationMutation class handle the mutation on the equation's children
 */
class EquationMutation : EquationTransformation {
   public:

    /**
     * @brief generate mutated equations
     * @param A list of Equations (not modified)
     * @return The list of equations mutated from the original list
     */
    std::pair<datamodel::EquationTree*, uint> generateMutatedEquations(
            const datamodel::EquationTree* equations,
            uint equationsSize,
            const std::vector<datamodel::DataPoint> inputDatas,
            std::unordered_set<std::string> &equationsStructuresHash,
            int maxNumberOfNodes,
            int generation) const;

    // getter / setter
    equationparameters::EquationMutationParameters equationMutationParameters() const;
    void setEquationMutationParameters(const equationparameters::EquationMutationParameters &equationMutationParameters);

   private:
    /**
     * @brief The equation mutation parameters containing a rate of mutation and a generation paramater object
     */
    equationparameters::EquationMutationParameters _equationMutationParameters;
    mutable std::mutex loopMutex;
};

}  // namespace algorithmcontroller
