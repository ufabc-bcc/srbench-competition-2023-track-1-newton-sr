#include "DistanceToDataCalculator.h"

#include <QMap>
#include <QFuture>

#include <QtConcurrent/QtConcurrentRun>
#include <QtMath>

namespace algorithmcontroller {

double DistanceToDataCalculator::computeDistance(const datamodel::EquationTree equationTree,
                                                 std::vector<datamodel::DataPoint> inputDatas){
    switch(equationTree.distanceToUse()){
        case equationparameters::EquationDistanceParameters::R2:
            return calculateRSquared(equationTree.root(), inputDatas);
        case equationparameters::EquationDistanceParameters::MSE:
            return calculateCumulatedDistanceToData(equationTree.root(), inputDatas);
        default:
            return calculateRSquared(equationTree.root(), inputDatas);
    }
}

double DistanceToDataCalculator::calculateCumulatedDistanceToData(datamodel::EquationTreeItem equationTreeItem,
                                                                  std::vector<datamodel::DataPoint> inputDatas) {
    double cumulatedError = 0;
    int nbValidData = 0;

    for (const auto &dataPoint : inputDatas){
        double equationValue = equationTreeItem.value(dataPoint.parameterList());
        if (!std::isnan(dataPoint.result()) && !std::isinf(dataPoint.result())) {
            if(std::isnan(equationValue) || !std::isfinite(equationValue)) {
                cumulatedError = nan("");
                break;
            } else {
                nbValidData++;
                cumulatedError += qSqrt((dataPoint.result() - equationValue) * (dataPoint.result() - equationValue));
            }
        }
    }

    if (!std::isnan(cumulatedError)) {
        cumulatedError /= nbValidData;
    }

    return cumulatedError;
}


double DistanceToDataCalculator::calculateAveragedInputDataValues(std::vector<datamodel::DataPoint> inputDatas) {
    double cummulatedValues = 0;
    int nbValidData = 0;
    for (const auto &dataPoint : inputDatas) {
        if (!std::isnan(dataPoint.result()) && !std::isinf(dataPoint.result())) {
            cummulatedValues += dataPoint.result();
            nbValidData++;
        }
    }
    return cummulatedValues/nbValidData;
}


double DistanceToDataCalculator::calculateRSquared(datamodel::EquationTreeItem equationTreeItem,
                                                   std::vector<datamodel::DataPoint> inputDatas) {
    double SSres = 0;
    double SStot = 0;

    const double yAvg = calculateAveragedInputDataValues(inputDatas);

    for (const auto &dataPoint : inputDatas) {
        double equationValue = equationTreeItem.value(dataPoint.parameterList());

        if (!std::isnan(dataPoint.result()) && !std::isinf(dataPoint.result())) {

            if (std::isnan(equationValue) || !std::isfinite(equationValue)) {
                return nan("");
            }
            else {
              SSres += (dataPoint.result()-equationValue)*(dataPoint.result()-equationValue);
              SStot += (dataPoint.result()-yAvg)*(dataPoint.result()-yAvg);
            }
        }
    }
    return SSres/SStot;
}


std::map<int, double> DistanceToDataCalculator::calculateDistancesToData(const QMap<int, datamodel::EquationTreeItem> &equations,
                                                                         const std::vector<datamodel::DataPoint> &inputDatas,
                                                                         bool concurrentCalculation) {
    if (concurrentCalculation)
        return calculateDistancesToDataConcurrent(equations, inputDatas);
    return calculateDistancesToDataNonConcurrent(equations, inputDatas);
}

std::map<int, double> DistanceToDataCalculator::calculateRSquaredCoeff(QMap<int, datamodel::EquationTreeItem> &equations,
                                                                       const std::vector<datamodel::DataPoint> &inputDatas,
                                                                       bool concurrentCalculation) {
    if (concurrentCalculation)
        return calculateRSquaredCoeffConcurrent(equations, inputDatas);
    return calculateRSquaredCoeffNonConcurrent(equations, inputDatas);
}

std::map<int, double> DistanceToDataCalculator::calculateDistancesToDataConcurrent(const QMap<int, datamodel::EquationTreeItem> &equations,
                                                                                   const std::vector<datamodel::DataPoint> &inputDatas) {
    std::map<int, double> distanceToData;
    if (equations.size() != 0 && inputDatas.size() != 0) {
        QMapIterator<int, datamodel::EquationTreeItem> equationIterator(equations);
        QMap<int, QFuture<double>> futures;

        // Start each calculation in a thread in parallel
        while (equationIterator.hasNext()) {
            equationIterator.next();
            futures.insert(equationIterator.key(),
                           QtConcurrent::run(calculateCumulatedDistanceToData, equationIterator.value(), inputDatas));
        }

        // Get the result of each calculation in the same order than the lanch,
        // so we wait the results of the first calculation then the second ... while all the calculations are running in threadeds
        QMapIterator<int, QFuture<double>> futurIterator(futures);
        while (futurIterator.hasNext()) {
            futurIterator.next();
            distanceToData.insert({equationIterator.key(), futurIterator.value().result()});
        }
    }
    return distanceToData;
}

std::map<int, double> DistanceToDataCalculator::calculateDistancesToDataNonConcurrent(const QMap<int, datamodel::EquationTreeItem> &equations,
                                                                                      const std::vector<datamodel::DataPoint> &inputDatas) {
    std::map<int, double> distanceToData;
    if (equations.size() != 0 && inputDatas.size() != 0) {
        QMapIterator<int, datamodel::EquationTreeItem> equationIterator(equations);

        while (equationIterator.hasNext()) {
            equationIterator.next();
            double cumulatedError = calculateCumulatedDistanceToData(equationIterator.value(), inputDatas);
            distanceToData.insert({equationIterator.key(), cumulatedError});
        }
    }
    return distanceToData;
}


std::map<int, double>  DistanceToDataCalculator::calculateRSquaredCoeffConcurrent(QMap<int, datamodel::EquationTreeItem> &equations,
                                                                                  const std::vector<datamodel::DataPoint> &inputDatas) {
    std::map<int, double> RSquaredOfData;
    if (equations.size() != 0 && inputDatas.size() != 0) {
        QMapIterator<int, datamodel::EquationTreeItem> equationIterator(equations);
        QMap<int, QFuture<double>> futures;
        while (equationIterator.hasNext()) {
            equationIterator.next();
            futures.insert(equationIterator.key(), QtConcurrent::run(calculateRSquared, equationIterator.value(), inputDatas) );
        }

        // Get the result of each calculation in the same order than the lanch,
        // so we wait the results of the first calculation then the second ... while all the calculations are running in threadeds
        QMapIterator<int, QFuture<double>> futurIterator(futures);
        while (futurIterator.hasNext()) {
            futurIterator.next();
            RSquaredOfData.insert({equationIterator.key(), futurIterator.value().result()});
        }
    }
    return RSquaredOfData;
}



std::map<int, double>  DistanceToDataCalculator::calculateRSquaredCoeffNonConcurrent(QMap<int, datamodel::EquationTreeItem> &equations,
                                                                                     const std::vector<datamodel::DataPoint> &inputDatas) {
    std::map<int, double> RSquaredOfData;
    if (equations.size() != 0 && inputDatas.size() != 0) {
        QMapIterator<int, datamodel::EquationTreeItem> equationIterator(equations);
        while (equationIterator.hasNext()) {
            equationIterator.next();
            const double R2 = calculateRSquared(equationIterator.value(), inputDatas);
            RSquaredOfData.insert({equationIterator.key(), R2});
        }
    }
    return RSquaredOfData;
}

} // namespace algorithmcontroller
