#include "AlgorithmController.h"

#include <QCoreApplication>
#include <QElapsedTimer>
#include <QHash>
#include <QMetaEnum>
#include <QtCharts/QBarSet>

#include "DataModel/NodeTypes.h"
#include "DataModel/EquationTree.h"
#include "DataModel/EquationTreeItem.h"
#include "DistanceToDataCalculator.h"
#include "EquationCrossbreeding.h"
#include "EquationEditors/EquationGenerator.h"
#include "EquationEditors/EquationPrinter.h"
#include "EquationEditors/EquationSimplifier.h"
#include "EquationEditors/EquationToTree.hpp"
#include "EquationFiltor.h"
#include "EquationMutation.h"
#include "ParetoEfficiencyCalculator.h"
#include "TotalNodeCalculator.h"
#include "Utils/ComparisonUtils.h"
#include "Logger_v2/Logger.h"
#include "libev3/parser.h"

// STL
#include <algorithm>
#include <limits>
#include <iostream>
#include <random>

#include <fstream>
#include <sstream>
#include <cstring>

#include <iostream>
#include <filesystem>



namespace algorithmcontroller {

int cpt = 0;
int nbGenerations = 0;
int age = cpt;

AlgorithmController::~AlgorithmController() {
    _workerThread.quit();
    _workerThread.wait();
    if(_equationsArray != nullptr){
        delete [] _equationsArray;
    }
}


static void updateDistanceToData(datamodel::EquationTree* equationsArray,
                                 uint equationsArraySize,
                                 const std::vector<datamodel::DataPoint> inputDatas) {
    std::for_each(equationsArray, equationsArray+equationsArraySize, [&inputDatas](datamodel::EquationTree& equation){
        double distanceR2 = DistanceToDataCalculator::calculateRSquared(equation.root(), inputDatas);
        equation.setDistanceR2(distanceR2);
        double distanceMSE = DistanceToDataCalculator::calculateCumulatedDistanceToData(equation.root(), inputDatas);
        equation.setDistanceMSE(distanceMSE);
    });
}


void WorkerGenerationCycling::doWorkParallel(algorithmcontroller::AlgorithmController *algorithmController,
                                             equationparameters::EquationGenerationCyclingParameters params) {

    QElapsedTimer timer;
    QElapsedTimer timer1;
    QElapsedTimer threadTimer;
    float temp_elapsed_time=0;
    float temp_var = 0;
    double generationTotalTime = 0;
    double generationsElapsedTime =0;
    timer.start();

    QElapsedTimer computeTimer;
    computeTimer.start();

    _working = true;

    /*** INIT ***/



    uint equationsArraySize = algorithmController->getEquationsArraySize();

    algorithmController->reallocEquationTree(equationsArraySize);

    datamodel::EquationTree* equationsArray = algorithmController->equationsArray();

    for (uint i = 0; i < equationsArraySize; i++)
        equationsArray[i].setDistanceToUse(params.equationDistanceParameters().getEquationDistance());

    std::unordered_set<std::string> &hashTable = *algorithmController->getEquationsStructuresHash();

    uint nbVariables = 0;
    if(equationsArraySize > 0){
        nbVariables = equationsArray[0].numberOfVariables();
    }

    EquationFiltor equationFiltor;
    equationFiltor.setEquationFilterParameters(params.equationFilterParameters());

    EquationCrossbreeding equationCrossbreeding;
    equationCrossbreeding.setEquationCrossBreedingParameters(params.equationCrossbreedingParameters());

    EquationMutation equationMutation;
    equationMutation.setEquationMutationParameters(params.equationMutationParameters());

    // Init the benchmark, no display after the initialisation

    if(!utils::CommandLineParser::getStartSilent()){
        emit algorithmController->forwardBenchmarkInit(crossbreeding, mutation, filter, pareto, process_clean_and_new_equation, signals_process, fitness, simplification);
    }
    if(algorithmController->getProcessBenchmark())  timer1.start();
    EquationFit* fitController = algorithmController->getFitController();
    fitController->setEquationFitParameters(params.equationFitParameters());
    //  End timer if benchmark is activated, crossbreeding
    if(algorithmController->getProcessBenchmark()){
        //qInfo() << timer1.elapsed();
        std::string message_info_timer = "Filter duration : "
                +  std::to_string(timer1.elapsed());
        logs::Logger::logInfoDetail(message_info_timer);
    }

    // Sort the equations for having the minimum distance
    equationFiltor.sortEquations(equationsArray, equationsArraySize);

    bool infinite = params.infiniteGeneration();
    const auto number = params.numberOfGenerations();
    auto distance = pow(10,params.distanceMinimum());
    auto time = params.timeSelected() * 1000;

    double min = DistanceToDataCalculator::computeDistance(equationsArray[0], algorithmController->inputFileManager()->inputDatas());
    int distParameter = params.activateDistanceMin();
    /*  0 => Disable
     *  1 => Enable
     *  2 => Zero;
     */
    if (distParameter==0) min = distance+1;
    if(distParameter==2) distance = 0;

    if (params.timeSelected() == 0) {
        time = timer.elapsed()+5000;
    }

    /*** MAIN LOOP ***/

    while (_working && (infinite || cpt < number) && (distance < min) && (timer.elapsed() < time)) {
        timer.start();
        temp_var = 0;

        /*** SIMPLIFY ***/

        if(algorithmController->getProcessBenchmark())  timer1.start();

        simplifyAllEquations(algorithmController->inputFileManager()->inputDatas(),
                            equationsArray,
                            equationsArraySize,
                            hashTable);


        if(algorithmController->getProcessBenchmark()){
            simplification->append(temp_elapsed_time =timer1.elapsed());
            temp_var +=temp_elapsed_time;
        }

        /*** CROSSBREED ***/
        // Generating offsprings by crossbreeding some of the equations.
        threadTimer.start();

        //  Start timer if benchmark is activated, crossbreeding
        if(algorithmController->getProcessBenchmark())  timer1.start();
        std::pair<datamodel::EquationTree*, uint> crossbreedsOutput = equationCrossbreeding.crossbreeds(equationsArray,
                                                                        equationsArraySize,
                                                                        algorithmController->inputFileManager()->inputDatas(),
                                                                        hashTable,
                                                                        params.maxNode(),
                                                                        cpt);

        datamodel::EquationTree* offspring = crossbreedsOutput.first;
        uint offspringSize = crossbreedsOutput.second;

        //  End timer if benchmark is activated, crossbreeding
        if(algorithmController->getProcessBenchmark()){
            crossbreeding->append(temp_elapsed_time =timer1.elapsed());
            temp_var +=temp_elapsed_time;
        }

        /*** MUTATE ***/

        //  Start timer if benchmark is activated, mutation
        if(algorithmController->getProcessBenchmark())  timer1.start();

        std::pair<datamodel::EquationTree*, uint> mutationOutput = equationMutation.generateMutatedEquations(equationsArray,
                                                                                                             equationsArraySize,
                                                                                                             algorithmController->inputFileManager()->inputDatas(),
                                                                                                             hashTable,
                                                                                                             params.maxNode(),
                                                                                                             cpt);

        datamodel::EquationTree* mutated = mutationOutput.first;
        uint mutatedSize = mutationOutput.second;

         //  End timer if benchmark is activated, mutation
        if(algorithmController->getProcessBenchmark()){
            mutation->append(temp_elapsed_time =timer1.elapsed());
            temp_var +=temp_elapsed_time;
        }


        /*** APPEND ORIGINAL Eq. + MUTATED Eq. + OFFSPRINGS Eq. ***/

        //  Start timer if benchmark is activated, new equations
        if(algorithmController->getProcessBenchmark())  timer1.start();
        // Insert the new equations after removing worst parents
        uint childSize = mutatedSize + offspringSize;
        uint equationsToFilterSize = equationsArraySize + childSize;
        datamodel::EquationTree* equationsToFilter = new datamodel::EquationTree[equationsToFilterSize];
        // Firstly : Copy actual equations at the beginning
        std::copy(equationsArray, equationsArray+equationsArraySize, equationsToFilter);
        //  End timer if benchmark is activated, new equations
        if(algorithmController->getProcessBenchmark()){
            process_clean_and_new_equation->append(temp_elapsed_time =timer1.elapsed());
            temp_var +=temp_elapsed_time;

        }

        // Next : Copy crossbreeding equations
        uint index = equationsArraySize;
        for (uint i = 0; i < offspringSize; i++) {
            if (offspring[i].root().currentNode() != nullptr){
                equationsToFilter[index] = offspring[i];
                index++;
            }
        }

        // Finally : Copy mutated equations
        for(uint i = 0; i < mutatedSize; i++){
            if(mutated[i].root().currentNode() != nullptr){
                equationsToFilter[index] = mutated[i];
                index++;
            }
        }

        //We generate random equations in case we lost some
        equationeditors::EquationGenerator equationGenerator;
        equationGenerator.setMaxDepth(algorithmController->getGenerationParameterCache().equationMaxDepth());
        equationGenerator.setSelectedNodesTypes(algorithmController->getGenerationParameterCache().selectedNodesTypes());
        equationGenerator.setNumberOfVariables(nbVariables);
        while(index < algorithmController->getEquationsArraySize()){
            equationsToFilter[index] = algorithmController->generateSingleEquation(equationGenerator, algorithmController->getCurrentGenerationCyclingParameters().equationDistanceParameters());
            index++;
        }

        equationsToFilterSize = index;

        childSize = equationsToFilterSize - equationsArraySize;

       if(algorithmController->getProcessBenchmark() ){
           timer1.start();
       }



        /*** FITTING (optimize constants up/down) ***/
        if(cpt % fitController->equationFitParameters().populationPeriod() == 0) {
            fitAllEquations(fitController,
                            algorithmController->inputFileManager()->inputDatas(),
                            equationsToFilter,
                            equationsToFilterSize,
                            hashTable);
        }
        statBasedEquationEdition(equationsToFilter, equationsToFilterSize, algorithmController->inputFileManager()->inputDatas(), hashTable);

        
        equationsToFilterSize = AlgorithmController::removeDuplicates(equationsToFilter, equationsToFilterSize);

        /*** Remove cases of division by 0  ***/
        AlgorithmController::removeDivisionByZero(equationsToFilter, equationsToFilterSize, nbVariables);
        
        /*** PARETO ***/
        // Evaluate Pareto for all the equations (necessary for the filter operation)
        ParetoEfficiencyCalculator::identifyParetoFrontier(equationsToFilter, equationsToFilterSize);
        if(algorithmController->getProcessBenchmark() && algorithmController->getDisplayFitnessBench()){
            fitness->append(temp_elapsed_time =timer1.elapsed());
            temp_var +=temp_elapsed_time;
        }
        //  Start timer if benchmark is activated, evaluate pareto
        if(algorithmController->getProcessBenchmark()) {
            timer1.start();
        }


        /*** FILTER EQUATIONS (to keep the best) ***/
        equationFiltor.filterEquations(equationsArray, algorithmController->getEquationsArraySize(),
                                       equationsToFilter, equationsToFilterSize,
                                       hashTable);
        // release memory after using
        delete [] equationsToFilter;

        equationsArraySize = algorithmController->getEquationsArraySize(); // Setting back original size, as losses from duplicate fits are restored during equation filtering

        //  End timer if benchmark is activated, filter
        if(algorithmController->getProcessBenchmark()){
            //qInfo()<<"Filter duration : "<<timer1.elapsed();
            filter->append(temp_elapsed_time =timer1.elapsed());
            temp_var +=temp_elapsed_time;
        }


        /*** EQUATION EFFICIENCY (set the bestEquation) ***/

        /* reset equation efficiency on all equations to value 1.0
         * the efficiency range of possible value is [0.0 and up] so -1.0 is not a result, it can be ignored on view side */
        for (uint i = 0; i < equationsArraySize; i++) {
            equationsArray[i].setEfficiency(-1.0);
        }
        // find the best equation by efficiency amongst pareto level 0 equations
        datamodel::EquationTree bestEquation = ParetoEfficiencyCalculator::getBestEquation(equationsArray, equationsArraySize);
        // gets all pareto level 0 equations
        QList<datamodel::EquationTree> paretoEquations = ParetoEfficiencyCalculator::getParetoEquations(equationsArray, equationsArraySize);
        /* affiche les equations du front de pareto :
            11:45:46.881 [Info] (algorithm) Best equations of Generation 0
            > Equation 0, (R2: 0.00627378, MSE: 0.000631417, complexity : 116.602, efficiency : 0.101428) : ((((((x0**1.48309)*(x2**((x5*((1.94672**((x0**(x5**-24.6212))+-0.5474))**0.625816))+-0.485744)))*(x3**-0.945861))*(x5**1.5574))*((x0*(cos(sin((sqrt(x6)+3.25171)))+-0.780146))+0.271351))*((x4*(x6**0.904823))+2.89933))
            - Equation 1, (R2: 0.680424, MSE: 0.00575936, complexity : 29.852, efficiency : 0.0427822) : -((0.000629607*(cos((x3+x2))-x4)))
            - Equation 2, (R2: 0.756071, MSE: 0.00567343, complexity : 13.4561, efficiency : 0.0699049) : -((-2.20553/x3))
            - Equation 3, (R2: 0.896098, MSE: 0.00539053, complexity : 2, efficiency : 0.0548527) : 1 / (x3)
            - Equation 4, (R2: 1, MSE: 0.00656316, complexity : 0.5, efficiency : 0) : 0.00638615
            Compute Time : 153610
        */
        std::stringstream ssBestEquation;
        ssBestEquation << "Best equations of Generation "+ std::to_string(_cpt) << std::endl;
        for (int i = 0; i < paretoEquations.size(); i++) {
            ssBestEquation << ((paretoEquations[i] == bestEquation) ? "> Equation " : "- Equation ") << i;
            ssBestEquation <<  ", (R2: " << 1 - paretoEquations[i].distanceR2();
            ssBestEquation << ", MSE: " << paretoEquations[i].distanceMSE();
            ssBestEquation << ", complexity : " << paretoEquations[i].complexity();
            ssBestEquation << ", efficiency : " << paretoEquations[i].efficiency();
            ssBestEquation << ") : " << equationeditors::equationToString(paretoEquations[i].root(), nbVariables) << std::endl;
        }
        ssBestEquation << "Compute Time : " << timer.elapsed() << std::endl;
        
        logs::Logger::logInfo(ssBestEquation.str(), {logs::LogTags::algorithm});
        emit algorithmController->updateBestEfficiencyEquation(bestEquation);

        /*** GENERATION END ***/

        QCoreApplication::processEvents();
        age++;

        //  Start timer if benchmark is activated, Signals
        if(algorithmController->getProcessBenchmark()){
            timer1.start();
        }

        emit generationCompleted(age, childSize);

        //  End timer if benchmark is activated, Signals
        if(algorithmController->getProcessBenchmark() && algorithmController->getDisplaySignalsBench()){
            signals_process->append(temp_elapsed_time = timer1.elapsed());
            temp_var +=temp_elapsed_time;
        }

        if(distParameter != 0){
            min = DistanceToDataCalculator::computeDistance(equationsArray[0], algorithmController->inputFileManager()->inputDatas());
        }

        if (params.timeSelected() == 0) time = timer.elapsed()<<2;

        // qInfo() << "FilterEquations of generation " << i << " tooks " <<
        // timer.restart() << " millisecond" ;
        delete [] offspring;
        delete [] mutated;

        if(generationTotalTime < temp_var ){
           generationTotalTime = temp_var ;
        }
        // If benchmark is activated, display it on the screen
        if(algorithmController->getProcessBenchmark()){
                emit algorithmController->forwardBenchmarkUpdate(generationTotalTime, std::max(0,age -1));
                //qInfo()<<";"<<crossbreeding->at(crossbreeding->count()-1)<<";"<<mutation->at(mutation->count()-1)<<";"<<filter->at(filter->count()-1)<<";"<<pareto->at(pareto->count()-1)<<";"<<process_clean_and_new_equation->at(process_clean_and_new_equation->count()-1)<<";"<<signals_process->at(signals_process->count()-1)<<";"<<fitness->at(fitness->count()-1) <<";"<<simplification->at(simplification->count()-1)<<";"<<temp_var<<";";

        }

        // Update the number of generation, this takes 0 to 1 ms
        generationsElapsedTime += timer.elapsed();
        if(_cpt !=0 ){
            emit algorithmController->forwardElapsedGenTimeEvent(QString::number((generationsElapsedTime)/(_cpt )) + " ms");
        }else{
            if(cpt==1 || cpt==0){
                emit algorithmController->forwardElapsedGenTimeEvent("0 ms");
                emit algorithmController->forwardBenchmarkReset();

            }else{
                if(_previousCpt == 0){
                     emit algorithmController->forwardElapsedGenTimeEvent(QString::number((generationsElapsedTime)/(cpt +1 )) + " ms");
                }else{
                    emit algorithmController->forwardElapsedGenTimeEvent(QString::number((generationsElapsedTime)/(cpt - _previousCpt)) + " ms");
                }
                 _previousCpt = cpt;
            }
        }
        _cpt++;
        cpt++;
    }
    _cpt = 1;
    _previousCpt = 0;
    emit algorithmController->instantRefreshFitness();
    emit algorithmController->instantRefreshEquationListControler();
    emit algorithmController->instantRefreshParetoControler(equationsArray, equationsArraySize);



    // Mostly a signal for the interface, to move the pause button back to
    // play and not continue or pause
    int lastGeneration = age;
    if ((!infinite && cpt >= number) || (distance >= min) || (timer.elapsed() > time))
    {

        if (!infinite && cpt >= number)
        {
            emit algorithmController->setRedNumberOfGenerations();
        }
        else if (distance >= min)
        {
            emit algorithmController->setRedDistance();
        }
        else if (timer.elapsed() > time)
        {
            emit algorithmController->setRedTime();
        }
        emit nonInfiniteGenerationCompleted();
        cpt = 0;
    }

    if(utils::CommandLineParser::getStartSilent()){
        if (equationsArraySize > 0)
        {
            std::string eq = equationeditors::equationToString(equationsArray[0].root(), nbVariables);

            // Output for benchmark
            std::stringstream ss;
            ss << "=> First equation : " << eq.c_str();
            ss << " Distance : " << equationsArray[0].distance();
            ss << " Compute Time : " << timer.elapsed();
            ss << " Last Generation : " << lastGeneration << std::endl;
            logs::Logger::logInfo(ss.str());
        }
        //TO BE CONFIRMED : exit added when using for command line mode
        exit(0);
    }
    emit workEnded();
}

AlgorithmController::AlgorithmController(QObject *parent) : QObject(parent) {
    WorkerGenerationCycling *worker = new WorkerGenerationCycling();
    worker->moveToThread(&_workerThread);
    connect(&_workerThread, &QThread::finished, worker, &QObject::deleteLater);
    connect(this, &AlgorithmController::generationCycling, worker, &WorkerGenerationCycling::doWorkParallel);
    connect(worker, &WorkerGenerationCycling::generationCompleted,
            this, &AlgorithmController::onEquationCycledGenerated, Qt::BlockingQueuedConnection);
    connect(this, &AlgorithmController::stopGenerationThread, worker, &WorkerGenerationCycling::stopWorking);
    connect(worker, &WorkerGenerationCycling::workEnded, this, &AlgorithmController::onSilentProcessDone);

    connect(worker, &WorkerGenerationCycling::workEnded, this, &AlgorithmController::actualizeViews);

    connect(worker, &WorkerGenerationCycling::nonInfiniteGenerationCompleted, this,
            &AlgorithmController::nonInfiniteGenerationComplete);

    connect(this, &AlgorithmController::resetGenForGenProcessTime, worker,
            &WorkerGenerationCycling::resetGenForGenProcessTime);
    _workerThread.start();
}

void AlgorithmController::actualizeViews()
{
    _workEnded = true;

    if (_resetGeneration) {
        cpt = 0;
        age = 0;
        _resetGeneration = false;
//        _equations.clear();
        emit generationCreated(_equationsArray, _equationsArraySize);
        emit equationsDataChanged(_equationsArray, _equationsArraySize);
        emit clearEquationPlotter();
        emit clearParetoRequest();

        QCoreApplication::processEvents();
    }
}

void AlgorithmController::continueGeneration(
        bool infiniteGeneration,
        int numberOfGeneration,
        double distanceMinimum,
        int activateDistanceMin,
        int timeSelected) {
    _workEnded = false;
    //New parameters update
    _currentGenerationCyclingParameters.setInfiniteGenerations(infiniteGeneration);
    _currentGenerationCyclingParameters.setNumberOfGenerations(numberOfGeneration);
    _currentGenerationCyclingParameters.setDistanceMinimum(distanceMinimum);
    _currentGenerationCyclingParameters.setActivateDistanceMinimum(activateDistanceMin);
    _currentGenerationCyclingParameters.setTimeSelected(timeSelected);
    emit generationCycling(this, _currentGenerationCyclingParameters);
}

void AlgorithmController::onSilentProcessDone(){

    if(utils::CommandLineParser::getStartSilent()){
        emit silentProcessDone(0);
    }
}

void AlgorithmController::forwardElapsedGenTimeEvent(const QString &value){
    emit generationElapsedTimeUpdated(value);
}

void AlgorithmController::forwardBenchmarkUpdate(int max_time, int  generationValue){
    emit benchmarkUpdated( max_time, generationValue);
}

void AlgorithmController::forwardBenchmarkReset(){
    emit benchmarkReset();
}


void AlgorithmController::processBenchmarkChanged(bool value1, bool value2, bool value3){
    processBenchmark = value1;
    previousDisplaySignalsBench   = displaySignalsBench;
    displaySignalsBench = value2;
    displayFitnessBench = value3;
}




void AlgorithmController::forwardBenchmarkInit(QBarSet *crossbreeding, QBarSet *mutation, QBarSet *filter, QBarSet *pareto, QBarSet *process_clean_and_new_equation, QBarSet *signals_process, QBarSet *fitness, QBarSet *simplification){
    emit benchmarkInit(crossbreeding, mutation, filter, pareto, process_clean_and_new_equation, signals_process, fitness, simplification);
}


void AlgorithmController::onEquationCycledGenerated(int generationNumber, int breedAndMutationRate)
{
    emit generationCreated(_equationsArray, _equationsArraySize, breedAndMutationRate);
    emit equationsDataChanged(_equationsArray, _equationsArraySize);
    emit generationCountChanged(generationNumber);

}


void AlgorithmController::resetGeneration()
{
    // If the thread is still running, we ask him to stop
    // and differ the reset into the slot that gets called
    // when the worker thread is done with its work
    // Also I don't think I need a mutex here, because _workEnded
    // will only be manipulated by the mainThread, same as this
    // function
    cpt = 0;
    age = 0;
    onEquationCycledGenerated(age);
    if (!_workEnded) {
        _resetGeneration = true;
        emit stopGenerationThread();
    }
    else {
        _resetGeneration = false;
        reallocEquationTree(0);
        emit generationCreated(_equationsArray, _equationsArraySize);
        emit equationsDataChanged(_equationsArray, _equationsArraySize);
        emit clearEquationPlotter();
        emit clearParetoRequest();
        QCoreApplication::processEvents();
    }
    emit this->forwardElapsedGenTimeEvent("0 ms");
    emit this->forwardBenchmarkReset();
    emit this->clearRefreshEquationListControler() ;
}

InputFileManager *AlgorithmController::inputFileManager() { return &_inputFileManager; }

EquationFit *AlgorithmController::getFitController() { return &_fitController; }

std::unordered_set<std::string> *AlgorithmController::getEquationsStructuresHash() { return &_equationsStructuresHash; }

datamodel::EquationTree* AlgorithmController::equationsArray() { return _equationsArray; }

uint AlgorithmController::getEquationsArraySize(){
    return _equationsArraySize;
}

void AlgorithmController::onEquationGenerationRequired(equationparameters::EquationGenerationParameters equationGenerationParameters,
                                                       equationparameters::EquationDistanceParameters equationDistanceParameters) {
    age=0;
    cpt=0;
    emit resetGenForGenProcessTime();
    onEquationCycledGenerated(age);
    logs::Logger::logDebug("on Equation Generation Required");
    if (_inputFileManager.inputDatas().size() == 0){
        logs::Logger::logWarning("Data input file is empty");
        resetGeneration();
        actualizeViews();
        return;
    }
    uint nbVariables = _inputFileManager.getNumberOfVariables();

    _generationParameterCache = equationGenerationParameters;




    //qInfo("Generation of equation required for %d equations and %d depth",
    //      equationGenerationParameters.equationNumber(), equationGenerationParameters.equationMaxDepth());
    std::string message_info_generation_equation = "Generation of equation required for "
            + std::to_string(equationGenerationParameters.equationNumber())
            + " equations and "
            + std::to_string(equationGenerationParameters.equationMaxDepth())
            +" depth.";
    logs::Logger::logDebug(message_info_generation_equation);
    equationeditors::EquationGenerator equationGenerator;
    equationGenerator.setMaxDepth(equationGenerationParameters.equationMaxDepth());
    equationGenerator.setSelectedNodesTypes(equationGenerationParameters.selectedNodesTypes());

    equationGenerator.setNumberOfVariables(nbVariables);

    reallocEquationTree(equationGenerationParameters.equationNumber());

    _equationsStructuresHash.clear();
    int equationGenerationSize = equationGenerationParameters.equationNumber() > INIT_POPULATION_SIZE ? equationGenerationParameters.equationNumber() : INIT_POPULATION_SIZE;
    _equationsStructuresHash.reserve(equationGenerationSize);
    datamodel::EquationTree* equationsInit = new datamodel::EquationTree[equationGenerationSize];
    
    //   // début : issue 43-initaliser-la-population-avec-des-équations
    /*** Equation Init Reading ***/

    // simplification libev3
    Ev3::ExpressionParser parser;
    for (uint j = 0; j < nbVariables; j++) {
        parser.SetVariableID("x" + std::to_string(j), j);
    }



    int i = 0;
    std::ifstream Equations ("./initEquation.txt");
    if(Equations) {
        std::string Line;
        while(getline(Equations,Line)) {
            QCoreApplication::processEvents();

            //simplification libev3 avant le parsing
            int nerr = 0;
            Ev3::Expression expr = parser.Parse(Line.c_str(), nerr);
            Ev3::Simplify(&expr);

            uint variableCount = 0;
            datamodel::EquationTree equation = equationToTreeParser::equationTreeFromString(expr->ToString());
            std::stringstream ss;
            
            ss << "Input equation after parsing and simplification : ";
            ss << equationeditors::equationToString(equation.root(), nbVariables) << std::endl;
            logs::Logger::logInfo(ss.str());
            equation.setTotalNode(algorithmcontroller::TotalNodeCalculator::calculateTotalNode(equation.root()));
            std::string structureHash = algorithmcontroller::EquationTransformation::computeHash(equation.root());
            equation.setStructureIdHash(structureHash);
            double distanceR2;
            double distanceMSE;
            bool validEquation = false;
            bool notFound = true;//_equationsStructuresHash.find(structureHash) == _equationsStructuresHash.end();
            bool isFinite = true;
            validEquation = notFound && isFinite && (nbVariables >= variableCount ? (equation.root().isValid(std::vector<double>(nbVariables))) : false);
            if(notFound && validEquation) {
                switch (equationDistanceParameters.getEquationDistance()) {
                    case equationparameters::EquationDistanceParameters::R2:   
                        distanceR2 = DistanceToDataCalculator::calculateRSquared(
                                    equation.root(), _inputFileManager.inputDatas());
                        isFinite = std::isfinite(distanceR2);
                        if(isFinite){ //Compute all other distances
                            distanceMSE = DistanceToDataCalculator::calculateCumulatedDistanceToData(
                                        equation.root(), _inputFileManager.inputDatas());
                        }
                        break;
                    case equationparameters::EquationDistanceParameters::MSE:
                        distanceMSE = DistanceToDataCalculator::calculateCumulatedDistanceToData(
                                    equation.root(), _inputFileManager.inputDatas());
                        isFinite = std::isfinite(distanceMSE);
                        if(isFinite){ //Compute all other distances
                            distanceR2 = DistanceToDataCalculator::calculateRSquared(
                                        equation.root(), _inputFileManager.inputDatas());
                        }
                        break;
                    default: //Default is R2
                        distanceR2 = DistanceToDataCalculator::calculateRSquared(
                                    equation.root(), _inputFileManager.inputDatas());
                        isFinite = std::isfinite(distanceR2);
                        if(isFinite){ //Compute all other distances
                            distanceMSE = DistanceToDataCalculator::calculateCumulatedDistanceToData(
                                        equation.root(), _inputFileManager.inputDatas());
                        }
                        break;
                }
                if (isFinite) {
                equationsInit[i] = datamodel::EquationTree(equation.root(), distanceR2, distanceMSE, structureHash);
                equationsInit[i].setNumberOfVariables(nbVariables);
                equationsInit[i].setTotalNode(algorithmcontroller::TotalNodeCalculator::calculateTotalNode(equationsInit[i].root()));
                equationsInit[i].setGeneration(0);
                equationsInit[i].setDistanceToUse(equationDistanceParameters.getEquationDistance());
                _equationsStructuresHash.insert(structureHash);
                equationsInit[i].setComplexity(equationsInit[i].totalNode());
                i++;
                }
            }
        }
    }

    while (i < equationGenerationSize) {
        equationsInit[i] = generateSingleEquation(equationGenerator, equationDistanceParameters);
        i++;
    }
    
    QElapsedTimer timer;
    timer.start();
    // Update Pareto efficiency level
    ParetoEfficiencyCalculator::identifyParetoFrontier(equationsInit, equationGenerationSize);
    std::copy(equationsInit,equationsInit+_equationsArraySize, _equationsArray);
    EquationFiltor equationFiltor;
    equationFiltor.setEquationFilterParameters(_currentGenerationCyclingParameters.equationFilterParameters());
    equationFiltor.sortEquations(_equationsArray, _equationsArraySize);

    delete [] equationsInit;
    //qInfo() << "ParetoEfficiencyCalculator tooks " << timer.restart() << " millisecond";
    std::string message_info_Pareto_efficency =  "ParetoEfficiencyCalculator tooks "
            +  std::to_string(timer.restart())
            + " millisecond";
    logs::Logger::logInfoDetail(message_info_Pareto_efficency, {logs::LogTags::pareto});
    emit equationsDataChanged(_equationsArray, _equationsArraySize);
}

void AlgorithmController::onStartGeneration(
        equationparameters::EquationGenerationParameters equationGenerationParameters,
        equationparameters::EquationGenerationCyclingParameters equationGenerationCyclingParameters)
{
    logs::Logger::logInfoDetail("on Start Generation");
    if (_inputFileManager.inputDatas().size() == 0){
        logs::Logger::logWarning("Data input file is empty");
        resetGeneration();
        actualizeViews();
        return;
    }

    // equationGenerationCyclingParameters.(_inputFileManager.getNumberOfVariables());
    // If there's no equation, I assume it's because the user didn't click on
    // init, so we do it for him here the signal is connected to the
    // EquationsGeneratorController

    if (_equationsArraySize == 0) {
        onEquationGenerationRequired(equationGenerationParameters, equationGenerationCyclingParameters.equationDistanceParameters());
    }
    onGenerationCyclingRequired(equationGenerationCyclingParameters);
}

void AlgorithmController::onGenerationCyclingRequired(
        equationparameters::EquationGenerationCyclingParameters equationGenerationCyclingParameters)
{

    // Needed otherwise the qthread doesn't seems to be able to use the parameter
    qRegisterMetaType<equationparameters::EquationGenerationCyclingParameters>(
                "equationparameters::EquationGenerationCyclingParameters");
    // We save the parameters in case we pause the generation
    _currentGenerationCyclingParameters = equationGenerationCyclingParameters;
    _workEnded = false;
    emit generationCycling(this, equationGenerationCyclingParameters);

}

void AlgorithmController::onInputDataSelected(const QString &inputFilePath, const QVariant &inputDatas)
{
    //qInfo() << "Input data selected";
    logs::Logger::logInfo("Input data selected");
    _inputFileManager.inputDataSelected(inputFilePath, inputDatas);

    const std::vector<datamodel::DataPoint> &points =_inputFileManager.inputDatas();

    updateDistanceToData(_equationsArray, _equationsArraySize, points);

    _fitController.updateInputData(std::list<datamodel::DataPoint>(points.begin(),points.end()));
    // Update Pareto efficiency level

    ParetoEfficiencyCalculator::identifyParetoFrontier(_equationsArray, _equationsArraySize);
    emit equationsDataChanged(_equationsArray, _equationsArraySize);
}

void AlgorithmController::onInputDataChanged(const QList<datamodel::DataPoint> inputDatas){
    _fitController.updateInputData(std::list<datamodel::DataPoint>(inputDatas.begin(),inputDatas.end()));
}

void AlgorithmController::removeDuplicates(datamodel::Equations &equations, datamodel::Equations &newEquations) {
    // Warning : this function assumes there are no duplicates in the vector
    // newEquations itself
    unsigned int count = 0;
    for (auto it = equations.begin(); it != equations.end();) {
        std::string equationStructureId = (*it).structureIdHash();

        auto duplicate = std::find_if(newEquations.begin(),
                                      newEquations.end(),
                                      [&](const datamodel::EquationTree &equation) {
            return equation.structureIdHash() == equationStructureId;
        });

        if (duplicate != newEquations.end()) {
            if ((*it).distance() <= (*duplicate).distance()) {
                duplicate = newEquations.erase(duplicate);
                ++it;
            } else {
                it = equations.erase(it);
            }
            ++count;
        } else {
            ++it;
        }
    }
}


/*Remove cases of division by 0 line after line*/
/* Simplification of equations */
void AlgorithmController::removeDivisionByZero(datamodel::EquationTree* equationsArray, const uint equationsArraySize, int nbVariables)
{
    std::vector<uint> indexToDelete;
    for(uint i = 0; i < equationsArraySize; i++){
        try{
        equationeditors::equationTreeItemSimplifier(equationsArray[i].rootRef(), nbVariables);
        }catch (const char* msg)/*catch(std::runtime_error &e)*/{
            indexToDelete.push_back(i);
        }
    }
    if (indexToDelete.size()> 0){
        datamodel::EquationTree* equationsValides = new datamodel::EquationTree[equationsArraySize-indexToDelete.size()];
        uint j=0; // equationsArray index
        uint equationCleanSize=0;
        for(uint i = 0; i < indexToDelete.size(); i++){
            if (j<indexToDelete[i]){
                std::copy(equationsArray+j,equationsArray+indexToDelete[i],equationsValides+equationCleanSize);
                equationCleanSize+=indexToDelete[i]-j;
                j=indexToDelete[i]+1;
            }
        }
        if (j<equationsArraySize-1){
            std::copy(equationsArray+j,equationsArray+equationsArraySize-1,equationsValides+equationCleanSize);
            equationCleanSize+=equationsArraySize-1-j;
        }
    }
}

int AlgorithmController::removeDuplicates(datamodel::EquationTree* equationsToFilter, uint equationsToFilterSize){
    std::sort(equationsToFilter, equationsToFilter + equationsToFilterSize, [&](const datamodel::EquationTree &equation1, const datamodel::EquationTree &equation2) {
        return (equation1.structureIdHash() < equation2.structureIdHash()) ||
                ((equation1.structureIdHash() == equation2.structureIdHash()) &&
                 utils::lessThan(equation1.distance(), equation2.distance()));
    });
    // Suppression des objets ayant le même attribut consécutif
    int taille = 0;
    for (uint i = 1; i < equationsToFilterSize; i++) {
        if (equationsToFilter[i].structureIdHash() != equationsToFilter[taille].structureIdHash()) {
            taille++;
            equationsToFilter[taille] = equationsToFilter[i];
        }
    }
    taille++;
    return taille;
}

/*double calculateCorrelation(std::vector<double> values, double values_mean, double values_deviation, std::vector<double> results) {
    double results_mean = sum_array(results) / results.size();
    double results_deviation = sqrt(sumOfSquaredDistance(results, results_mean) / (results.size()));
    double var_sum = 0.0;
    for (uint i = 0; i < values.size() && i < results.size(); i++) {
        var_sum += (values[i] - values_mean) * (results[i] - results_mean);
    }
    double correlation = var_sum / (values.size());
    double coeff = correlation / (results_deviation * values_deviation);
    std::cout << "coeff : " << coeff << std::endl;
}*/

datamodel::EquationTreeItem varianceBasedEditing(datamodel::EquationTreeItem equationTreeItem, int nbVariables, const std::vector<datamodel::DataPoint> inputDatas, bool *simplified) {
    std::vector<datamodel::EquationTreeItem> empty = {};
    if (equationTreeItem.currentNode()->nbArguments()) {
        double values[inputDatas.size()];
        double sum = 0.0;
        uint i;
        //on store les resultats et on calcul la somme
        for (i = 0; i < inputDatas.size(); i+=1) { 
            const auto &dataPoint = inputDatas[i];
            double equationValue = equationTreeItem.value(dataPoint.parameterList());
            if (!std::isnan(equationValue) && std::isfinite(equationValue)) {
                values[i] = equationValue;
                sum += equationValue;
            }
        }
        //calcul de la moyenne
        double mean = sum / i;
        double sumOfSquaredDistance = 0.0;
        //somme du carré de la distance
        for (double value : values) {
            sumOfSquaredDistance += pow(value - mean, 2);
        }
        double variance = sqrt(sumOfSquaredDistance / i);
        //normalisation de la variance
        if (abs(variance / mean) < VARIANCE_THRESHOLD) {
            equationTreeItem.setCurrentNode(std::shared_ptr<datamodel::EquationNode>(new datamodel::ConstantNode(mean)));
            equationTreeItem.setArguments(empty);
            *simplified = true;
        }
        equationTreeItem.setVariance(variance);
    }
    std::vector<datamodel::EquationTreeItem> arguments = equationTreeItem.arguments();
    for (uint i = 0; i < arguments.size(); i++) {
        if (arguments[i].currentNode()->nbArguments())
            arguments[i] = varianceBasedEditing(arguments[i], nbVariables, inputDatas, simplified);
    }
    equationTreeItem.setArguments(arguments);
    return equationTreeItem;
}

datamodel::EquationTreeItem coeffBasedEditing(datamodel::EquationTreeItem equationTreeItem, int nbVariables, const std::vector<datamodel::DataPoint> inputDatas, bool *simplified) {
    bool toSimplify = false;
    double coefficient = COEFF_THRESHOLD;
    double ratio = 0.0;
    if ((equationTreeItem.currentNode()->type() == datamodel::EquationNode::NodeType::Addition || equationTreeItem.currentNode()->type() == datamodel::EquationNode::NodeType::Soustraction) && equationTreeItem.currentNode()->nbArguments() == 2) {
        toSimplify = true;
        std::vector<datamodel::EquationTreeItem> arguments = equationTreeItem.arguments();
        //on test pour chaque valeur si le ratio d'une operande vs l'autre est plus élevé que 1/coefficient ou plus petit que coefficient
        for (uint i = 0; i < inputDatas.size(); i++) { 
            const auto &dataPoint = inputDatas[i];
            ratio = abs(equationTreeItem.arguments()[0].value(dataPoint.parameterList())) / abs(equationTreeItem.arguments()[1].value(dataPoint.parameterList()));
            if ((ratio < 1 && ratio > coefficient) || (ratio > 1 && ratio < 1 / coefficient)) {
                //si ce n'est pas le cas on ne simplifie pas
                toSimplify = false;
                break;
            }
        }
    }
    if (toSimplify) {
        //si on supprime la première operande et que la node parent est une soustraction on passe la seconde operande en negatif
        if (ratio > coefficient)
            equationTreeItem = equationTreeItem.arguments()[0];
        else if (equationTreeItem.currentNode()->type() == datamodel::EquationNode::NodeType::Soustraction) {
            equationTreeItem = equationTreeItem.arguments()[1];
            if (equationTreeItem.currentNode()->type() == datamodel::EquationNode::NodeType::Constant) {
                auto *value_node = dynamic_cast<datamodel::ConstantNode *>(equationTreeItem.currentNode().get());
                value_node->setValue(equationTreeItem.value(inputDatas[0].parameterList()) * -1);
            }
            else {
                std::vector<datamodel::EquationTreeItem> arguments;
                arguments.push_back(equationTreeItem);
                datamodel::EquationTreeItem temp_node{};
                temp_node.setCurrentNode(std::shared_ptr<datamodel::EquationNode>(new datamodel::NegativeNode));
                temp_node.setArguments(arguments);
                equationTreeItem = temp_node;
            }
        }
        else
            equationTreeItem = equationTreeItem.arguments()[1];
        *simplified = true;
    }
    std::vector<datamodel::EquationTreeItem> arguments = equationTreeItem.arguments();
    for (uint i = 0; i < arguments.size(); i++) {
        if (arguments[i].currentNode()->nbArguments())
            arguments[i] = coeffBasedEditing(arguments[i], nbVariables, inputDatas, simplified);
    }
    equationTreeItem.setArguments(arguments);
    return equationTreeItem;
}

void WorkerGenerationCycling::statBasedEquationEdition(datamodel::EquationTree* equationsArray,
                                                    const uint equationsArraySize,
                                                    const std::vector<datamodel::DataPoint> &points,
                                                    std::unordered_set<std::string> &hashTable) {
    int thread_count = std::thread::hardware_concurrency();
    if(thread_count < 0){
        thread_count = 1;
    }
    auto work_per_thread = equationsArraySize / thread_count;

    uint randomIdx[equationsArraySize];
    for(uint i = 0; i < equationsArraySize; i++){
        randomIdx[i] = i;
    }
    std::random_device rd;
    std::mt19937 g(rd());
    std::shuffle(randomIdx, randomIdx+equationsArraySize, g);
    auto worker = [&points, &equationsArray, &randomIdx, &hashTable](unsigned int begin, unsigned int end) {
        for (; begin < end ; ++begin) {
            uint equationIdx = randomIdx[begin];
            bool simplified = false;
            bool toReset = false;
            if (equationsArray[equationIdx].is_stat_simple())
                continue;
            int count = 0;
            while (equationsArray[equationIdx].is_stat_simple() == false) {
                equationsArray[equationIdx].rootRef() = coeffBasedEditing(equationsArray[equationIdx].root(), equationsArray[equationIdx].numberOfVariables(), points, &simplified);
                equationsArray[equationIdx].rootRef() = varianceBasedEditing(equationsArray[equationIdx].root(), equationsArray[equationIdx].numberOfVariables(), points, &simplified);
                // si l'arbre a été simplifié on boucle jusqu'a qu'il ne soit plus simplifiable
                if (simplified) {
                    equationsArray[equationIdx].is_stat_simple() = false;
                    toReset = true;
                    simplified = false;
                }
                else
                    equationsArray[equationIdx].is_stat_simple() = true;
                count++;
            }
            bool isFinite = false;
            if (toReset) {
                double distanceR2 = DistanceToDataCalculator::calculateRSquared(equationsArray[equationIdx].root(), points);
                isFinite = std::isfinite(distanceR2);
                if (!isFinite || !(equationsArray[equationIdx].root().isValid(std::vector<double>(equationsArray[equationIdx].numberOfVariables())))) {
                    equationsArray[equationIdx].root().setCurrentNode(nullptr);
                    continue;
                }
                std::string old_struct_hash = equationsArray[equationIdx].structureIdHash();
                equationsArray[equationIdx].setTotalNode(algorithmcontroller::TotalNodeCalculator::calculateTotalNode(equationsArray[equationIdx].root()));
                std::string structureHash = algorithmcontroller::EquationTransformation::computeHash(equationsArray[equationIdx].root());
                equationsArray[equationIdx].setStructureIdHash(structureHash);
                hashTable.erase(old_struct_hash);
                hashTable.insert(structureHash);
                equationsArray[equationIdx].setDistanceR2(distanceR2);
                equationsArray[equationIdx].setDistanceMSE(DistanceToDataCalculator::calculateCumulatedDistanceToData(
                                                        equationsArray[equationIdx].root(),
                                                        points));
                equationsArray[equationIdx].setComplexity(equationsArray[equationIdx].totalNode());
            }
        }
    };

    std::vector<std::thread> workers;
    workers.reserve(thread_count);
    for (auto i = 0u ; i < (uint)thread_count - 1 ; ++i) {
        workers.emplace_back(worker, i * work_per_thread, (i + 1) * work_per_thread);
    }
    workers.emplace_back(worker, (thread_count - 1) * work_per_thread, equationsArraySize);

    for (auto& thread : workers) {
        thread.join();
    }
}

void WorkerGenerationCycling::stopWorking() {
    _working = false;
    _cpt = 0;
}

void WorkerGenerationCycling::resetGenForGenProcessTime() {
    _previousCpt = 0;
}

/*

void WorkerGenerationCycling::fitAllEquations(EquationFit* fitController,
                                              const QList<datamodel::DataPoint> &points,
                                              datamodel::EquationTree* equationsArray,
                                              const uint equationsArraySize) {
    QElapsedTimer timeri;
    timeri.start();
    if (fitController->equationFitParameters().duration() == 0) {
        return;
    }

//    // if tuning the +2 away, ensure hardware_concurrency does not return 0. thread_count >= 2 is assumed later on this code
    int thread_count = std::thread::hardware_concurrency()-2;
    if(thread_count < 0){
        thread_count = 1;
    }
    thread_count = 1;
    qDebug("Equations array size : %d", equationsArraySize);
    auto work_per_thread = equationsArraySize / thread_count;

    uint randomIdx[equationsArraySize];
    for(uint i = 0; i < equationsArraySize; i++){
        randomIdx[i] = i;
    }
    std::random_device rd;
    std::mt19937 g(rd());

    std::shuffle(randomIdx, randomIdx+equationsArraySize, g);
    auto worker = [&fitController, &points, &equationsArray, &randomIdx](unsigned int begin, unsigned int end) {
    auto worker = [&fitController, &points, &equationsArray](unsigned int begin, unsigned int end) {
        QElapsedTimer  timeri1 ;
        timeri1.start();
        for (; begin < end ; ++begin) {
            uint equationIdx = randomIdx[begin];

            if (fitController->fitEquation(equationsArray[equationIdx])) {
                equationsArray[equationIdx].setDistance(
                            DistanceToDataCalculator::calculateCumulatedDistanceToData(
                                equationsArray[equationIdx].root(),
                                points
                                ));
            }
        }
        qInfo()<<"Timer thread " <<":  "<<timeri1.elapsed();
    };

    std::vector<std::thread> workers;
    workers.reserve(thread_count);
    for (auto i = 0u ; i < thread_count - 1 ; ++i) {
        workers.emplace_back(worker, i * work_per_thread, (i + 1) * work_per_thread);
    }
    workers.emplace_back(worker, (thread_count - 1) * work_per_thread, equationsArraySize);

    qInfo()<<" Part 1"<<timeri.elapsed();
    timeri.start();
    for (auto& thread : workers) {
        thread.join();
    }
    qInfo()<<" Part 5"<<timeri.elapsed();
}

*/


void WorkerGenerationCycling::simplifyAllEquations(const std::vector<datamodel::DataPoint> &points,
                                                    datamodel::EquationTree* &equationsArray,
                                                    const uint equationsArraySize,
                                                    std::unordered_set<std::string> &hashTable) {
        
        // Amelioration possible, lire le nom des variables dans l'input et les déclarer ici a la place de xj
        uint nbVariables = equationsArray[0].numberOfVariables();
        Ev3::ExpressionParser parser;
        for (uint j = 0; j < nbVariables; j++) {
            parser.SetVariableID("x" + std::to_string(j), j);
        }
        for (uint equationIdx = 0; equationIdx < equationsArraySize; equationIdx++) {
            if (equationsArray[equationIdx].is_simple() == true)
                continue;
            int nerr = 0;
            Ev3::Expression expr;
            try {
                 expr = parser.Parse(equationeditors::equationToString(equationsArray[equationIdx].root(), nbVariables).c_str(), nerr);
            } catch (const Ev3::ErrDivideByZero& e) {
                continue;
            }
            try {
                bool simp = Ev3::Simplify(&expr);
                if (!simp)
                    continue;
            } catch (const Ev3::ErrNotPermitted& e) {
                continue;
            }
            equationsArray[equationIdx].rootRef() = equationToTreeParser::equationTreeFromString(expr->ToString());
            equationsArray[equationIdx].setDistanceR2(DistanceToDataCalculator::calculateRSquared(
                                                            equationsArray[equationIdx].root(),
                                                            points));

            equationsArray[equationIdx].setDistanceMSE(DistanceToDataCalculator::calculateCumulatedDistanceToData(
                                                            equationsArray[equationIdx].root(),
                                                            points));
            equationsArray[equationIdx].setTotalNode(TotalNodeCalculator::calculateTotalNode(equationsArray[equationIdx].root()));
            equationsArray[equationIdx].setComplexity(equationsArray[equationIdx].totalNode());
            std::string old_struct_hash = equationsArray[equationIdx].structureIdHash();
            std::string structureHash = algorithmcontroller::EquationTransformation::computeHash(equationsArray[equationIdx].root());
            equationsArray[equationIdx].setStructureIdHash(structureHash);
            hashTable.erase(old_struct_hash);
            hashTable.insert(structureHash);
            equationsArray[equationIdx].is_simple() = true;
        }
}

void WorkerGenerationCycling::fitAllEquations(EquationFit* fitController,
                                              const std::vector<datamodel::DataPoint> &points,
                                              datamodel::EquationTree* equationsArray,
                                              const uint equationsArraySize,
                                              std::unordered_set<std::string> &hashTable) {
    if (fitController->equationFitParameters().duration() == 0) {
        return;
    }

//    // if tuning the +2 away, ensure hardware_concurrency does not return 0. thread_count >= 2 is assumed later on this code
    int thread_count = std::thread::hardware_concurrency();
    if(thread_count < 0){
        thread_count = 1;
    }
    //qDebug("Equations array size : %d", equationsArraySize);
    auto work_per_thread = equationsArraySize / thread_count;

    uint randomIdx[equationsArraySize];
    for(uint i = 0; i < equationsArraySize; i++){
        randomIdx[i] = i;
    }
    std::random_device rd;
    std::mt19937 g(rd());
    std::shuffle(randomIdx, randomIdx+equationsArraySize, g);
    auto worker = [&fitController, &points, &equationsArray, &randomIdx, &hashTable](unsigned int begin, unsigned int end) {
        for (; begin < end ; ++begin) {
            uint equationIdx = randomIdx[begin];
            //code de Alexis Dandres commenté : tester si c'est pas plus long de calculer les constantes que de faire passer les equations deja fit
            /*if (equationsArray[equationIdx].was_fitted())
                continue;
            double bef = equationsArray[equationIdx].root().totalConstantValue();*/
            if (fitController->fitEquation(equationsArray[equationIdx])) {
                /*double aft = equationsArray[equationIdx].root().totalConstantValue();
                if (bef == aft)
                    equationsArray[equationIdx].setFitted(true);*/
                if (equationsArray[equationIdx].root().currentNode()->type() == datamodel::EquationNode::NodeType::Constant ||
                    equationsArray[equationIdx].root().currentNode()->type() == datamodel::EquationNode::NodeType::Variable) {
                    equationsArray[equationIdx].root().setArguments({});
                }
                equationsArray[equationIdx].setDistanceR2(DistanceToDataCalculator::calculateRSquared(
                                                            equationsArray[equationIdx].root(),
                                                            points));

                equationsArray[equationIdx].setDistanceMSE(DistanceToDataCalculator::calculateCumulatedDistanceToData(
                                                            equationsArray[equationIdx].root(),
                                                            points));
                equationsArray[equationIdx].setTotalNode(TotalNodeCalculator::calculateTotalNode(equationsArray[equationIdx].root()));
                equationsArray[equationIdx].setComplexity(equationsArray[equationIdx].totalNode());
                std::string old_struct_hash = equationsArray[equationIdx].structureIdHash();
                std::string structureHash = algorithmcontroller::EquationTransformation::computeHash(equationsArray[equationIdx].root());
                equationsArray[equationIdx].setStructureIdHash(structureHash);
                hashTable.erase(old_struct_hash);
                hashTable.insert(structureHash);
            }
        }
    };

    std::vector<std::thread> workers;
    workers.reserve(thread_count);
    for (auto i = 0u ; i < (uint)thread_count - 1 ; ++i) {
        workers.emplace_back(worker, i * work_per_thread, (i + 1) * work_per_thread);
    }
    workers.emplace_back(worker, (thread_count - 1) * work_per_thread, equationsArraySize);

    for (auto& thread : workers) {
        thread.join();
    }
}

void AlgorithmController::onStopEquationsGeneration() {
    emit stopGenerationThread();
}

void AlgorithmController::reallocEquationTree(uint newSize){
    if(_equationsArraySize != newSize){
        if(_equationsArray != nullptr){
            delete [] _equationsArray;
        }
        _equationsArray = new datamodel::EquationTree[newSize];
        if(_equationsArray == nullptr){
            // to test ???
        }
        _equationsArraySize = newSize;
    }
}


bool AlgorithmController::getProcessBenchmark(){ return processBenchmark;}

bool AlgorithmController::getDisplaySignalsBench(){ return displaySignalsBench;}

bool AlgorithmController::getDisplayFitnessBench(){ return displayFitnessBench;}

bool AlgorithmController::getPreviousDisplaySignalsBench(){ return previousDisplaySignalsBench;}

bool AlgorithmController::getPreviousDisplayFitnessBench(){ return previousDisplayFitnessBench;}

datamodel::EquationTree AlgorithmController::generateSingleEquation(const equationeditors::EquationGenerator& equationGenerator,
                                                                    const equationparameters::EquationDistanceParameters& equationDistanceParameters){
    QCoreApplication::processEvents();
    datamodel::EquationTreeItem equationGenerated;
    std::string structureHash;
    double distanceR2;
    double distanceMSE;
    bool validEquation = false;
    do{
        equationGenerated = equationGenerator.generateEquation();
        structureHash = EquationTransformation::computeHash(equationGenerated);
        bool notFound = _equationsStructuresHash.find(structureHash) == _equationsStructuresHash.end();

        bool isFinite = false;
        if(notFound){
            switch (equationDistanceParameters.getEquationDistance()) {
                case equationparameters::EquationDistanceParameters::R2:
                    distanceR2 = DistanceToDataCalculator::calculateRSquared(
                                equationGenerated, _inputFileManager.inputDatas());
                    isFinite = std::isfinite(distanceR2);
                    if(isFinite){ //Compute all other distances
                        distanceMSE = DistanceToDataCalculator::calculateCumulatedDistanceToData(
                                    equationGenerated, _inputFileManager.inputDatas());
                    }
                    break;
                case equationparameters::EquationDistanceParameters::MSE:
                    distanceMSE = DistanceToDataCalculator::calculateCumulatedDistanceToData(
                                equationGenerated, _inputFileManager.inputDatas());
                    isFinite = std::isfinite(distanceMSE);
                    if(isFinite){ //Compute all other distances
                        distanceR2 = DistanceToDataCalculator::calculateRSquared(
                                    equationGenerated, _inputFileManager.inputDatas());
                    }
                    break;
                default: //Default is R2
                    distanceR2 = DistanceToDataCalculator::calculateRSquared(
                                equationGenerated, _inputFileManager.inputDatas());
                    isFinite = std::isfinite(distanceR2);
                    if(isFinite){ //Compute all other distances
                        distanceMSE = DistanceToDataCalculator::calculateCumulatedDistanceToData(
                                    equationGenerated, _inputFileManager.inputDatas());
                    }
                    break;
            }
        }
        validEquation = notFound && isFinite && (equationGenerated.isValid(std::vector<double>(equationGenerator.numberOfVariables())));
    } while (!validEquation);

    _equationsStructuresHash.insert(structureHash);

    datamodel::EquationTree equation(equationGenerated, distanceR2, distanceMSE, structureHash);
    equation.setTotalNode(TotalNodeCalculator::calculateTotalNode(equation.root()));
    equation.setComplexity(equation.totalNode());
    equation.setNumberOfVariables(equationGenerator.numberOfVariables());
    equation.setDistanceToUse(equationDistanceParameters.getEquationDistance());
    return equation;
}

equationparameters::EquationGenerationCyclingParameters AlgorithmController::getCurrentGenerationCyclingParameters() const
{
    return _currentGenerationCyclingParameters;
}

equationparameters::EquationGenerationParameters AlgorithmController::getGenerationParameterCache() const
{
    return _generationParameterCache;
}



}  // namespace algorithmcontroller
