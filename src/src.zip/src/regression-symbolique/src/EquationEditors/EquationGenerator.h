
#pragma once

#include <memory>

#include "DataModel/EquationNode.h"

#include "DataModel/VariableNode.h"

namespace datamodel
{
class EquationTreeItem;
}

namespace equationeditors
{
/**
 * @brief The EquationGenerator class ??
 */
class EquationGenerator
{
   public:
    /*!
     * @brief Get the max depth of the equation to generate
     * @return the max depth of the equation
     */
    int maxDepth() const;

    /*!
     * @brief Set the max depth of the equation to generate
     * @param max_depth the max depth of the equation to generate
     */
    void setMaxDepth(int max_depth);

    /*!
     * @brief Get the min range of the constantes generated
     * @return the min range of the constantes generated
     */
    double minNumber() const;

    /*!
     * @brief Set the min range of the constantes generated
     * @param min_number the min range of the constantes generated
     */
    void setMinNumber(double min_number);

    /*!
     * @brief Get the max range of the constant generated
     * @return the max range of the constant generated
     */
    double maxNumber() const;

    /*!
     * @brief Set the max range of the constant generated
     * @param max_number the max range of the constant generated
     */
    void setMaxNumber(double max_number);

    /*!
     * @brief Get the number of different variables on the equation
     * @return the number of different variables on the equation
     */
    uint numberOfVariables() const;

    /*!
     * @brief Set the number of different variables on the equation
     * @param nbVar the number of different variables on the equation
     */
    void setNumberOfVariables(uint nbVar);

    /*!
     * @brief Generate an equation randomly
     * @return the equation generated
     */
    datamodel::EquationTreeItem generateEquation() const;

    datamodel::EquationTreeItem generateEquationTreeItem(int depth) const;

    datamodel::EquationTreeItem generateEquationPower() const;

    std::shared_ptr<datamodel::EquationNode> generateEquationNode(int depth) const;

    /**
     * @brief generateEquationNode Generate a random node from selectedNodesTypes
     * @param selectedNodesTypes The list of possible nodes to generate
     * @return A random node taken from selectedNodesTypes
     */
    std::shared_ptr<datamodel::EquationNode> generateEquationNode(const QList<datamodel::EquationNode::NodeType> &selectedNodesTypes, const unsigned short int &nbArguments = 2) const;

    /**
     * @brief generateEquationNode Generate an equation node from type nodetype and with nbArguments if the node nodetype is elligible
     * @param nodetype The type of the node to generate
     * @param nbArguments The number of arguments the node will have if the node is compatible otherwise it will be ignored
     * @return The genrated node from type nodetype and number of arguments nbArguments
     */
    std::shared_ptr<datamodel::EquationNode> generateEquationNode(
        datamodel::EquationNode::NodeType nodetype,
        const unsigned short int &nbArguments = 2) const;

    std::shared_ptr<datamodel::VariableNode> generateRandomVariableNode() const;

    const QList<datamodel::EquationNode::NodeType> &selectedNodesTypes() const;
    // Use a set to ensure we have one occurance only of each node type
    void setSelectedNodesTypes(const QSet<datamodel::EquationNode::NodeType> &selectedNodesTypes);

private:
    double _generateRandomNumber() const;

    int _maxDepth = 0;
    double _minNumber = -1000;
    double _maxNumber = +1000;
    uint _nbVar = 0;
    QList<datamodel::EquationNode::NodeType> _selectedNodesTypes{datamodel::EquationNode::Constant,
                                                                 datamodel::EquationNode::Variable};
};
}  // namespace equationeditors
