#include "EquationCrossbreeder.h"

#include <EquationEditors/RandomGenerator.h>

//t1 #include <QDebug>
#include <iostream>//t1
#include "EquationEditors/EquationPrinter.h"
#include "Logger_v2/Logger.h"
#include "DataModel/EquationNode.h"
#include "randomNodeSelector.h"

namespace equationeditors {
equationparameters::EquationCrossbreedingParameters::CrossbreedingMethod EquationCrossbreeder::crossbreedingMethod() const
{
    return _crossbreedingMethod;
}

void EquationCrossbreeder::setCrossbreedingMethod(const equationparameters::EquationCrossbreedingParameters::CrossbreedingMethod &crossbreedingMethod)
{
    _crossbreedingMethod = crossbreedingMethod;
}

datamodel::EquationTreeItem EquationCrossbreeder::crossbreeds(
    const datamodel::EquationTreeItem &firstParent,
    const datamodel::EquationTreeItem &secondParent) const
{
    switch (_crossbreedingMethod) {
    case equationparameters::EquationCrossbreedingParameters::RandomTreeSubstitution:
        return randomTreeSubstitutionCrossbreeding(firstParent, secondParent);
    case equationparameters::EquationCrossbreedingParameters::ConstantDepthNodeSubstitution:
        return constantDepthRandomNodeCrossbreeding(firstParent, secondParent);
    case equationparameters::EquationCrossbreedingParameters::ConstantDepthTreeSubstitution:
        return constantDepthTreeSubstitution(firstParent, secondParent);
    }

    //qWarning() << "Unknown crossbreeding method";
    logs::Logger::logWarning("Unknown crossbreeding method", {logs::LogTags::crossbreed, logs::LogTags::equationEditor});
    return datamodel::EquationTreeItem();
}

datamodel::EquationTreeItem EquationCrossbreeder::randomTreeSubstitutionCrossbreeding(
    const datamodel::EquationTreeItem &firstParent, const datamodel::EquationTreeItem &secondParent)
{
    // Copy the first parent
    datamodel::EquationTreeItem offspring(firstParent);

    // Select a random node in the first parent
    datamodel::EquationTreeItem &selectedTreeToSubstitute = equationeditors::selectRandomNode(
        offspring);

    const datamodel::EquationTreeItem &selectedTreeForSubstitution
        = equationeditors::selectRandomNode(secondParent);

    selectedTreeToSubstitute = selectedTreeForSubstitution;

    return offspring;
}

QPair<datamodel::EquationTreeItem,datamodel::EquationTreeItem> EquationCrossbreeder::randomTreeSubstitutionCrossbreeding_twoChildren(
    const datamodel::EquationTreeItem &firstParent, const datamodel::EquationTreeItem &secondParent)
{
    //Instancing return type
    QPair<datamodel::EquationTreeItem,datamodel::EquationTreeItem> twoChildren;

    // Copy the first parent
    datamodel::EquationTreeItem offspring_1(firstParent);

    // Copy the second parent
    datamodel::EquationTreeItem offspring_2(secondParent);

    // Select a random node in the first parent
    datamodel::EquationTreeItem &selectedTreeToSubstitute_1 = equationeditors::selectRandomNode(
        offspring_1);
    //Select a random node in the second parent
    datamodel::EquationTreeItem &selectedTreeToSubstitute_2 = equationeditors::selectRandomNode(
        offspring_2);

    const datamodel::EquationTreeItem selectedTreeForSubstitution_1
        = selectedTreeToSubstitute_2;

    const datamodel::EquationTreeItem selectedTreeForSubstitution_2
        = selectedTreeToSubstitute_1;

    // Substituting the two full nodes of the two parents into the two new children

    selectedTreeToSubstitute_1 = selectedTreeForSubstitution_1;
    selectedTreeToSubstitute_2 = selectedTreeForSubstitution_2;

    //building the returning QPair

    twoChildren.first = offspring_1;
    twoChildren.second = offspring_2 ;

    return twoChildren;
}

std::pair<datamodel::EquationTreeItem,datamodel::EquationTreeItem> EquationCrossbreeder::randomTreeSubstitutionCrossbreeding_twoChildrenParallel(
    const datamodel::EquationTreeItem &firstParent, const datamodel::EquationTreeItem &secondParent)
{
    //Instancing return type
    std::pair<datamodel::EquationTreeItem,datamodel::EquationTreeItem> twoChildren;

    // Copy the first parent
    datamodel::EquationTreeItem offspring_1(firstParent);

    // Copy the second parent
    datamodel::EquationTreeItem offspring_2(secondParent);

    // Select a random node in the first parent
    datamodel::EquationTreeItem &selectedTreeToSubstitute_1 = equationeditors::selectRandomNode(
        offspring_1);
    //Select a random node in the second parent
    datamodel::EquationTreeItem &selectedTreeToSubstitute_2 = equationeditors::selectRandomNode(
        offspring_2);



    const datamodel::EquationTreeItem selectedTreeForSubstitution_1
        = selectedTreeToSubstitute_2;

    const datamodel::EquationTreeItem selectedTreeForSubstitution_2
        = selectedTreeToSubstitute_1;

    // Substituting the two full nodes of the two parents into the two new children

    selectedTreeToSubstitute_1 = selectedTreeForSubstitution_1;
    selectedTreeToSubstitute_2 = selectedTreeForSubstitution_2;

    //building the returning QPair

    twoChildren.first = offspring_1;
    twoChildren.second = offspring_2 ;

    return twoChildren;
}


datamodel::EquationTreeItem EquationCrossbreeder::constantDepthRandomNodeCrossbreeding(
    const datamodel::EquationTreeItem &firstParent, const datamodel::EquationTreeItem &secondParent)
{
    datamodel::EquationTreeItem offspring;
    int parentIndex = RandomGenerator().getRngGenerator().bounded(2);

    if (parentIndex == 0) {
        offspring.setCurrentNode(firstParent.currentNode());

        completeArgumentsForDepth(offspring, firstParent, secondParent, 1);

    } else {
        offspring.setCurrentNode(secondParent.currentNode());

        completeArgumentsForDepth(offspring, firstParent, secondParent, 1);
    }

    return offspring;
}

datamodel::EquationTreeItem EquationCrossbreeder::constantDepthTreeSubstitution(
    const datamodel::EquationTreeItem &firstParent, const datamodel::EquationTreeItem &secondParent)
{
    // Copy the first parent
    datamodel::EquationTreeItem offspring(firstParent);

    // Select a random node in the first parent
    datamodel::EquationTreeItem &selectedTreeToSubstitute = equationeditors::selectRandomNode(
        offspring);

    int currentDepth = firstParent.depth() - selectedTreeToSubstitute.depth();

    selectedTreeToSubstitute = selectRandomArgumentAtDepth(secondParent, currentDepth);

    return offspring;
}

void EquationCrossbreeder::completeArgumentsForDepth(datamodel::EquationTreeItem &nodeToComplete,
                                                     const datamodel::EquationTreeItem &firstParent,
                                                     const datamodel::EquationTreeItem &secondParent,
                                                     int depth)
{
    if (nodeToComplete.currentNode()) {
        QList<datamodel::EquationTreeItem> arguments;
        for (int i = 0; i < nodeToComplete.currentNode()->nbArguments(); ++i) {
            int parentIndex = RandomGenerator().getRngGenerator().bounded(2);

            datamodel::EquationTreeItem argument;

            if (parentIndex == 0) {
                datamodel::EquationTreeItem selectedNode
                    = equationeditors::selectRandomArgumentAtDepth(firstParent, depth);
                argument.setCurrentNode(selectedNode.currentNode());
            } else {
                datamodel::EquationTreeItem selectedNode
                    = equationeditors::selectRandomArgumentAtDepth(secondParent, depth);
                argument.setCurrentNode(selectedNode.currentNode());
                completeArgumentsForDepth(argument, firstParent, secondParent, depth + 1);
            }

            completeArgumentsForDepth(argument, firstParent, secondParent, depth + 1);
            arguments.append(argument);


        }

        std::vector<datamodel::EquationTreeItem> vectArguments;
        vectArguments.reserve(arguments.size());
        std::copy(arguments.begin(), arguments.end(), std::back_inserter(vectArguments));

        nodeToComplete.setArguments(vectArguments);
    }
}
} // namespace equationeditors
