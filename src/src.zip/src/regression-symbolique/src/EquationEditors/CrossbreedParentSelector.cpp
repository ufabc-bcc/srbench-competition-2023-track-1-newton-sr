#include "CrossbreedParentSelector.h"

#include <EquationEditors/RandomGenerator.h>
#include "EquationEditors/EquationPrinter.h"

//t1 #include <QMap>

#include "Utils/ComparisonUtils.h"

namespace equationeditors {
CrossbreedParentSelector::CrossbreedParentSelector(
        const datamodel::EquationTree* equationsData,
        uint dataSize,
    equationparameters::EquationCrossbreedingParameters::ParentSelectionStrategy
        parentSelectionStrategy,
    equationparameters::EquationCrossbreedingParameters::ParentSelectionCriteria
        parentSelectionCriteria,
    double crossbreedingRate, int tournamentSize)
    : _equationsData(equationsData),
      _dataSize(dataSize),
      _crossbreedingRate(crossbreedingRate),
      _parentSelectionStrategy(parentSelectionStrategy),
      _parentSelectionCriteria(parentSelectionCriteria),
      _tournamentSize(tournamentSize)
{
}


std::pair<datamodel::EquationTreeItem, datamodel::EquationTreeItem>* CrossbreedParentSelector::parentsSelection(uint numberOfParentsToSelect) {
    uint* selectedParentsIndex;

    // Depending on the parent selection strategy chosen.
    std::pair<datamodel::EquationTreeItem, datamodel::EquationTreeItem>* parentsSelected = new std::pair<datamodel::EquationTreeItem, datamodel::EquationTreeItem>[numberOfParentsToSelect];
    switch (_parentSelectionStrategy) {
    // Select by tournament
    case equationparameters::EquationCrossbreedingParameters::Tournament:
        // Lists of not selected equations.
        // Useful to avoid having the same equation several times in the
        // tournament.
        std::vector<unsigned int> notSelectedEquations;
        // List of selected equations for the tournament.
        std::list<unsigned int> tournamentEquations;

        uint parentsSize = numberOfParentsToSelect * 2;
        selectedParentsIndex = new uint[parentsSize];
        for (uint index = 0; index < parentsSize; ++index)
        {
            notSelectedEquations.clear();
            notSelectedEquations.reserve(_dataSize);

            for (unsigned int k = 0; k < _dataSize; k++) {
                notSelectedEquations.push_back(k);
            }
            tournamentEquations.clear();
            for (int i = 0; i < _tournamentSize; i++) {
                int randomUnselected = RandomGenerator().getRngGenerator().bounded((int)notSelectedEquations.size());
                unsigned int pickedEquationIndex = notSelectedEquations.at(randomUnselected);
                if (tournamentEquations.size() == 0) {
                    // First element for tournament
                    tournamentEquations.push_back(pickedEquationIndex);
                } else if (_compareParentsByCriteria(_equationsData[pickedEquationIndex],
                                                     _equationsData[tournamentEquations.front()])) {
                    // Better than all already present, Go first
                    tournamentEquations.push_front(pickedEquationIndex);
                } else
                {
                    // Not the best, Go last
                    tournamentEquations.push_back(pickedEquationIndex);
                }
                notSelectedEquations.erase(notSelectedEquations.cbegin() + randomUnselected);
            }
            selectedParentsIndex[index] = tournamentEquations.front();
        }

        for (uint i = 0; i < numberOfParentsToSelect; i++) {
            parentsSelected[i] = {_equationsData[selectedParentsIndex[i*2]].root(),
                          _equationsData[selectedParentsIndex[i*2+1]].root()};
        }
        delete [] selectedParentsIndex;
        break;
    }
    return parentsSelected;
}

equationparameters::EquationCrossbreedingParameters::ParentSelectionStrategy
CrossbreedParentSelector::getParentSelectionStrategy() const {
  return _parentSelectionStrategy;
}

void CrossbreedParentSelector::setParentSelectionStrategy(
    const equationparameters::EquationCrossbreedingParameters::ParentSelectionStrategy
        &parentSelectionStrategy) {
  _parentSelectionStrategy = parentSelectionStrategy;
}

equationparameters::EquationCrossbreedingParameters::ParentSelectionCriteria
CrossbreedParentSelector::getParentSelectionCriteria() const {
  return _parentSelectionCriteria;
}

void CrossbreedParentSelector::setParentSelectionCriteria(
    const equationparameters::EquationCrossbreedingParameters::ParentSelectionCriteria
        &parentSelectionCriteria) {
  _parentSelectionCriteria = parentSelectionCriteria;
}

double CrossbreedParentSelector::getCrossbreedingRate() const {
  return _crossbreedingRate;
}

void CrossbreedParentSelector::setCrossbreedingRate(
    const double &crossbreedingRate) {
  _crossbreedingRate = crossbreedingRate;
}

int CrossbreedParentSelector::getTournamentSize() const {
  return _tournamentSize;
}

void CrossbreedParentSelector::setTournamentSize(const int &tournamentSize) {
  _tournamentSize = tournamentSize;
}

bool CrossbreedParentSelector::_compareParentsByCriteria(
    const datamodel::EquationTree &parentA,
    const datamodel::EquationTree &parentB) const {
  switch (_parentSelectionCriteria) {
    case equationparameters::EquationCrossbreedingParameters::Distance:
      return parentA.compareDistance(parentB);

    case equationparameters::EquationCrossbreedingParameters::Complexity:
      return parentA.compareParetoComplexity(parentB);

    case equationparameters::EquationCrossbreedingParameters::Pareto:
      return parentA.compareParetoDistance(parentB);

    case equationparameters::EquationCrossbreedingParameters::Age:
      return parentA.compareParetoAge(parentB);

    default:
      return false;
  }
}

}  // namespace equationeditors
