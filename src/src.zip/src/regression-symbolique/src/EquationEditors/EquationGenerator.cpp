#include "EquationGenerator.h"

#include <EquationEditors/EquationSimplifier.h>
#include <EquationEditors/RandomGenerator.h>

#include <DataModel/AbsoluteNode.h>
#include <DataModel/AdditionNode.h>
#include <DataModel/ArctanNode.h>
#include <DataModel/ConstantNode.h>
#include <DataModel/CosinusNode.h>
#include <DataModel/DivisionNode.h>
#include <DataModel/ExponentialNode.h>
#include <DataModel/InverseNode.h>
#include <DataModel/LogarithmeNode.h>
#include <DataModel/MaxNode.h>
#include <DataModel/MinNode.h>
#include <DataModel/MultiplicationNode.h>
#include <DataModel/NegativeNode.h>
#include <DataModel/PowerNode.h>
#include <DataModel/SinusNode.h>
#include <DataModel/SoustractionNode.h>
#include <DataModel/SquareRootNode.h>
#include <DataModel/TanNode.h>

#include <QSet>

namespace equationeditors
{
int EquationGenerator::maxDepth() const { return _maxDepth; }

void EquationGenerator::setMaxDepth(int max_depth) { _maxDepth = max_depth; }

double EquationGenerator::minNumber() const { return _minNumber; }

void EquationGenerator::setMinNumber(double min_number) { _minNumber = min_number; }

double EquationGenerator::maxNumber() const { return _maxNumber; }

void EquationGenerator::setMaxNumber(double max_number) { _maxNumber = max_number; }

uint EquationGenerator::numberOfVariables() const { return _nbVar; }

void EquationGenerator::setNumberOfVariables(uint nbVar) { _nbVar = nbVar; }

datamodel::EquationTreeItem EquationGenerator::generateEquation() const
{
    datamodel::EquationTreeItem equationTreeItem = generateEquationTreeItem(0);

    // Try to simplify generated equation item
    equationeditors::equationTreeItemSimplifier(equationTreeItem, _nbVar);

    return equationTreeItem;
}

datamodel::EquationTreeItem EquationGenerator::generateEquationTreeItem(int depth) const
{
    datamodel::EquationTreeItem equationTreeItem;
    QList<datamodel::EquationTreeItem> arguments;
    std::vector<double> variablesValue(_nbVar,0.);

    bool bSimplify = false;
    do
    {
        auto equationNode = generateEquationNode(depth);
        datamodel::EquationTreeItem newEquationTreeItem(equationNode);
        equationTreeItem = newEquationTreeItem;
        arguments.clear();

        for (int i = 0; i < equationNode->nbArguments(); ++i)
        {
            // Simplification: call generateEquationTreeItem(depth + 1) again until no simplification is possible
            datamodel::EquationTreeItem arg;

            bSimplify = false;
            arg = generateEquationTreeItem(depth + 1);

            // Exemple: "x - x" or "x / x"
            // if equationNode.type == Soustraction or Division, avoid arguments[0].type == arguments[1].type == VariableNode
            if (i == 1 && (equationNode->type() == datamodel::EquationNode::Soustraction ||
                           equationNode->type() == datamodel::EquationNode::Division) &&
                           arg.currentNode()->type() == datamodel::EquationNode::Variable &&
                           arguments.at(0).currentNode()->type() == datamodel::EquationNode::Variable)
            {
                bSimplify = true;
            }

            // Exemple: "Constant [operator] Constant"
            // if arguments[0].type == arguments[1].type == ConstantNode
            if (i == 1 && arg.currentNode()->type() == datamodel::EquationNode::Constant &&
                          arguments.at(0).currentNode()->type() == datamodel::EquationNode::Constant)
            {
                bSimplify = true;
            }

            // Exemple: "f(Constant)"
            // if equationNode->nbArguments() == 1 and arguments[0].type == ConstantNode
            if (equationNode->nbArguments() == 1 && arg.currentNode()->type() == datamodel::EquationNode::Constant)
            {
                bSimplify = true;
            }

            // Exemple: "... / Constant"
            // if equationNode.type == Division and arguments[1].type == ConstantNode
            if (i == 1 && (equationNode->type() == datamodel::EquationNode::Division) &&
                    arg.currentNode()->type() == datamodel::EquationNode::Constant)
            {
                bSimplify = true;
            }

            // Exemple: "1 / Constant"
            // if equationNode.type == Inverse and arguments[0].type == ConstantNode
            if (equationNode->type() == datamodel::EquationNode::Inverse &&
                    arg.currentNode()->type() == datamodel::EquationNode::Constant)
            {
                bSimplify = true;
            }

            // Exemple: "a ^ constant, constant < -20"
            // if equationNode.type == Power and arguments[0].type == ConstantNode
            if (i == 1 && equationNode->type() == datamodel::EquationNode::Power &&
                          arg.currentNode()->type() == datamodel::EquationNode::Constant &&
                          arg.currentNode()->value(variablesValue) < -20)
            {
                bSimplify = true;
            }


            arguments.append(arg);
        }

    } while (bSimplify);

    std::vector<datamodel::EquationTreeItem> vectArguments;
    vectArguments.reserve(arguments.size());
    std::copy(arguments.begin(), arguments.end(), std::back_inserter(vectArguments));

    equationTreeItem.setArguments(vectArguments);
    return equationTreeItem;
}

std::shared_ptr<datamodel::EquationNode> EquationGenerator::generateEquationNode(int depth) const
{
    datamodel::EquationNode::NodeType randomNodeType;

    if (depth < _maxDepth)
    {
        int indexOfRandomNodeType = RandomGenerator().getRngGenerator().bounded(_selectedNodesTypes.size());
        randomNodeType = _selectedNodesTypes.at(indexOfRandomNodeType);
    }
    else
    {
        // Generate a constant or a variable
        // bounded(): generates one random 32-bit quantity in the range between 0 (inclusive) and highest (exclusive).
        randomNodeType = datamodel::EquationNode::NodeType(
            RandomGenerator().getRngGenerator().bounded(datamodel::EquationNode::Variable + 2));
    }

    return generateEquationNode(randomNodeType);
}

std::shared_ptr<datamodel::EquationNode> EquationGenerator::generateEquationNode(const QList<datamodel::EquationNode::NodeType> &selectedNodesTypes, const unsigned short int &nbArguments) const
{
    int indexOfRandomNodeType = RandomGenerator().getRngGenerator().bounded(selectedNodesTypes.size());
    datamodel::EquationNode::NodeType randomNodeType = selectedNodesTypes[indexOfRandomNodeType];
    return generateEquationNode(randomNodeType, nbArguments);
}

std::shared_ptr<datamodel::EquationNode> EquationGenerator::generateEquationNode(
    datamodel::EquationNode::NodeType nodetype, const unsigned short int &nbArguments) const
{
    std::shared_ptr<datamodel::EquationNode> equationNode;
    switch (nodetype)
    {
        case datamodel::EquationNode::Constant:
            return std::shared_ptr<datamodel::EquationNode>(new datamodel::ConstantNode(_generateRandomNumber()));
        case datamodel::EquationNode::Variable:
        {
            return generateRandomVariableNode();
        }
        case datamodel::EquationNode::Addition:
            return std::shared_ptr<datamodel::EquationNode>(new datamodel::AdditionNode(nbArguments));
        case datamodel::EquationNode::Soustraction:
            return std::shared_ptr<datamodel::EquationNode>(new datamodel::SoustractionNode());
        case datamodel::EquationNode::Multiplication:
            return std::shared_ptr<datamodel::EquationNode>(new datamodel::MultiplicationNode(nbArguments));
        case datamodel::EquationNode::Division:
            return std::shared_ptr<datamodel::EquationNode>(new datamodel::DivisionNode());
        case datamodel::EquationNode::Cosinus:
            return std::shared_ptr<datamodel::EquationNode>(new datamodel::CosinusNode());
        case datamodel::EquationNode::Sinus:
            return std::shared_ptr<datamodel::EquationNode>(new datamodel::SinusNode());
        case datamodel::EquationNode::Exponential:
            return std::shared_ptr<datamodel::EquationNode>(new datamodel::ExponentialNode());
        case datamodel::EquationNode::Logarithm:
            return std::shared_ptr<datamodel::EquationNode>(new datamodel::LogarithmeNode());
        case datamodel::EquationNode::Power:
            return std::shared_ptr<datamodel::EquationNode>(new datamodel::PowerNode());
        case datamodel::EquationNode::SquareRoot:
            return std::shared_ptr<datamodel::EquationNode>(new datamodel::SquareRootNode());
        case datamodel::EquationNode::Min:
            return std::shared_ptr<datamodel::EquationNode>(new datamodel::MinNode());
        case datamodel::EquationNode::Max:
            return std::shared_ptr<datamodel::EquationNode>(new datamodel::MaxNode());
        case datamodel::EquationNode::Absolute:
            return std::shared_ptr<datamodel::EquationNode>(new datamodel::AbsoluteNode());
        case datamodel::EquationNode::Inverse:
            return std::shared_ptr<datamodel::EquationNode>(new datamodel::InverseNode());
        case datamodel::EquationNode::Negative:
            return std::shared_ptr<datamodel::EquationNode>(new datamodel::NegativeNode());
        case datamodel::EquationNode::Arctan:
            return std::shared_ptr<datamodel::EquationNode>(new datamodel::ArctanNode());
        case datamodel::EquationNode::Tan:
            return std::shared_ptr<datamodel::EquationNode>(new datamodel::TanNode());
    }

    return std::shared_ptr<datamodel::EquationNode>();
}

std::shared_ptr<datamodel::VariableNode> EquationGenerator::generateRandomVariableNode() const
{
    int randomIdx = RandomGenerator().getRngGenerator().bounded(_nbVar);
    return std::shared_ptr<datamodel::VariableNode>(new datamodel::VariableNode(randomIdx));
}

double EquationGenerator::_generateRandomNumber() const
{
    double randomInZeroOne = RandomGenerator().getRngGenerator().generateDouble();
    // We want a real number between _minNumber and _maxNumber instead of 0 and 1

    double val = randomInZeroOne*(_maxNumber-_minNumber)+_minNumber;
    return val;
}

const QList<datamodel::EquationNode::NodeType> &EquationGenerator::selectedNodesTypes() const
{
    return _selectedNodesTypes;
}

void EquationGenerator::setSelectedNodesTypes(const QSet<datamodel::EquationNode::NodeType> &selectedNodesTypes)
{
    QSet<datamodel::EquationNode::NodeType> treatedSelectedNodesTypes(selectedNodesTypes);
    // Insert constant and variable to always ensure we have this nodes
    treatedSelectedNodesTypes.insert(datamodel::EquationNode::Constant);
    treatedSelectedNodesTypes.insert(datamodel::EquationNode::Variable);

    _selectedNodesTypes = QList<datamodel::EquationNode::NodeType>(treatedSelectedNodesTypes.begin(),
                                                                   treatedSelectedNodesTypes.end());

    // Because the QSet input has a random memory layout ordering, we need to sort the operators
    // in the QList to ensure deterministic behaviour when using a fixed rng seed
    std::sort(_selectedNodesTypes.begin(), _selectedNodesTypes.end(),
              [](const datamodel::EquationNode::NodeType node1, const datamodel::EquationNode::NodeType node2) {
                return (node1 < node2);
              });
}
}  // namespace equationeditors
