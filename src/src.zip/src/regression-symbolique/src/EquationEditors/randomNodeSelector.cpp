#include "randomNodeSelector.h"

#include "RandomGenerator.h"


namespace equationeditors {
datamodel::EquationTreeItem &selectRandomArgument(datamodel::EquationTreeItem &equation) {
    if (equation.arguments().size() > 0) {
        unsigned short int randomArgumentIndex = RandomGenerator().getRngGenerator().bounded((int)equation.arguments().size());

        return equation.arguments()[randomArgumentIndex];
    } else {
        return equation;
    }
}

static void getAllEquationTreeitem(const datamodel::EquationTreeItem& item, QList<const datamodel::EquationTreeItem*>& list)
{
    list.push_back(&item);

    for(auto& argument : item.arguments())
        getAllEquationTreeitem(argument,list);
}

static void getAllEquationTreeitem(datamodel::EquationTreeItem& item, QList<datamodel::EquationTreeItem*>& list)
{
    list.push_back(&item);

    for(auto& argument : item.arguments())
        getAllEquationTreeitem(argument,list);
}

static void getAllEquationTerminalTreeItems(datamodel::EquationTreeItem& item, QList<datamodel::EquationTreeItem*>& list)
{
    bool isTerminalNode = false;
    isTerminalNode = isTerminalNode || item.arguments().empty();
    for (auto& argument : item.arguments())
    {
        isTerminalNode = isTerminalNode || argument.arguments().empty();
    }
    if (isTerminalNode)
    {
        list.push_back(&item);
    }

    for(auto& argument : item.arguments())
        getAllEquationTerminalTreeItems(argument,list);
}

datamodel::EquationTreeItem &selectRandomNode(datamodel::EquationTreeItem &equation)
{
    QList<datamodel::EquationTreeItem*> items;
    getAllEquationTreeitem(equation,items);

    auto index = RandomGenerator().getRngGenerator().bounded(items.size());
    return *items[index];
}

datamodel::EquationTreeItem selectRandomNode(const datamodel::EquationTreeItem &equation)
{
    QList<const datamodel::EquationTreeItem*> items;
    getAllEquationTreeitem(equation,items);

    auto index = RandomGenerator().getRngGenerator().bounded(items.size());
    return *items[index];
}

datamodel::EquationTreeItem &selectRandomTerminalNode(datamodel::EquationTreeItem &equation)
{
    QList<datamodel::EquationTreeItem*> items;
    getAllEquationTerminalTreeItems(equation,items);

    auto index = RandomGenerator().getRngGenerator().bounded(items.size());
    return *items[index];
}

datamodel::EquationTreeItem selectRandomArgument(const datamodel::EquationTreeItem &equation)
{
    
    if (equation.arguments().size() > 0) {
        int randomArgumentIndex = RandomGenerator().getRngGenerator().bounded((int)equation.arguments().size());

        return equation.arguments().at(randomArgumentIndex);
    } else {
        return equation;
    }
}

datamodel::EquationTreeItem selectRandomArgumentAtDepth(const datamodel::EquationTreeItem &equation,
                                                        int depth)
{
    if (depth != 0) {
        datamodel::EquationTreeItem selectedArgument = selectRandomArgument(equation);
        return selectRandomArgumentAtDepth(selectedArgument, depth - 1);
    } else {
        return equation;
    }
}

} // namespace equationeditors
