﻿#include "EquationMutator.h"

#include "EquationGenerator.h"
#include "Logger_v2/Logger.h"
#include "randomNodeSelector.h"
#include "RandomGenerator.h"
#include <vector>

#include "Utils/EnumUtils.h"

#include <DataModel/AdditionNode.h>
#include <DataModel/ArctanNode.h>
#include <DataModel/ConstantNode.h>
#include <DataModel/CosinusNode.h>
#include <DataModel/DivisionNode.h>
#include <DataModel/EquationTreeItem.h>
#include <DataModel/ExponentialNode.h>
#include <DataModel/LogarithmeNode.h>
#include <DataModel/InverseNode.h>
#include <DataModel/MaxNode.h>
#include <DataModel/MinNode.h>
#include <DataModel/MultiplicationNode.h>
#include <DataModel/NegativeNode.h>
#include <DataModel/PowerNode.h>
#include <DataModel/SinusNode.h>
#include <DataModel/SoustractionNode.h>
#include <DataModel/SquareRootNode.h>
#include <DataModel/VariableNode.h>

namespace equationeditors {

EquationMutator::~EquationMutator()
{
    if(_parent) _parent = nullptr;
}

void EquationMutator::mutateEquations(datamodel::EquationTreeItem &equation, const unsigned int &maxNbMutations)
{
    // Two types of mutations (equal probabilities) : constant or non constant branch depth
    unsigned int nbMutations = RandomGenerator().getRngGenerator().bounded(maxNbMutations)+1;

    for(unsigned int i = 0; i < nbMutations; i++){
        bool constantDepthMutation = RandomGenerator().getRngGenerator().bounded(2) < 1;
        datamodel::EquationTreeItem* selectedRandomNode{nullptr};
        if (constantDepthMutation){
            selectedRandomNode = &selectRandomNode(equation);
        } else {
            selectedRandomNode = &selectRandomTerminalNode(equation);
        }

        if(selectedRandomNode){
            //Get parent
            _parent = equation.findParent(selectedRandomNode->currentNode());
            mutateSingle(*selectedRandomNode);
        }
    }
}

void EquationMutator::mutateTerminalNode(datamodel::EquationTreeItem &equation)
{
    using std::placeholders::_1;

    //List of possible mutations
    std::vector<std::function<void(datamodel::EquationTreeItem&)>> possibleMutations{
        std::bind(&EquationMutator::replaceCurrentNodeRandom, this, _1),
        std::bind(&EquationMutator::addRandomNodeBefore, this, _1)
    };

    //We can remove parent node only if the node has a parent
    if(_parent)
        possibleMutations.push_back(std::bind(&EquationMutator::removeNodeBefore, this, _1));

    //We choose a random mutation from the list
    possibleMutations[RandomGenerator().getRngGenerator().bounded(static_cast<int>(possibleMutations.size()))](equation);
}

void EquationMutator::mutateCommutativeNode(datamodel::EquationTreeItem &equation)
{
    using std::placeholders::_1;

    //List of possible mutations
    std::vector<std::function<void(datamodel::EquationTreeItem&)>> possibleMutations{
        std::bind(&EquationMutator::replaceCurrentNodeRandom, this, _1),
        std::bind(&EquationMutator::removeRandomNodeAfter, this, _1),
        std::bind(&EquationMutator::addRandomNodeAfter, this, _1),
        std::bind(&EquationMutator::addRandomNodeBefore, this, _1)
    };

    //We can remove parent node only if the node has a parent
    if(_parent)
        possibleMutations.push_back(std::bind(&EquationMutator::removeNodeBefore, this, _1));

    //We choose a random mutation from the list
    possibleMutations[RandomGenerator().getRngGenerator().bounded(static_cast<int>(possibleMutations.size()))](equation);
}

void EquationMutator::mutateNonCommutativeAndMinMaxNode(datamodel::EquationTreeItem &equation)
{
    using std::placeholders::_1;

    //List of possible mutations
    std::vector<std::function<void(datamodel::EquationTreeItem&)>> possibleMutations{
        std::bind(&EquationMutator::replaceCurrentNodeRandom, this, _1),
        std::bind(&EquationMutator::removeRandomNodeAfter, this, _1),
        std::bind(&EquationMutator::addRandomNodeBefore, this, _1)
    };

    //We can remove parent node only if the node has a parent
    if(_parent)
        possibleMutations.push_back(std::bind(&EquationMutator::removeNodeBefore, this, _1));

    //We choose a random mutation from the list
    possibleMutations[RandomGenerator().getRngGenerator().bounded(static_cast<int>(possibleMutations.size()))](equation);
}

void EquationMutator::mutateFunctionNode(datamodel::EquationTreeItem &equation)
{
    using std::placeholders::_1;

    //List of possible mutations
    std::vector<std::function<void(datamodel::EquationTreeItem&)>> possibleMutations{
        std::bind(&EquationMutator::replaceCurrentNodeRandom, this, _1),
        std::bind(&EquationMutator::addRandomNodeAfter, this, _1),
        std::bind(&EquationMutator::addRandomNodeBefore, this, _1)
    };

    //We can remove a node of a function only if the child is a function
    if(equation.arguments().front().currentNode()->category() == datamodel::EquationNode::NodeCategory::Function)
        possibleMutations.push_back(std::bind(&EquationMutator::removeRandomNodeAfter, this, _1));

    //We can remove parent node only if the node has a parent
    if(_parent)
        possibleMutations.push_back(std::bind(&EquationMutator::removeNodeBefore, this, _1));

    //We choose a random mutation from the list
    possibleMutations[RandomGenerator().getRngGenerator().bounded(static_cast<int>(possibleMutations.size()))](equation);
}

void EquationMutator::mutateSingle(datamodel::EquationTreeItem &equation)
{
    switch (equation.currentNode()->category())
    {
    case datamodel::EquationNode::NodeCategory::Terminal:
        mutateTerminalNode(equation);
        break;
    case datamodel::EquationNode::NodeCategory::Commutative:
        mutateCommutativeNode(equation);
        break;
    case datamodel::EquationNode::NodeCategory::NonCommutative:
    case datamodel::EquationNode::NodeCategory::MinMax:
        mutateNonCommutativeAndMinMaxNode(equation);
        break;
    case datamodel::EquationNode::NodeCategory::Function:
        mutateFunctionNode(equation);
        break;
    }
}

const equationparameters::EquationGenerationParameters &EquationMutator::equationGenerationParameters() const {
    return _equationGenerationParameters;
}

void EquationMutator::setEquationGenerationParameters(
    const equationparameters::EquationGenerationParameters &equationGenerationParameters) {
    _equationGenerationParameters = equationGenerationParameters;
    _equationGenerator.setMaxDepth(_equationGenerationParameters.equationMaxDepth());
    _equationGenerator.setSelectedNodesTypes(_equationGenerationParameters.selectedNodesTypes());
    _equationGenerator.setNumberOfVariables(_equationGenerationParameters.numberOfVariables());
}

void EquationMutator::addRandomNodeAfter(datamodel::EquationTreeItem &equation){
    //Get all available mutations
    QList<datamodel::EquationNode::NodeType> nodeTypes = getNodeAdditionAfterPosibility(equation.currentNode());
    if(!nodeTypes.empty()){
        //Generate random node type taken from nodeTypes
        std::shared_ptr<datamodel::EquationNode> newNode = _equationGenerator.generateEquationNode(nodeTypes);
        datamodel::EquationTreeItem newTree(newNode);

        //Add the node
        if(equation.currentNode()->category() == datamodel::EquationNode::NodeCategory::Commutative){
            equation.arguments().push_back(newTree);
            //Modify the equation with the right parameters
            equation.currentNode()->setNbArguments(equation.arguments().size());
        } else if(equation.currentNode()->category() == datamodel::EquationNode::NodeCategory::Function){
            newTree.setArguments(std::vector<datamodel::EquationTreeItem>({equation.arguments().front()}));
            equation.setArguments(std::vector<datamodel::EquationTreeItem>({newTree}));
        } else {
            logs::Logger::logWarning("addRandomNode not implemented for category " + utils::EnumUtils::categoryToString(equation.currentNode()->category()), {logs::LogTags::equationEditor});
        }
    } else {
        logs::Logger::logWarning("No mutation possible for the node " + utils::EnumUtils::typeToString(equation.currentNode()->type()), {logs::LogTags::equationEditor});
    }
}

void EquationMutator::removeRandomNodeAfter(datamodel::EquationTreeItem &equation){
    if(equation.currentNode()->category() == datamodel::EquationNode::NodeCategory::Function){
        //Remove node only if the child is a function
        if(equation.arguments().front().currentNode()->category() == datamodel::EquationNode::NodeCategory::Function){
            equation.arguments().front().setCurrentNode(equation.arguments().front().arguments().front().currentNode());
            equation.setArguments(equation.arguments().front().arguments());
        } else {
            logs::Logger::logDebug("Node category is function but his child is not, unbale to perform deletion of his child -> child type is " + utils::EnumUtils::categoryToString(equation.arguments().front().currentNode()->category()), {logs::LogTags::equationEditor});
        }
    } else if (equation.currentNode()->category() == datamodel::EquationNode::NodeCategory::Commutative ||
               equation.currentNode()->category() == datamodel::EquationNode::NodeCategory::NonCommutative ||
               equation.currentNode()->category() == datamodel::EquationNode::NodeCategory::MinMax){
        //Randomly choose the index of the node to remove
        int nodeToRemove = RandomGenerator().getRngGenerator().bounded(static_cast<int>(equation.arguments().size()));

        //Remove the node
        equation.arguments().erase(equation.arguments().begin() + nodeToRemove);

        if(equation.arguments().size() == 1){ //Only one node left => the current node become the node left
            equation.setCurrentNode(equation.arguments().front().currentNode());
            equation.setArguments(equation.arguments().front().arguments());
        } else {
            equation.currentNode()->setNbArguments(equation.arguments().size());
        }
    } else {
        logs::Logger::logWarning("removeRandomNode not implemented for category " + utils::EnumUtils::categoryToString(equation.currentNode()->category()), {logs::LogTags::equationEditor});
    }
}

void EquationMutator::replaceCurrentNodeRandom(datamodel::EquationTreeItem &equation){
    //Get all available mutations
    QList<datamodel::EquationNode::NodeType> nodeTypes = getNodeReplacementPosibility(equation.currentNode());
    if(!nodeTypes.empty()){
        //Generate new random node
        std::shared_ptr<datamodel::EquationNode> newNode = _equationGenerator.generateEquationNode(nodeTypes, equation.currentNode()->nbArguments());

        //Replace current node
        equation.setCurrentNode(newNode);
    } else {
        logs::Logger::logWarning("No mutation possible for the node " + utils::EnumUtils::typeToString(equation.currentNode()->type()), {logs::LogTags::equationEditor});
    }
}

void EquationMutator::removeNodeBefore(datamodel::EquationTreeItem &equation){
    if(_parent){
        _parent->setCurrentNode(equation.currentNode());
        _parent->setArguments(equation.arguments());
    } else {
        logs::Logger::logDebug("Can't remove node parent because the node has no parent", {logs::LogTags::equationEditor});
    }
}

void EquationMutator::addRandomNodeBefore(datamodel::EquationTreeItem &equation){
    //Get all available mutations
    QList<datamodel::EquationNode::NodeType> nodeTypes = getNodeAdditionBeforePosibility(equation.currentNode());

    //Generate random node type taken from nodeTypes
    std::shared_ptr<datamodel::EquationNode> newNode = _equationGenerator.generateEquationNode(nodeTypes);
    datamodel::EquationTreeItem newTree(newNode);
    newTree.setArguments(std::vector<datamodel::EquationTreeItem>{equation});

    if(newNode->category() == datamodel::EquationNode::NodeCategory::Commutative ||
              newNode->category() == datamodel::EquationNode::NodeCategory::NonCommutative ||
              newNode->category() == datamodel::EquationNode::NodeCategory::MinMax){
        //Generate random terminal node taken from nodeTypes
        QList<datamodel::EquationNode::NodeType> nodeTypes{
            datamodel::EquationNode::Constant,
            datamodel::EquationNode::Variable
        };
        std::shared_ptr<datamodel::EquationNode> newTerminalNode = _equationGenerator.generateEquationNode(nodeTypes);
        datamodel::EquationTreeItem newTerminalTree(newTerminalNode);
        newTree.arguments().push_back(newTerminalTree);
    } else if(newNode->category() != datamodel::EquationNode::NodeCategory::Function){
        logs::Logger::logError("Unable to add a random node before with a node with category " + utils::EnumUtils::categoryToString(newNode->category()), {logs::LogTags::equationEditor});
        return;
    }
    if(_parent){
        for(datamodel::EquationTreeItem& argument : _parent->arguments()){
            if(argument == equation){
                argument = newTree;
                break;
            }
        }
    }
    equation = newTree;
}

QList<datamodel::EquationNode::NodeType> EquationMutator::getNodeReplacementPosibility(const std::shared_ptr<datamodel::EquationNode>& node){
    //List of available mutations
    QList<datamodel::EquationNode::NodeType> nodeTypes;
    if(node->type() == datamodel::EquationNode::Constant){
        nodeTypes.push_back(datamodel::EquationNode::Variable);
    } else if(node->type() == datamodel::EquationNode::Variable){
        nodeTypes.push_back(datamodel::EquationNode::Constant);
    } else if(node->category() == datamodel::EquationNode::NodeCategory::Commutative) {
        if(node->nbArguments() == 2){ //Only two children => replace current node by a non-commutative node
            // Mutate to division/soustraction/power
            nodeTypes = QList<datamodel::EquationNode::NodeType>{
                    datamodel::EquationNode::Division,
                    datamodel::EquationNode::Soustraction,
                    datamodel::EquationNode::Power
            };
        } else { //Replace current node by it's commutative node counterpart
            if(node->type() == datamodel::EquationNode::Addition) // Mutate to multiplication
                nodeTypes.push_back(datamodel::EquationNode::Multiplication);
            else if(node->type() == datamodel::EquationNode::Multiplication) // Mutate to addition
                nodeTypes.push_back(datamodel::EquationNode::Addition);
            else{
                logs::Logger::logError("This node can't be muted, it's not a commutative node. Type -> " + std::to_string(node->type()), {logs::LogTags::equationEditor});
            }
        }
    } else if(node->category() == datamodel::EquationNode::NodeCategory::NonCommutative ||
              node->category() == datamodel::EquationNode::NodeCategory::MinMax) {
        nodeTypes = QList<datamodel::EquationNode::NodeType>{
            datamodel::EquationNode::Division,
            datamodel::EquationNode::Soustraction,
            datamodel::EquationNode::Power,
            datamodel::EquationNode::Addition,
            datamodel::EquationNode::Multiplication,
            datamodel::EquationNode::Min,
            datamodel::EquationNode::Max
        };

        //Remove current node
        nodeTypes.removeOne(node->type());
    } else if(node->category() == datamodel::EquationNode::NodeCategory::Function) {
        nodeTypes = QList<datamodel::EquationNode::NodeType>{
            datamodel::EquationNode::Cosinus,
            datamodel::EquationNode::Sinus,
            datamodel::EquationNode::Logarithm,
            datamodel::EquationNode::Exponential,
            datamodel::EquationNode::SquareRoot,
            datamodel::EquationNode::Absolute,
            datamodel::EquationNode::Inverse,
            datamodel::EquationNode::Negative,
            datamodel::EquationNode::Arctan,
            datamodel::EquationNode::Tan
        };

        //Remove current node
        nodeTypes.removeOne(node->type());
    } else {
        logs::Logger::logError("No mutation available for this node. Type -> " + utils::EnumUtils::typeToString(node->type()), {logs::LogTags::equationEditor});
    }

    //We remove the unselected nodes setted in parameters
    std::sort(nodeTypes.begin(), nodeTypes.end());
    QList<datamodel::EquationNode::NodeType> selectedNodesTypes = _equationGenerator.selectedNodesTypes();
    std::sort(selectedNodesTypes.begin(), selectedNodesTypes.end());

    QList<datamodel::EquationNode::NodeType> finalNodeTypes;
    std::set_intersection(nodeTypes.begin(), nodeTypes.end(),
                          selectedNodesTypes.begin(), selectedNodesTypes.end(),
                          std::back_inserter(finalNodeTypes));

    return finalNodeTypes;
}

QList<datamodel::EquationNode::NodeType> EquationMutator::getNodeAdditionAfterPosibility(const std::shared_ptr<datamodel::EquationNode>& node){
    //List of available mutations
    QList<datamodel::EquationNode::NodeType> nodeTypes;
    if(node->category() == datamodel::EquationNode::NodeCategory::Commutative) {
        nodeTypes = QList<datamodel::EquationNode::NodeType>{
                datamodel::EquationNode::Constant,
                datamodel::EquationNode::Variable,
        };
    } else if(node->category() == datamodel::EquationNode::NodeCategory::Function) {
        nodeTypes = QList<datamodel::EquationNode::NodeType>{
                datamodel::EquationNode::Cosinus,
                datamodel::EquationNode::Sinus,
                datamodel::EquationNode::Logarithm,
                datamodel::EquationNode::Exponential,
                datamodel::EquationNode::SquareRoot,
                datamodel::EquationNode::Absolute,
                datamodel::EquationNode::Inverse,
                datamodel::EquationNode::Negative,
                datamodel::EquationNode::Arctan,
                datamodel::EquationNode::Tan
        };

        //Remove current node
        nodeTypes.removeOne(node->type());
    } else {
        logs::Logger::logError("No mutation available for this node. Type -> " + utils::EnumUtils::typeToString(node->type()), {logs::LogTags::equationEditor});
    }

    //We remove the unselected nodes setted in parameters
    std::sort(nodeTypes.begin(), nodeTypes.end());
    QList<datamodel::EquationNode::NodeType> selectedNodesTypes = _equationGenerator.selectedNodesTypes();
    std::sort(selectedNodesTypes.begin(), selectedNodesTypes.end());

    QList<datamodel::EquationNode::NodeType> finalNodeTypes;
    std::set_intersection(nodeTypes.begin(), nodeTypes.end(),
                          selectedNodesTypes.begin(), selectedNodesTypes.end(),
                          std::back_inserter(finalNodeTypes));

    return finalNodeTypes;
}

QList<datamodel::EquationNode::NodeType> EquationMutator::getNodeAdditionBeforePosibility(const std::shared_ptr<datamodel::EquationNode>& node){
    //List of available mutations
    QList<datamodel::EquationNode::NodeType> nodeTypes{
                datamodel::EquationNode::Cosinus,
                datamodel::EquationNode::Sinus,
                datamodel::EquationNode::Logarithm,
                datamodel::EquationNode::Exponential,
                datamodel::EquationNode::SquareRoot,
                datamodel::EquationNode::Absolute,
                datamodel::EquationNode::Inverse,
                datamodel::EquationNode::Negative,
                datamodel::EquationNode::Arctan,
                datamodel::EquationNode::Tan,
                datamodel::EquationNode::Min,
                datamodel::EquationNode::Max,
                datamodel::EquationNode::Addition,
                datamodel::EquationNode::Multiplication,
                datamodel::EquationNode::Soustraction,
                datamodel::EquationNode::Division,
                datamodel::EquationNode::Power
    };

    //Remove current node
    nodeTypes.removeOne(node->type());

    //We remove the unselected nodes setted in parameters
    std::sort(nodeTypes.begin(), nodeTypes.end());
    QList<datamodel::EquationNode::NodeType> selectedNodesTypes = _equationGenerator.selectedNodesTypes();
    std::sort(selectedNodesTypes.begin(), selectedNodesTypes.end());

    QList<datamodel::EquationNode::NodeType> finalNodeTypes;
    std::set_intersection(nodeTypes.begin(), nodeTypes.end(),
                          selectedNodesTypes.begin(), selectedNodesTypes.end(),
                          std::back_inserter(finalNodeTypes));

    return finalNodeTypes;
}


} // namespace equationeditors
