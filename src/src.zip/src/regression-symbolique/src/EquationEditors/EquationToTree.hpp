#pragma once

#include <unordered_set>
#include <string>

namespace datamodel {
class EquationTree;
}

namespace equationToTreeParser {

/**
 * Converts an equation string to an equation tree
 * @param eq Equation formatted by sympy's "srepr" function
 * @return An equation tree corresponding to the passed string
 *
 * @throws std::out_of_range
 * @throws std::invalid_argument
 */
[[nodiscard]] datamodel::EquationTreeItem parse_python_eq(const char* eq, uint * variableCount);


/**
 * Converts an equation string to an equation tree
 * @param eq Equation formatted by sympy's "srepr" function
 * @return An equation tree corresponding to the passed string
 *
 * @throws std::out_of_range
 * @throws std::invalid_argument
 */
[[nodiscard]] datamodel::EquationTreeItem equationTreeFromString(std::string expression);

}