
#pragma once

#include "EquationParameters/EquationGenerationParameters.h"
#include "DataModel/EquationTreeItem.h"
#include "EquationGenerator.h"

namespace equationeditors {

class EquationMutator
{
public:
    ~EquationMutator();

    /**
     * @brief mutateEquations Perform mutation on datamodel::EquationTreeItem equation nbMutations times
     * @param equation The equation to mutate
     * @param maxNbMutations The maximum number of mutations tha will be performed on the quation, one mutation will always be performed
     */
    void mutateEquations(datamodel::EquationTreeItem &equation, const unsigned int &maxNbMutations);

    /**
     * @brief mutateSingle mutate the single node
     * @param equation The node to mutate
     */
    void mutateSingle(datamodel::EquationTreeItem &equation);

    const equationparameters::EquationGenerationParameters &equationGenerationParameters() const;
    void setEquationGenerationParameters(
        const equationparameters::EquationGenerationParameters &equationGenerationParameters);

private:
    /**
     * @brief mutateTerminalNode mutate a node of category terminal
     * @param equation The node to mutate
     */
    void mutateTerminalNode(datamodel::EquationTreeItem &equation);

    /**
     * @brief mutateCommutativeNode mutate a node of category commutative
     * @param equation The node to mutate
     */
    void mutateCommutativeNode(datamodel::EquationTreeItem &equation);

    /**
     * @brief mutateNonCommutativeAndMinMaxNode mutate a node of category MinMax
     * @param equation The node to mutate
     */
    void mutateNonCommutativeAndMinMaxNode(datamodel::EquationTreeItem &equation);

    /**
     * @brief mutateFunctionNode mutate a node of category function
     * @param equation The node to mutate
     */
    void mutateFunctionNode(datamodel::EquationTreeItem &equation);

    /**
     * @brief addRandomNodeAfter add a node randomly taken from nodeTypes at the end of the EquationTreeItem equation
     * @param equation The equation that will have a node added
     */
    void addRandomNodeAfter(datamodel::EquationTreeItem &equation);

    /**
     * @brief removeRandomNodeAfter remove a random node from the EquationTreeItem equation. If there is only one node left it will become the new equation.
     * @param equation The equation that will have a node removed
     */
    void removeRandomNodeAfter(datamodel::EquationTreeItem &equation);

    /**
     * @brief replaceCurrentNodeRandom replace the top node by one of the type in nodeTypes
     * @param equation The equation that will have it's top node replaced
     */
    void replaceCurrentNodeRandom(datamodel::EquationTreeItem &equation);

    /**
     * @brief removeNodeBefore Remove the node before the current node if it exist
     * @param equation The current node
     */
    void removeNodeBefore(datamodel::EquationTreeItem &equation);

    /**
     * @brief addRandomNodeBefore Add a node before the current node
     * @param equation The current node
     */
    void addRandomNodeBefore(datamodel::EquationTreeItem &equation);

    /**
     * @brief getNodeReplacementPosibility Get all the node replacement possibilty from the datamodel::EquationNode node
     * @param node The node from which we want to have it's possible mutations
     * @return The list of possible mutations
     */
    QList<datamodel::EquationNode::NodeType> getNodeReplacementPosibility(const std::shared_ptr<datamodel::EquationNode>& node);

    /**
     * @brief getNodeAdditionPosibility Get all the node that can be added after the datamodel::EquationNode node
     * @param node The node from which we want to have it's possible mutations
     * @return The list of possible mutations
     */
    QList<datamodel::EquationNode::NodeType> getNodeAdditionAfterPosibility(const std::shared_ptr<datamodel::EquationNode> &node);

    /**
     * @brief getNodeAdditionBeforePosibility Get all the node that can be added before the datamodel::EquationNode node
     * @param node The node from which we want to have it's possible mutations
     * @return The list of possible mutations
     */
    QList<datamodel::EquationNode::NodeType> getNodeAdditionBeforePosibility(const std::shared_ptr<datamodel::EquationNode> &node);

    equationparameters::EquationGenerationParameters _equationGenerationParameters;

    EquationGenerator _equationGenerator;
    datamodel::EquationTreeItem* _parent{nullptr};
};
} // namespace equationeditors

