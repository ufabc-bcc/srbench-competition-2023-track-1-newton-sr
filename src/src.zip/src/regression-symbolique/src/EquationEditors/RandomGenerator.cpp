#include "RandomGenerator.h"

#include <QDebug>
namespace equationeditors {

#ifdef FIXED_SEED
QRandomGenerator RandomGenerator::_rngGenerator = QRandomGenerator(0);
#else
QRandomGenerator RandomGenerator::_rngGenerator = QRandomGenerator::securelySeeded();
#endif

QRandomGenerator& RandomGenerator::getRngGenerator()
{
    return _rngGenerator;
}

}  // namespace equationeditors
