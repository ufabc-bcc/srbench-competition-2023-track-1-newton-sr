
#pragma once

#include "DataModel/EquationTreeItem.h"
#include "EquationEditors_global.h"

namespace equationeditors {

/*!
 * @brief Select a random node at any depth in the given equation
 * @param equation the equation for which we select a node
 * @return a reference on a random node selected in the given equation
 */
datamodel::EquationTreeItem &selectRandomNode(
    datamodel::EquationTreeItem &equation);

datamodel::EquationTreeItem selectRandomNode(
    const datamodel::EquationTreeItem &equation);

/*!
 * @brief Select a "terminal" (last or before the last of a given branch) in the given equation
 * @param equation the equation for which we select a node
 * @return a reference on a random node selected in the given equation
 */
datamodel::EquationTreeItem &selectRandomTerminalNode(
    datamodel::EquationTreeItem &equation);

/*!
 * @brief Select one random argument in the given equation, meaning a node wich is direct argument of the given equation
 * @param equation the equation for which we select an argument
 * @return a reference on a random node selected in the list of the arguments in the given equation
 */
datamodel::EquationTreeItem &selectRandomArgument(
    datamodel::EquationTreeItem &equation);

datamodel::EquationTreeItem selectRandomArgument(
    const datamodel::EquationTreeItem &equation);

datamodel::EquationTreeItem selectRandomArgumentAtDepth(
    const datamodel::EquationTreeItem &equation, int depth);

} // namespace equationeditors


