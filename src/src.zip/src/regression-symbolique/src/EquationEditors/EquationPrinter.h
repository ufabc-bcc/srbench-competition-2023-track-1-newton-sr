
#pragma once

#include <iomanip>
#include <sstream>

#include <cmath>
#include <vector>
#include <utility>

#include "EquationEditors_global.h"

namespace datamodel
{
class EquationTreeItem;
}

namespace equationeditors
{

/**
 * @brief The NamedConstant class Represents an important constant with a name
 *
 */
struct NamedConstant {
    double value;
    std::string string;
    std::string pythonString;
    std::string latexString;
    std::string latexColorString;
};

/* List of named "important" constants */
 const std::vector<NamedConstant> namedConstants = {
    NamedConstant { M_PI , "π", "pi", "pi", "{\\color{green}\\pi}"},
    NamedConstant { M_PI / 2, "(π/2)", "pi/2", "\\frac{\\pi}{2}", "{\\color{black}\\frac{\\color{green}\\pi}{\\color{green}2}}"},
    NamedConstant { M_E, "e", "e", "e", "{\\color{green}e} "}
};

/**
 * @brief findMatchingConstant Given a value and a list of constants, finds the first constant that matches the value up to a given precision
 * @param value
 * @param precision Numbers of decimal digits to match
 * @return An iterator to the first constant found or an iterator to the end if not found
 *
 * @note This function is linear to the number of constants.
 * We coud sort the constants first and use binary search to get logarithmic complexity,
 * but is unlikely to provide any performance increase considering the current number of constants.
 */
std::vector<NamedConstant>::const_iterator findMatchingConstant(double value, const std::vector<NamedConstant> &constants, int precision = 6) ;

/**
 * @brief equationToString Analyse and return all the information related to en equation
 * @param equationTreeItem The analyzed equation
 * @param variableName The name of the variable (E.g: x)
 * @return A string representing the equation
 */
std::string equationToString(const datamodel::EquationTreeItem &equationTreeItem,
                                                 uint nbVar, int precision = 6);

std::string equationToPythonString(const datamodel::EquationTreeItem &equationTreeItem,
                                                       uint nbVar, int precision = 6, bool forSymPy = false);

std::string equationToLatexString(const datamodel::EquationTreeItem &equationTreeItem,
                                                       uint nbVar, int precision = 6);

std::string equationToLatexColorString(const datamodel::EquationTreeItem &equationTreeItem,
                                                       uint nbVar, int precision = 6);

}  // namespace equationeditors
