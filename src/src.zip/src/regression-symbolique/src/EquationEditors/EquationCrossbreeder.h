
#pragma once

#include "EquationParameters/EquationCrossbreedingParameters.h"
#include "DataModel/EquationTreeItem.h"
#include "EquationEditors_global.h"

namespace equationeditors
{
/**
 * @brief The EquationCrossbreeder class handle the cross bredding of a list of ?? equation
 */
class EquationCrossbreeder
{
   public:
    /**
     * @brief Crossbreeds two equation depending on the current method applied (_crossbreedingMethod)
     * @param firstParent The first parent equation
     * @param secondParent The second parent equation
     * @return The created equation child
     */
    datamodel::EquationTreeItem crossbreeds(const datamodel::EquationTreeItem &firstParent,
                                            const datamodel::EquationTreeItem &secondParent) const;

    /**
     * @brief Crossbreeds two equation with the tree substitution method
     * @param firstParent The first parent equation
     * @param secondParent The second parent equation
     * @return The created equation child
     */
    static datamodel::EquationTreeItem randomTreeSubstitutionCrossbreeding(
        const datamodel::EquationTreeItem &firstParent, const datamodel::EquationTreeItem &secondParent);

    /**
     * @brief Crossbreeds two equation with the tree substitution method
     * @param firstParent The first parent equation
     * @param secondParent The second parent equation
     * @return The two newly created equation children
     */

    static QPair<datamodel::EquationTreeItem,datamodel::EquationTreeItem>  randomTreeSubstitutionCrossbreeding_twoChildren(
        const datamodel::EquationTreeItem &firstParent, const datamodel::EquationTreeItem &secondParent);

    static std::pair<datamodel::EquationTreeItem,datamodel::EquationTreeItem>  randomTreeSubstitutionCrossbreeding_twoChildrenParallel(
        const datamodel::EquationTreeItem &firstParent, const datamodel::EquationTreeItem &secondParent);

    /**
     * @brief Crossbreeds two equation with the depth random  method
     * @param firstParent The first parent equation
     * @param secondParent The second parent equation
     * @return The created equation child
     */
    static datamodel::EquationTreeItem constantDepthRandomNodeCrossbreeding(
        const datamodel::EquationTreeItem &firstParent, const datamodel::EquationTreeItem &secondParent);

    /**
     * @brief Crossbreeds two equation with the depth tree substitution method
     * @param firstParent The first parent equation
     * @param secondParent The second parent equation
     * @return The created equation child
     */
    static datamodel::EquationTreeItem constantDepthTreeSubstitution(
        const datamodel::EquationTreeItem &firstParent, const datamodel::EquationTreeItem &secondParent);

    /**
     * @brief ??
     * @param nodeToComplete
     * @param firstParent
     * @param secondParent
     * @param depth
     */
    static void completeArgumentsForDepth(datamodel::EquationTreeItem &nodeToComplete,
                                          const datamodel::EquationTreeItem &firstParent,
                                          const datamodel::EquationTreeItem &secondParent, int depth);

    // getter / setter
    equationparameters::EquationCrossbreedingParameters::CrossbreedingMethod crossbreedingMethod() const;
    void setCrossbreedingMethod(
        const equationparameters::EquationCrossbreedingParameters::CrossbreedingMethod &crossbreedingMethod);

   private:
    /**
     * @brief The cross breading method, RandomTreeSubstitution by default
     */
    equationparameters::EquationCrossbreedingParameters::CrossbreedingMethod _crossbreedingMethod{
        equationparameters::EquationCrossbreedingParameters::CrossbreedingMethod::RandomTreeSubstitution};
};
}  // namespace equationeditors
