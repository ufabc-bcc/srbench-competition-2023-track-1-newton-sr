#ifndef RANDOMGENERATOR_H
#define RANDOMGENERATOR_H

#pragma once

#include "EquationEditors_global.h"

#include <QRandomGenerator>

namespace equationeditors
{
/**
 * @brief The RandomGenerator class
 */
class RandomGenerator
{
   public:

    /**
     * @brief get the random generator
     * @return the random generator
     */
    QRandomGenerator& getRngGenerator();

   private:
    static QRandomGenerator _rngGenerator;
};
}  // namespace equationeditors

#endif // RANDOMGENERATOR_H
