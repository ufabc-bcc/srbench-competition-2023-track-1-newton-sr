#include "EquationPrinter.h"

#include "Logger_v2/Logger.h"
#include <DataModel/EquationNode.h>
#include <DataModel/EquationTreeItem.h>
#include <iostream>
#include <string> //t1

namespace equationeditors
{


std::vector<NamedConstant>::const_iterator findMatchingConstant(double value, const std::vector<NamedConstant> &constants, int precision) {
    double epsilon = pow(0.1, precision);
    return std::find_if(constants.begin(), constants.end(), [epsilon, value](const NamedConstant& constant) {
        return std::abs(constant.value - value) < epsilon;
    });
}

std::string equationToString(const datamodel::EquationTreeItem &equationTreeItem, uint nbVar, int precision) { //t1

    if (!equationTreeItem.currentNode()) {
        //qWarning() << "Cannot generate string for an equation without current node";
        logs::Logger::logWarning("Cannot generate string for an equation without current node", {logs::LogTags::equationEditor});
        return "";
    }

    if (equationTreeItem.currentNode()->nbArguments() != equationTreeItem.arguments().size()) {
        //qWarning(
        //    "Cannot generate string for equation with different number of arguments "
        //    "(%d) then expected (%zu)",
        //    equationTreeItem.currentNode()->nbArguments(), equationTreeItem.arguments().size());
        std::string message_warning_equation_different_argument = "Cannot generate string for equation with different number of arguments "
                + std::to_string(equationTreeItem.currentNode()->nbArguments())
                + " then expected "
                + std::to_string(equationTreeItem.arguments().size());
        logs::Logger::logWarning(message_warning_equation_different_argument, {logs::LogTags::equationEditor});
        return "";
    }

    std::vector<std::string> equations;
    for(const datamodel::EquationTreeItem& argument : equationTreeItem.arguments()){
        equations.push_back(equationToString(argument, nbVar, precision));
    }

    switch (equationTreeItem.currentNode()->type())
    {
        case datamodel::EquationNode::Constant: {
            // The value of the variable is not important so i put 0
            std::vector<double> variablesValue(nbVar, 0.);
            double value = equationTreeItem.currentNode()->value(variablesValue);

            // Check if the constant corresponds to a named constant and use it in this case
            auto namedConstantIt = findMatchingConstant(value, namedConstants, precision);
            if (namedConstantIt != namedConstants.end()) {
                return namedConstantIt->string;
            }

            std::stringstream stream;
            stream << std::setprecision(precision) << value;
            return stream.str();
        }
        case datamodel::EquationNode::Variable:{
                return equationTreeItem.currentNode()->toLabel();
        }
        case datamodel::EquationNode::Addition:{
                std::string str = "(";
                for(size_t i = 0; i < equations.size() - 1; ++i){
                    str += equations[i];
                    str += " + ";
                }
                str += equations.back();
                str += ")";
                return str;
        }
        case datamodel::EquationNode::Cosinus:
            return "cos("+equations.front()+")";
        case datamodel::EquationNode::Sinus:
            return "sin("+equations.front()+")";
        case datamodel::EquationNode::Division:
            return "("+equations.front()+" / "+equations.back()+")";
        case datamodel::EquationNode::Multiplication:{
            std::string str = "(";
            for(size_t i = 0; i < equations.size() - 1; ++i){
                str += equations[i];
                str += " * ";
            }
            str += equations.back();
            str += ")";
            return str;
        }
        case datamodel::EquationNode::Soustraction:
            return "("+equations.front()+" - "+equations.back()+")";
        case datamodel::EquationNode::Power:
            return "("+equations.front()+"^"+equations.back()+")";
        case datamodel::EquationNode::Exponential:
            return "exp("+equations.front()+")";
        case datamodel::EquationNode::Logarithm:
            return "log("+equations.front()+")";
        case datamodel::EquationNode::SquareRoot:
            return "sqrt("+equations.front()+")";
        case datamodel::EquationNode::Min:
            return "min("+equations.front()+","+equations.back()+")";
        case datamodel::EquationNode::Max:
            return "max("+equations.front()+","+equations.back()+")";
        case datamodel::EquationNode::Absolute:
            return "abs("+equations.front()+")";
        case datamodel::EquationNode::Inverse:
            return "1/("+equations.front()+")";
        case datamodel::EquationNode::Negative:
            return "-("+equations.front()+")";
        case datamodel::EquationNode::Arctan:
            return "atan("+equations.front()+")";
        case datamodel::EquationNode::Tan:
            return "tan("+equations.front()+")";
    }

    return "";//t1 return QString();
}

std::string equationToPythonString(const datamodel::EquationTreeItem &equationTreeItem, uint nbVar, int precision, bool forSymPy) {
    if (!equationTreeItem.currentNode()) {
        //qWarning() << "Cannot generate string for an equation without current node";
        logs::Logger::logWarning("Cannot generate string for an equation without current node", {logs::LogTags::equationEditor});
        return "";
    }
    if (equationTreeItem.currentNode()->nbArguments() != equationTreeItem.arguments().size()) {
       //qWarning(
       //     "Cannot generate string for equation with different number of arguments "
       //     "(%d) then expected (%d)",
       //     equationTreeItem.currentNode()->nbArguments(), (int)equationTreeItem.arguments().size());
       std::string message_warning_equation_different_argument_python = "Cannot generate string for equation with different number of arguments "
               + std::to_string(equationTreeItem.currentNode()->nbArguments())
               + " then expected "
               + std::to_string(equationTreeItem.arguments().size());
       logs::Logger::logWarning(message_warning_equation_different_argument_python, {logs::LogTags::equationEditor});
        return "";
    }

    std::stringstream stream;

    switch (equationTreeItem.currentNode()->type())
    {
        case datamodel::EquationNode::Constant: {
            // The value of the variable is not important so i put 0
            std::vector<double> variablesValue(nbVar, 0.);
            double value = equationTreeItem.currentNode()->value(variablesValue);

            // Check if the constant corresponds to a named constant and use it in this case
            auto namedConstantIt = findMatchingConstant(value, namedConstants, precision);
            if (namedConstantIt != namedConstants.end()) {
                return namedConstantIt->pythonString;
            }
            stream << std::setprecision(precision) << value;
            return stream.str();
        }
        case datamodel::EquationNode::Variable:
            return equationTreeItem.currentNode()->toLabel();
        case datamodel::EquationNode::Exponential:
            if (forSymPy) {
                stream << "expo**("
                       << equationToPythonString(equationTreeItem.arguments().at(0), nbVar, precision, forSymPy)
                       << ")";
                return stream.str();
            }
            // else fallthrough
        case datamodel::EquationNode::Cosinus:
        case datamodel::EquationNode::Sinus:
        case datamodel::EquationNode::Logarithm:
        case datamodel::EquationNode::SquareRoot:
        case datamodel::EquationNode::Absolute:
        case datamodel::EquationNode::Inverse:
        case datamodel::EquationNode::Negative:
        case datamodel::EquationNode::Arctan:
        case datamodel::EquationNode::Tan: {
            stream << equationTreeItem.currentNode()->toString();
            stream << "(" << equationToPythonString(equationTreeItem.arguments().at(0), nbVar, precision, forSymPy) << ")";
            return stream.str();
        }
        case datamodel::EquationNode::Addition:
        case datamodel::EquationNode::Division:
        case datamodel::EquationNode::Multiplication:
        case datamodel::EquationNode::Soustraction:
        case datamodel::EquationNode::Power:
        {
            stream << "(" << equationToPythonString(equationTreeItem.arguments().at(0), nbVar, precision, forSymPy);
            stream << equationTreeItem.currentNode()->toString();
            stream << equationToPythonString(equationTreeItem.arguments().at(1), nbVar, precision, forSymPy) << ")";
            return stream.str();
        }
        case datamodel::EquationNode::Min:
        case datamodel::EquationNode::Max: {
            stream << equationTreeItem.currentNode()->toString() << "(";
            stream << equationToPythonString(equationTreeItem.arguments().at(0), nbVar, precision, forSymPy) << ",";
            stream << equationToPythonString(equationTreeItem.arguments().at(1), nbVar, precision, forSymPy) << ")";
            return stream.str();
        }
    }
    return std::string();
}

// Monochrome display of equations with laTex
std::string equationToLatexString(const datamodel::EquationTreeItem &equationTreeItem, uint nbVar, int precision) {
    if (!equationTreeItem.currentNode()) {
        //qWarning() << "Cannot generate string for an equation without current node";
        logs::Logger::logWarning("Cannot generate string for an equation without current node", {logs::LogTags::equationEditor});
        return "";
    }
    if (equationTreeItem.currentNode()->nbArguments() != equationTreeItem.arguments().size()) {
        //qWarning(
        //    "Cannot generate string for equation with different number of arguments "
        //    "(%d) then expected (%zu)",
        //    equationTreeItem.currentNode()->nbArguments(), equationTreeItem.arguments().size());
        std::string message_warning_equation_different_argument_Latex = "Cannot generate string for equation with different number of arguments "
                + std::to_string(equationTreeItem.currentNode()->nbArguments())
                + " then expected "
                + std::to_string(equationTreeItem.arguments().size());
        logs::Logger::logWarning(message_warning_equation_different_argument_Latex, {logs::LogTags::equationEditor});
        return "";
    }

    std::string eq1;
    std::string eq2;

    if (equationTreeItem.arguments().size() >= 1)
        eq1 = equationToLatexString(equationTreeItem.arguments().at(0), nbVar, precision);
    if (equationTreeItem.arguments().size() >= 2)
        eq2 = equationToLatexString(equationTreeItem.arguments().at(1), nbVar, precision);

    switch (equationTreeItem.currentNode()->type())
    {
        case datamodel::EquationNode::Constant: {
            // The value of the variable is not important so i put 0
            std::vector<double> variablesValue(nbVar, 0.);
            double value = equationTreeItem.currentNode()->value(variablesValue);

            // Check if the constant corresponds to a named constant and use it in this case
            auto namedConstantIt = findMatchingConstant(value, namedConstants, precision);
            if (namedConstantIt != namedConstants.end()) {
                return namedConstantIt->latexString;
            }

            std::stringstream stream;
            stream << std::setprecision(precision) << value;
            return stream.str();
        }
        case datamodel::EquationNode::Variable:
            return equationTreeItem.currentNode()->toLabel();//t_1 return QString::fromStdString(equationTreeItem.currentNode()->toString());
        case datamodel::EquationNode::Addition:
            return "("+eq1+" + "+eq2+")";
        case datamodel::EquationNode::Cosinus:
            return "\\cos{("+eq1+")}";
        case datamodel::EquationNode::Sinus:
            return "\\sin{("+eq1+")}";
        case datamodel::EquationNode::Division:
            return "\\frac{"+eq1+"}{"+eq2+"}";
        case datamodel::EquationNode::Multiplication:
            return "("+eq1+" * "+eq2+")";
        case datamodel::EquationNode::Soustraction:
            return "("+eq1+" - "+eq2+")";
        case datamodel::EquationNode::Power:
            return ""+eq1+"^{"+eq2+"}";
        case datamodel::EquationNode::Exponential:
            return "\\exp{("+eq1+")}";
        case datamodel::EquationNode::Logarithm:
            return "\\ln{("+eq1+")}";
        case datamodel::EquationNode::SquareRoot:
            return "\\sqrt{"+eq1+"}";
        case datamodel::EquationNode::Min:
            return "\\min{("+eq1+";"+eq2+")}";
        case datamodel::EquationNode::Max:
            return "\\max{("+eq1+";"+eq2+")}";
        case datamodel::EquationNode::Absolute:
            return "\\mid"+eq1+"\\mid";
        case datamodel::EquationNode::Inverse:
            return "\\frac{1}{"+eq1+"}";
        case datamodel::EquationNode::Negative:
            return "-("+eq1+")";
        case datamodel::EquationNode::Arctan:
            return "\\arctan("+eq1+")";
        case datamodel::EquationNode::Tan:
            return "\\tan("+eq1+")";
    }
    return "";
}

    //Color display of equations with laTex
    std::string equationToLatexColorString(const datamodel::EquationTreeItem &equationTreeItem, uint nbVar, int precision) {
        if (!equationTreeItem.currentNode()) {
            //qWarning() << "Cannot generate string for an equation without current node";
            logs::Logger::logWarning("Cannot generate string for an equation without current node", {logs::LogTags::equationEditor});
            return "";
        }
        if (equationTreeItem.currentNode()->nbArguments() != equationTreeItem.arguments().size()) {
            //qWarning(
            //    "Cannot generate string for equation with different number of arguments "
            //    "(%d) then expected (%zu)",
            //    equationTreeItem.currentNode()->nbArguments(), equationTreeItem.arguments().size());
            std::string message_warning_equation_different_argument_Latex = "Cannot generate string for equation with different number of arguments "
                    + std::to_string(equationTreeItem.currentNode()->nbArguments())
                    + " then expected "
                    + std::to_string(equationTreeItem.arguments().size());
            logs::Logger::logWarning(message_warning_equation_different_argument_Latex, {logs::LogTags::equationEditor});
            return "";
        }

        std::string eq1;
        std::string eq2;

        if (equationTreeItem.arguments().size() >= 1)
            eq1 = equationToLatexColorString(equationTreeItem.arguments().at(0), nbVar, precision);
        if (equationTreeItem.arguments().size() >= 2)
            eq2 = equationToLatexColorString(equationTreeItem.arguments().at(1), nbVar, precision);

        switch (equationTreeItem.currentNode()->type())
        {
            case datamodel::EquationNode::Constant: {
                // The value of the variable is not important so i put 0
                std::vector<double> variablesValue(nbVar, 0.);
                double value = equationTreeItem.currentNode()->value(variablesValue);

                // Check if the constant corresponds to a named constant and use it in this case
                auto namedConstantIt = findMatchingConstant(value, namedConstants, precision);
                if (namedConstantIt != namedConstants.end()) {
                    return "{\\color{black}" + namedConstantIt->latexColorString+ "}";
                }

                std::stringstream stream;
                stream << std::setprecision(precision) << value;
                return "{\\color{green}" + stream.str()+ "}";

    //            return "{\\color{green}" + std::to_string(equationTreeItem.currentNode()->value(variablesValue))+ "}";
            }
            case datamodel::EquationNode::Variable:
                return "{\\color{blue}" + equationTreeItem.currentNode()->toLabel() + "}";//t_1 return QString::fromStdString(equationTreeItem.currentNode()->toString());

            case datamodel::EquationNode::Addition:
                return "{\\color{black}(}"+eq1+" {\\color{black}+} "+eq2+"{\\color{black})}";

            case datamodel::EquationNode::Cosinus:
                return "{\\color{red}\\cos{\\color{black}("+eq1+")}}";

            case datamodel::EquationNode::Sinus:
                return "{\\color{red}\\sin{\\color{black}("+eq1+")}}";

            case datamodel::EquationNode::Division:
                return "{\\color{black}\\frac{"+eq1+"}{"+eq2+"}}";

            case datamodel::EquationNode::Multiplication:
                return "{\\color{black}(}"+eq1+" {\\color{black}*} "+eq2+"{\\color{black})}";

            case datamodel::EquationNode::Soustraction:
                return "{\\color{black}(}"+eq1+" {\\color{black}-} "+eq2+"{\\color{black})}";

            case datamodel::EquationNode::Power:
                return ""+eq1+"^{"+eq2+"}";

            case datamodel::EquationNode::Exponential:
                return "{\\color{red}\\exp{\\color{black}("+eq1+")}}";

            case datamodel::EquationNode::Logarithm:
                return "{\\color{red}\\ln{\\color{black}("+eq1+")}}";

            case datamodel::EquationNode::SquareRoot:
                return "{\\color{black}\\sqrt{"+eq1+"}}";

            case datamodel::EquationNode::Min:
                return "{\\color{red}\\min{\\color{black}("+eq1+"{\\color{black};}"+eq2+")}}";

            case datamodel::EquationNode::Max:
                return "{\\color{red}\\max{\\color{black}("+eq1+"{\\color{black};}"+eq2+")}}";

            case datamodel::EquationNode::Absolute:
                return "{\\color{red}\\mid"+eq1+"\\mid}";

            case datamodel::EquationNode::Inverse:
                return "{\\color{black}\\frac{\\color{green}1}{"+eq1+"}}";

            case datamodel::EquationNode::Negative:
                return "{\\color{black}-("+eq1+")}";

            case datamodel::EquationNode::Arctan:
                return "{\\color{red}\\arctan{\\color{black}("+eq1+")}}";

            case datamodel::EquationNode::Tan:
                return "{\\color{red}\\tan{\\color{black}("+eq1+")}}";
        }
        return "";
    }

}  // namespace equationeditors
