#include <atomic>
#include <mutex>
#include <algorithm>
#include <string>

#include "AlgorithmControllers/TotalNodeCalculator.h"
#include "AlgorithmControllers/equationtransformation.h"
#include "DataModel/EquationTreeItem.h"
#include "DataModel/EquationTree.h"
#include "DataModel/NodeTypes.h"
#include "EquationEditors/EquationPrinter.h"
#include "Logger_v2/Logger.h"

#include "Utils/StringUtils.h"

#include "FileReaderWriter/FileReaderWriter_global.h"

#include "EquationEditors/EquationToTree.hpp"

#include <iostream>


datamodel::EquationTreeItem equationToTreeParser::equationTreeFromString(std::string expression) {
    datamodel::EquationTreeItem root;
    std::vector<datamodel::EquationTreeItem> arguments;

    if (expression.empty()) {
        return root;
    }

    auto starts_with = [](std::string str, std::string beg) {
        if (str.length() < beg.length()) {
        // La chaîne à vérifier est plus courte que la chaîne de début
        return false;
        }

        for (size_t i = 0; i < beg.length(); ++i) {
            if (str[i] != beg[i]) {
                // Les caractères ne correspondent pas
                return false;
            }
        }

        // Tous les caractères correspondent jusqu'à présent
        return true;
    };

    auto find_next = [](std::string str, char c) {
        int parenthesesCount = 0;
        for (int i = 0; i < str.length(); ++i) {
            if (str[i] == '(') {
                parenthesesCount++;
            } else if (str[i] == ')') {
                parenthesesCount--;
            } else if (parenthesesCount == 0 && str[i] == c) {
                return i;
            }
        }
        return -1;
    };

    auto is_number = [](char c) {
        if ((c >= '0' && c <= '9') || c == '-')
            return 1;
        return 0;
    };

    // extract the index of a variable formated as varnameVARINDEX, VARINDEX being a number and varname containing no digit
    // or it can also be formatted as the name of a header of the file loaded
    auto extract_varIndex = [](const char* str) {
        //Get the variable name
        std::string varName{""};
        while (*str && *str != '\'') {
            varName.push_back(*str);
            ++str;
        }

        //Check if the variable name came from one of the header of the file
        //NOTE: The last value of g_lineData is the target
        for(size_t i = 0; i < g_lineData.size() - 1; ++i)
            if(utils::StringUtils::isEqualCaseInsensitve(g_lineData[i], varName))
                return i;

        //Extract the index of a variable formated as varnameVARINDEX, VARINDEX being a number and varname containing no digit
        size_t index = varName.find_first_of("0123456789");

        //If no index are found we return 0 by default
        if(index == std::string::npos)
            return static_cast<size_t>(0);

        return std::stoull(varName.substr(index));
    };

    // Supprimer les espaces
    expression.erase(remove_if(expression.begin(), expression.end(), [](unsigned char c) { return isspace(c); }), expression.end());

    int parenthesesCount = 0;
    int operatorIndex = -1;
    int lowestPrecedence = 999999;
    bool isPower = false;

    // Parcourir l'expression de gauche à droite pour trouver l'opérateur de plus basse précédence
    for (uint i = 0; i < expression.length(); i++) {
        char c = expression[i];

        if (c == '(') {
            parenthesesCount++;
        } else if (c == ')') {
            parenthesesCount--;
        } else if (parenthesesCount == 0 && ((c == '+' && !(i > 0 && expression[i - 1] == 'e')) || (c == '-' && i > 0 && expression[i - 1] != 'e' && expression[i - 1] != '*' && expression[i - 1] != '^')  || c == '*' || c == '/' || c == '^')) {
            int precedence = 0;
            if (c == '-')
                precedence = 2;
            else if (c == '+') {
                precedence = 1;
            } else if (c == '*'|| c == '/' || c == '^') {
                precedence = 3;
            }

            if (precedence < lowestPrecedence) {
                lowestPrecedence = precedence;
                operatorIndex = i;
            }
        }
    }
    if (operatorIndex != -1 && !(operatorIndex == 0 && expression[0] == '-')) {
        arguments.push_back(equationTreeFromString(expression.substr(0, operatorIndex)));
        if (expression[operatorIndex + 1] == '*') {
            operatorIndex++;
            isPower = true;
        }
        std::vector<datamodel::EquationTreeItem> current_arguments;
        current_arguments.push_back(arguments[0]);
        if (expression[operatorIndex] == '+') {
            datamodel::EquationTreeItem temp_node{}; // brand new node
            int next_op = 0;
            int count = 1;
            while (next_op != -1) {
                next_op = find_next(expression.c_str() + operatorIndex + 1, expression[operatorIndex]);
                if (next_op != -1) {
                    current_arguments.push_back(equationTreeFromString(expression.substr(operatorIndex + 1, next_op)));
                    operatorIndex += next_op + 1;
                }
                else {
                    current_arguments.push_back(equationTreeFromString(expression.substr(operatorIndex + 1)));
                }
                count++;
            }

            temp_node.setCurrentNode(std::shared_ptr<datamodel::EquationNode>(new datamodel::AdditionNode));
            temp_node.setArguments(current_arguments);
            temp_node.currentNode()->setNbArguments(count);
            current_arguments.clear();
            current_arguments.push_back(temp_node);
        }
        else if (expression[operatorIndex] == '*' && isPower == false) {
            datamodel::EquationTreeItem temp_node{}; // brand new node
            int next_op = 0;
            int count = 1;
            while (next_op != -1) {
                next_op = find_next(expression.c_str() + operatorIndex + 1, expression[operatorIndex]);
                if (next_op != -1) {
                    current_arguments.push_back(equationTreeFromString(expression.substr(operatorIndex + 1, next_op)));
                    operatorIndex += next_op + 1;
                }
                else {
                    current_arguments.push_back(equationTreeFromString(expression.substr(operatorIndex + 1)));
                }
                count++;
            }

            temp_node.setCurrentNode(std::shared_ptr<datamodel::EquationNode>(new datamodel::MultiplicationNode));
            temp_node.setArguments(current_arguments);
            temp_node.currentNode()->setNbArguments(count);
            current_arguments.clear();
            current_arguments.push_back(temp_node);
        }
        else if (expression[operatorIndex] == '/') {
            arguments.push_back(equationTreeFromString(expression.substr(operatorIndex + 1)));
            for (uint i = 1 ; i < arguments.size() ; ++i) {

                datamodel::EquationTreeItem temp_node{}; // brand new node
                const std::vector<double> empty;
                if (current_arguments[0].currentNode()->type() == datamodel::EquationNode::NodeType::Constant && current_arguments[0].value(empty) == 1) {
                    current_arguments.clear();
                    temp_node.setCurrentNode(std::shared_ptr<datamodel::EquationNode>(new datamodel::InverseNode));
                    current_arguments.push_back(arguments[i]);
                    temp_node.setArguments(current_arguments);
                    current_arguments.clear();
                    current_arguments.push_back(temp_node);
                } else {
                    current_arguments.push_back(arguments[i]);
                    temp_node.setCurrentNode(std::shared_ptr<datamodel::EquationNode>(new datamodel::DivisionNode));
                    temp_node.setArguments(current_arguments);
                    current_arguments.clear();
                    current_arguments.push_back(temp_node);
                }
            }
        }
        else if (expression[operatorIndex] == '-' && isPower == false) {
            arguments.push_back(equationTreeFromString(expression.substr(operatorIndex + 1)));
            for (uint i = 1 ; i < arguments.size() ; ++i) {

                datamodel::EquationTreeItem temp_node{}; // brand new node
                current_arguments.push_back(arguments[i]);

                temp_node.setCurrentNode(std::shared_ptr<datamodel::EquationNode>(new datamodel::SoustractionNode));
                temp_node.setArguments(current_arguments);

                current_arguments.clear();
                current_arguments.push_back(temp_node);
            }
        }
        else if (expression[operatorIndex] == '^' || isPower == true) {
            arguments.push_back(equationTreeFromString(expression.substr(operatorIndex + 1)));
            for (uint i = 1 ; i < arguments.size() ; ++i) {

                datamodel::EquationTreeItem temp_node{}; // brand new node
                current_arguments.push_back(arguments[i]);

                temp_node.setCurrentNode(std::shared_ptr<datamodel::EquationNode>(new datamodel::PowerNode));
                temp_node.setArguments(current_arguments);

                current_arguments.clear();
                current_arguments.push_back(temp_node);
            }
        }

        root = current_arguments.back();
    }
    else if (expression[0] == '(' && expression[expression.length() - 1] == ')') {
        std::string subExpr = expression.substr(1, expression.length() - 2);
        root = equationTreeFromString(subExpr);
    }
    else if (starts_with(expression, "cos(") && expression[expression.length() - 1] == ')') {
        arguments.push_back(equationTreeFromString(expression.substr(4, expression.length() - 5)));
        root.setCurrentNode(std::shared_ptr<datamodel::EquationNode>(new datamodel::CosinusNode));
        root.setArguments(arguments);
    }
    else if (starts_with(expression, "sin(") && expression[expression.length() - 1] == ')') {
        arguments.push_back(equationTreeFromString(expression.substr(4, expression.length() - 5)));
        root.setCurrentNode(std::shared_ptr<datamodel::EquationNode>(new datamodel::SinusNode));
        root.setArguments(arguments);
    }
    else if (starts_with(expression, "tan(") && expression[expression.length() - 1] == ')') {
        arguments.push_back(equationTreeFromString(expression.substr(4, expression.length() - 5)));
        root.setCurrentNode(std::shared_ptr<datamodel::EquationNode>(new datamodel::TanNode));
        root.setArguments(arguments);
    }
    else if (starts_with(expression, "exp(") && expression[expression.length() - 1] == ')') {
        arguments.push_back(equationTreeFromString(expression.substr(4, expression.length() - 5)));
        root.setCurrentNode(std::shared_ptr<datamodel::EquationNode>(new datamodel::ExponentialNode));
        root.setArguments(arguments);
    }
    else if ((starts_with(expression, "log(") || starts_with(expression, "ln("))&& expression[expression.length() - 1] == ')') {
        arguments.push_back(equationTreeFromString(expression.substr(4, expression.length() - 5)));
        root.setCurrentNode(std::shared_ptr<datamodel::EquationNode>(new datamodel::LogarithmeNode));
        root.setArguments(arguments);
    }
    else if (starts_with(expression, "atan(") && expression[expression.length() - 1] == ')') {
        arguments.push_back(equationTreeFromString(expression.substr(5, expression.length() - 6)));
        root.setCurrentNode(std::shared_ptr<datamodel::EquationNode>(new datamodel::ArctanNode));
        root.setArguments(arguments);
    }
    else if (starts_with(expression, "sqrt(") && expression[expression.length() - 1] == ')') {
        arguments.push_back(equationTreeFromString(expression.substr(5, expression.length() - 6)));
        root.setCurrentNode(std::shared_ptr<datamodel::EquationNode>(new datamodel::SquareRootNode));
        root.setArguments(arguments);
    }
    else if (starts_with(expression, "max(") && expression[expression.length() - 1] == ')') {
        arguments.push_back(equationTreeFromString(expression.substr(4, expression.length() - 5)));
        size_t commaPos = expression.find(",");
        if (commaPos != std::string::npos) {
            std::string result = expression.substr(commaPos + 1);
            arguments.push_back(equationTreeFromString(result.substr(0, result.length() - 1)));
            root.setCurrentNode(std::shared_ptr<datamodel::EquationNode>(new datamodel::MaxNode()));
            root.setArguments(arguments);
        }
    }
    else if (starts_with(expression, "min(") && expression[expression.length() - 1] == ')') {
        arguments.push_back(equationTreeFromString(expression.substr(4, expression.length() - 5)));
        size_t commaPos = expression.find(",");
        if (commaPos != std::string::npos) {
            std::string result = expression.substr(commaPos + 1);
            arguments.push_back(equationTreeFromString(result.substr(0, result.length() - 2)));
            root.setCurrentNode(std::shared_ptr<datamodel::EquationNode>(new datamodel::MinNode()));
            root.setArguments(arguments);
        }
    }
    else if (starts_with(expression, "abs(") && expression[expression.length() - 1] == ')') {
        arguments.push_back(equationTreeFromString(expression.substr(4, expression.length() - 5)));
        root.setCurrentNode(std::shared_ptr<datamodel::EquationNode>(new datamodel::AbsoluteNode()));
        root.setArguments(arguments);
    }
    else if (starts_with(expression, "pi")) {
        root.setCurrentNode(std::shared_ptr<datamodel::EquationNode>(new datamodel::ConstantNode(M_PI)));
    }
    else if (expression[0] == '-' && expression[1] == '(') {
        root.setCurrentNode(std::shared_ptr<datamodel::EquationNode>(new datamodel::NegativeNode()));
        arguments.push_back(equationTreeFromString(expression.substr(1)));
        root.setArguments(arguments);
    }
    else if (is_number(expression[0])) {
        root.setCurrentNode(std::shared_ptr<datamodel::EquationNode>(new datamodel::ConstantNode(std::stod(expression))));
    }
    else {
        uint varIndex = extract_varIndex(expression.c_str());
        //*variableCount = *variableCount < varIndex + 1 ? varIndex + 1 : *variableCount;
        root.setCurrentNode(std::shared_ptr<datamodel::EquationNode>(new datamodel::VariableNode(varIndex)));
        root.setArguments(arguments);
    }
    return root;
}