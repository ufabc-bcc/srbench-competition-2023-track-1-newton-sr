#ifndef EQUATIONSIMPLIFIER_H
#define EQUATIONSIMPLIFIER_H

#pragma once

#include "EquationEditors_global.h"

namespace datamodel
{
class EquationTree;
class EquationTreeItem;
}

namespace equationeditors
{
/**
 * @brief equationTreeSimplifier Analyse and modify equation tree to simplify it
 * @param equationTree The analyzed equation tree
 */
void equationTreeSimplifier(datamodel::EquationTree &equationTree);

/**
 * @brief equationTreeSimplifier Analyse and modify equation tree item to simplify it
 * @param nbVar Number of variables in the equation
 * @param equationTree The analyzed equation tree item
 */
void equationTreeItemSimplifier(datamodel::EquationTreeItem &equationTreeItem, uint nbVar);

/**
 * @brief equationSimplifier Analyse and modify equation item to simplify it
 * @param equationTreeItem The analyzed equation item
 * @param nbVar Number of variables in the equation
 * @return False if equation item is invalid
 */
bool equationSimplifier(datamodel::EquationTreeItem &equationTreeItem, uint nbVar);

}  // namespace equationeditors

#endif // EQUATIONSIMPLIFIER_H
