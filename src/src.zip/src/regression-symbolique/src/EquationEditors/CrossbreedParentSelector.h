
#pragma once

#include "EquationParameters/EquationCrossbreedingParameters.h"
#include "DataModel/EquationTreeItem.h"
#include "DataModel/EquationTree.h"
#include "EquationEditors_global.h"

namespace equationeditors
{
/**
 * @brief The CrossbreedParentSelector class
 */
class CrossbreedParentSelector
{
   public:
    /**
     * @brief constructor of CrossbreedParentSelector class
     * @param equationsData : map of equations
     * @param parentSelectionStrategy : Strategy in parent choice
     * @param parentSelectionCriteria : Criteria in parent choice
     * @param crossbreedingRate : Parent selection rate
     * @param tournamentSize :  size of tournament if parentSelectionStrategy is Tournament
     */
    CrossbreedParentSelector(
        const datamodel::EquationTree* equationsData,
            uint dataSize,
        equationparameters::EquationCrossbreedingParameters::ParentSelectionStrategy parentSelectionStrategy,
        equationparameters::EquationCrossbreedingParameters::ParentSelectionCriteria parentSelectionCriteria,
        double crossBreedingRate = 1,
        int tournamentSize = 1);

    /**
     * @brief Select parent for the crossbreeding
     * @return the list of pairs of parents for crossbreeding
     */

    std::pair<datamodel::EquationTreeItem, datamodel::EquationTreeItem>* parentsSelection(uint numberOfParentsToSelect);
    /**
     * @brief get the parentSelectionStrategy
     * @return the parentSelectionStrategy
     */
    equationparameters::EquationCrossbreedingParameters::ParentSelectionStrategy getParentSelectionStrategy() const;
    /**
     * @brief set the parentSelectionStrategy
     * @param parentSelectionStrategy : the new parentSelectionStrategy
     */
    void setParentSelectionStrategy(const equationparameters::EquationCrossbreedingParameters::ParentSelectionStrategy &parentSelectionStrategy);

    /**
     * @brief get the parentSelectionCriteria
     * @return the parentSelectionCriteria
     */
    equationparameters::EquationCrossbreedingParameters::ParentSelectionCriteria getParentSelectionCriteria() const;
    /**
     * @brief set the parentSelectionCriteria
     * @param parentSelectionStrategy : the new parentSelectionCriteria
     */
    void setParentSelectionCriteria(const equationparameters::EquationCrossbreedingParameters::ParentSelectionCriteria &parentSelectionCriteria);

    /**
     * @brief get the crossbreeding rate
     * @return the crossbreeding rate
     */
    double getCrossbreedingRate() const;
    /**
     * @brief set the crossbreeding rate
     * @param crossbreedingRate : the new crossbreeding rate
     */
    void setCrossbreedingRate(const double &crossbreedingRate);


    /**
     * @brief get the tournamentSize
     * @return the tournament size
     */
    int getTournamentSize() const;
    /**
     * @brief set the tournamentSize
     * @param tournamentSize : the new tournament size
     */
    void setTournamentSize(const int &tournamentSize);

   private:
    // Copy of this util class have no meaning
    Q_DISABLE_COPY_MOVE(CrossbreedParentSelector)

    const datamodel::EquationTree* _equationsData;

    uint _dataSize;

    double _crossbreedingRate;

    equationparameters::EquationCrossbreedingParameters::ParentSelectionStrategy _parentSelectionStrategy;

    equationparameters::EquationCrossbreedingParameters::ParentSelectionCriteria _parentSelectionCriteria;

    int _tournamentSize;

    bool _compareParentsByCriteria(const datamodel::EquationTree &parentA, const datamodel::EquationTree &parentB) const;
};
}  // namespace equationeditors
