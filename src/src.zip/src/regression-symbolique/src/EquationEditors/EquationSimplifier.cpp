#include "EquationSimplifier.h"
#include "Logger_v2/Logger.h"

#include <DataModel/EquationNode.h>
#include <DataModel/EquationTree.h>
#include <QDebug>
#include <iostream>//t1
#include <cmath>
#include <stdexcept>

#include <DataModel/AbsoluteNode.h>
#include <DataModel/AdditionNode.h>
#include <DataModel/ArctanNode.h>
#include <DataModel/ConstantNode.h>
#include <DataModel/CosinusNode.h>
#include <DataModel/DivisionNode.h>
#include <DataModel/EquationTreeItem.h>
#include <DataModel/ExponentialNode.h>
#include <DataModel/InverseNode.h>
#include <DataModel/LogarithmeNode.h>
#include <DataModel/MaxNode.h>
#include <DataModel/MinNode.h>
#include <DataModel/MultiplicationNode.h>
#include <DataModel/NegativeNode.h>
#include <DataModel/PowerNode.h>
#include <DataModel/SinusNode.h>
#include <DataModel/SoustractionNode.h>
#include <DataModel/SquareRootNode.h>
#include <DataModel/VariableNode.h>

#include <EquationEditors/EquationPrinter.h>

namespace equationeditors
{
//=====================================================================================================================
// Depth First Traversal - Postorder (Left, Right, Root) - Iterative
void equationTreeSimplifier(datamodel::EquationTree &equationTree) {
    datamodel::EquationTreeItem &root = equationTree.rootRef();
    uint nbVar = equationTree.numberOfVariables();
    equationTreeItemSimplifier(root, nbVar);
}

//=====================================================================================================================
// Depth First Traversal - Postorder (Left, Right, Root) - Iterative
void equationTreeItemSimplifier(datamodel::EquationTreeItem &equationTreeItem, uint nbVar)
{
    datamodel::EquationTreeItem *pCurrent = &equationTreeItem;
    QSet<void*> visited;

    while (!visited.contains(static_cast<void*>(pCurrent))) {

        bool newVisit = false;
        for (int i = 0; i < (int)pCurrent->arguments().size() ; i++) {
            if (!visited.contains(static_cast<void*>( &(pCurrent->arguments()[i]) ))) {
                // Visit argument subtree
                pCurrent = &(pCurrent->arguments()[i]);
                newVisit = true;
                break;
            }
        }
        if (!newVisit) {
            // Process node
            visited.insert(static_cast<void*>(pCurrent));
            try{
            [[maybe_unused]] bool bRes = equationSimplifier(*pCurrent, nbVar);
            }catch (std::runtime_error &e) {
                std::string error(e.what());
                std::string message_info_equation_unvailable = error
                        + " -> for the equation "
                        + equationeditors::equationToString(equationTreeItem,nbVar)
                        + " which was removed after processing" ;
                logs::Logger::logInfoDetail(message_info_equation_unvailable, {logs::LogTags::equationEditor, logs::LogTags::simplification});
            }
            // TODO Error processing?
            pCurrent = &equationTreeItem;
        }
    }
}

//=====================================================================================================================
void replaceByConstant(datamodel::EquationTreeItem &equationTreeItem, double number) {
    std::shared_ptr<datamodel::EquationNode> newNode(new datamodel::ConstantNode(number));
    // TODO Delete old CurrentNode is automatic?
    equationTreeItem.setCurrentNode(newNode);
    // TODO Delete old arguments?
    std::vector<datamodel::EquationTreeItem> vectArguments;
    equationTreeItem.setArguments(vectArguments);
}

//=====================================================================================================================
void replaceByOtherArgument(datamodel::EquationTreeItem &equationTreeItem, const datamodel::EquationTreeItem &otherTreeItem) {
    equationTreeItem.setCurrentNode(otherTreeItem.currentNode());

    std::vector<datamodel::EquationTreeItem> vectArguments;
    vectArguments.reserve(otherTreeItem.arguments().size());
    std::copy(otherTreeItem.arguments().begin(), otherTreeItem.arguments().end(), std::back_inserter(vectArguments));

    equationTreeItem.setArguments(vectArguments);
}

//=====================================================================================================================
//void simplifyConstantCloseToZero(datamodel::EquationTreeItem &equationTreeItem, uint nbVar) {
//    std::vector<double> variablesValue(nbVar,0.);
//    double nodeValue = equationTreeItem.currentNode()->value(variablesValue);
//    std::string valueString = std::to_string(nodeValue);

//    std::vector<std::string> list;
//    std::string separator = "e";

//    size_t pos = 0;
//    std::string token;
//    while ((pos = valueString.find(separator)) != std::string::npos) {
//        token = valueString.substr(0, pos);
//        valueString.erase(0, pos + separator.length());
//        list.push_back(token);
//    }
//    list.push_back(valueString);

//    if(list.size() == 2){
//        double exponentValue = std::stod(list.at(1));
//        double exponentMin = -6.0;
//        if(exponentValue < exponentMin){
//            replaceByConstant(equationTreeItem, 0);
//        }
//    }
//}

//void simplifyConstantCloseToOne(datamodel::EquationTreeItem &equationTreeItem, uint nbVar) {
//    std::vector<double> variablesValue(nbVar,0.);

//    double nodeValue = equationTreeItem.currentNode()->value(variablesValue);

//    double nodeValueMinusOne = nodeValue - 1;
//    std::string valueMinusOneString = std::to_string(nodeValueMinusOne);//t_1 QString valueMinusOneString = QString::number(nodeValueMinusOne);

//    std::vector<std::string> list;
//    std::string separator = "e";

//    size_t pos = 0;
//    std::string token;
//    while ((pos = valueMinusOneString.find(separator)) != std::string::npos) {
//        token = valueMinusOneString.substr(0, pos);
//        valueMinusOneString.erase(0, pos + separator.length());
//        list.push_back(token);
//    }

//    list.push_back(valueMinusOneString);

//    if(list.size() == 2){
//        double exponentValue = std::stod(list.at(1));
//        double exponentMin = -6.0;
//        if(exponentValue < exponentMin){
//            replaceByConstant(equationTreeItem, 1);
//            return;
//        }
//    }
//    double nodeValuePlusOne = nodeValue + 1;
//    std::string valuePlusOneString = std::to_string(nodeValuePlusOne);

//   while ((pos = valueMinusOneString.find(separator)) != std::string::npos) {
//        token = valueMinusOneString.substr(0, pos);
//        valueMinusOneString.erase(0, pos + separator.length());
//        list.push_back(token);
//    }
//    list.push_back(valueMinusOneString);

//    if(list.size() == 2){
//        double exponentValue = std::stod(list.at(1));
//        double exponentMin = -6.0;
//        if(exponentValue < exponentMin){
//            replaceByConstant(equationTreeItem, -1);
//            return;
//        }
//    }
//}

void simplifyConstant(datamodel::EquationTreeItem &equationTreeItem, uint nbVar){
    std::vector<double> variablesValue(nbVar,0.);
    double nodeValue = equationTreeItem.currentNode()->value(variablesValue);

    if (abs(round(nodeValue) - nodeValue) <= 0.000001) {
        replaceByConstant(equationTreeItem, round(nodeValue));
    }
}

//=====================================================================================================================
void simplifyAddition(datamodel::EquationTreeItem &equationTreeItem, uint nbVar) {

    bool constantExist{false};
    double result{0.};
    std::vector<double> variablesValue(nbVar,0.);
    std::vector<datamodel::EquationTreeItem> vectArguments;

    // constants simplification
    //-------------------------------------------------------------------------
    for(datamodel::EquationTreeItem &argument: equationTreeItem.arguments()){
        if(argument.currentNode()->type() == datamodel::EquationNode::Constant){
            simplifyConstant(argument, nbVar);
            result += argument.value(variablesValue);
            constantExist=true;
        } else {
            vectArguments.push_back(argument);
        }
    }


    // Addition of constants => constant
    //-------------------------------------------------------------------------
    if(constantExist){
        if(result != 0.){ //If the new calculated constant is 0 we ignore it
            std::shared_ptr<datamodel::EquationNode> newConstantNode(new datamodel::ConstantNode(result));
            datamodel::EquationTreeItem newConstantTreeItem(newConstantNode);
            vectArguments.push_back(newConstantTreeItem);
        }

        if(vectArguments.size() == 0){ //No sub-node left => We remplace the node by a 0 constant
            replaceByConstant(equationTreeItem, 0);
            return;
        } else if(vectArguments.size() == 1){ //Only one sub-node left => We remplace the node by the sub-node
            replaceByOtherArgument(equationTreeItem, vectArguments.front());
            return;
        } else {
            if(result < 0){ //This node become a soustraction with the new calculated constant at the end
                vectArguments.pop_back();

                std::shared_ptr<datamodel::EquationNode> newConstantNode(new datamodel::ConstantNode(-result));
                datamodel::EquationTreeItem newConstantTreeItem(newConstantNode);

                std::shared_ptr<datamodel::EquationNode> newSoustractionNode(new datamodel::SoustractionNode());
                datamodel::EquationTreeItem newSoustractionTreeItem(newSoustractionNode);

                if(vectArguments.size() == 1){ //Only one node left on the addition => soustraction
                    newSoustractionTreeItem.setArguments(std::vector<datamodel::EquationTreeItem>{vectArguments.front(), newConstantTreeItem});
                    replaceByOtherArgument(equationTreeItem, newSoustractionTreeItem);
                } else { //addition + negative constant => soustraction with left part addition and right part constant
                    std::shared_ptr<datamodel::EquationNode> newAdditionNode(new datamodel::AdditionNode(vectArguments.size()));
                    datamodel::EquationTreeItem newAdditionTreeItem(newAdditionNode);
                    newAdditionTreeItem.setArguments(vectArguments);

                    newSoustractionTreeItem.setArguments(std::vector<datamodel::EquationTreeItem>{newAdditionTreeItem, newConstantTreeItem});
                    replaceByOtherArgument(equationTreeItem, newSoustractionTreeItem);
                    //The current node became a soustraction but we didn't finish the simplification of the addition node
                    simplifyAddition(equationTreeItem.arguments().front(), nbVar);
                }
                return;
            } else { //We recreate the addition node with the new calculated constant at the end
                std::shared_ptr<datamodel::EquationNode> newAdditionNode(new datamodel::AdditionNode(vectArguments.size()));
                datamodel::EquationTreeItem newAdditionTreeItem(newAdditionNode);
                newAdditionTreeItem.setArguments(vectArguments);
                replaceByOtherArgument(equationTreeItem, newAdditionTreeItem);
            }
        }
    }

    //At this state we should have 0 constant or only one constant at the end of the addition

    // Addition of identical positive and negative => removed
    //-------------------------------------------------------------------------
    for(size_t i = 0; i < equationTreeItem.arguments().size() - 1;){
        bool oppositeFound{false};
        for(size_t j = i+1; j < equationTreeItem.arguments().size(); ++j){
            if(equationTreeItem.arguments()[i].currentNode()->type() == datamodel::EquationNode::Negative){
                //If the current value is negative we are looking for it's identical positive value
                if(equationTreeItem.arguments()[i].arguments().front() == equationTreeItem.arguments()[j]){ //ex: -X + X
                    oppositeFound=true;
                    vectArguments.erase(vectArguments.begin() + j);
                    vectArguments.erase(vectArguments.begin() + i);
                    break;
                }
            } else {
                //If the current value is positive we are looking for it's identical negative value
                if(equationTreeItem.arguments()[j].currentNode()->type() == datamodel::EquationNode::Negative &&
                        equationTreeItem.arguments()[i] == equationTreeItem.arguments()[j].arguments().front()){ //ex: X + -X
                    oppositeFound=true;
                    vectArguments.erase(vectArguments.begin() + j);
                    vectArguments.erase(vectArguments.begin() + i);
                    break;
                }
            }
        }
        if(oppositeFound){
            if(vectArguments.size() == 0){ //No sub-node left => We remplace the node by a 0 constant
                replaceByConstant(equationTreeItem, 0);
                return;
            } else if(vectArguments.size() == 1){ //Only one sub-node left => We remplace the node by the sub-node
                replaceByOtherArgument(equationTreeItem, vectArguments.front());
                return;
            } else { //We recreate the addition node without the two opposites values
                std::shared_ptr<datamodel::EquationNode> newAdditionNode(new datamodel::AdditionNode(vectArguments.size()));
                datamodel::EquationTreeItem newAdditionTreeItem(newAdditionNode);
                newAdditionTreeItem.setArguments(vectArguments);
                replaceByOtherArgument(equationTreeItem, newAdditionTreeItem);
            }
        } else i++;
    }

    // Addition of identical node => multiplication of this node
    //-------------------------------------------------------------------------
    for(size_t i = 0; i < equationTreeItem.arguments().size() - 1; ++i){
        int nbOccurences = 1;
        for(size_t j = i+1; j < vectArguments.size();){
            if(equationTreeItem.arguments()[i] == vectArguments[j]){
                nbOccurences++;
                vectArguments.erase(vectArguments.begin() + j);
            } else j++;
        }
        if (nbOccurences > 1){ //There is identical nodes in our addition
            //We create the multiplication node
            std::shared_ptr<datamodel::EquationNode> newMultiplicationNode(new datamodel::MultiplicationNode());
            datamodel::EquationTreeItem newMultiplicationTreeItem(newMultiplicationNode);

            if(equationTreeItem.arguments()[i].currentNode()->type() == datamodel::EquationNode::Negative){ //The negative is deplaced on the constant, ex: 2*(-X) => -2*X
                //We create the constant node corresponding to the number of occurences
                std::shared_ptr<datamodel::EquationNode> newConstantNode(new datamodel::ConstantNode(-nbOccurences));
                datamodel::EquationTreeItem newConstantTreeItem(newConstantNode);
                //Multiplication node = -nbOccurences * occurence
                newMultiplicationTreeItem.setArguments(std::vector<datamodel::EquationTreeItem>{newConstantTreeItem, equationTreeItem.arguments()[i].arguments().front()});
            } else {
                //We create the constant node corresponding to the number of occurences
                std::shared_ptr<datamodel::EquationNode> newConstantNode(new datamodel::ConstantNode(nbOccurences));
                datamodel::EquationTreeItem newConstantTreeItem(newConstantNode);
                //Multiplication node = nbOccurences * occurence
                newMultiplicationTreeItem.setArguments(std::vector<datamodel::EquationTreeItem>{newConstantTreeItem, equationTreeItem.arguments()[i]});
            }

            if(vectArguments.size() > 1){
                //We replace the occurence by the multiplication node
                vectArguments[i] = newMultiplicationTreeItem;

                //We create the new addition node which replace the occurence node by the multiplication node and remove all other occurence nodes
                std::shared_ptr<datamodel::EquationNode> newAdditionNode(new datamodel::AdditionNode(vectArguments.size()));
                datamodel::EquationTreeItem newAdditionTreeItem(newAdditionNode);
                newAdditionTreeItem.setArguments(vectArguments);

                //We replace the current addition node by the new one
                replaceByOtherArgument(equationTreeItem, newAdditionTreeItem);
            } else {
                //If there is only one element left we replace the addition by the multiplication
                replaceByOtherArgument(equationTreeItem, newMultiplicationTreeItem);
                return;
            }
        }
    }
}

//=====================================================================================================================
void simplifySoustraction(datamodel::EquationTreeItem &equationTreeItem, uint nbVar) {
    // Soustraction of same value => 0
    //-------------------------------------------------------------------------
    if (equationTreeItem.arguments().front() == equationTreeItem.arguments().back()) {
        replaceByConstant(equationTreeItem, 0);
        return;
    }

    datamodel::EquationTreeItem firstItem = equationTreeItem.arguments().at(0);
    if (firstItem.currentNode()->type() == datamodel::EquationNode::Constant)
        simplifyConstant(firstItem, nbVar);
    datamodel::EquationTreeItem secondItem = equationTreeItem.arguments().at(1);
    if (secondItem.currentNode()->type() == datamodel::EquationNode::Constant)
        simplifyConstant(secondItem, nbVar);

    // Soustraction of constants => constant
    //-------------------------------------------------------------------------
    std::vector<double> variablesValue(nbVar,0.);

    if (equationTreeItem.arguments().at(0).currentNode()->type() == datamodel::EquationNode::Constant &&
            equationTreeItem.arguments().at(1).currentNode()->type() == datamodel::EquationNode::Constant) {
        double result = equationTreeItem.arguments().at(0).value(variablesValue) - equationTreeItem.arguments().at(1).value(variablesValue);
        replaceByConstant(equationTreeItem, result);
        return;
    }

    // Soustraction of 0 (ie Z - 0) => other argument
    //-------------------------------------------------------------------------
    if ( equationTreeItem.arguments().at(1).currentNode()->type() == datamodel::EquationNode::Constant &&
                                 equationTreeItem.arguments().at(1).value(variablesValue) == 0) {
        const datamodel::EquationTreeItem &otherTreeItem = equationTreeItem.arguments().at(0);
        replaceByOtherArgument(equationTreeItem, otherTreeItem);
        return;
    }

    // Soustraction of 0 (ie 0 - Z) => (-1 * other argument)
    //-------------------------------------------------------------------------
    if ( equationTreeItem.arguments().at(0).currentNode()->type() == datamodel::EquationNode::Constant &&
                                 equationTreeItem.arguments().at(0).value(variablesValue) == 0) {
        const datamodel::EquationTreeItem &otherTreeItem = equationTreeItem.arguments().at(1);

        std::shared_ptr<datamodel::EquationNode> newNode(new datamodel::MultiplicationNode());
        equationTreeItem.setCurrentNode(newNode);
        datamodel::EquationTreeItem constantLeft( std::shared_ptr<datamodel::EquationNode>(new datamodel::ConstantNode(-1)) );
        equationTreeItem.setArguments(std::vector<datamodel::EquationTreeItem>{constantLeft, otherTreeItem});
        return;
    }

    // Soustraction of negative => Addition of positive
    //-------------------------------------------------------------------------
    if ( equationTreeItem.arguments().at(1).currentNode()->type() == datamodel::EquationNode::Negative) {
        const datamodel::EquationTreeItem &negativeTreeItem = equationTreeItem.arguments().at(1).arguments().at(0);
        const datamodel::EquationTreeItem &otherTreeItem = equationTreeItem.arguments().at(0);
        std::shared_ptr<datamodel::EquationNode> newNode(new datamodel::AdditionNode());
        equationTreeItem.setCurrentNode(newNode);
        datamodel::EquationTreeItem leftArgument = otherTreeItem;
        datamodel::EquationTreeItem rightArgument = negativeTreeItem;
        equationTreeItem.setArguments(std::vector<datamodel::EquationTreeItem>{leftArgument, rightArgument});
        return;
    }

    // Addition of negative constant => Soustraction of positive constant
    //-------------------------------------------------------------------------
    if ( (equationTreeItem.arguments().at(1).currentNode()->type() == datamodel::EquationNode::Constant &&
         equationTreeItem.arguments().at(1).value(variablesValue) < 0) ) {
        double result = -equationTreeItem.arguments().at(1).value(variablesValue);
        const datamodel::EquationTreeItem &otherTreeItem = equationTreeItem.arguments().at(0);
        std::shared_ptr<datamodel::EquationNode> newNode(new datamodel::AdditionNode());
        equationTreeItem.setCurrentNode(newNode);
        datamodel::EquationTreeItem leftArgument = otherTreeItem;
        datamodel::EquationTreeItem rightArgument( std::shared_ptr<datamodel::EquationNode>(new datamodel::ConstantNode(result)) );
        equationTreeItem.setArguments(std::vector<datamodel::EquationTreeItem>{leftArgument, rightArgument});
        return;
    }
}

//=====================================================================================================================
void simplifyMultiplication(datamodel::EquationTreeItem &equationTreeItem, uint nbVar) {

    std::vector<double> variablesValue(nbVar,0.);
    double result{1.};
    bool constantExist{false};
    std::vector<datamodel::EquationTreeItem> vectArguments;

    // Constants simplification
    for(datamodel::EquationTreeItem &argument: equationTreeItem.arguments()){
        if(argument.currentNode()->type() == datamodel::EquationNode::Constant){
            simplifyConstant(argument, nbVar);
            result *= argument.value(variablesValue);
            constantExist = true;
        } else {
            vectArguments.push_back(argument);
        }
    }

    // Multiplication of constants => constant
    //-------------------------------------------------------------------------
    if(constantExist){
        if(result == 0.){ //If the new calculated constant is 0, the whole multiplication is 0
            replaceByConstant(equationTreeItem, 0);
            return;
        }

        if(vectArguments.size() == 0){ //All value were constants => We replace it by the result of all constants
            replaceByConstant(equationTreeItem, result);
            return;
        } else { //We recreate the multiplication node with the result of cumulated constant at the beginning
            if(result == -1.){ //If the new calculated constant is -1, we ignore it but we change the sign of the next node
                if(vectArguments.front().currentNode()->type() == datamodel::EquationNode::Negative){
                    vectArguments.front() = vectArguments.front().arguments().front();
                } else {
                    //We create the negative node with the first node of the multiplication
                    std::shared_ptr<datamodel::NegativeNode> newNegativeNode(new datamodel::NegativeNode());
                    datamodel::EquationTreeItem newNegativeTreeItem(newNegativeNode);
                    newNegativeTreeItem.setArguments(std::vector<datamodel::EquationTreeItem>{vectArguments.front()});
                    vectArguments.front() = newNegativeTreeItem;
                }
            } else if(result != 1.){ //If the new calculated constant is 1, we ignore it
                //We create the constant node with the result
                std::shared_ptr<datamodel::EquationNode> newConstantNode(new datamodel::ConstantNode(result));
                datamodel::EquationTreeItem newConstantTreeItem(newConstantNode);
                //We insert the constant at the front for easier lisibility
                vectArguments.insert(vectArguments.begin(), newConstantTreeItem);
            }

            if(vectArguments.size() == 1){ //One node left => the node left become the current node
                replaceByOtherArgument(equationTreeItem, vectArguments.front());
                return;
            } else {
                std::shared_ptr<datamodel::EquationNode> newMultiplicationNode(new datamodel::MultiplicationNode(vectArguments.size()));
                datamodel::EquationTreeItem newMultiplicationTreeItem(newMultiplicationNode);
                newMultiplicationTreeItem.setArguments(vectArguments);
                replaceByOtherArgument(equationTreeItem, newMultiplicationTreeItem);
            }
        }
    }

    //At this state we should have only one constant at the beginning of the multiplication or no constant at all

    // Multiplication of negatives => Multiplication of positives
    //-------------------------------------------------------------------------
    for(size_t i = 0; i < equationTreeItem.arguments().size() - 1; ++i){
        if(equationTreeItem.arguments()[i].currentNode()->type() == datamodel::EquationNode::Negative){
            for(size_t j = i+1; j < equationTreeItem.arguments().size(); ++j){
                if(equationTreeItem.arguments()[j].currentNode()->type() == datamodel::EquationNode::Negative){

                    //We remove the negations of the two arguments
                    vectArguments = equationTreeItem.arguments();
                    vectArguments[i] = equationTreeItem.arguments()[i].arguments().front();
                    vectArguments[j] = equationTreeItem.arguments()[j].arguments().front();

                    //In the new multiplication we replace the two negatives by the two positives
                    std::shared_ptr<datamodel::EquationNode> newMultiplicationNode(new datamodel::MultiplicationNode(vectArguments.size()));
                    datamodel::EquationTreeItem newMultiplicationTreeItem(newMultiplicationNode);
                    newMultiplicationTreeItem.setArguments(vectArguments);
                    replaceByOtherArgument(equationTreeItem, newMultiplicationTreeItem);
                    break;
                }
            }
        }
    }

    // Multiplication of same values => powers of single value (ex: (X * X) => (X ^ 2))
    //-------------------------------------------------------------------------
    for(size_t i = 0; i < equationTreeItem.arguments().size() - 1; ++i){
        unsigned int nbOccurences = 1;
        unsigned int nbNegatives = 0;
        datamodel::EquationTreeItem currentArgument;
        if(equationTreeItem.arguments()[i].currentNode()->type() == datamodel::EquationNode::Negative){
            currentArgument = equationTreeItem.arguments()[i].arguments().front();
            nbNegatives++;
        } else {
            currentArgument = equationTreeItem.arguments()[i];
        }

        for(size_t j = i+1; j < vectArguments.size();){
            if(equationTreeItem.arguments()[j].currentNode()->type() == datamodel::EquationNode::Negative){
                if(equationTreeItem.arguments()[j].arguments().front() == currentArgument){
                    nbNegatives++;
                    nbOccurences++;
                    vectArguments.erase(vectArguments.begin() + j);
                } else j++;
            } else {
                if(equationTreeItem.arguments()[j] == currentArgument){
                    nbOccurences++;
                    vectArguments.erase(vectArguments.begin() + j);
                } else  j++;
            }
        }

        if(nbOccurences > 1){
            //We create the power node
            std::shared_ptr<datamodel::EquationNode> newPowerNode(new datamodel::PowerNode());
            datamodel::EquationTreeItem newPowerTreeItem(newPowerNode);

            //We create the constant node corresponding to the number of occurences
            std::shared_ptr<datamodel::EquationNode> newConstantNode(new datamodel::ConstantNode(nbOccurences));
            datamodel::EquationTreeItem newConstantTreeItem(newConstantNode);

            if(nbNegatives % 2 == 0){ //Factorisation is positive
                //Power node = occurence ^ nbOccurences
                newPowerTreeItem.setArguments(std::vector<datamodel::EquationTreeItem>{currentArgument, newConstantTreeItem});
            } else { //Factorisation is negative
                //We create the negative node => -occurence
                std::shared_ptr<datamodel::EquationNode> newNegativeNode(new datamodel::NegativeNode());
                datamodel::EquationTreeItem newNegativeTreeItem(newNegativeNode);
                newNegativeTreeItem.setArguments(std::vector<datamodel::EquationTreeItem>{currentArgument});

                //Power node = (-occurence) ^ nbOccurences
                newPowerTreeItem.setArguments(std::vector<datamodel::EquationTreeItem>{newNegativeTreeItem, newConstantTreeItem});
            }

            if(vectArguments.size() == 1){ //If there is only one element left we replace the multiplication by the power
                replaceByOtherArgument(equationTreeItem, newPowerTreeItem);
                return;
            } else {
                //We replace the occurence by the power node
                vectArguments[i] = newPowerTreeItem;

                //We create the new multiplication node which replace the occurence node by the power node and remove all other occurence nodes
                std::shared_ptr<datamodel::EquationNode> newMultiplicationNode(new datamodel::MultiplicationNode(vectArguments.size()));
                datamodel::EquationTreeItem newMultiplicationTreeItem(newMultiplicationNode);
                newMultiplicationTreeItem.setArguments(vectArguments);

                replaceByOtherArgument(equationTreeItem, newMultiplicationTreeItem);
            }
        }
    }
}

//=====================================================================================================================
void simplifyDivision(datamodel::EquationTreeItem &equationTreeItem, uint nbVar) {
    datamodel::EquationTreeItem firstItem = equationTreeItem.arguments().at(0);
    if (firstItem.currentNode()->type() == datamodel::EquationNode::Constant) {
        simplifyConstant(firstItem, nbVar);
    }
    datamodel::EquationTreeItem secondItem = equationTreeItem.arguments().at(1);
    if (secondItem.currentNode()->type() == datamodel::EquationNode::Constant)
        simplifyConstant(secondItem, nbVar);

    // Division of constants => constant
    //-------------------------------------------------------------------------
    std::vector<double> variablesValue(nbVar,0.);

    if (equationTreeItem.arguments().at(0).currentNode()->type() == datamodel::EquationNode::Constant &&
            equationTreeItem.arguments().at(1).currentNode()->type() == datamodel::EquationNode::Constant) {
        if (equationTreeItem.arguments().at(1).value(variablesValue) == 0) {
            throw std::runtime_error("Case of division by 0");
            return;
        }

        double result = equationTreeItem.arguments().at(0).value(variablesValue) / equationTreeItem.arguments().at(1).value(variablesValue);
        replaceByConstant(equationTreeItem, result);
        return;
    }

    // Division by 1 (ie Z / 1) => other argument
    //-------------------------------------------------------------------------
    if (equationTreeItem.arguments().at(1).currentNode()->type() == datamodel::EquationNode::Constant &&
            equationTreeItem.arguments().at(1).value(variablesValue) == 1) {
        const datamodel::EquationTreeItem &otherTreeItem = equationTreeItem.arguments().at(0);
        replaceByOtherArgument(equationTreeItem, otherTreeItem);
        return;
    }

    // "x / x" => constant = 1
    //-------------------------------------------------------------------------
    if (equationTreeItem.arguments().front() == equationTreeItem.arguments().back()) {
        replaceByConstant(equationTreeItem, 1);
        return;
    }
}

//=====================================================================================================================
void simplifyCosinus(datamodel::EquationTreeItem &equationTreeItem, uint nbVar) {
    // Cosinus of constant => constant
    //-------------------------------------------------------------------------
    std::vector<double> variablesValue(nbVar,0.);

    if (equationTreeItem.arguments().at(0).currentNode()->type() == datamodel::EquationNode::Constant) {
        double result = cos(equationTreeItem.arguments().at(0).value(variablesValue));
        replaceByConstant(equationTreeItem, result);
        return;
    }
}

//=====================================================================================================================
void simplifySinus(datamodel::EquationTreeItem &equationTreeItem, uint nbVar) {
    // Sinus of constant => constant
    //-------------------------------------------------------------------------
    std::vector<double> variablesValue(nbVar,0.);

    if (equationTreeItem.arguments().at(0).currentNode()->type() == datamodel::EquationNode::Constant) {
        double result = sin(equationTreeItem.arguments().at(0).value(variablesValue));
        replaceByConstant(equationTreeItem, result);
        return;
    }
}

//=====================================================================================================================
void simplifyTangent(datamodel::EquationTreeItem &equationTreeItem, uint nbVar) {
    // Sinus of constant => constant
    //-------------------------------------------------------------------------
    std::vector<double> variablesValue(nbVar,0.);

    if (equationTreeItem.arguments().at(0).currentNode()->type() == datamodel::EquationNode::Constant) {
        double result = tan(equationTreeItem.arguments().at(0).value(variablesValue));
        replaceByConstant(equationTreeItem, result);
        return;
    }
}

//=====================================================================================================================
void simplifyLogarithm(datamodel::EquationTreeItem &equationTreeItem, uint nbVar) {
    // Logarithm of constant => constant
    //-------------------------------------------------------------------------
    std::vector<double> variablesValue(nbVar,0.);

    if (equationTreeItem.arguments().at(0).currentNode()->type() == datamodel::EquationNode::Constant) {
        double result = log(equationTreeItem.arguments().at(0).value(variablesValue));
        replaceByConstant(equationTreeItem, result);
        return;
    }
}

//=====================================================================================================================
void simplifyExponential(datamodel::EquationTreeItem &equationTreeItem, uint nbVar) {
    // Exponential of constant => constant
    //-------------------------------------------------------------------------
    std::vector<double> variablesValue(nbVar,0.);

    if (equationTreeItem.arguments().at(0).currentNode()->type() == datamodel::EquationNode::Constant)
    {
        double result = exp(equationTreeItem.arguments().at(0).value(variablesValue));
        replaceByConstant(equationTreeItem, result);
        return;
    }

    // Exponential of logarithm => expr
    //-------------------------------------------------------------------------
    if (equationTreeItem.arguments().at(0).currentNode()->type() == datamodel::EquationNode::Logarithm)
    {
        datamodel::EquationTreeItem item = equationTreeItem.arguments().at(0);
        replaceByOtherArgument(equationTreeItem, item.arguments().at(0));
        return;
    }
}

//=====================================================================================================================
void simplifyPower(datamodel::EquationTreeItem &equationTreeItem, uint nbVar) {
    datamodel::EquationTreeItem firstItem = equationTreeItem.arguments().at(0);
    if (firstItem.currentNode()->type() == datamodel::EquationNode::Constant)
        simplifyConstant(firstItem, nbVar);
    datamodel::EquationTreeItem secondItem = equationTreeItem.arguments().at(1);
    if (secondItem.currentNode()->type() == datamodel::EquationNode::Constant){
        simplifyConstant(secondItem, nbVar);
    }
    std::vector<double> variablesValue(nbVar,0.);

    // Power of 0 => constant = 1
    //-------------------------------------------------------------------------
    if (equationTreeItem.arguments().at(1).currentNode()->type() == datamodel::EquationNode::Constant &&
            equationTreeItem.arguments().at(1).value(variablesValue) == 0) {
        replaceByConstant(equationTreeItem, 1);
        return;
    }
    // 1 power n => 1
    //-------------------------------------------------------------------------
    if ( equationTreeItem.arguments().at(0).currentNode()->type() == datamodel::EquationNode::Constant &&
                                 equationTreeItem.arguments().at(0).value(variablesValue) == 1) {
        replaceByConstant(equationTreeItem, 1);
        return;
    }

    // Power of 1 => other argument
    //-------------------------------------------------------------------------
    if ( equationTreeItem.arguments().at(1).currentNode()->type() == datamodel::EquationNode::Constant &&
                                 equationTreeItem.arguments().at(1).value(variablesValue) == 1) {
        const datamodel::EquationTreeItem &otherTreeItem = equationTreeItem.arguments().at(0);
        replaceByOtherArgument(equationTreeItem, otherTreeItem);
        return;
    }

    // Power of constants => constant
    //-------------------------------------------------------------------------
    if (equationTreeItem.arguments().at(0).currentNode()->type() == datamodel::EquationNode::Constant &&
            equationTreeItem.arguments().at(1).currentNode()->type() == datamodel::EquationNode::Constant) {
        double result = pow(equationTreeItem.arguments().at(0).value(variablesValue), equationTreeItem.arguments().at(1).value(variablesValue));
        replaceByConstant(equationTreeItem, result);
        return;
    }
}

//=====================================================================================================================
void simplifySquareRoot(datamodel::EquationTreeItem &equationTreeItem, uint nbVar)
{
    // SquareRoot of constant => constant
    //-------------------------------------------------------------------------
    std::vector<double> variablesValue(nbVar,0.);

    if (equationTreeItem.arguments().at(0).currentNode()->type() == datamodel::EquationNode::Constant) {
        double result = sqrt(equationTreeItem.arguments().at(0).value(variablesValue));
        replaceByConstant(equationTreeItem, result);
        return;
    }
}

//=====================================================================================================================
void simplifyMin(datamodel::EquationTreeItem &equationTreeItem, uint nbVar)
{
    // Min of constants => constant
    //-------------------------------------------------------------------------
    std::vector<double> variablesValue(nbVar,0.);

    if (equationTreeItem.arguments().at(0).currentNode()->type() == datamodel::EquationNode::Constant &&
            equationTreeItem.arguments().at(1).currentNode()->type() == datamodel::EquationNode::Constant) {
        double result = std::min(equationTreeItem.arguments().at(0).value(variablesValue), equationTreeItem.arguments().at(1).value(variablesValue));
        replaceByConstant(equationTreeItem, result);
        return;
    }
}

//=====================================================================================================================
void simplifyMax(datamodel::EquationTreeItem &equationTreeItem, uint nbVar)
{
    // Max of constants => constant
    //-------------------------------------------------------------------------
    std::vector<double> variablesValue(nbVar,0.);

    if (equationTreeItem.arguments().at(0).currentNode()->type() == datamodel::EquationNode::Constant &&
            equationTreeItem.arguments().at(1).currentNode()->type() == datamodel::EquationNode::Constant) {
        double result = std::max(equationTreeItem.arguments().at(0).value(variablesValue), equationTreeItem.arguments().at(1).value(variablesValue));
        replaceByConstant(equationTreeItem, result);
        return;
    }
}

//=====================================================================================================================
void simplifyAbsolute(datamodel::EquationTreeItem &equationTreeItem, uint nbVar)
{
    // Absolute of constant => constant
    //-------------------------------------------------------------------------
    std::vector<double> variablesValue(nbVar,0.);

    if (equationTreeItem.arguments().at(0).currentNode()->type() == datamodel::EquationNode::Constant) {
        double result = fabs(equationTreeItem.arguments().at(0).value(variablesValue));
        replaceByConstant(equationTreeItem, result);
        return;
    }
}

//=====================================================================================================================
void simplifyInverse(datamodel::EquationTreeItem &equationTreeItem, uint nbVar)
{
    // Division of constants => constant
    //-------------------------------------------------------------------------
    std::vector<double> variablesValue(nbVar,0.);

    if (equationTreeItem.arguments().at(0).currentNode()->type() == datamodel::EquationNode::Constant) {
        if (equationTreeItem.arguments().at(0).value(variablesValue) == 0) {
            equationTreeItem.arguments().at(0).value(variablesValue);
            throw std::runtime_error("Case of division by 0");
            return;
        }

        double result = 1 / equationTreeItem.arguments().at(0).value(variablesValue);
        replaceByConstant(equationTreeItem, result);
        return;
    }
}

//=====================================================================================================================
void simplifyArctan(datamodel::EquationTreeItem &equationTreeItem, uint nbVar)
{
    // Cosinus of constant => constant
    //-------------------------------------------------------------------------
    std::vector<double> variablesValue(nbVar,0.);

    if (equationTreeItem.arguments().at(0).currentNode()->type() == datamodel::EquationNode::Constant)
    {
        double result = atan(equationTreeItem.arguments().at(0).value(variablesValue));
        replaceByConstant(equationTreeItem, result);
        return;
    }
}

//=====================================================================================================================
void simplifyNegative(datamodel::EquationTreeItem &equationTreeItem, uint nbVar)
{
    // Absolute of constant => constant
    //-------------------------------------------------------------------------
    std::vector<double> variablesValue(nbVar,0.);

    if (equationTreeItem.arguments().at(0).currentNode()->type() == datamodel::EquationNode::Constant)
    {
        double result = (-1) * equationTreeItem.arguments().at(0).value(variablesValue);
        replaceByConstant(equationTreeItem, result);
        return;
    }
}

//=====================================================================================================================
// Leaf simplification
// bool -> void? Used for Unit Test.
bool equationSimplifier(datamodel::EquationTreeItem &equationTreeItem, uint nbVar)
{
    if (!equationTreeItem.currentNode())
    {
        //qWarning() << "Cannot generate string for an equation without current node";
        logs::Logger::logWarning("Cannot generate string for an equation without current node", {logs::LogTags::equationEditor, logs::LogTags::simplification});
        return false;
    }

    if (equationTreeItem.currentNode()->nbArguments() != equationTreeItem.arguments().size())
    {
        //qWarning(
        //    "Cannot generate string for equation with different number of arguments "
        //    "(%d) then expected (%zu)",
        //    equationTreeItem.currentNode()->nbArguments(), equationTreeItem.arguments().size());
        std::string message_warning_equation_different_argument_Simplifier = "Cannot generate string for equation with different number of arguments "
                + std::to_string(equationTreeItem.currentNode()->nbArguments())
                + " then expected "
                + std::to_string(equationTreeItem.arguments().size());
        logs::Logger::logWarning(message_warning_equation_different_argument_Simplifier, {logs::LogTags::equationEditor, logs::LogTags::simplification});
        return false;
    }

    switch (equationTreeItem.currentNode()->type())
    {
        case datamodel::EquationNode::Constant:
            //Constant simplification must be done depending on what operation is using that constant
            break;
        case datamodel::EquationNode::Variable:
            break;
        case datamodel::EquationNode::Addition:
            simplifyAddition(equationTreeItem, nbVar);
            break;
        case datamodel::EquationNode::Soustraction:
            simplifySoustraction(equationTreeItem, nbVar);
            break;
        case datamodel::EquationNode::Multiplication:
            simplifyMultiplication(equationTreeItem, nbVar);
            break;
        case datamodel::EquationNode::Division:
            simplifyDivision(equationTreeItem, nbVar);
            break;
        case datamodel::EquationNode::Cosinus:
            simplifyCosinus(equationTreeItem, nbVar);
            break;
        case datamodel::EquationNode::Sinus:
            simplifySinus(equationTreeItem, nbVar);
            break;
        case datamodel::EquationNode::Tan:
            simplifyTangent(equationTreeItem, nbVar);
            break;
        case datamodel::EquationNode::Logarithm:
            simplifyLogarithm(equationTreeItem, nbVar);
            break;
        case datamodel::EquationNode::Exponential:
            simplifyExponential(equationTreeItem, nbVar);
            break;
        case datamodel::EquationNode::Power:
            simplifyPower(equationTreeItem, nbVar);
            break;
        case datamodel::EquationNode::SquareRoot:
            simplifySquareRoot(equationTreeItem, nbVar);
            break;
        case datamodel::EquationNode::Min:
            simplifyMin(equationTreeItem, nbVar);
            break;
        case datamodel::EquationNode::Max:
            simplifyMax(equationTreeItem, nbVar);
            break;
        case datamodel::EquationNode::Absolute:
            simplifyAbsolute(equationTreeItem, nbVar);
            break;
        case datamodel::EquationNode::Arctan:
            simplifyArctan(equationTreeItem, nbVar);
            break;
        case datamodel::EquationNode::Inverse:
            simplifyInverse(equationTreeItem, nbVar);
            break;
        case datamodel::EquationNode::Negative:
            simplifyNegative(equationTreeItem, nbVar);
            break;
    }
    return true;
}

}  // namespace equationeditors
