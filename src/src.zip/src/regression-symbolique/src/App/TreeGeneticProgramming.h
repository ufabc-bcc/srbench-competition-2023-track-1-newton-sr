#pragma once

#include <QObject>

namespace algorithmcontroller {
class AlgorithmController;
}

namespace viewcontroller {
class EquationsListController;
class ParametersControllers;
class EquationPlotterController;
class EquationParetoEfficiencyController;
}

/*!
 * @brief High level class managing the application
 */
class TreeGeneticProgramming : public QObject
{
    Q_OBJECT

    Q_PROPERTY(
        viewcontroller::ParametersControllers *parametersControllers READ parametersControllers CONSTANT)
  public:
    /*!
     * @brief Construct an instance with the given parent
     * @param parent the parent of the instance
     */
    explicit TreeGeneticProgramming(QObject* parent = nullptr);

    /*!
     * @brief Destructor
     */
    ~TreeGeneticProgramming() override;

    /*!
     * @brief Register the qml types for the qml
     */
    void registerQmlTypes();

    /*!
     * @brief Get the controller of the algorithm of generation of the algorithm and of genetic evolutions
     * @return the controller of the algorithm of generation of the algorithm and of genetic evolutions
     */
    algorithmcontroller::AlgorithmController *algorithmController();

    /*!
     * @brief Get the list view of the list of the equations
     * @return the list view of the list of the equations
     */
    viewcontroller::EquationsListController *equationListController();

    /**
     * @brief Get the object that controls the EquationPlotter
     * @return viewcontroller::EquationPlotterControler* 
     */
    viewcontroller::EquationPlotterController* equationPlotterController();

    /*!
     * @brief Get the high level class managing the parameters of the application
     * @return the high level class managing the parameters of the application
     */
    viewcontroller::ParametersControllers *parametersControllers();


private:

  /**
   * @brief Simply a helper function to regroup QObject::connect tied to the ParametersController
   */
  void connectParametersControllerEvents();
  
    Q_DISABLE_COPY_MOVE(TreeGeneticProgramming)

    viewcontroller::ParametersControllers *_parametersControllers{nullptr};

    algorithmcontroller::AlgorithmController *_algorithmController{nullptr};

    viewcontroller::EquationsListController *_equationListController{nullptr};

    viewcontroller::EquationParetoEfficiencyController *_equationParetoController{nullptr};

    viewcontroller::EquationPlotterController* _equationPlotterController{nullptr};
};
