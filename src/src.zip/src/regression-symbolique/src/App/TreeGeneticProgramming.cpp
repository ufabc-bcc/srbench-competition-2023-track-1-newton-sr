#include "TreeGeneticProgramming.h"

#include <QtQml/QQmlEngine>

#include "AlgorithmControllers/AlgorithmController.h"
#include "Utils/AppFileSystem.h"
#include "ViewControllers/DataListFormatter.h"
#include "ViewControllers/EquationsListController.h"
#include "ViewControllers/EquationParetoEfficiencyController.h"
#include "ViewControllers/FilesSelectionController.h"
#include "ViewControllers/ParametersControllers.h"
#include "ViewControllers/EquationPlotterController.h"
#include "ViewControllers/EquationPlotterController.h"
#include "ViewControllers/benchmarkcontroller.h"



void TreeGeneticProgramming::connectParametersControllerEvents()
{
    QObject::connect(_parametersControllers, &viewcontroller::ParametersControllers::initButtonClicked,
                     _algorithmController, &algorithmcontroller::AlgorithmController::onEquationGenerationRequired);


//    QObject::connect(_parametersControllers, &viewcontroller::ParametersControllers::fitParametersUpdate,
//                     _algorithmController,
//                     &algorithmcontroller::AlgorithmController::onFitParametersUpdate);

    QObject::connect(_parametersControllers, &viewcontroller::ParametersControllers::startButtonClicked,
                     _algorithmController, &algorithmcontroller::AlgorithmController::onStartGeneration);

    QObject::connect(_parametersControllers, &viewcontroller::ParametersControllers::continueButtonClicked,
                     _algorithmController, &algorithmcontroller::AlgorithmController::continueGeneration);

    QObject::connect(_parametersControllers, &viewcontroller::ParametersControllers::resetButtonClicked,
                     _algorithmController, &algorithmcontroller::AlgorithmController::resetGeneration);

    // each time we click on the "generate x generation" button => we clear the fitness and pareto chart
    QObject::connect(_parametersControllers, &viewcontroller::ParametersControllers::startButtonClicked,
                     [this] { _equationListController->clearFitnessChart(); });

    QObject::connect(_parametersControllers, &viewcontroller::ParametersControllers::inputDataSelected,
                     _algorithmController, &algorithmcontroller::AlgorithmController::onInputDataSelected);

    QObject::connect(_parametersControllers, &viewcontroller::ParametersControllers::pauseButtonClicked,
                     _algorithmController, &algorithmcontroller::AlgorithmController::stopGenerationThread);
}

TreeGeneticProgramming::TreeGeneticProgramming(QObject *parent)
    : QObject(parent),
      _parametersControllers(new viewcontroller::ParametersControllers(this)),
      _algorithmController(new algorithmcontroller::AlgorithmController(this)),
      _equationListController(new viewcontroller::EquationsListController(this)),
      _equationPlotterController(new viewcontroller::EquationPlotterController(this))
{
    connectParametersControllerEvents();

    QObject::connect(_algorithmController, &algorithmcontroller::AlgorithmController::nonInfiniteGenerationComplete,
                     _parametersControllers, &viewcontroller::ParametersControllers::refreshStartButton);

    QObject::connect(_algorithmController, &algorithmcontroller::AlgorithmController::setRedDistance,
                     _parametersControllers, &viewcontroller::ParametersControllers::redDistanceMin);
    QObject::connect(_algorithmController, &algorithmcontroller::AlgorithmController::setRedNumberOfGenerations,
                     _parametersControllers, &viewcontroller::ParametersControllers::redNumberOfGenerations);
    QObject::connect(_algorithmController, &algorithmcontroller::AlgorithmController::setRedTime,
                     _parametersControllers, &viewcontroller::ParametersControllers::redTime);

    QObject::connect(_parametersControllers->equationGenerationController(), &viewcontroller::EquationsGeneratorController::realNumberPrecisionChanged,
                     _equationListController, &viewcontroller::EquationsListController::updatePrecision);

    // TODO Probably group every clear signal into 1
    QObject::connect(_algorithmController, &algorithmcontroller::AlgorithmController::clearEquationPlotter,
                     _equationPlotterController, &viewcontroller::EquationPlotterController::clearView);

    QObject::connect(_algorithmController, &algorithmcontroller::AlgorithmController::clearParetoRequest,
                     _parametersControllers->equationParetoEfficiencyController(), &viewcontroller::EquationParetoEfficiencyController::clear);

    QObject::connect(_algorithmController, &algorithmcontroller::AlgorithmController::clearParetoRequest,
                     _equationListController, &viewcontroller::EquationsListController::clearFitnessChart);

    QObject::connect(_algorithmController, &algorithmcontroller::AlgorithmController::equationsDataChanged,
                     _equationListController, &viewcontroller::EquationsListController::onEquationsDataChanged);

    QObject::connect(_algorithmController, &algorithmcontroller::AlgorithmController::generationCreated,
                     _equationListController, &viewcontroller::EquationsListController::onGenerationCreated );

    QObject::connect(_algorithmController, &algorithmcontroller::AlgorithmController::generationCountChanged,
                     _equationListController, &viewcontroller::EquationsListController::onGenerationCountChanged);

    QObject::connect(_algorithmController, &algorithmcontroller::AlgorithmController::equationsDataChanged,
                     _parametersControllers->equationParetoEfficiencyController(), &viewcontroller::EquationParetoEfficiencyController::onEquationsDataChanged);

    QObject::connect(_algorithmController->inputFileManager(),
                     &algorithmcontroller::InputFileManager::inputDatasChanged,
                     _parametersControllers->inputDataViewController(),
                     &viewcontroller::InputDataViewController::onInputDatasChanged);

    QObject::connect(_algorithmController->inputFileManager(),
                    &algorithmcontroller::InputFileManager::inputDatasChangedResetWindow,
                     _algorithmController, &algorithmcontroller::AlgorithmController::resetGeneration);

    QObject::connect(_algorithmController->inputFileManager(),
                     &algorithmcontroller::InputFileManager::inputDatasChangedInitStartButton,
                     _parametersControllers, &viewcontroller::ParametersControllers::initStartButton);

    QObject::connect(_equationListController, &viewcontroller::EquationsListController::textGenerationUpdated,
                     _parametersControllers, &viewcontroller::ParametersControllers::refreshTestGeneration);

    QObject::connect(_algorithmController, &algorithmcontroller::AlgorithmController::generationElapsedTimeUpdated,
                     _parametersControllers, &viewcontroller::ParametersControllers::refreshGenerationElapsedTime);

    QObject::connect(_algorithmController, &algorithmcontroller::AlgorithmController::generationElapsedTimeUpdated,
                     _parametersControllers, &viewcontroller::ParametersControllers::refreshGenerationElapsedTime);

    // Signal > Slot related to highlighting best equation (efficiency) in Equations List
    QObject::connect(_algorithmController, &algorithmcontroller::AlgorithmController::updateBestEfficiencyEquation,
                     [this](const datamodel::EquationTree equation) {
                        _equationListController->onBestEquationChanged(equation);
                    });

    // Signal > Slot related to plotting the best equation (efficiency)
    QObject::connect(_algorithmController, &algorithmcontroller::AlgorithmController::updateBestEfficiencyEquation,
                     [this](const datamodel::EquationTree equation) {
                        _equationPlotterController->onBestEfficiencyChanged(equation.root());
                    });

    QObject::connect(_algorithmController, &algorithmcontroller::AlgorithmController::benchmarkUpdated,
                  _equationListController, &viewcontroller::EquationsListController::updateBenchmarkSeries, Qt::BlockingQueuedConnection);

    QObject::connect(_algorithmController, &algorithmcontroller::AlgorithmController::benchmarkInit,
                  _equationListController, &viewcontroller::EquationsListController::initBenchmarkSeriesPtr);

    QObject::connect(_parametersControllers, &viewcontroller::ParametersControllers::resetBenchmarkChart,
                  _equationListController, &viewcontroller::EquationsListController::resetBenchmarkSeries);

    QObject::connect(_algorithmController, &algorithmcontroller::AlgorithmController::benchmarkReset,
                  _equationListController, &viewcontroller::EquationsListController::resetBenchmarkSeries);

    QObject::connect(_parametersControllers, &viewcontroller::ParametersControllers::processBenchmarkChanged,
                  _algorithmController, &algorithmcontroller::AlgorithmController::processBenchmarkChanged );

    QObject::connect(_equationListController, &viewcontroller::EquationsListController::equationSelected,
                     _equationPlotterController, &viewcontroller::EquationPlotterController::onEquationSelected);

    QObject::connect(_algorithmController, &algorithmcontroller::AlgorithmController::equationsDataChanged,
                     [this](const datamodel::EquationTree* equationsArray, uint equationsArraySize) {
                         if (equationsArraySize != 0)
                         {
                             _equationPlotterController->onBestChanged(equationsArray[0].root());
                         }
                     });

//    QObject::connect(_algorithmController->inputFileManager(),
//                    &algorithmcontroller::InputFileManager::inputDatasChangedResetWindow,
//                     _algorithmController, &algorithmcontroller::AlgorithmController::resetGeneration);

    QObject::connect(_parametersControllers->equationGenerationController(), &viewcontroller::EquationsGeneratorController::equationsListRefreshRateChanged,
                    _equationListController, &viewcontroller::EquationsListController::updateEquationsRefreshRate);

    QObject::connect(_parametersControllers, &viewcontroller::ParametersControllers::setDisplayEquationListControler,
                    _equationListController,  &viewcontroller::EquationsListController::setDisplayEquationListControler);


    QObject::connect(_parametersControllers, &viewcontroller::ParametersControllers::instantRefreshEquationListControler,
                    _equationListController,  &viewcontroller::EquationsListController::instantRefreshEquationListControler);

    QObject::connect(_algorithmController, &algorithmcontroller::AlgorithmController::instantRefreshEquationListControler,
                    _equationListController,  &viewcontroller::EquationsListController::instantRefreshEquationListControler);


    //QObject::connect(_parametersControllers->equationParetoEfficiencyController() , &viewcontroller::EquationParetoEfficiencyController::paretoRefreshRateChanged,
    //                _equationListController,  &viewcontroller::EquationsListController::updateParetoRefreshRate);

    QObject::connect(_parametersControllers->equationParetoEfficiencyController(), &viewcontroller::EquationParetoEfficiencyController::paretoRefreshRateChanged,
                    _parametersControllers->equationParetoEfficiencyController(), &viewcontroller::EquationParetoEfficiencyController::updateParetoRefreshRate);

    QObject::connect(_parametersControllers, &viewcontroller::ParametersControllers::setDisplayParetoController ,
                    _parametersControllers->equationParetoEfficiencyController(), &viewcontroller::EquationParetoEfficiencyController::setDisplayParetoController);


    QObject::connect(_parametersControllers, &viewcontroller::ParametersControllers::fitnessRefreshRateChanged,
                    _equationListController, &viewcontroller::EquationsListController::setFitnessRefreshRate);

    QObject::connect(_parametersControllers, &viewcontroller::ParametersControllers::setDisplayFitnessController ,
                    _equationListController, &viewcontroller::EquationsListController::setDisplayFitnessController );


    QObject::connect(_algorithmController, &algorithmcontroller::AlgorithmController::instantRefreshFitness,
                    _equationListController,  &viewcontroller::EquationsListController::instantRefreshFitness);

    QObject::connect(_parametersControllers, &viewcontroller::ParametersControllers::instantRefreshFitness,
                    _equationListController,  &viewcontroller::EquationsListController::instantRefreshFitness);

    QObject::connect(_parametersControllers, &viewcontroller::ParametersControllers::clearRefreshEquationListControler,
                    _equationListController,  &viewcontroller::EquationsListController::clearRefreshEquationListControler);



    QObject::connect(_algorithmController, &algorithmcontroller::AlgorithmController::clearRefreshEquationListControler ,
                    _equationListController,  &viewcontroller::EquationsListController::clearRefreshEquationListControler);

    QObject::connect(_parametersControllers->benchmarkController(), &viewcontroller::BenchmarkController::sendProcessBenchmark,
                    _parametersControllers->benchmarkController(), &viewcontroller::BenchmarkController::receiveProcessBenchmark);

    QObject::connect(_parametersControllers->benchmarkController(), &viewcontroller::BenchmarkController::sendDisplaySignalsBench,
                    _parametersControllers->benchmarkController(), &viewcontroller::BenchmarkController::receiveDisplaySignalsBench);

    QObject::connect(_parametersControllers->benchmarkController(), &viewcontroller::BenchmarkController::sendDisplayFitnessBench,
                    _parametersControllers->benchmarkController(), &viewcontroller::BenchmarkController::receiveDisplayFitnessBench);









    QObject::connect(_equationListController,&viewcontroller::EquationsListController::equationSelected,
                     _equationPlotterController,&viewcontroller::EquationPlotterController::onEquationSelected);

//    QObject::connect(_algorithmController->inputFileManager(),
//                       &algorithmcontroller::InputFileManager::inputDatasChangedInitStartButton,
//                    _parametersControllers, &viewcontroller::ParametersControllers::initStartButton);

//    QObject::connect(_equationListController,&viewcontroller::EquationsListController::equationSelected,
//                     _equationPlotterController,&viewcontroller::EquationPlotterController::onEquationSelected);


    QObject::connect(   _algorithmController->inputFileManager(),
                        &algorithmcontroller::InputFileManager::inputDatasChanged,
                        _algorithmController,
                        &algorithmcontroller::AlgorithmController::onInputDataChanged);


    QObject::connect(_algorithmController->inputFileManager(),
                        &algorithmcontroller::InputFileManager::inputDatasChanged,
                        _equationPlotterController,
                     &viewcontroller::EquationPlotterController::onInputDataChanged);

    _algorithmController->inputFileManager()->setApplicationDataFolder(utils::AppFileSystem::dataFolder());
    _algorithmController->inputFileManager()->loadDefaultInputFile();

    _equationListController->setEquationParetoEfficiency( _parametersControllers->equationParetoEfficiencyController());
}

TreeGeneticProgramming::~TreeGeneticProgramming() {}

void TreeGeneticProgramming::registerQmlTypes()
{
    _parametersControllers->registerQmlTypes();

    qmlRegisterUncreatableType<viewcontroller::EquationPlotterController>(
        "com.treegeneticprogramming.equationPlotterController", 1, 0, "EquationPlotterController",
        QStringLiteral("EquationPlotterController can only be created from c++"));

    qmlRegisterUncreatableType<viewcontroller::ParametersControllers>(
        "com.treegeneticprogramming.parameters", 1, 0, "ParametersControllers",
        QStringLiteral("EquationsListController can only be created from c++"));

    qmlRegisterUncreatableType<viewcontroller::EquationsListController>(
        "com.treegeneticprogramming.controller", 1, 0, "EquationsListController",
        QStringLiteral("EquationsListController can only be created from c++"));

    qmlRegisterUncreatableType<viewcontroller::EquationParetoEfficiencyController>(
        "com.treegeneticprogramming.controller", 1, 0, "EquationParetoEfficiencyController",
        QStringLiteral("EquationParetoEfficiencyController can only be created from c++"));

    qmlRegisterUncreatableType<viewcontroller::BenchmarkController>(
        "com.treegeneticprogramming.controller", 1, 0, "BenchmarkController",
        QStringLiteral("BenchmarkController can only be created from c++"));


    qmlRegisterType<viewcontroller::FilesSelectionController>("com.treegeneticprogramming.controller", 1, 0,
                                                              "FilesSelectionController");

    qmlRegisterType<viewcontroller::DataListFormatter>("com.treegeneticprogramming.controller", 1, 0,
                                                       "DataListFormatter");
}

algorithmcontroller::AlgorithmController *TreeGeneticProgramming::algorithmController()
{
    return _algorithmController;
}

viewcontroller::EquationsListController *TreeGeneticProgramming::equationListController()
{
    return _equationListController;
}

// viewcontroller::EquationParetoEfficiencyController *TreeGeneticProgramming::EquationParetoEfficiencyController()
//{
//    return  _parametersControllers->equationParetoEfficiencyController();
//}

viewcontroller::ParametersControllers *TreeGeneticProgramming::parametersControllers()
{
    return _parametersControllers;
}

viewcontroller::EquationPlotterController *TreeGeneticProgramming::equationPlotterController()
{
    return _equationPlotterController;
}
