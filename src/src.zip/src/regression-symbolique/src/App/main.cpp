#include <QApplication>
#include <QCoreApplication>
#include <QQmlApplicationEngine>
#include <QtQuickControls2/QQuickStyle>
#include <QThread>

#include "AlgorithmControllers/AlgorithmController.h"
//#include "Logger/LogHandler.h"
#include "TreeGeneticProgramming.h"
#include "Utils/AppFileSystem.h"
#include "Utils/FileUtils.h"
#include "Utils/CommandLineParser.h"
#include "ViewControllers/EquationsListController.h"
#include "ViewControllers/ParametersControllers.h"
#include "Logger_v2/Logger.h"

namespace datamodel
{
class Category;
}

int main(int argc, char* argv[])
{
    //------------------------------------------------------------------
    // Create the core of the application
    //------------------------------------------------------------------
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);

    QApplication app(argc, argv);

    app.setApplicationName(QStringLiteral("TreeGeneticProgramming"));
    app.setOrganizationName(QStringLiteral("Capgemini"));
    app.setOrganizationDomain(QStringLiteral("Capgemini domain"));
    std::string dataPath = app.applicationDirPath().toStdString() + "/data";

    QQmlApplicationEngine engine;

    //------------------------------------------------------------------
    // Init Logger_v2
    //------------------------------------------------------------------
    logs::Logger logger_v2;

    //------------------------------------------------------------------
    // Parse command line options
    //------------------------------------------------------------------
    utils::CommandLineParser::ParseCommandLine();
    utils::CommandLineParser::DisplayParametersAtInit();

    //------------------------------------------------------------------
    // Initialize the file system of the application
    //------------------------------------------------------------------
    utils::AppFileSystem::createFolders(dataPath);

    //------------------------------------------------------------------
    // Clean old logs and initialize the new one
    //------------------------------------------------------------------

    logs::Logger::logInfo("Startup of the application");

    //------------------------------------------------------------------
    // Initialize the high level class managing the application
    //------------------------------------------------------------------
    auto treeGeneticProgramming = new TreeGeneticProgramming(&app);

    //------------------------------------------------------------------
    // Register the types used in the qml
    //------------------------------------------------------------------
    treeGeneticProgramming->registerQmlTypes();

    //------------------------------------------------------------------
    // Load the fonts of the application
    //------------------------------------------------------------------
    utils::FileUtils::loadFonts(QStringLiteral(":/TreeGeneticProgramming/Resources"));

    //------------------------------------------------------------------
    // Choose the style of the qt quick controls
    //------------------------------------------------------------------
    QQuickStyle::setStyle(QStringLiteral("Material"));

    //------------------------------------------------------------------
    // Load the main qml of the application
    //------------------------------------------------------------------
    const QUrl url(QStringLiteral("qrc:/TreeGeneticProgramming/main.qml"));

    //------------------------------------------------------------------
    // Set the properties of the qml to share c++ data to the qml
    //------------------------------------------------------------------
    engine.setInitialProperties(
        {{"parametersControllers", QVariant::fromValue(treeGeneticProgramming->parametersControllers())},
         {"equationListController", QVariant::fromValue(treeGeneticProgramming->equationListController())},
         {"equationPlotterController", QVariant::fromValue(treeGeneticProgramming->equationPlotterController())},
         {"appSourceFolder", utils::AppFileSystem::sourceApplicationFolder()}});

    treeGeneticProgramming->parametersControllers()->equationGenerationController()->setFitDuration(utils::CommandLineParser::getFitDuration());
    treeGeneticProgramming->parametersControllers()->equationGenerationController()->setFitPopulationPeriod(utils::CommandLineParser::getFitPopulationPeriod());
    std::string distanceToUse = utils::CommandLineParser::getDistanceToUse();
    if(distanceToUse == "R2") treeGeneticProgramming->parametersControllers()->equationDistanceController()->setEquationDistance(equationparameters::EquationDistanceParameters::R2);
    else if(distanceToUse == "MSE") treeGeneticProgramming->parametersControllers()->equationDistanceController()->setEquationDistance(equationparameters::EquationDistanceParameters::MSE);
    else{
        std::cout << "Warning: Invalid distance, please see --help" << std::endl;
        return -1;
    }


    // If the command line parameter "-s" is set to true, we execute the algorithm right away without any UI.
    if(utils::CommandLineParser::getStartSilent())
    {
        treeGeneticProgramming->algorithmController()->onEquationGenerationRequired(
                    treeGeneticProgramming->parametersControllers()->equationGenerationController()->equationGenerationParameters(),
                    treeGeneticProgramming->parametersControllers()->equationDistanceController()->getEquationDistanceParameters());
        treeGeneticProgramming->parametersControllers()->forwardStartButtonClickedEvent();
        QObject::connect( treeGeneticProgramming->algorithmController(), &algorithmcontroller::AlgorithmController::silentProcessDone,
                          &app, QCoreApplication::exit, Qt::QueuedConnection);
        return app.exec();
    }
    // If it is set to false, we display the UI and wait for the user input.
    else
    {
        engine.load(url);

        if (engine.rootObjects().isEmpty())
        {
            //qWarning() << "Main Qml not valid.";
            logs::Logger::logWarning("Main Qml not valid.", {logs::LogTags::app});
            return -1;
        }
        return app.exec();
    }
}
