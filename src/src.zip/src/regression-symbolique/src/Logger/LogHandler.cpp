/*#include "LogHandler.h"

#include <QDebug>
#include <QMutex>
#include <QTextStream>

#include "LogFile.h"

namespace logger
{
LogFile* LogHandler::_logFile     = nullptr;
LogHandler* LogHandler::_instance = nullptr;

/// The maximal age of a log file in days, older log files than this value are cleaned by the cleanLogger method
constexpr uint LOG_FILE_MAX_AGE = 15;

LogHandler::LogHandler(const QDir& dir)
{
    _logFile = new LogFile(dir);

#ifdef QT_NO_DEBUG
    qSetMessagePattern("[%{if-info}Info%{endif}%{if-warning}Warning"
                       "%{endif}%{if-critical}Critical%{endif}%{if-fatal}Fatal%{endif}] %{time"
                       " hh:mm:ss.zzz} : \"%{message}\"");
#else
    qSetMessagePattern("[%{if-debug}Debug%{endif}%{if-info}Info%{endif}%{if-warning}Warning"
                       "%{endif}%{if-critical}Critical%{endif}%{if-fatal}Fatal%{endif}] %{time"
                       " hh:mm:ss.zzz} : \"%{message}\" %{file}:%{line}");
#endif
}

LogHandler* LogHandler::buildInstance(const QDir& dir)
{
    if (!_instance) {_instance = new LogHandler(dir); }
    return _instance;
}

void LogHandler::deleteInstance()
{
    if (_logFile)
    {
        _logFile->close();
        delete _logFile;
    }

    delete _instance;
}

void LogHandler::messageHandler(QtMsgType type, const QMessageLogContext& context, const QString& message)
{
    if (!_instance) { qFatal("You must initialize LogHandler before call of logs");} // OLD LOGGER

#ifdef QT_NO_DEBUG
    if (type == QtDebugMsg) return;
#endif

    static QMutex mutex;
    QMutexLocker lock(&mutex);

    QString logMessage(qFormatLogMessage(type, context, message));

    QTextStream stdOutStream(stdout);

    // Color the console output with one color for each log level
    switch (type)
    {
        case QtDebugMsg:
            stdOutStream << "\033[38;2;176;176;176m";
            break;
        case QtInfoMsg:
            stdOutStream << "\033[38;2;54;189;244m";
            break;
        case QtWarningMsg:
            stdOutStream << "\033[38;2;255;153;0m";
            break;
        case QtCriticalMsg:
            stdOutStream << "\033[38;2;255;51;0m";
            break;
        case QtFatalMsg:
            stdOutStream << "\033[38;2;153;0;0m";
            break;
    }

    // "\033[0m" reset the standart console output
    stdOutStream << logMessage << "\033[0m" << Qt::endl;

    if (_logFile->open((QIODevice::Append)))
    {
        QTextStream(_logFile) << logMessage << Qt::endl;

        _logFile->close();
    }
    else
    {
        qFatal("Cannot write in the log file %s", qUtf8Printable(_logFile->fileName())); //OLD LOGGER

    }
}

void LogHandler::cleanLogger(const QDir& dir)
{
    const QStringList filesList(dir.entryList(QStringList() << QStringLiteral("*.log"), QDir::Files));

    for (const QString& logFileName : filesList)
    {
        LogFile logFile(dir.absolutePath() + "/" + logFileName);

        if (logFile.getLogDate().daysTo(QDateTime::currentDateTime()) > LOG_FILE_MAX_AGE)
        {
            qInfo() << "Remove log file : " << logFile.fileName();
            logFile.remove();
        }
    }
}
}    // namespace logger
*/
