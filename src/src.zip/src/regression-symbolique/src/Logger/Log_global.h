/*#pragma once

#include <QtCore/qglobal.h>
*/
