/*#include "LogFile.h"

namespace logger {
constexpr int START_DATE = 23;
constexpr int END_DATE = 18;
const QString LogFile::LOG_DATE_FORMAT = QStringLiteral("yyyyMMdd_hhmmsszzz");

LogFile::LogFile(const QString &fileName, QObject *parent) : QFile(fileName, parent)
{
    if (exists()) {
        // The format of the file is TreeGeneticProgramming_yyyyMMdd_hhmmsszzz.log
        QString logFileName(QFileInfo(fileName).fileName());
        QString logDate(logFileName.mid(START_DATE, END_DATE));
        _logDate = QDateTime::fromString(logDate, LOG_DATE_FORMAT);
    }
}

LogFile::LogFile(const QDir &path, QObject *parent)
    : QFile(parent), _logDate(QDateTime::currentDateTime())
{
    QString logFileName;
    logFileName = path.path() + "/TreeGeneticProgramming_" + _logDate.toString(LOG_DATE_FORMAT)
                  + ".log";
    setFileName(logFileName);
}
} // namespace logger
*/
