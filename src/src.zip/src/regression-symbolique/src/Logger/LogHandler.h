/*#pragma once

#include <QDir>

#include "Log_global.h"

namespace logger
{
class LogFile;

/*!
 * @brief Singleton class handeling the log writting, format and the cleaning of log files
 */
/*class LogHandler
{
  public:
    /*!
     * @brief Build the instance of the LogHandler to create logs in the given folder
     * @param dir the folder where the log will be written
     * @return the instance of the LogHandler
     */
    /*static LogHandler* buildInstance(const QDir& dir);

    /*!
     * @brief Delete the instance of the LogHandler
     */
    /*static void deleteInstance();

    /*!
     * @brief Format and print output log message
     * @param type the type of the log message (debug, warning, critical or fatal)
     * @param context informations about the log message location
     * @param message the message to log
     */
    /*static void messageHandler(QtMsgType type, const QMessageLogContext& context, const QString& message);

    /*!
     * @brief Delete the too old logs message in the given folder
     * @param dir the folder where the too old log message are cleanned
     */
    /*static void cleanLogger(const QDir& dir);

  private:
    /*!
     * @brief Default contructor. Create an instance of the LogHandler to generate log file in the given folder
     * @param dir the folder where the log files will be generated
     */
    /*explicit LogHandler(const QDir& dir);
    /*!
     * @brief Default destructor
     */
    /*~LogHandler() = default;

    Q_DISABLE_COPY_MOVE(LogHandler)

    /// The log file where log are written
    static LogFile* _logFile;

    /// The instance of the LogHandler
    static LogHandler* _instance;
};
}    // namespace logger
*/
