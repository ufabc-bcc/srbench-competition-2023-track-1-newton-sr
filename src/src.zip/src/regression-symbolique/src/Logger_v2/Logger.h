#pragma once

#include <cstring>
#include <iostream>
#include <string>
#include <stdexcept>
#include <exception>
#include <set>
#include <mutex>
#include <fstream>
#include <limits.h>
#include <ctime>

namespace logs {

/**
 * @brief This is a custom Exception that is NOT AN EXEPTION, IT IS BASICALLY AN EMPTY EXCEPTION
 * Used in functions that have optionnal argument of type exception
 */
class VoidException : public std::exception {
public: const char * what() const noexcept override { return "VoidException"; }
};


/* LOG TYPE: the different type of log messages */

/**
 * Every log message has a type, sorted and defined by this level of severity
 * Log messages are filtered depending on the logMode
 * 
 * Critical are sever issues that should not happen and could trigger a program crash or an unpredictable behavior
 * Error are issues that could happen under certain circumstances and could trigger a program functionnality to not work as expected
 * Warning are non-critical issues, the program will work as expected, they could show that an error occured and it was self-fixed, or a status growing that could lead to an error
 * Info are general information about the program, meant for the user, should be understood as big steps information, should not spam
 * Info_detail are detailed information about the program, meant for the user, should be understood as small steps information, could spamm
 * Debug are general debug info, meant for the dev, should be understood as big steps information, should not spam
 * Debug_detail are detailed debug info, meant for the dev, should be understood as small steps information, could spamm
 * 
 * More types could be added, but they must respect the visibility order, see logMode for more information
*/
enum class LogType { Critical, Error, Warning, Info, Info_detail, Debug, Debug_detail};
/**
 * Use this function to cast the enum class LogType to char*
 * Exemple: log::LogTypeToString(LogMode::Info) returns "Info"
*/
const char* LogTypeToString(LogType logType);
/* End of LOG TYPE */

/* LOG MODE: the level of filtering of log types */

/**
 * The logMode define which LogTypes should be shown or ingored based on the maximum severity authorised for logging
 * 
 * Undefined: ingores all logs (that is before the logger is instanciated)
 * IgnoreAll: ignores all logs
 * Criticals: shows Critical logs only
 * Errors: shows Critical + Error logs
 * Warnigns: shows Critical to Warning logs
 * Infos: shows Critical to Info logs
 * Infos_detailed: shows Critical to Info_detail logs
 * Debug: shows Critical to Debug logs
 * Debug_detailed: shows Critical to Debug_detail logs (shows everything)
*/
enum class LogMode { Undefined, IgnoreAll, Critical, Error, Warning, Info, Info_detail, Debug, Debug_detail};
/**
 * @brief Use this function to cast the enum class LogMode to const char*
 * @warning (for dev) If you modify LogMode you must modify Logger::extractLogMode
*/
const char* LogModeToString(LogMode logMode);
/* End of LOG MODE */

/* LOG TAGS: those are optionnaly added to log messages to filter them */

/**
 * Tags added to the log message, can be used to filter the messages with logging tools
 * ! KEEP THE ENUM ALPHA SORTED FOR READABILITY
 * ! ADD NEW TAGS IN BOTH LogTagsToString & logTagsFromString
 * Exemple of use: logs::logInfo("a message", {LogTags::mutation, LogTags::settings});
*/
enum class LogTags {algav, algorithm, algorithmController, app,
                    blacklist, blacklistTest1, blacklistTest2,
                    crossbreed,
                    equationEditor,
                    fitness, fitting,
                    logs,
                    mutation,
                    pareto, python,
                    settings, simplification,
                    tests,
                    utils,
                    viewController,
                    fileReaderWriter
};
/**
 * @brief Use this function to cast the tag in const char*
 * @return const char* of the tag
*/
const char* LogTagsToString(LogTags tag);
/**
 * @brief Use this function return the enum equal to the string
 * @param String
 * @return log::logTagsFromString("mutation") returns logs::LogTags::mutation
*/
inline logs::LogTags logTagsFromString(std::string tag) {
    if (tag == "algav") return LogTags::algav;
    if (tag == "algorithm") return LogTags::algorithm;
    if (tag == "algorithmController") return LogTags::algorithmController;
    if (tag == "blacklist") return LogTags::blacklist;
    if (tag == "blacklistTest1") return LogTags::blacklistTest1;
    if (tag == "blacklistTest2") return LogTags::blacklistTest2;
    if (tag == "crossbreed") return LogTags::crossbreed;
    if (tag == "equationEditor") return LogTags::equationEditor;
    if (tag == "fitting") return LogTags::fitting;
    if (tag == "logs") return LogTags::logs;
    if (tag == "mutation") return LogTags::mutation;
    if (tag == "pareto") return LogTags::pareto;
    if (tag == "settings") return LogTags::settings;
    if (tag == "simplification") return LogTags::simplification;
    if (tag == "tests") return LogTags::tests;
    if (tag == "viewController") return LogTags::viewController;
    if (tag == "python") return LogTags::python;
    if (tag == "utils") return LogTags::utils;
    if (tag == "app") return LogTags::app;
    if (tag == "fitness") return LogTags::fitness;
    if (tag == "fileReaderWriter") return LogTags::fileReaderWriter;
    throw std::invalid_argument("Paramater " + tag+ "not recognized in call of funtion logTagsFromString defined in Logger.h");
}
/* End of LOG TAGS */


/* STYLE & COLORS for CONSOLE MESSAGES */
namespace LogStyle{
// style
constexpr char reset[] = "\x1b[0m";
constexpr char bright[] = "\x1b[1m";
constexpr char dim[] = "\x1b[2m";
constexpr char underscore[] = "\x1b[4m";
constexpr char blink[] = "\x1b[5m";
constexpr char reverse[] = "\x1b[7m";
constexpr char hidden[] = "\x1b[8m";
//colors
constexpr char black[] = "\x1b[30m";
constexpr char red[] = "\x1b[31m";
constexpr char green[] = "\x1b[32m";
constexpr char yellow[] = "\x1b[33m";
constexpr char blue[] = "\x1b[34m";
constexpr char magenta[] = "\x1b[35m";
constexpr char cyan[] = "\x1b[36m";
constexpr char white[] = "\x1b[37m";
// composition
constexpr char error[] = "\x1b[1;31m";
constexpr char warning[] = "\x1b[1;33m";
constexpr char info[] = "\x1b[1;32m";
constexpr char info_detail[] = "\x1b[32m";
constexpr char debug[] = "\x1b[1;34m";
constexpr char debug_detail[] = "\x1b[34m";
} //namespace LogStyle


/**
 * @brief This class handles logs for the program it outputs to console and/or files (.log)
 * It has settings (stored in a JSON) to customise it
 * logMode allows to filter which messages are shown
 * All log messages have a LogType and a message, optionnaly they can also have tags and/or an error
*/
class Logger {
    public:
        /**
         * @brief Constructor, load settings and instanciate the logger
        */
        Logger();
        /**
         * @brief Destructor, to stop the Logger properly
        */
        ~Logger();

        /**
         * @brief Logs a critical error level message
         * @param tags are optionnal
         * @param error is optionnal
        */
        inline static void logCritical(std::string message, const std::exception& error = logs::VoidException()) {
            Logger::logCritical(message, std::set<LogTags>(), error);
        }
        /**
         * @brief Logs a critical error level message
         * @param tags are optionnal
         * @param error is optionnal
        */
        static void logCritical(std::string message, std::set<LogTags> tags, const std::exception& error = logs::VoidException());

        /**
         * @brief Logs an error level message
         * @param tags are optionnal
         * @param error is optionnal
        */
        inline static void logError(std::string message, const std::exception& error = logs::VoidException()) {
            Logger::logError(message, std::set<LogTags>(), error);
        }
        /**
         * @brief Logs an error level message
         * @param tags are optionnal
         * @param error is optionnal
        */
        static void logError(std::string message, std::set<LogTags> tags, const std::exception& error = logs::VoidException());

        /**
         * @brief Logs a warning level message
         * @param tags are optionnal
         * @param error is optionnal
        */
        inline static void logWarning(std::string message, const std::exception& error = logs::VoidException()) {
            Logger::logWarning(message, std::set<LogTags>(), error);
        }
        /**
         * @brief Logs a warning level message
         * @param tags are optionnal
         * @param error is optionnal
        */
        static void logWarning(std::string message, std::set<LogTags> tags, const std::exception& error = logs::VoidException());

        /**
         * Logs a general information message with optionnal tags
        */
        static void logInfo(std::string message, std::set<LogTags> tags = std::set<LogTags>());
        /**
         * Logs a detailed information message with optionnal tags
        */
        static void logInfoDetail(std::string message, std::set<LogTags> tags = std::set<LogTags>());
        /**
         * Logs a general debug message with optionnal tags
         * In release mode (NDEBUG) this function is ignored
        */
        inline static void logDebug(std::string message, std::set<LogTags> tags = std::set<LogTags>()) {
            #ifndef NDEBUG
                _logDebug(message, tags);
            #endif
        }
        /**
         * Logs a detailed debug message with optionnal tags
         * In release mode (NDEBUG) this function is ignored
        */
        inline static void logDebugDetail(std::string message, std::set<LogTags> tags = std::set<LogTags>()) {
            #ifndef NDEBUG
                _logDebugDetail(message, tags);
            #endif
        }
        static void _logDebug(std::string message, std::set<LogTags> tags = std::set<LogTags>());
        static void _logDebugDetail(std::string message, std::set<LogTags> tags = std::set<LogTags>());

    
    private:
        /* private variables */
        static std::mutex _mutex;
        static std::string _relativePathToLogsDirectory;
        static std::string _logFile;
        static std::string _settingsPath;
        static LogMode _logMode;
        static bool _outputConsole;
        static bool _colorConsoleText;
        static bool _outputFile;
        static unsigned int _fileLifespan;  // number of days logs are kept on disc
        static bool _testing;
        static bool _blacklistEnabled;
        static std::set<LogTags> _blacklist;

        /* private methods */

        /**
         * This function load the logger settings from the json setting file
        */
        void getLoggerSettings();
        /**
         * This function is used in getLoggerSettings to extract the LogMode from the json data
        */
        LogMode extractLogMode(std::string str_logMode);
        /**
         * this function saves the logger settings on the json setting file
         * This is currently not used (as of december 2022) but if someday the settings are managed through the UI they could be set here
         * TODO pas urgent car on ne l'utilise pas
        */
        void setLoggerSettings();
        /**
         * Create a log file if outputFile is true
        */
        void createLogFile();
        /**
         * @brief This functions writes the logs in the log file (.log) if outputFile is true
        */
        static void writeOnFile(std::string message);

        /**
         * This stops the logger from working and closes the log file properly
        */
        void stopLogger();

        /**
         * @brief Log an init message with settings and context
         */
        void initConsoleMessage();

        /**
         * @brief Verify if any tag is contained in the blacklist
         * @param a set of tags
         * @return true if one of the tag is blacklisted
         */
        static bool isInBlacklist(std::set<logs::LogTags> tags);

        /**
         * @brief This function handle all the console logs,
         * It format the messages by adding date, colors, etc.
         * @param tags is optionnal, exemple set tags like this: {LogTags::tests, LogTags::logs}
         * @param error is optionnal
        */
        inline static void handleConsoleLogs(LogType logType, std::string message, const std::exception& error = logs::VoidException()) {
            Logger::handleConsoleLogs(logType, message, std::set<LogTags>(), error);
        }
        /**
         * @brief This function handle all the console logs,
         * It format the messages by adding date, colors, etc.
         * @param tags is optionnal, exemple set tags like this: {LogTags::tests, LogTags::logs}
         * @param error is optionnal
        */
        static void handleConsoleLogs(LogType logType, std::string message, std::set<LogTags> tags, const std::exception& error = logs::VoidException());

       /**
         * @brief This function handle the file logging
         * It format the messages then writes in the file log
         * @param tags is optionnal, exemple set tags like this: {LogTags::tests, LogTags::logs}
         * @param error is optionnal
        */
        inline static void handleFileLogs(LogType logType, std::string message, const std::exception& error = logs::VoidException()) {
            Logger::handleConsoleLogs(logType, message, std::set<LogTags>(), error);
        }
        /**
         * @brief This function handle all the console logs,
         * It format the messages by adding date, colors, etc.
         * @param tags is optionnal, exemple set tags like this: {LogTags::tests, LogTags::logs}
         * @param error is optionnal
        */
        static void handleFileLogs(LogType logType, std::string message, std::set<LogTags> tags, const std::exception& error = logs::VoidException());

        /**
         * @brief This function tests all the log types with a basic message
         */
        static void testAll();
};


} // namespace logs



namespace logTime { /* GESTION DU TEMPS ET DES DATES DANS LE LOGGER */
/**
 * @brief Allows to define different date format for every output considered by the logger
 * index 0: date format used in console
 * index 1: date format for the log filename
 * index 2: date format used in files
 *
 * date and time format: see format definition of std::put
 * (https://en.cppreference.com/w/cpp/locale/time_put/put)
 * In addition, %% specifying milliseconds part on 3 digits at the end of the timestamp string.
 * For log file name format, don't use separators \/:*?"<>|
 */
const std::string DATE_FORMAT[]= {"%H:%M:%S.%%","%Y%m%d_%H%M%S","%H:%M:%S.%%"};
/**
 * This fuction is used in logTime::dateTimeToString
 */
std::ostream& formatDateTime(std::ostream& out, const tm& t, const char* fmt);
/**
 * @brief This function return the given time in the given format
 * @param format takes on of const string DATE_FORMAT[] defined in logger.h
 */
std::string dateTimeToString(const tm& dateTime, const time_t &ms, const char* format);
/**
 * @brief This function return the current time in the given format
 * @param format takes on of const string DATE_FORMAT[] defined in logger.h
 */
std::string dateTimeToStringNow(const char* format);

/**
 * @brief This functions used in the Logger constructor clears the outdated log files
 * observe the .log files and delete those that exceed the number of days (_fileLifespan)
 */
void removeOutDatedLogFiles(const unsigned int daysToSubst, const std::string path);
} // namespace logTime
