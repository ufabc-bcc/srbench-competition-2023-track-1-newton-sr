# LOGGER C++11

This logger is a custom made tool that does not require Qt.  
The logger has settings located in the file: settings/logger_settings.json  
It logs messages in with different **log types** (Critical, Error, Warning, Info, etc.) which can be filtered, option LogMode in the settings.  
Messages also contains optionnal **tags** to give more context while reading logs.  
There are currently two outputs : console and log files, other outputs could be added.

## Testing

You can test the logger by activating the option "testing" in the logger settings.

## Settings

Located in settings/logger_settings.json they are copied in the binary at build time.  
You can change the settings in the project folder then build. Or change the settings in the binary folder and run the app without building, but at next build the settings will be overwritten.

The settings contains :  
- logMode <String> is the filter level of logs, for exemple 'Warning' will show Critical, Error and Warning, but will ignore all log level higher than Warning (Info, Debug, etc.)
- outputConsole: see the logs in the console
- colorConsoleText: add colors to the console, works with unix terminals but doesn't work with some windows consoles
- outputFile: write the logs in logs files, located in the binary folder logs
- relativePathToLogsDirectory: is the relative path from the binary executable to the logs folder
- fileLifespan: duration in days after which log files are considered outdated and deleted
- testing: test all possible log messages at startup
- blacklist: list of tags, the logger will ignore logs containing any of those tags

## LogType & LogMode

Defined in the src/Logger/Logger.h in the namespace logs.

**logs::LogType** are the type of log message.  
Associated function:  
```cpp
logs::LogTypeToString(logs::LogType logType) return a const char*
```

**logs::LogMode** are the filter level of log type.  
Associated function:  
```cpp
logs::LogModeToString(logs::LogMode logMode) return a const char*
```

##### Recommanded settings:  
- Warning when you want to see only problems
- Info when you want to see problems and general information
- Debug_detail when you work on the code

## LogTags

Defined in the src/Logger/Logger.h in the namespace logs.

The tags are unique and should be used in all logs to quickly catch the context of the log. This help filter message with the blacklist functionnality.

Tags should be kept sorted in the header for readability, and when adding/removing a tag, should update the associated functions accordingly:

```cpp
//exemple of usage
Logger::logWarning("Test message w/ tags, w/o error", {LogTags::tests, LogTags::logs});
Logger::logWarning("Test message w/ both tags & error", {LogTags::tests, LogTags::logs},std::invalid_argument("Invalid arg in my func"));
// methods to convert a LogTags to/from string
logs::LogTagsToString(logs::LogTags tag) returns a const char *
logs::logTagsFromString(std::string tag) returns a logs::LogTags
```


## namespace LogStyle within namespace logs

This namespace contains some defined experession to change the style and color of console messages. Composition contains both style and colors.

## namespace LogTime in Logger.h and Logger.cpp

This namespace contains methods to format the Date in logs.  
logTime::DATE_FORMAT[] allows to define different date format for every output considered by the logger.

## Class Logger

Contains the public functions, can be used like this:

##### Critical
```cpp
logs::Logger::logCritical("message")
logs::Logger::logCritical("message", {tags})
logs::Logger::logCritical("message", <std::exception>)
logs::Logger::logCritical("message", {tags}, <std::exception>)
```
##### Error
```cpp
logs::Logger::logError("message")
logs::Logger::logError("message", {tags})
logs::Logger::logError("message", <std::exception>)
logs::Logger::logError("message", {tags}, <std::exception>)
```
##### Warning
```cpp
logs::Logger::logWarning("message")
logs::Logger::logWarning("message", {tags})
logs::Logger::logWarning("message", <std::exception>)
logs::Logger::logWarning("message", {tags}, <std::exception>)
```
##### Info
```cpp
logs::Logger::logInfo("message")
logs::Logger::logInfo("message", {tags})
```
##### Info_detail
```cpp
logs::Logger::logInfoDetail("message")
logs::Logger::logInfoDetail("message", {tags})
```
##### Debug
```cpp
logs::Logger::logDebug("message")
logs::Logger::logDebug("message", {tags})
```
##### Debug_detail
```cpp
logs::Logger::logDebugDetail("message")
logs::Logger::logDebugDetail("message", {tags})
```

## File logs

Located in the binary folder with a format similar to this:

> logs/TreeGeneticProgramming_YYYYMMDD_HHMMSS.log

The format can be specified in src/Logger_v2/Logger.h in namespace logTime::DATE_FORMAT
