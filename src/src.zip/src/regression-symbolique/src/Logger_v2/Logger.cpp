#include "Logger.h"

#include <sys/time.h>
#include <sstream>
#include <locale>
#include <filesystem>
#include <dirent.h>
#include <stdio.h>
#include <typeinfo>

#include <nlohmann/json.hpp> // for JSON, see https://github.com/nlohmann/json#readme
using json = nlohmann::json; // for JSON


namespace logs {

/* LOGGER CLASS PUBLIC MEMBERS */

Logger::Logger() {
    // loads the settings
    Logger::getLoggerSettings();

    // if (outputFile) create a log file
    if (Logger::_outputFile) Logger::createLogFile();

    // init message
    if (Logger::_outputConsole) Logger::initConsoleMessage();

    // testing all messages
    if (Logger::_testing) Logger::testAll();

    // remove outdated log files
    logTime::removeOutDatedLogFiles(Logger::_fileLifespan, Logger::_relativePathToLogsDirectory);
}

Logger::~Logger(){
    // delete the instance
    Logger::stopLogger();
}

void Logger::logCritical(std::string message, std::set<LogTags> tags, const std::exception& error) {
    // verify is the current LogMode from settings
    // comparing logs::LogMode with (logs::LogType +2)
    // +2 because logs::LogMode has two more members than logs::LogTypes (which are Undefined & IgnoreAll)
    if (static_cast<std::underlying_type<LogMode>::type>(_logMode) < (static_cast<std::underlying_type<LogType>::type>(LogType::Critical) +2)){
        return;
    }
    // output: console
    if (Logger::_outputConsole) Logger::handleConsoleLogs(LogType::Critical, message, tags, error);

    // output: file
    if (Logger::_outputFile) Logger::handleFileLogs(LogType::Critical, message, tags, error);
}
void Logger::logError(std::string message, std::set<LogTags> tags, const std::exception& error) {
    // verify is the current LogMode from settings
    // comparing logs::LogMode with (logs::LogType +2)
    // +2 because logs::LogMode has two more members than logs::LogTypes (which are Undefined & IgnoreAll)
    if (static_cast<std::underlying_type<LogMode>::type>(_logMode) < (static_cast<std::underlying_type<LogType>::type>(LogType::Error) +2)){
        return;
    }
    // output: console
    if (Logger::_outputConsole) Logger::handleConsoleLogs(LogType::Error, message, tags, error);

    // output: file
    if (Logger::_outputFile) Logger::handleFileLogs(LogType::Error, message, tags, error);
}
void Logger::logWarning(std::string message, std::set<LogTags> tags, const std::exception& error) {
    // verify is the current LogMode from settings
    // comparing logs::LogMode with (logs::LogType +2)
    // +2 because logs::LogMode has two more members than logs::LogTypes (which are Undefined & IgnoreAll)
    if (static_cast<std::underlying_type<LogMode>::type>(_logMode) < (static_cast<std::underlying_type<LogType>::type>(LogType::Warning) +2)){
        return;
    }
    // output: console
    if (Logger::_outputConsole) Logger::handleConsoleLogs(LogType::Warning, message, tags, error);

    // output: file
    if (Logger::_outputFile) Logger::handleFileLogs(LogType::Warning, message, tags, error);
}
void Logger::logInfo(std::string message, std::set<LogTags> tags) {
    // verify is the current LogMode from settings
    // comparing logs::LogMode with (logs::LogType +2)
    // +2 because logs::LogMode has two more members than logs::LogTypes (which are Undefined & IgnoreAll)
    if (static_cast<std::underlying_type<LogMode>::type>(_logMode) < (static_cast<std::underlying_type<LogType>::type>(LogType::Info) +2)){
        return;
    }
    // output: console
    if (Logger::_outputConsole) Logger::handleConsoleLogs(LogType::Info, message, tags);

    // output: file
    if (Logger::_outputFile) Logger::handleFileLogs(LogType::Info, message, tags);
}
void Logger::logInfoDetail(std::string message, std::set<LogTags> tags) {
    // verify is the current LogMode from settings
    // comparing logs::LogMode with (logs::LogType +2)
    // +2 because logs::LogMode has two more members than logs::LogTypes (which are Undefined & IgnoreAll)
    if (static_cast<std::underlying_type<LogMode>::type>(_logMode) < (static_cast<std::underlying_type<LogType>::type>(LogType::Info_detail) +2)){
        return;
    }
    // output: console
    if (Logger::_outputConsole) Logger::handleConsoleLogs(LogType::Info_detail, message, tags);

    // output: file
    if (Logger::_outputFile) Logger::handleFileLogs(LogType::Info_detail, message, tags);
}
// the following fns (_logDebug, _log...) are private methods forwarded from (logDebug, log...) defined in the header
void Logger::_logDebug(std::string message, std::set<LogTags> tags) {
    // verify is the current LogMode from settings
    // comparing logs::LogMode with (logs::LogType +2)
    // +2 because logs::LogMode has two more members than logs::LogTypes (which are Undefined & IgnoreAll)
    if (static_cast<std::underlying_type<LogMode>::type>(_logMode) < (static_cast<std::underlying_type<LogType>::type>(LogType::Debug) +2)){
        return;
    }
    // output: console
    if (Logger::_outputConsole) Logger::handleConsoleLogs(LogType::Debug, message, tags);

    // output: file
    if (Logger::_outputFile) Logger::handleFileLogs(LogType::Debug, message, tags);
}
void Logger::_logDebugDetail(std::string message, std::set<LogTags> tags)  {
    // verify is the current LogMode from settings
    // comparing logs::LogMode with (logs::LogType +2)
    // +2 because logs::LogMode has two more members than logs::LogTypes (which are Undefined & IgnoreAll)
    if (static_cast<std::underlying_type<LogMode>::type>(_logMode) < (static_cast<std::underlying_type<LogType>::type>(LogType::Debug_detail) +2)){
        return;
    }
    // output: console
    if (Logger::_outputConsole) Logger::handleConsoleLogs(LogType::Debug_detail, message, tags);

    // output: file
    if (Logger::_outputFile) Logger::handleFileLogs(LogType::Debug_detail, message, tags);
}

/* LOGGER CLASS PRIVATE MEMBERS */

/* default values, they are later overriten by Logger::getLoggerSettings() */
std::mutex Logger::_mutex{};
std::string Logger::_logFile = "";
std::string Logger::_relativePathToLogsDirectory = "../../logs";
std::string Logger::_settingsPath = "logger_settings.json";
LogMode Logger::_logMode = LogMode::Debug_detail;
bool Logger::_outputConsole = true;
bool Logger::_colorConsoleText = false;
bool Logger::_outputFile = true;
unsigned int Logger::_fileLifespan = UINT_MAX;  // number of days logs are kept on disc
bool Logger::_testing = false;
bool Logger::_blacklistEnabled = true;
std::set<LogTags> Logger::_blacklist = std::set<LogTags>();

void Logger::getLoggerSettings() {
    json data = nullptr;
    try {
        // open and read the JSON settings file
        std::ifstream ifs;
        ifs.open(_settingsPath);
        // verify we opened correctly
        if (!ifs.good()) {
            Logger::logError("Error when reading the setting file", {LogTags::settings, LogTags::logs});
            return;
        }
        // extract file into JSON
        data = json::parse(ifs);
        if (ifs.is_open()) ifs.close();
    } catch (const std::ifstream::failure& e) {
        Logger::logError("Error when reading the setting file", {LogTags::settings, LogTags::logs}, e);
    } catch (const nlohmann::json::exception& e) {
        Logger::logError("Error with Nohlmann parser", {LogTags::settings, LogTags::logs}, e);
    }

    // read the JSON and set the settings
    if (data.contains("outputConsole")){
        Logger::_outputConsole = data.at("outputConsole").get<bool>();
    } else Logger::logError("Error with JSON, couldn't extract outputConsole", {LogTags::settings, LogTags::logs});

    if (data.contains("colorConsoleText")){
        Logger::_colorConsoleText = data.at("colorConsoleText").get<bool>();
    } else Logger::logError("Error with JSON, couldn't extract colorConsoleText", {LogTags::settings, LogTags::logs});

    if (data.contains("outputFile")){
        Logger::_outputFile = data.at("outputFile").get<bool>();
    } else Logger::logError("Error with JSON, couldn't extract outputFile", {LogTags::settings, LogTags::logs});

    if (data.contains("relativePathToLogsDirectory")){
        Logger::_relativePathToLogsDirectory = data.at("relativePathToLogsDirectory").get<std::string>();
    } else Logger::logError("Error with JSON, couldn't extract relativePathToLogsDirectory", {LogTags::settings, LogTags::logs});

    if (data.contains("fileLifespan")){
        Logger::_fileLifespan = data.at("fileLifespan").get<int>();
    } else Logger::logError("Error with JSON, couldn't extract fileLifespan", {LogTags::settings, LogTags::logs});
    
    Logger::_logMode = extractLogMode(data["logMode"].get<std::string>());

    if (data.contains("testing")){
        Logger::_testing = data.at("testing").get<bool>();
    } else Logger::logError("Error with JSON, couldn't extract testing", {LogTags::settings, LogTags::logs, LogTags::tests});

    if (data.contains("blacklist")){
        for (auto& tag : data["blacklist"]){
            try {
                _blacklist.emplace(logs::logTagsFromString(tag));
            } catch (std::invalid_argument& e) {
                Logger::logError("Error caught in Logger::getLoggerSettings() when retrieving blacklist, the tag you inputted in the settings probably doesn't exists",
                                 {LogTags::settings, LogTags::logs, LogTags::blacklist}, e);
            }
        }
        _blacklistEnabled = !(_blacklist.empty());
    } else Logger::logError("Error with JSON, couldn't extract blacklist", {LogTags::settings, LogTags::logs, LogTags::blacklist});
}

LogMode Logger::extractLogMode(std::string str_logMode) {
    if (str_logMode == "Undefined") return LogMode::Undefined;
    if (str_logMode == "IgnoreAll") return LogMode::IgnoreAll;
    if (str_logMode == "Critical") return LogMode::Critical;
    if (str_logMode == "Error") return LogMode::Error;
    if (str_logMode == "Warning") return LogMode::Warning;
    if (str_logMode == "Info") return LogMode::Info;
    if (str_logMode == "Info_detail") return LogMode::Info_detail;
    if (str_logMode == "Debug") return LogMode::Debug;
    if (str_logMode == "Debug_detail") return LogMode::Debug_detail;
    Logger::logError("Error: wrong argument in extractLogMode with arg: " + str_logMode, {LogTags::settings, LogTags::logs});
    return LogMode::Undefined;
}
void setLoggerSettings() {} // TODO pas urgent car on ne l'utilise pas

void Logger::createLogFile() {
    std::string fileName = Logger::_relativePathToLogsDirectory + "/TreeGeneticProgramming_"
                           + logTime::dateTimeToStringNow(logTime::DATE_FORMAT[1].c_str())
                           + ".log";
    std::ofstream ofs(fileName);
    ofs.close();
    _logFile = fileName;
}

void Logger::writeOnFile(std::string message) {
    Logger::_mutex.lock();
    // open file in append mode
    std::ofstream file(Logger::_logFile, std::ios_base::app);
    // write on file
    file << message;
    // close
    file.close();
    Logger::_mutex.unlock();
}

void Logger::stopLogger(){
    // toggle off all settings
    Logger::_logMode = LogMode::IgnoreAll;
    Logger::_outputConsole = false;
    Logger::_colorConsoleText = false;
    Logger::_outputFile = false;
    Logger::_fileLifespan = UINT_MAX;
    Logger::_testing = false;
    Logger::_blacklistEnabled = false;
    Logger::_blacklist = std::set<LogTags>();
}

void Logger::initConsoleMessage() {
    std::stringstream ss;
    ss << "Logger initialized with the following settings:" << std::endl;
    ss << "# [Logger settings]" << std::endl;
    
    ss << "# LogMode: " << LogModeToString(_logMode) << std::endl;

    ss << "# outputConsole: ";
    if (_outputConsole) ss << "true" << std::endl;
    else ss << "false" << std::endl;

    ss << "# colorConsoleText: ";
    if (_colorConsoleText) ss << "true" << std::endl;
    else ss << "false" << std::endl;

    ss << "# outputFile: ";
    if (_outputFile) ss << "true" << std::endl;
    else ss << "false" << std::endl;

    ss << "# relativePathToLogsDirectory: " << _relativePathToLogsDirectory << std::endl;

    ss << "# fileLifespan: " << std::to_string(_fileLifespan) << std::endl;

    ss << "# testing: ";
    if (_testing) ss << "true" << std::endl;
    else ss << "false" << std::endl;

    if (_blacklistEnabled) {
        ss << "# blacklist: ";
        for (auto it: Logger::_blacklist) {
            ss << logs::LogTagsToString(it) << " ";
        }
        ss << std::endl;
    } else ss << "# Blacklist: disabled (because empty)" << std::endl;
    Logger::logInfo(ss.str(), {LogTags::logs, LogTags::settings});
}

bool Logger::isInBlacklist(std::set<logs::LogTags> tags) {
    for (logs::LogTags it: tags)
        if (Logger::_blacklist.find(it) != Logger::_blacklist.end())
            return true;
    return false;
}


void Logger::handleConsoleLogs(LogType logType, std::string message, std::set<LogTags> tags, const std::exception& error) {
    // doesn't output if tag in blacklist
    if (Logger::_blacklistEnabled){
        if (Logger::isInBlacklist(tags)) return;
    }
    // reformating the message for the console
    std::stringstream ss;
    // add date
    ss << logTime::dateTimeToStringNow(logTime::DATE_FORMAT[0].c_str());
    // add LogType
    ss << " [" << LogTypeToString(logType) << "] ";
    // optionnaly add tags
    if (!tags.empty()){
        size_t nbTags = tags.size();
        size_t cpt = 0;
        ss << "(";
        for(std::set<logs::LogTags>::iterator it = tags.begin(); it != tags.end(); it++){
            ss << LogTagsToString(*it);
            if (++cpt < nbTags) ss << ", ";
        }
        ss << ") ";
    }
    // add message
    ss << message;
    // add error
    if(typeid(error) != typeid(logs::VoidException)) {
        ss << " ERROR: " << error.what();
    }
    // add style and send
    switch(logType) {
        case LogType::Critical:
            if (Logger::_colorConsoleText)
                std::cerr << LogStyle::error << ss.str() << LogStyle::reset << std::endl;
            else
                std::cerr << ss.str() << std::endl;
            break;
        case LogType::Error:
            if (Logger::_colorConsoleText)
                std::cerr << LogStyle::error << ss.str() << LogStyle::reset << std::endl;
            else
                std::cerr << ss.str() << std::endl;
            break;
        case LogType::Warning:
            if (Logger::_colorConsoleText)
                std::cout << LogStyle::warning << ss.str() << LogStyle::reset << std::endl;
            else
                std::cout << ss.str() << std::endl;
            break;
        case LogType::Info:
            if (Logger::_colorConsoleText)
                std::cout << LogStyle::info << ss.str() << LogStyle::reset << std::endl;
            else
                std::cout << ss.str() << std::endl;
            break;
        case LogType::Info_detail:
            if (Logger::_colorConsoleText)
                std::cout << LogStyle::info_detail << ss.str() << LogStyle::reset << std::endl;
            else
                std::cout << ss.str() << std::endl;
            break;
        case LogType::Debug:
            if (Logger::_colorConsoleText)
                std::cout << LogStyle::debug << ss.str() << LogStyle::reset << std::endl;
            else
                std::cout << ss.str() << std::endl;
            break;
        case LogType::Debug_detail:
            if (Logger::_colorConsoleText)
                std::cout << LogStyle::debug_detail << ss.str() << LogStyle::reset << std::endl;
            else
                std::cout << ss.str() << std::endl;
            break;
        default:
            Logger::logError("Error: in Logger::handleConsoleLogs couldn't recognize argument logType", {LogTags::logs});
    }
}
void Logger::handleFileLogs(LogType logType, std::string message, std::set<LogTags> tags, const std::exception& error) {
    // doesn't output if tag in blacklist
    if (Logger::_blacklistEnabled){
        if (Logger::isInBlacklist(tags)) return;
    }
    // reformating the message for the file
    std::stringstream ss;
    // add date
    ss << logTime::dateTimeToStringNow(logTime::DATE_FORMAT[2].c_str());
    // add LogType
    ss << " [" << LogTypeToString(logType) << "] ";
    // optionnaly add tags
    if (!tags.empty()){
        size_t nbTags = tags.size();
        size_t cpt = 0;
        ss << "(";
        for(std::set<logs::LogTags>::iterator it = tags.begin(); it != tags.end(); it++){
            ss << LogTagsToString(*it);
            if (++cpt < nbTags) ss << ", ";
        }
        ss << ") ";
    }
    // add message
    ss << message;
    // add error
    if(typeid(error) != typeid(logs::VoidException)) {
        ss << " ERROR: " << error.what();
    }
    // write on log file
    ss << std::endl;
    try {
        Logger::writeOnFile(ss.str());
    } catch (const std::exception& error) {
        Logger::logError("In Logger::handleFileLogs there was an error with Logger::writeOnFile when attempting to write: "+ ss.str(),{logs::LogTags::logs},error);
    }
}

void Logger::testAll() {
    //Critical
    Logger::logCritical("Test message without tags nor error");
    Logger::logCritical("Test message with tags, without error", {LogTags::tests, LogTags::logs});
    Logger::logCritical("Test message without tags but with error", std::invalid_argument("Invalid arg in my func"));
    Logger::logCritical("Test message with both tags & error", {LogTags::tests, LogTags::logs}, std::invalid_argument("Invalid arg in my func"));
    //Error
    Logger::logError("Test message without tags nor error");
    Logger::logError("Test message with tags, without error", {LogTags::tests, LogTags::logs});
    Logger::logError("Test message without tags but with error", std::invalid_argument("Invalid arg in my func"));
    Logger::logError("Test message with both tags & error", {LogTags::tests, LogTags::logs}, std::invalid_argument("Invalid arg in my func"));
    //Warning
    Logger::logWarning("Test message without tags nor error");
    Logger::logWarning("Test message with tags, without error", {LogTags::tests, LogTags::logs});
    Logger::logWarning("Test message without tags but with error", std::invalid_argument("Invalid arg in my func"));
    Logger::logWarning("Test message with both tags & error", {LogTags::tests, LogTags::logs}, std::invalid_argument("Invalid arg in my func"));
    //Info
    Logger::logInfo("Test message without tags");
    Logger::logInfo("Test message with tags", {LogTags::tests, LogTags::logs});
    //Info_detail
    Logger::logInfoDetail("Test message without tags");
    Logger::logInfoDetail("Test message with tags", {LogTags::tests, LogTags::logs});
    //Debug
    Logger::logDebug("Test message without tags");
    Logger::logDebug("Test message with tags", {LogTags::tests, LogTags::logs});
    //Debug_detail
    Logger::logDebugDetail("Test message without tags");
    Logger::logDebugDetail("Test message with tags", {LogTags::tests, LogTags::logs});
    //blacklist
    Logger::logDebug("This message should not be shown if 'blacklistTest1' is in the blacklist settings, otherwise it's normal",
                     {LogTags::tests, LogTags::blacklist, LogTags::blacklistTest1});
    Logger::logDebug("This message should not be shown if 'blacklistTest2' is in the blacklist settings, otherwise it's normal",
                     {LogTags::tests, LogTags::blacklist, LogTags::blacklistTest2});
}

/* LogType Function */

const char* LogTypeToString(LogType logType) {
    switch (logType) {
        case LogType::Critical: return "Critical";
        case LogType::Error: return "Error";
        case LogType::Warning: return "Warning";
        case LogType::Info: return "Info";
        case LogType::Info_detail: return "Info_detail";
        case LogType::Debug: return "Debug";
        case LogType::Debug_detail: return "Debug_detail";
        default:
            Logger::logError("", {LogTags::logs}, std::invalid_argument("Paramater not recognized in call of funtion LogTypeToString defined in Logger.h"));
            return "ERROR_UNRECOGNIZED_LogType";
    }
}

/* LogMode Function */

const char* LogModeToString(LogMode logMode) {
    switch (logMode) {
        case LogMode::Undefined: return "Undefined";
        case LogMode::IgnoreAll: return "IgnoreAll";
        case LogMode::Critical: return "Critical";
        case LogMode::Error: return "Error";
        case LogMode::Warning: return "Warning";
        case LogMode::Info: return "Info";
        case LogMode::Info_detail: return "Info_detail";
        case LogMode::Debug: return "Debug";
        case LogMode::Debug_detail: return "Debug_detail";
        default:
            Logger::logError("", {LogTags::logs}, std::invalid_argument("Paramater not recognized in call of funtion LogModeToString defined in Logger.h"));
            return "ERROR_UNRECOGNIZED_LogMode";
    }
}

/* LogTags Functions */

const char* LogTagsToString(LogTags tag) {
    switch (tag) {
        case LogTags::algav: return "algav";
        case LogTags::algorithm: return "algorithm";
        case LogTags::algorithmController: return "algorithmController";
        case LogTags::blacklist: return "blacklist";
        case LogTags::blacklistTest1: return "blacklistTest1";
        case LogTags::blacklistTest2: return "blacklistTest2";
        case LogTags::crossbreed: return "crossbreed";
        case LogTags::equationEditor: return "equationEditor";
        case LogTags::fitting: return "fitting";
        case LogTags::logs: return "logs";
        case LogTags::mutation: return "mutation";
        case LogTags::pareto: return "pareto";
        case LogTags::settings: return "settings";
        case LogTags::simplification: return "simplification";
        case LogTags::tests: return "tests";
        case LogTags::viewController: return "viewController";
        case LogTags::python: return "python";
        case LogTags::utils: return "utils";
        case LogTags::app: return "app";
        case LogTags::fitness: return "fitness";
        case LogTags::fileReaderWriter: return "fileReaderWriter";
        default:
            Logger::logError("", {LogTags::logs}, std::invalid_argument("Paramater not recognized in call of funtion LogTagsToString defined in Logger.h"));
            return "ERROR_UNRECOGNIZED_LogTags";
    }
}

} // namespace logs



namespace logTime {

/* Problem :
 * You want to convert a date and/or time to a formatted string.
 * Solution :
 * You can use the time_put template class from the <locale> header
 * see https://www.oreilly.com/library/view/c-cookbook/0596007612/ch05s03.html
*/
std::ostream& formatDateTime(std::ostream& out, const tm& t, const char* fmt) {
  const std::time_put<char>& dateWriter = std::use_facet<std::time_put<char> >(out.getloc());
  int n = strlen(fmt);
  if (dateWriter.put(out, out, ' ', &t, fmt, fmt + n).failed()) {
    throw std::runtime_error("failure to format date time");
  }
  return out;
}
std::string dateTimeToString(const tm& dateTime, const time_t &ms, const char* format) {
  std::stringstream s;
  formatDateTime(s, dateTime, format);

  std::string strOut = s.str();
  // specific case for milliseconds
  if (strOut.back() == '%') {
      strOut.pop_back();
      if (ms < 10) {
          strOut.append("00");
      } else if (ms < 100){
          strOut.push_back('0');
      }
      strOut.append(std::to_string(ms));
  }
  return strOut;
}
std::string dateTimeToStringNow(const char* format) {
  struct timeval time_now{};
  tm nowTime{};

  gettimeofday(&time_now, nullptr);

  time_t now = time_now.tv_sec;
  nowTime = *localtime(&now);

  return dateTimeToString(nowTime, time_now.tv_usec / 1000, format);
}
void subDaysNow(struct tm* dateAndTime, const unsigned int daysToSubst) {
    const time_t oneDay = 24 * 60 * 60;

    // the number of seconds since 00:00 hours, Jan 1, 1970 UTC
    time_t now = time(nullptr);
    *dateAndTime = *localtime(&now);

    time_t date_seconds = mktime(dateAndTime) - (daysToSubst * oneDay);

    *dateAndTime = *localtime(&date_seconds);
}
void removeOutDatedLogFiles(const unsigned int daysToSubst, const std::string path) {
    struct dirent *dir;
    int nbOfFiles(0); // number of files deleted as output
    // opendir() renvoie un pointeur de type DIR
    DIR *d = opendir(path.c_str());
    if (d) {
        struct tm timeRef = {};
        subDaysNow(&timeRef, daysToSubst);
        std::string strtimeRef = dateTimeToString(timeRef, 0, "%Y%m%d");
        while ((dir = readdir(d)) != NULL) {
            std::string s;
            s.append(dir->d_name);
            if (s.find("TreeGeneticProgramming_") != std::string::npos) {
                std::string sDate;
                sDate = s.substr(23, 8);
                if (sDate <= strtimeRef) {
                    std::string sPathFileName;
                    sPathFileName.append(path.c_str());
                    sPathFileName.append("/");
                    sPathFileName.append(dir->d_name);
                    logs::Logger::logDebugDetail("Removing outdated file: " + sPathFileName, {logs::LogTags::logs});
                    remove(sPathFileName.c_str());
                    nbOfFiles++;
                }
            }
        }
        closedir(d);
    }
    if (nbOfFiles > 0)
        logs::Logger::logInfoDetail("The Logger has deleted " +  std::to_string(nbOfFiles)
                                    + " outdated log files that were older than "
                                    + std::to_string(daysToSubst) + " days", {logs::LogTags::logs});
}

} //namespace logTime
