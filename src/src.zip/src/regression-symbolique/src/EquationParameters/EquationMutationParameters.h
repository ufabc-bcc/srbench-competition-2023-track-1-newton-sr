
#pragma once

#include "EquationParameters_global.h"
#include "EquationGenerationParameters.h"

namespace equationparameters
{
/**
 * @brief The EquationMutationParameters class is used as parameter to create mutated equations
 * depending on :
 * - mutation rate
 * - generation sub paramater
 */
class EquationMutationParameters
{
   public:
    // getter / setter
    double mutationRate() const;
    void setMutationRate(double mutationRate);

    int nbMutationPossible() const;
    void setNbMutationPossible(int nbMutationPossible);

    const EquationGenerationParameters &equationGenerationParameters() const;
    void setEquationGenerationParameters(const EquationGenerationParameters &equationGenerationParameters);

   private:
    /**
     * @brief The rate of mutation, 0 by default
     */
    double _mutationRate{0.};

    int _nbMutationPossible{utils::CommandLineParser::getNbMutationPossible()};

    /**
     * @brief The generation parameter used to mutate
     */
    EquationGenerationParameters _equationGenerationParameters;
};
}  // namespace equationparameters
