#include "EquationMutationParameters.h"

namespace equationparameters {

double EquationMutationParameters::mutationRate() const {
    return _mutationRate;
}

void EquationMutationParameters::setMutationRate(double mutationRate) {
    _mutationRate = mutationRate;
}

int EquationMutationParameters::nbMutationPossible() const {
    return _nbMutationPossible;
}

void EquationMutationParameters::setNbMutationPossible(int nbMutationPossible) {
    _nbMutationPossible = nbMutationPossible;
}

const EquationGenerationParameters &EquationMutationParameters::equationGenerationParameters() const {
    return _equationGenerationParameters;
}

void EquationMutationParameters::setEquationGenerationParameters(const EquationGenerationParameters &equationGenerationParameters) {
    _equationGenerationParameters = equationGenerationParameters;
}

} //namespace equationparameters
