#include "EquationDistanceParameters.h"

namespace equationparameters {
EquationDistanceParameters::EquationDistance EquationDistanceParameters::getEquationDistance() const
{
    return _equationDistance;
}

void EquationDistanceParameters::setEquationDistance(const EquationDistance &newEquationDistance)
{
    _equationDistance = newEquationDistance;
}
} //namespace equationparameters
