#pragma once

#include "Utils/Settings.h"

namespace equationparameters
{
/**
 * @brief The EquationDistanceParameters class is used as parameter to set the distance to use in computation
 */
class EquationDistanceParameters
{
    Q_GADGET
public:
    enum EquationDistance
    {
        R2,
        MSE
    };
    Q_ENUM(EquationDistance)

    EquationDistance getEquationDistance() const;
    void setEquationDistance(const EquationDistance &newEquationDistance);

    static EquationDistance defaultEquationDistance()
    {
        auto defaultSetting =
            Settings::instance()->value("EquationDistance/Distance", "R2").toString();

        if (defaultSetting.compare("R2", Qt::CaseSensitivity::CaseInsensitive) == 0)
        {
            return R2;
        }
        else if (defaultSetting.compare("MSE", Qt::CaseSensitivity::CaseInsensitive) == 0)
        {
            return MSE;
        }

        return R2;
    }

    private:
        EquationDistance _equationDistance{defaultEquationDistance()};
};
} //namespace equationparameters
