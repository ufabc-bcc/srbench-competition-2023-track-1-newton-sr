
#pragma once

#include <QSet>

#include "DataModel/EquationNode.h"
#include "EquationParameters_global.h"
#include "Utils/CommandLineParser.h"

namespace equationparameters
{
/**
 * @brief The EquationGenerationParameters class is used as parameter to create a new generation of equation
 * depending on :
 * - equation number
 * - equation max depth
 * - equation types
 */
class EquationGenerationParameters
{
   public:
    // getter / setter
    int equationNumber() const;
    void setEquationNumber(int numberOfEquations);

    int maxNode()const;
    void setMaxNode(int maxNode);

    int equationMaxDepth() const;
    void setEquationMaxDepth(int equationMaxDepth);

    uint numberOfVariables() const;
    void setNumberOfVariables(uint nbVar);

    QSet<datamodel::EquationNode::NodeType> selectedNodesTypes() const;
    void setSelectedNodesTypes(const QSet<datamodel::EquationNode::NodeType> &selectedNodesTypes);

   private:
    /**
     * @brief The number of equations, 100 by default
     */
    int _equationNumber{utils::CommandLineParser::getBasePopulation()};
    /**
     * @brief The maximun depth for the equations, 5 by default
     */
    int _equationMaxDepth{utils::CommandLineParser::getEquationMaximumDepth()};
    /**
     * @brief The maximum number of node an equation should have before being weighted 
     */
    int _maxNode;
    /**
     * @brief The number of different variables on the equations
     */
    uint _nbVar{0};
    /**
     * @brief A list of node types
     */
    QSet<datamodel::EquationNode::NodeType> _selectedNodesTypes;
};
}  // namespace equationparameters
