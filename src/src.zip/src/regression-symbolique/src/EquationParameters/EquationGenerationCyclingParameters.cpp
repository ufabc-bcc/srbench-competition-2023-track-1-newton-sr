#include "EquationGenerationCyclingParameters.h"

namespace equationparameters {
int EquationGenerationCyclingParameters::numberOfGenerations() const
{
    return _numberOfGenerations;
}

int EquationGenerationCyclingParameters::maxNode()const
{
    return _maxNode;
}

void EquationGenerationCyclingParameters::setMaxNode(const int maxNode)
{
    _maxNode= maxNode;
}

void EquationGenerationCyclingParameters::setNumberOfGenerations(int numberOfGeneration)
{
    _numberOfGenerations = numberOfGeneration;
}

bool EquationGenerationCyclingParameters::infiniteGeneration()const
{
    return _infiniteGeneration;
}

void EquationGenerationCyclingParameters::setInfiniteGenerations(bool value)
{
    _infiniteGeneration=value;
}

double EquationGenerationCyclingParameters::distanceMinimum() const
{
    return _distanceMin;
}
void EquationGenerationCyclingParameters::setDistanceMinimum(double distanceMin)
{
    _distanceMin=distanceMin;
}
int EquationGenerationCyclingParameters::activateDistanceMin() const
{
    return _activateDistanceMin;
}
void EquationGenerationCyclingParameters::setActivateDistanceMinimum(int activateDistanceMin)
{
    _activateDistanceMin=activateDistanceMin;
}
const EquationFilterParameters &EquationGenerationCyclingParameters::equationFilterParameters() const
{
    return _equationFilterParameters;
}

void EquationGenerationCyclingParameters::setEquationFilterParameters(const EquationFilterParameters &equationFilterParameters)
{
    _equationFilterParameters = equationFilterParameters;
}

const EquationCrossbreedingParameters &
EquationGenerationCyclingParameters::equationCrossbreedingParameters() const
{
    return _equationCrossbreedingParameters;
}

void EquationGenerationCyclingParameters::setEquationCrossbreedingParameters(const EquationCrossbreedingParameters &equationCrossbreedingParameters)
{
    _equationCrossbreedingParameters = equationCrossbreedingParameters;
}

const EquationMutationParameters &EquationGenerationCyclingParameters::equationMutationParameters()
    const
{
    return _equationMutationParameters;
}

void EquationGenerationCyclingParameters::setEquationMutationParameters(const EquationMutationParameters &equationMutationParameters)
{
    _equationMutationParameters = equationMutationParameters;
}

const EquationFitParameters &EquationGenerationCyclingParameters::equationFitParameters()
    const
{
    return _equationFitParameters;
}

void EquationGenerationCyclingParameters::setEquationFitParameters(const EquationFitParameters &equationFitParameters)
{
//    _equationFitParameters.setDuration(equationFitParameters.duration());
//    _equationFitParameters.setPopulationPeriod(equationFitParameters.populationPeriod());
    _equationFitParameters = equationFitParameters;
}

const EquationDistanceParameters &EquationGenerationCyclingParameters::equationDistanceParameters() const
{
    return _equationDistanceParameters;
}

void EquationGenerationCyclingParameters::setEquationDistanceParameters(const EquationDistanceParameters &equationDistanceParameters)
{
    _equationDistanceParameters = equationDistanceParameters;
}

void EquationGenerationCyclingParameters::setTimeSelected(int time)
{
    _timeSelected = time;
}
int EquationGenerationCyclingParameters::timeSelected() const
{
    return _timeSelected;
}

}
