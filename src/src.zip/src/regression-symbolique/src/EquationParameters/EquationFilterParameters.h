#pragma once

#include "EquationParameters_global.h"
#include "Utils/CommandLineParser.h"
#include "Utils/Settings.h"

namespace equationparameters
{
/**
 * @brief The EquationFilterParameters class is used as parameter to filter a list of equation depending on :
 *  - from: index where to begin the computation
 *  - number of equations
 */
class EquationFilterParameters
{
    Q_GADGET
   public:
    enum EquationsFilterCriteria
    {
        Distance,
        Complexity,
        Pareto,
        Age
    };
    Q_ENUM(EquationsFilterCriteria)

    // getter / setter
    int fromEquation() const;
    void setFromEquation(int fromEquation);
    int numberOfEquationsSelected() const;
    void setNumberOfEquationsSelected(int numberOfEquationsSelected);

    int numberOfEquations() const;
    void setNumberOfEquations(int numberOfEquations);

    EquationsFilterCriteria getEquationsFilterCriteria() const;
    void setEquationsFilterCriteria(const EquationsFilterCriteria &equationsFilterCriteria);

    static EquationsFilterCriteria defaultEquationFilterCriteria()
    {
        auto defaultSetting =
            Settings::instance()->value("EquationCrossBreeding/ParentSelectionCriteria", "Distance").toString();

        if (defaultSetting.compare("Distance", Qt::CaseSensitivity::CaseInsensitive) == 0)
        {
            return Distance;
        }
        else if (defaultSetting.compare("Pareto", Qt::CaseSensitivity::CaseInsensitive) == 0)
        {
            return Pareto;
        }
        else if (defaultSetting.compare("Complexity", Qt::CaseSensitivity::CaseInsensitive) == 0)
        {
            return Complexity;
        }
        else if (defaultSetting.compare("Age", Qt::CaseSensitivity::CaseInsensitive) == 0)
        {
            return Age;
        }

        return Distance;
    }

   private:
    /**
     * @brief The min range index of the equation, ordered by performance. 1 by default so the best equation
     */
    int _fromEquation{utils::CommandLineParser::getFilterFrom()};

    /**
     * @brief The number of equation selected begining to the fromEquation index.
     */
    int _numberOfEquationsSelected{0};

    /**
     * @brief The total number of equations (as defined in EquationGenerationParameters) it represents the
     * population number.
     */
    int _numberOfEquations;

    /**
     * @brief Parent cross selection criteria, following by default.
     */
    EquationsFilterCriteria _equationsFilterCriteria{defaultEquationFilterCriteria()};
};
}  // namespace equationparameters
