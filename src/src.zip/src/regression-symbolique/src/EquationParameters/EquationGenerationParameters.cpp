#include "EquationGenerationParameters.h"

namespace equationparameters {

int EquationGenerationParameters::equationNumber() const
{
    return _equationNumber;
}

void EquationGenerationParameters::setEquationNumber(int equationNumber)
{
    _equationNumber = equationNumber;
}

int EquationGenerationParameters::equationMaxDepth() const
{
    return _equationMaxDepth;
}

void EquationGenerationParameters::setEquationMaxDepth(int equationMaxDepth)
{
    _equationMaxDepth = equationMaxDepth;
}

uint EquationGenerationParameters::numberOfVariables() const
{
    return _nbVar;
}

void EquationGenerationParameters::setNumberOfVariables(uint nbVar){
    _nbVar = nbVar;
}

QSet<datamodel::EquationNode::NodeType> EquationGenerationParameters::selectedNodesTypes() const
{
    return _selectedNodesTypes;
}

void EquationGenerationParameters::setSelectedNodesTypes(const QSet<datamodel::EquationNode::NodeType> &selectedNodesTypes)
{
    _selectedNodesTypes = selectedNodesTypes;
}

} // namespace equationparameters
