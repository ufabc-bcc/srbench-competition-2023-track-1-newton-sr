#include "EquationFilterParameters.h"

namespace equationparameters {
int EquationFilterParameters::fromEquation() const
{
    return _fromEquation;
}

void EquationFilterParameters::setFromEquation(int fromEquation)
{
    _fromEquation = fromEquation;
}

int EquationFilterParameters::numberOfEquationsSelected() const
{
    return _numberOfEquationsSelected;
}

void EquationFilterParameters::setNumberOfEquationsSelected(int numberOfEquationsSelected)
{
    _numberOfEquationsSelected = numberOfEquationsSelected;
}

int EquationFilterParameters::numberOfEquations() const
{
    return _numberOfEquations;
}

void EquationFilterParameters::setNumberOfEquations(int numberOfEquations)
{
    _numberOfEquations = numberOfEquations;
}

EquationFilterParameters::EquationsFilterCriteria
EquationFilterParameters::getEquationsFilterCriteria() const
{
    return _equationsFilterCriteria;
}

void EquationFilterParameters::setEquationsFilterCriteria(const EquationFilterParameters::EquationsFilterCriteria &equationsFilterCriteria)
{
    _equationsFilterCriteria = equationsFilterCriteria;
}

}
