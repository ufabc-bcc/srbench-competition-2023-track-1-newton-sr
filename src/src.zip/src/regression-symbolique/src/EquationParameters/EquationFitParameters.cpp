#include "EquationFitParameters.h"
#include "Logger_v2/Logger.h"

namespace {
//helper
template <typename T>
struct mnumeric_limits : std::numeric_limits<T> {};

template <typename T>
struct mnumeric_limits<std::atomic<T>> : std::numeric_limits<T> {};
} // anonymous namespace

namespace equationparameters {

int EquationFitParameters::duration() const {
    return _duration_ms;
}

void EquationFitParameters::setDuration(int duration)
{
    //qInfo() << "setfitDuration : " << duration;
    std::string message_info_set_fit_Duration = "setfitDuration : "
            + std::to_string(duration);
    logs::Logger::logInfo(message_info_set_fit_Duration);
    if (_duration_ms != duration) {
        _duration_ms = duration;
        assert(duration >= 0 && duration <= mnumeric_limits<decltype(_duration_ms)>::max());
        Settings::instance()->setValue("EquationGeneration/FitDuration", duration);
//        emit fitParametersChanged(_fitParameters);
    }
}

int EquationFitParameters::populationPeriod() const {
    return _populationPeriod;
}

void EquationFitParameters::setPopulationPeriod(int populationPeriod)
{
    if (_populationPeriod != populationPeriod) {
        _populationPeriod = populationPeriod;
        assert(populationPeriod > 0 && populationPeriod <= mnumeric_limits<decltype(_populationPeriod)>::max());
                //emit fitParametersChanged(_fitParameters);
    }
}



}
