#pragma once

#include "EquationParameters_global.h"
#include "EquationCrossbreedingParameters.h"
#include "EquationFilterParameters.h"
#include "EquationDistanceParameters.h"
#include "EquationMutationParameters.h"
#include "Utils/CommandLineParser.h"
#include "../ViewControllers/EquationsGeneratorController.h"

namespace equationparameters
{
/**
 * @brief The EquationGenerationCyclingParameters class is used as parameter to create a new cycling generation of
 * equation depending on sub parameters :
 * - equation filter
 * - equation crossbreeding
 * - equation mutation
 * And also
 * - the number of generation wanted
 */
class EquationGenerationCyclingParameters
{
   public:
    // getter / setter

    [[nodiscard]] int maxNode()const;
    void setMaxNode(int maxNode);

    int numberOfGenerations() const;
    void setNumberOfGenerations(int numberOfGeneration);

    bool infiniteGeneration()const;
    void setInfiniteGenerations(bool value);

    void setFreshNewGeneration(int value){_freshNewGeneration = value;}
    int freshNewGeneration()const{return _freshNewGeneration;}

    void setDistanceMinimum(double distanceMin);
    double distanceMinimum() const;

    void setActivateDistanceMinimum(int activateDistanceMin);
    int activateDistanceMin() const;

    void setTimeSelected(int time);
    int timeSelected() const;

    const EquationFilterParameters &equationFilterParameters() const;
    void setEquationFilterParameters(const EquationFilterParameters &equationFilterParameters);

    const EquationCrossbreedingParameters &equationCrossbreedingParameters() const;
    void setEquationCrossbreedingParameters(
        const EquationCrossbreedingParameters &equationCrossbreedingParameters);

    const EquationMutationParameters &equationMutationParameters() const;
    void setEquationMutationParameters(const EquationMutationParameters &equationMutationParameters);

    const EquationFitParameters &equationFitParameters() const;
    void setEquationFitParameters(const EquationFitParameters &equationFitParameters);

    const EquationDistanceParameters &equationDistanceParameters() const;
    void setEquationDistanceParameters(const EquationDistanceParameters &equationDistanceParameters);

private:
   
    int _timeSelected{utils::CommandLineParser::getTimeSelected()};
    /**
     * @brief The number of generation wanted, 0 by default
     */
    int _numberOfGenerations{utils::CommandLineParser::getNumberOfGenerations()};
    
    /**
     * @brief If true, the generation cycling won't stop
     */
    bool _infiniteGeneration{false};
    
    /**
     * @brief Minimum distance
     */
    double _distanceMin{utils::CommandLineParser::getDistanceMinimum()};
    /**
     * @brief Activate Min Distance
     */
    int _activateDistanceMin{utils::CommandLineParser::getActivateDistanceMin()};
    /**
     * @brief Parameters related to the filter
     */
    EquationFilterParameters _equationFilterParameters;
    /**
     * @brief Parameters related to the crossbreading
     */
    EquationCrossbreedingParameters _equationCrossbreedingParameters;
    /**
     * @brief Parameters related to the mutations
     */
    EquationMutationParameters _equationMutationParameters;

    /**
     * @brief Parameters related to the fit
     */
    EquationFitParameters _equationFitParameters;

    /**
     * @brief Parameters related to the distance
     */
    EquationDistanceParameters _equationDistanceParameters;

    int _maxNode;
    int _freshNewGeneration;
};
}  // namespace equationparameters
