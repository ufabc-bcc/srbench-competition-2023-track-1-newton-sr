#pragma once

#include <QObject>

#include "EquationParameters_global.h"
#include "Utils/CommandLineParser.h"
#include "Utils/Settings.h"

namespace equationparameters
{
/**
 * @brief The EquationCrossbreedingParameters class is used as parameter to cross bread a list of equation
 * depending on :
 * - parent selection strategy
 * - cross breading method
 */
class EquationCrossbreedingParameters
{
    Q_GADGET
   public:
    enum ParentSelectionStrategy
    {
        Tournament
    };
    Q_ENUM(ParentSelectionStrategy)

    enum ParentSelectionCriteria
    {
        Distance,
        Complexity,
        Pareto,
        Age
    };
    Q_ENUM(ParentSelectionCriteria)

    enum CrossbreedingMethod
    {
        ConstantDepthTreeSubstitution,
        ConstantDepthNodeSubstitution,
        RandomTreeSubstitution
    };
    Q_ENUM(CrossbreedingMethod)

    // getters / setters
    double getCrossbreedingRate() const;
    void setCrossbreedingRate(const double &crossbreedingRate);

    int getTournamentSize() const;
    void setTournamentSize(const int &tournamentSize);

    ParentSelectionStrategy getParentSelectionStrategy() const;
    void setParentSelectionStrategy(const ParentSelectionStrategy &parentSelectionStrategy);

    ParentSelectionCriteria getParentSelectionCriteria() const;
    void setParentSelectionCriteria(const ParentSelectionCriteria &parentSelectionCriteria);

    CrossbreedingMethod getCrossbreedingMethod() const;
    void setCrossbreedingMethod(const CrossbreedingMethod &crossbreedingMethod);

    static ParentSelectionStrategy defaultParentSelectionStrategy()
    {
        auto defaultSetting =
            Settings::instance()->value("EquationCrossBreeding/ParentSelectionStrategy", "Tournament").toString();

        if (defaultSetting.compare("Tournament", Qt::CaseSensitivity::CaseInsensitive) == 0)
        {
            return Tournament;
        }

        return Tournament;
    }

    static ParentSelectionCriteria defaultParentSelectionCriteria()
    {
        auto defaultSetting =
            Settings::instance()->value("EquationCrossBreeding/ParentSelectionCriteria", "Distance").toString();

        if (defaultSetting.compare("Distance", Qt::CaseSensitivity::CaseInsensitive) == 0)
        {
            return Distance;
        }
        else if (defaultSetting.compare("Pareto", Qt::CaseSensitivity::CaseInsensitive) == 0)
        {
            return Pareto;
        }
        else if (defaultSetting.compare("Complexity", Qt::CaseSensitivity::CaseInsensitive) == 0)
        {
            return Complexity;
        }
        else if (defaultSetting.compare("Age", Qt::CaseSensitivity::CaseInsensitive) == 0)
        {
            return Age;
        }

        return Distance;
    }

    static CrossbreedingMethod defaultCrossbreedingMethod()
    {
        auto defaultSetting =
            Settings::instance()->value("EquationCrossBreeding/CrossBreedingStrategy", "Random").toString();

        if (defaultSetting.compare("Random", Qt::CaseSensitivity::CaseInsensitive) == 0)
        {
            return RandomTreeSubstitution;
        }

        return RandomTreeSubstitution;
    }

   private:
    /**
     * @brief Rate of the equations to be crossbred.
     */
    double _crossbreedingRate{utils::CommandLineParser::getCrossbreedingRate()};

    /**
     * @brief Tournament size for the tournament selection method.
     */
    int _tournamentSize{utils::CommandLineParser::getTournamentSize()};

    /**
     * @brief Parent cross selection strategy, following by default.
     */
    ParentSelectionStrategy _parentSelectionStrategy{defaultParentSelectionStrategy()};

    /**
     * @brief Parent cross selection criteria, following by default.
     */
    ParentSelectionCriteria _parentSelectionCriteria{defaultParentSelectionCriteria()};


    /**
     * @brief Parent cross method, depth node substitution by default.
     */
    CrossbreedingMethod _crossbreedingMethod{defaultCrossbreedingMethod()};

    /**
     * @brief The number of different variables on the equations
     */
    uint _nbVar{0};
};
}  // namespace equationparameters
