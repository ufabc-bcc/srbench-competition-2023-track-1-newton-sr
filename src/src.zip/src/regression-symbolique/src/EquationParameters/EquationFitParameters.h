
#pragma once

#include <atomic>
#include "Utils/CommandLineParser.h"

#include "EquationParameters_global.h"
#include "EquationGenerationParameters.h"
#include <assert.h>
#include "Utils/Settings.h"

namespace equationparameters
{
/**
 * @brief The EquationMutationParameters class is used as parameter to create mutated equations
 * depending on :
 * - mutation rate
 * - generation sub paramater
 */
class EquationFitParameters
{
   public:
    // getter / setter
    int duration() const; // in ms
    void setDuration(int duration);

    int populationPeriod() const;
    void setPopulationPeriod(int populationPeriod);

//    const equationparameters::EquationGenerationParameters &equationGenerationParameters() const;
//    void setEquationGenerationParameters(
//        const equationparameters::EquationGenerationParameters &equationGenerationParameters);

   private:

//    std::atomic_uint16_t _duration_ms{0};
//    std::atomic_uint16_t _populationPeriod{1};
      int _duration_ms{0};
      int _populationPeriod{1};
    // TODO already exist in mutation and crossbreeding parameters
//    /**
//     * @brief The generation parameter used to fit
//     */
//    equationparameters::EquationGenerationParameters _equationGenerationParameters;
};
}  // namespace equationparameters
