#include "EquationCrossbreedingParameters.h"

namespace equationparameters
{
double EquationCrossbreedingParameters::getCrossbreedingRate() const { return _crossbreedingRate; }

void EquationCrossbreedingParameters::setCrossbreedingRate(const double &crossbreedingRate)
{
    _crossbreedingRate = crossbreedingRate;
}

EquationCrossbreedingParameters::ParentSelectionStrategy
EquationCrossbreedingParameters::getParentSelectionStrategy() const
{
    return _parentSelectionStrategy;
}

void EquationCrossbreedingParameters::setParentSelectionStrategy(
    const EquationCrossbreedingParameters::ParentSelectionStrategy &parentSelectionStrategy)
{
    _parentSelectionStrategy = parentSelectionStrategy;
}

EquationCrossbreedingParameters::ParentSelectionCriteria
EquationCrossbreedingParameters::getParentSelectionCriteria() const
{
    return _parentSelectionCriteria;
}

void EquationCrossbreedingParameters::setParentSelectionCriteria(
    const EquationCrossbreedingParameters::ParentSelectionCriteria &parentSelectionCriteria)
{
    _parentSelectionCriteria = parentSelectionCriteria;
}

int EquationCrossbreedingParameters::getTournamentSize() const { return _tournamentSize; }

void EquationCrossbreedingParameters::setTournamentSize(const int &tournamentSize)
{
    _tournamentSize = tournamentSize;
}

EquationCrossbreedingParameters::CrossbreedingMethod EquationCrossbreedingParameters::getCrossbreedingMethod()
    const
{
    return _crossbreedingMethod;
}

void EquationCrossbreedingParameters::setCrossbreedingMethod(const CrossbreedingMethod &crossbreedingMethod)
{
    _crossbreedingMethod = crossbreedingMethod;
}
}  // namespace equationparameters
