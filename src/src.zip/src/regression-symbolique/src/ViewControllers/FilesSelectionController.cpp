#include "FilesSelectionController.h"
#include "Logger_v2/Logger.h"

#include <QDebug>
#include <QFile>
#include "FileReaderWriter/InputDataReader.h"

#define CSV "csv"
#define TSV "tsv"

namespace viewcontroller
{
FilesSelectionController::FilesSelectionController(QObject *parent) : QObject(parent) {}

void FilesSelectionController::onInputDataFileSelected(QUrl fileUrl)
{
    logs::Logger::logInfo("New input file selected : " + fileUrl.toString().toStdString(), {logs::LogTags::viewController});

    setInputFilePath(fileUrl.toLocalFile());
    QFile selectedFile(inputFilePath());

    QString suffix = selectedFile.fileName().toLower().split('.').last();
    if(suffix != CSV && suffix != TSV){
        logs::Logger::logError("Selected file extension not supported", {logs::LogTags::viewController});
        emit fileReadingError(QStringLiteral("Selected file extension not supported"));
        return;
    }

    if (!selectedFile.exists()) {
        logs::Logger::logError("Selected file does not exists", {logs::LogTags::viewController});
        emit fileReadingError(QStringLiteral("Selected file does not exists"));
        return;
    }

    if (!selectedFile.open(QIODevice::ReadOnly)) {
        logs::Logger::logError("Selected file cannot be read", {logs::LogTags::viewController});
        emit fileReadingError(QStringLiteral("Selected file cannot be read"));
        return;
    }

    filereaderwriter::InputDataReader inputReader(inputFilePath().toStdString());

    std::vector<datamodel::DataPoint> datas = inputReader.readDataFile();

    if (datas.empty()) {
        if (!inputReader.error()) {
            logs::Logger::logError("Selected file contains empty data", {logs::LogTags::viewController});
            emit fileReadingError(QStringLiteral("Selected file contains empty data"));
            return;
        }
        else {
            logs::Logger::logError("An error occured during parsing of file : "
                                     , {logs::LogTags::viewController}
                                     ,std::invalid_argument(inputReader.errorString()));
            emit fileReadingError(QStringLiteral("An error occured during parsing of file : ") +
                                  QString(inputReader.errorString().c_str()));
            return;
        }
    }

    logs::Logger::logInfoDetail("Input file successfully readed");
    QList<datamodel::DataPoint> datas_qt(datas.begin(), datas.end());
    emit inputDatasImported(datas_qt);
}

const QString &FilesSelectionController::inputFilePath() const { return _inputFilePath; }

void FilesSelectionController::setInputFilePath(const QString &inputFilePath)
{
    if (_inputFilePath != inputFilePath)
    {
        _inputFilePath = inputFilePath;
        emit inputFilePathChanged();
    }
}
}  // namespace viewcontroller
