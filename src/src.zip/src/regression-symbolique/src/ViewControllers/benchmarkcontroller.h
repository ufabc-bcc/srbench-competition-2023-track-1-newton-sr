
#pragma once

#include <QDebug>
#include <QtCharts/QAbstractSeries>
#include <QtCharts/QChart>
#include <QtCharts/QChartView>
#include <QtCharts/QLineSeries>
#include <QtCharts/QLogValueAxis>
#include <QtCharts/QScatterSeries>
#include <QtCharts/QValueAxis>
#include <QtCharts/QXYSeries>
#include <QtCharts/QBarSet>
#include <QtCharts/QStackedBarSeries>
#include <QtCharts/QBarCategoryAxis>
#include <QtCharts/QAbstractBarSeries>
#include <QtCharts/QAbstractSeries>


#include <algorithm>
#include <cmath>

#include "../DataModel/EquationTree.h"
#include "../DataModel/EquationTreeItem.h"
#include "ViewControllers_global.h"

using namespace QtCharts;

namespace viewcontroller {

/**
 * @brief The EquationParetoEfficiencyController class handle the computation of
 * pareto efficiency (distance / complexity and pareto frontier) and provide the
 * results
 */
class BenchmarkController
    : public QObject {
  Q_OBJECT
    Q_PROPERTY(bool processBenchmark READ processBenchmark WRITE setProcessBenchmark NOTIFY sendProcessBenchmark)
    Q_PROPERTY(bool displaySignalsBench READ displaySignalsBench WRITE setDisplaySignalsBench NOTIFY sendDisplaySignalsBench )
    Q_PROPERTY(bool displayFitnessBench READ displayFitnessBench WRITE setDisplayFitnessBench NOTIFY sendDisplayFitnessBench )

private:

  QBarSet *_crossbreeding ;
  QBarSet *_mutation ;
  QBarSet *_filter ;
  QBarSet *_pareto ;
  QBarSet *_process_clean_and_new_equation;
  QBarSet *_signals_process ;
  QBarSet *_fitness ;
  QBarSet *_simplification ;

  QAbstractSeries* _equationSeries{nullptr};
  QStackedBarSeries* _previousSeries = nullptr;
  QBarCategoryAxis * _previousX =  nullptr;
  Q_DISABLE_COPY_MOVE(BenchmarkController)
  bool _processBenchmark{false};
  bool _displaySignalsBench{false};
   bool _displayFitnessBench{false};
  int gen =0;
  QStringList categories;
  /**
   * @brief The pareto chart
   */
  QChart* _benchmarkChart{nullptr};

  /**
   * @brief X axis pointer
   */
  QValueAxis * _xAxis{nullptr};

  /**
   * @brief Y axis pointer
   */
  QAbstractAxis* _yAxis{nullptr};

  /**
   * @brief True if the chart are initialized
   */
  bool _initialized{false};

  /**
   * @brief Put points into chart
   */
  void plotPoints();

  /**
   * @brief Put series into chart
   */
  void plotSeries();

  /**
   * @brief Choose point with a pareto level lower than _maxParetoSeries
   */
  void filteredPoints();

  /**
   * @brief map equations distance and complexity to a Series Points
   * @param equations
   */
  void mapSeriesPoints(const datamodel::Equations& equations);



  /**
   * @brief Update X and Y axes scale
   */
  void updateAxes();

  /**
   * @brief Update the chart display, call when _maxParetoSeries is modified
   */
  void updateDisplay();
 public:
  explicit BenchmarkController(QObject* parent = nullptr);
  void setProcessBenchmark(bool value);
  void setDisplaySignalsBench(bool value);
  void setDisplayFitnessBench(bool value);
  void setProcessBenchmark(bool value1, bool value2, bool value3);
  bool processBenchmark() const;
  bool displaySignalsBench() const;
  bool displayFitnessBench() const;

  /**
   * @brief init Initialise the fitness series
   * @param average The error average series
   * @param best The best error series
   */
  void init(QAbstractSeries *equations);
  void initSeries(QBarSet *crossbreeding, QBarSet *mutation, QBarSet *filter, QBarSet *pareto, QBarSet *process_clean_and_new_equation, QBarSet *signals_process, QBarSet *fitness, QBarSet *simplification);
  void benchmarkChartUpdate(int max_time, int generationValue);
  void benchmarkChartReset();

  public slots:
    void receiveProcessBenchmark(bool value);
    void receiveDisplaySignalsBench(bool value);
    void receiveDisplayFitnessBench(bool value);

  signals:
    void sendProcessBenchmark(bool value);
    void sendDisplaySignalsBench(bool value);
    void sendDisplayFitnessBench(bool value);




};

}  // namespace viewcontroller
