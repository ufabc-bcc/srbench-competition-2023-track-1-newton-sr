#include <QDebug>
#include <QPointF>
#include <QtCharts/QLineSeries>

#include "DataModel/EquationTreeItem.h"
#include "EquationFitness.h"
#include "Logger_v2/Logger.h"

using namespace QtCharts;

namespace viewcontroller
{
void EquationFitness::init(QAbstractSeries *average, QAbstractSeries *best, int *fitnessRefreshValue, int *fitnessRefreshCountValue)
{
    fitenessRefreshRate = fitnessRefreshValue;
    fitnessCurrentCount = fitnessRefreshCountValue;
    // init the two series with the pointers comming from the Qml
    if (average != nullptr && best != nullptr)
    {
        QXYSeries *averageSeries = static_cast<QXYSeries *>(average);
        if (averageSeries != nullptr)
        {
            _averageSeries = averageSeries;
        }
        QXYSeries *bestSeries = static_cast<QXYSeries *>(best);
        if (bestSeries != nullptr)
        {
            _bestSeries = bestSeries;
        }

        if (_bestSeries != nullptr && _averageSeries != nullptr)
        {
            _initialized = true;
        }
        else
        {
            //qWarning() << "[EquationFitness] Initialization failed, one or more series are invalid or null.";
            logs::Logger::logWarning("[EquationFitness] Initialization failed, one or more series are invalid or null.",
                                     {logs::LogTags::viewController, logs::LogTags::fitness});
        }
    }
}

void EquationFitness::clear()
{
    if (_initialized)
    {
        _bestSeries->clear();
        _averageSeries->clear();
        _generationNumber = 0;
        _yMax = 0;
        _yMin = 1;
    }
}

void EquationFitness::addGeneration(const datamodel::EquationTree* generation, uint generationSize, int breedAndMutationRate)
{

    if (_initialized && generationSize != 0)
    {
        // compute the best and average distance points
        EquationFitness::GenerationPoints points = computeSeriesPoints(generation, generationSize, breedAndMutationRate);

        // append the series' points
        _averageSeries->append(points.averageGenerationPoint);
        _bestSeries->append(points.bestGenerationPoint);

        // update the series' axis
        *fitnessCurrentCount =  *fitnessCurrentCount +1;
        if( *fitenessRefreshRate == *fitnessCurrentCount ){
             updateAxis();
            *fitnessCurrentCount = 0;
        }

    }

}

EquationFitness::GenerationPoints EquationFitness::computeSeriesPoints(const datamodel::EquationTree* generation, uint generationSize, int breedAndMutationRate)
{
    double min = -1;
    double sum = 0;
   // QMapIterator<int, QPair<datamodel::EquationTreeItem, double>> equationsIterator(generation);

    // for each unchanged equation we check the minimum and compute the sum
    for(uint i = 0; i < generationSize - breedAndMutationRate; i++)
    {
        double distance = generation[i].distance();
        min = (min < 0) ? distance : qMin(min, distance);
        sum += distance;
    }

    // we keep iterating on breeded and mutated equations to check the minimum
    for(uint i = generationSize - breedAndMutationRate; i < generationSize; i++)
    {
        double distance = generation[i].distance();
        min = (min < 0) ? distance : qMin(min, distance);
    }

    // compute the average of the generation
    double average = sum / (generationSize - breedAndMutationRate);

    // we compute the maximum to know what is the max y we can have
    _yMax = qMax(_yMax, average);

    // we compute the minimum to know what is the min y we can have ( >0 )
    double tempMin = qMin(_yMin, min);
    _yMin = tempMin = 0 ? _yMin : tempMin;

    // create the points
    EquationFitness::GenerationPoints pts;
    pts.averageGenerationPoint = QPointF(_generationNumber, average);
    pts.bestGenerationPoint = QPointF(_generationNumber, min);

    // increment the number of generation done (used for x axis)
    _generationNumber++;

    return pts;
}


void EquationFitness::updateAxis()
{
    QAbstractAxis *xAxis = _averageSeries->attachedAxes().at(0);
    QAbstractAxis *yAxis = _averageSeries->attachedAxes().at(1);

    // we update the maximum for x and range for y axis
    if (xAxis != nullptr && yAxis != nullptr)
    {
        xAxis->setMax(_generationNumber);
        yAxis->setRange(_yMin, _yMax);
    }
}

}  // namespace viewcontroller
