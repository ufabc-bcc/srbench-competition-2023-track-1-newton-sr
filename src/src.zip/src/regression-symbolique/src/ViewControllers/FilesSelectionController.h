
#pragma once

#include <QObject>
#include <QUrl>

#include "DataModel/DataPoint.h"

namespace viewcontroller
{
/**
 * @brief The FilesSelectionController class allows to retrieve user info related to input file selection
 */
class FilesSelectionController : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QString inputFilePath READ inputFilePath WRITE setInputFilePath NOTIFY inputFilePathChanged)
   public:
    explicit FilesSelectionController(QObject *parent = nullptr);

    const QString &inputFilePath() const;
    void setInputFilePath(const QString &inputFilePath);

   public slots:
    void onInputDataFileSelected(QUrl fileUrl);

   signals:
    void inputFilePathChanged();
    void fileReadingError(QString error);
    void inputDatasImported(QList<datamodel::DataPoint> datas);

   private:
    Q_DISABLE_COPY_MOVE(FilesSelectionController)

    QString _inputFilePath;
};
}  // namespace viewcontroller
