
#pragma once

#include <QObject>
#include <QFileInfo>

#include "EquationParameters/EquationFilterParameters.h"
#include "EquationParameters/EquationGenerationCyclingParameters.h"
#include "EquationParameters/EquationGenerationParameters.h"
#include "EquationParameters/EquationMutationParameters.h"
#include "EquationCrossbreedingController.h"
#include "EquationMutationController.h"
#include "EquationsFilterController.h"
#include "EquationDistanceController.h"
#include "EquationsGeneratorController.h"
#include "EquationParetoEfficiencyController.h"
#include "benchmarkcontroller.h"
#include "GenerationCyclingController.h"
#include "InputDataViewController.h"
#include "ViewControllers_global.h"

namespace viewcontroller
{
/*!
 * @brief High level class to manage all the parameters of the application
 */
class ParametersControllers : public QObject
{
    Q_OBJECT

    Q_PROPERTY(QString textStartButton READ textStartButton WRITE setTextStartButton NOTIFY textStartButtonUpdated)
    Q_PROPERTY(QString textGeneration READ textGeneration WRITE setTextGeneration NOTIFY textGenerationUpdated)
    Q_PROPERTY(QString generationElapsedTime READ generationElapsedTime WRITE setGenerationElapsedTime NOTIFY generationElapsedTimeUpdated)
    Q_PROPERTY(bool isEnableButton READ isEnableButton WRITE setIsEnableButton NOTIFY isEnableButtonUpdated)

    Q_PROPERTY(QString colorDistance READ colorDistance WRITE setColorDistance NOTIFY colorDistanceChanged)
    Q_PROPERTY(QString colorNumberOfGenerations READ colorNumberOfGenerations WRITE setColorNumberOfGenerations NOTIFY colorNumberOfGenerationsChanged)

    Q_PROPERTY(QString colorTime READ colorTime WRITE setColorTime NOTIFY colorTimeChanged)

    Q_PROPERTY(viewcontroller::EquationsGeneratorController *equationGenerationController READ
                   equationGenerationController CONSTANT)
    Q_PROPERTY(
        viewcontroller::EquationsFilterController *equationFilterController READ equationFilterController CONSTANT)
    Q_PROPERTY(viewcontroller::EquationCrossbreedingController *equationCrossbreedingController READ
                   equationCrossbreedingController CONSTANT)
    Q_PROPERTY(viewcontroller::GenerationCyclingController *generationCyclingController READ
                   generationCyclingController CONSTANT)
    Q_PROPERTY(
        viewcontroller::InputDataViewController *inputDataViewController READ inputDataViewController CONSTANT)
    Q_PROPERTY(EquationMutationController *equationMutationController READ equationMutationController CONSTANT)
    Q_PROPERTY(EquationParetoEfficiencyController *equationParetoEfficiencyController READ
                   equationParetoEfficiencyController CONSTANT)

    Q_PROPERTY(BenchmarkController *benchmarkController READ
                   benchmarkController CONSTANT)

    Q_PROPERTY(int timeSelected READ timeSelected WRITE setTimeSelected NOTIFY timeSelectedChanged)

    Q_PROPERTY(QString nameDisplay READ
               nameDisplay CONSTANT)
    Q_PROPERTY(QString nameDisplay READ nameDisplay WRITE setNameDisplay NOTIFY nameDisplayChanged)

    Q_PROPERTY(QString targetDisplay READ
               targetDisplay CONSTANT)
    Q_PROPERTY(QString targetDisplay READ targetDisplay WRITE setTargetDisplay NOTIFY targetDisplayChanged)

    Q_PROPERTY(int fitnessRefreshRate READ fitnessRefreshRate WRITE setFitnessRefreshRate NOTIFY
                   fitnessRefreshRateChanged)

    Q_PROPERTY(
        viewcontroller::EquationDistanceController *equationDistanceController READ equationDistanceController CONSTANT)



   public:
    explicit ParametersControllers(QObject *parent = nullptr);

    /*!
     * @brief Register the qml types for the qml
     */
    void registerQmlTypes();

    /*!
     * @brief Get the controller of the view to manage the parameters of the equation generation
     * @return the controller of the view to manage the parameters of the equation generation
     */
    EquationsGeneratorController *equationGenerationController();

    /*!
     * @brief Get the controller of the view to manage the parameters of the filter of the equations
     * @return the controller of the view to manage the parameters of the filter of the equations
     */
    EquationsFilterController *equationFilterController();

    /*!
     * @brief Get the controller of the view to manage the parameters of the distance of the equations
     * @return the controller of the view to manage the parameters of the distance of the equations
     */
    EquationDistanceController *equationDistanceController();

    EquationCrossbreedingController *equationCrossbreedingController();

    GenerationCyclingController *generationCyclingController();

    InputDataViewController *inputDataViewController();

    EquationMutationController *equationMutationController();

    EquationParetoEfficiencyController *equationParetoEfficiencyController();

    BenchmarkController *benchmarkController();

    QString textStartButton()const;
    QString textGeneration() const;
    QString generationElapsedTime() const;
    void setTextStartButton(const QString& value);
    void setTextGeneration (const QString& value);
    void setGenerationElapsedTime (const QString& value);

    bool isEnableButton()const;
    void setIsEnableButton(const bool& value);

    QString colorDistance()const;
    void setColorDistance(const QString& value);

    QString colorNumberOfGenerations()const;
    void setColorNumberOfGenerations(const QString& value);

    QString colorTime() const;
    void setColorTime(const QString& value);

    int timeSelected()const;
    void setTimeSelected(int time);

    QString nameDisplay()const;
    void setNameDisplay(const QString& name);

    QString targetDisplay()const;
    void setTargetDisplay(const QString& name);

    int fitnessRefreshRate() const;
    void setFitnessRefreshRate(int);


   public slots:

    /**
     * @brief   This slot should be called when the generation is in finite
     *          mode, and reached max generation count
     */
    void refreshStartButton();
    void refreshTestGeneration(const QString &value);
    void refreshGenerationElapsedTime(const QString &value);

    void initStartButton();
    void initTestGeneration();
    void initGenerationElapsedTime();

    void redDistanceMin();
    void redNumberOfGenerations();
    void redTime();

    /**
     * @brief Forward the reset clicked event to the AlgorithmController
     */
    void forwardResetButtonClickedEvent();

    /**
     * @brief Forward the pause button clicked event to the AlgorithmController
     */
    void forwardPauseButtonClickedEvent();

    /**
     * @brief Forward the continue button clicked event to the AlgorithmController
     */
    void forwardContinueButtonClickedEvent();

    /**
     * @brief Forward the start button clicked event to the AlgorithmController
     */
    void forwardStartButtonClickedEvent();

    /**
     * @brief Forward the init button clicked event to the Algorithm Controller
     */
    void forwardInitButtonClickedEvent(equationparameters::EquationGenerationParameters);


    void resetColors();

    void forwardProcessBenchmarkChanged(bool value1, bool value2, bool value3);

   signals:

    void textStartButtonUpdated(QString);
    void textGenerationUpdated(QString);
    void generationElapsedTimeUpdated(QString);
    void resetBenchmarkChart();
    void isEnableButtonUpdated(bool);
    void initButtonClicked(equationparameters::EquationGenerationParameters, equationparameters::EquationDistanceParameters);
    void startButtonClicked(equationparameters::EquationGenerationParameters, equationparameters::EquationGenerationCyclingParameters);

    void pauseButtonClicked();
    void continueButtonClicked(bool infiniteGeneration, int numberOfGeneration, double distanceMinimum,
                               int activateDistanceMin, int timeSelected, const equationparameters::EquationFilterParameters & eqFilterParams);
    void colorDistanceChanged(QString color);
    void colorNumberOfGenerationsChanged(QString color);
    void colorTimeChanged(QString color);
    void resetButtonClicked();
    void setDisplayEquationListControler();
    void setDisplayParetoController();
    void instantRefreshEquationListControler();
    void clearRefreshEquationListControler();
    void setDisplayFitnessController();
    void instantRefreshFitness();
    void processBenchmarkChanged(bool value1, bool value2, bool value3);



    void timeSelectedChanged(int time);

    void nameDisplayChanged(QString name);

    void targetDisplayChanged(QString name);

    void inputDataSelected(const QString &inputFilePath, const QVariant &inputDatas);

    void fitnessRefreshRateChanged(int);

   private:
    Q_DISABLE_COPY_MOVE(ParametersControllers)

    EquationsFilterController _equationFilterController;

    EquationDistanceController _equationDistanceController;

    EquationsGeneratorController _equationGenerationController;

    EquationCrossbreedingController _equationCrossbreedingController;

    GenerationCyclingController _generationCyclingController;

    InputDataViewController _inputDataViewController;

    EquationMutationController _equationMutationController;

    EquationParetoEfficiencyController _equationParetoEfficiencyController;

    BenchmarkController _benchmarkController;

    QString _textStartButton{"Start"};
    QString _textGeneration{"0"};
    QString _generationElapsedTime{"0 ms"};
    bool _isEnableButton = false;
    QString _colorDistance{"black"};
    QString _colorNumberOfGenerations{"black"};
    QString _colorTime{"black"};
    int _time = 0;
    QString _nameDisplay{""};
    QString _targetDisplay{""};
    int _fitnessRefreshRate{1};

};
}  // namespace viewcontroller
