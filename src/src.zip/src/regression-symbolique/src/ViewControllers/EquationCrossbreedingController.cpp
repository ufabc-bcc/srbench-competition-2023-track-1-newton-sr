#include "EquationCrossbreedingController.h"

namespace viewcontroller
{
EquationCrossbreedingController::EquationCrossbreedingController(QObject *parent) : QObject(parent) {}

double
EquationCrossbreedingController::getCrossbreedingRate() const
{
    return _equationCrossBreadingParameters.getCrossbreedingRate();
}

void EquationCrossbreedingController::setCrossbreedingRate(const double crossbreedingRate)
{
    if(_equationCrossBreadingParameters.getCrossbreedingRate() != crossbreedingRate)
    {
        _equationCrossBreadingParameters.setCrossbreedingRate((crossbreedingRate));
        Settings::instance()->setValue("EquationCrossBreeding/CrossBreedingRate", 100 * crossbreedingRate);
        emit crossbreedingRateChanged();
    }
}


equationparameters::EquationCrossbreedingParameters::ParentSelectionStrategy
EquationCrossbreedingController::getParentSelectionStrategy() const
{
    return _equationCrossBreadingParameters.getParentSelectionStrategy();
}

void EquationCrossbreedingController::setParentSelectionStrategy(
    const equationparameters::EquationCrossbreedingParameters::ParentSelectionStrategy &parentSelectionStrategy)
{
    if (_equationCrossBreadingParameters.getParentSelectionStrategy() != parentSelectionStrategy)
    {
        _equationCrossBreadingParameters.setParentSelectionStrategy(parentSelectionStrategy);
        QMetaEnum metaEnum = QMetaEnum::fromType<equationparameters::EquationCrossbreedingParameters::ParentSelectionStrategy>();
        Settings::instance()->setValue("EquationCrossBreeding/ParentSelectionStrategy", metaEnum.valueToKey(parentSelectionStrategy));
        emit parentSelectionStrategyChanged();
    }
}

equationparameters::EquationCrossbreedingParameters::ParentSelectionCriteria
EquationCrossbreedingController::getParentSelectionCriteria() const
{
    return _equationCrossBreadingParameters.getParentSelectionCriteria();
}

void EquationCrossbreedingController::setParentSelectionCriteria(
    const equationparameters::EquationCrossbreedingParameters::ParentSelectionCriteria &parentSelectionCriteria)
{
    if (_equationCrossBreadingParameters.getParentSelectionCriteria() != parentSelectionCriteria)
    {
        _equationCrossBreadingParameters.setParentSelectionCriteria(parentSelectionCriteria);
        QMetaEnum metaEnum = QMetaEnum::fromType<equationparameters::EquationCrossbreedingParameters::ParentSelectionCriteria>();
        Settings::instance()->setValue("EquationCrossBreeding/ParentSelectionCriteria", metaEnum.valueToKey(parentSelectionCriteria));
        emit parentSelectionCriteriaChanged();
    }
}

int EquationCrossbreedingController::getTournamentSize() const
{
    return _equationCrossBreadingParameters.getTournamentSize();
}

void EquationCrossbreedingController::setTournamentSize(const int &tournamentSize)
{
    if (_equationCrossBreadingParameters.getTournamentSize() != tournamentSize)
    {
        _equationCrossBreadingParameters.setTournamentSize(tournamentSize);
        Settings::instance()->setValue("EquationCrossBreeding/TournamentSize", tournamentSize);
        emit tournamentSizeChanged();
    }
}

equationparameters::EquationCrossbreedingParameters::CrossbreedingMethod
EquationCrossbreedingController::getCrossbreedingMethod() const
{
    return _equationCrossBreadingParameters.getCrossbreedingMethod();
}

void EquationCrossbreedingController::setCrossbreedingMethod(
    const equationparameters::EquationCrossbreedingParameters::CrossbreedingMethod &crossbreedingMethod)
{
    if (_equationCrossBreadingParameters.getCrossbreedingMethod() != crossbreedingMethod)
    {
        _equationCrossBreadingParameters.setCrossbreedingMethod(crossbreedingMethod);
        QMetaEnum metaEnum = QMetaEnum::fromType<equationparameters::EquationCrossbreedingParameters::CrossbreedingMethod>();
        Settings::instance()->setValue("EquationCrossBreeding/CrossBreedingStrategy", metaEnum.valueToKey(crossbreedingMethod));
        emit crossbreedingMethodChanged();
    }
}

void EquationCrossbreedingController::onEquationCrossBreedingRequest()
{
    emit equationsCrossbreedingRequired(_equationCrossBreadingParameters);
}

const equationparameters::EquationCrossbreedingParameters &
EquationCrossbreedingController::getEquationCrossBreadingParameters() const
{
    return _equationCrossBreadingParameters;
}

}  // namespace viewcontroller
