
#pragma once

#include <QObject>

#include "ViewControllers_global.h"
#include "Utils/CommandLineParser.h"

namespace viewcontroller
{
/**
 * @brief The EquationMutationController class create the link between Qml and Equation algorihtmes
 */
class EquationMutationController : public QObject
{
    Q_OBJECT

    Q_PROPERTY(double mutationRate READ mutationRate WRITE setMutationRate NOTIFY mutationRateChanged)
    Q_PROPERTY(int nbMutationPossible READ nbMutationPossible WRITE setNbMutationPossible NOTIFY nbMutationPossibleChanged)

   public:
    EquationMutationController(QObject *parent = nullptr);

    // property getter/setter
    double mutationRate() const;
    void setMutationRate(double mutationRate);

    int nbMutationPossible() const;
    void setNbMutationPossible(int nbMutationPossible);
   signals:
    // property signal
    void mutationRateChanged();
    void nbMutationPossibleChanged();

   private:
    /**
     * @brief The rate of mutation, 0.15 by default
     */
    double _mutationRate{utils::CommandLineParser::getMutationRate()};
    int _nbMutationPossible{utils::CommandLineParser::getNbMutationPossible()};

};
}  // namespace viewcontroller
