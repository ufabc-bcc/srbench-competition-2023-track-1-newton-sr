#include "EquationMutationController.h"
#include "Utils/Settings.h"

namespace viewcontroller {

EquationMutationController::EquationMutationController(QObject *parent) : QObject(parent) {}

double EquationMutationController::mutationRate() const
{
    return _mutationRate;
}

void EquationMutationController::setMutationRate(double mutationRate)
{
    if (_mutationRate != mutationRate) {
        _mutationRate = mutationRate;
        Settings::instance()->setValue("EquationMutation/MutationRate", 100 * mutationRate);
        emit mutationRateChanged();
    }
}


int EquationMutationController::nbMutationPossible() const
{
    return _nbMutationPossible;
}

void EquationMutationController::setNbMutationPossible(int nbMutationPossible)
{
    if (_nbMutationPossible != nbMutationPossible) {
        _nbMutationPossible = nbMutationPossible;
        Settings::instance()->setValue("EquationMutation/NbOfMutations", nbMutationPossible);
        emit nbMutationPossibleChanged();
    }
}

}
