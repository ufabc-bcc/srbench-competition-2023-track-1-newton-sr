
#pragma once

#include <QObject>
#include <QList>

#include "DataModel/DataPoint.h"

namespace viewcontroller {
class InputDataViewController : public QObject
{
    Q_OBJECT
    Q_PROPERTY(QList<datamodel::DataPoint> inputDatas READ inputDatas NOTIFY inputDatasChanged)
public:
    explicit InputDataViewController(QObject *parent = nullptr);

    QList<datamodel::DataPoint> inputDatas() const;
    std::vector<datamodel::DataPoint> inputDatas_v() const{return _inputDatas;};

signals:
    void inputDatasChanged();

public slots:
    void onInputDatasChanged(const QList<datamodel::DataPoint> inputDatas);
private:
    Q_DISABLE_COPY_MOVE(InputDataViewController)

    std::vector<datamodel::DataPoint> _inputDatas;
    };
} // namespace viewcontroller

