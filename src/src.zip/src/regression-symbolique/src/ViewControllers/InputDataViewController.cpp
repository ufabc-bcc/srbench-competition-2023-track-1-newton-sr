#include <QDebug>

#include "InputDataViewController.h"

namespace viewcontroller {
InputDataViewController::InputDataViewController(QObject *parent) : QObject(parent)
{

}

QList<datamodel::DataPoint> InputDataViewController::inputDatas() const
{
    QList<datamodel::DataPoint> data(_inputDatas.begin(), _inputDatas.end());
    return data;
}

void InputDataViewController::onInputDatasChanged(const QList<datamodel::DataPoint> inputDatas)
{
    std::vector<datamodel::DataPoint> inputDatas_v(inputDatas.begin(), inputDatas.end());

    if (inputDatas_v != _inputDatas) {
        _inputDatas = inputDatas_v;
        emit inputDatasChanged();
    }
}

}  // namespace viewcontroller
