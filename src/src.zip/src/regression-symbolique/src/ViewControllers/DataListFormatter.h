
#pragma once

#include <QAbstractListModel>

#include "DataModel/DataPoint.h"
#include "ViewControllers_global.h"

namespace viewcontroller
{
/**
 * @brief The DataListFormatter class is used as list in qml
 */
class DataListFormatter : public QAbstractListModel
{
    Q_OBJECT

    Q_PROPERTY(QList<datamodel::DataPoint> datas READ datas WRITE setDatas NOTIFY datasChanged)
   public:
    enum DataRoles
    {
        Value= Qt::UserRole,
        Parameters
    };
    Q_ENUM(DataRoles)

    DataListFormatter(QObject *parent = nullptr);

    /// Override funtion of QAbstractListModel
    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const override;
    /// Override funtion of QAbstractListModel
    int rowCount(const QModelIndex &parent = QModelIndex()) const override;
    /// Override funtion of QAbstractListModel
    QHash<int, QByteArray> roleNames() const override;

    const QList<datamodel::DataPoint> &datas() const;
    void setDatas(const QList<datamodel::DataPoint> &datas);

   signals:
    void datasChanged();

   private:
    Q_DISABLE_COPY_MOVE(DataListFormatter)

    QList<datamodel::DataPoint> _datas;
};
}  // namespace viewcontroller
