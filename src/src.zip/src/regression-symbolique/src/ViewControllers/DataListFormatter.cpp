#include "DataListFormatter.h"
#include "QDebug"

namespace viewcontroller
{
DataListFormatter::DataListFormatter(QObject *parent) : QAbstractListModel(parent)
{
    qRegisterMetaType<datamodel::DataPoint>();
}

QVariant DataListFormatter::data(const QModelIndex &index, int role) const
{
    if (index.row() < 0 || index.row() >= rowCount())
    {
        return QVariant();
    }

    switch (role)
    {
        case Parameters:
            return QVariant::fromValue(_datas.at(index.row()).parameterList());
        case Value:
            return _datas.at(index.row()).result();
        default:
            return QVariant();
    }
}

int DataListFormatter::rowCount(const QModelIndex &parent) const
{
    Q_UNUSED(parent)
    return _datas.size();
}

QHash<int, QByteArray> DataListFormatter::roleNames() const
{
    QHash<int, QByteArray> roles;
    roles.insert(Parameters, "Parameters");
    roles.insert(Value, "Value");
    return roles;
}

const QList<datamodel::DataPoint> &DataListFormatter::datas() const { return _datas; }

void DataListFormatter::setDatas(const QList<datamodel::DataPoint> &datas)
{
    if (datas != _datas)
    {
        beginResetModel();
        _datas = datas;
        emit datasChanged();
        endResetModel();
    }
}


}  // namespace viewcontroller

