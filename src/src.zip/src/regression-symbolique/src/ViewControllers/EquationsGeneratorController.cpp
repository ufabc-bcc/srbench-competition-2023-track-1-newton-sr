#include "EquationsGeneratorController.h"
#include "Utils/Settings.h"
#include "Logger_v2/Logger.h"

namespace viewcontroller {


EquationsGeneratorController::EquationsGeneratorController(QObject *parent) : QObject(parent) {
    QObject::connect(&_selectedNodeListController, &SelectedNodeListController::selectedNodesTypesChanged, this,
                     &EquationsGeneratorController::onEquationNodeTypeChanged);

    _equationGenerationParameters.setEquationNumber(utils::CommandLineParser::getBasePopulation());
    _equationGenerationParameters.setEquationMaxDepth(utils::CommandLineParser::getEquationMaximumDepth());
    _equationGenerationParameters.setSelectedNodesTypes(_selectedNodeListController.selectedNodesTypes());

    setFitDuration(utils::CommandLineParser::getFitDuration());
    setFitPopulationPeriod(utils::CommandLineParser::getFitPopulationPeriod());

    _realNumberPrecision = utils::CommandLineParser::getRealNumberPrecision();
    _maxNode = utils::CommandLineParser::getMaxNode();
    _freshNewGeneration = Settings::instance()->value("EquationGeneration/FreshGeneration", 0).toInt();
    _equationsListRefreshRate = Settings::instance()->value("EquationListRefreshRate", 1).toInt();
}


int EquationsGeneratorController::freshNewGeneration() const { return _freshNewGeneration; }

void EquationsGeneratorController::setFreshNewGeneration(int value) {
    if (_freshNewGeneration != value) {
        _freshNewGeneration = value;
        Settings::instance()->setValue("EquationGeneration/FreshGeneration", value);
        emit freshNewGenerationChanged(value);
    }
}

int EquationsGeneratorController::fitDuration() const { return _fitDuration; }

void EquationsGeneratorController::setFitDuration(int value){
    if (_fitDuration != value) {
        _fitDuration = value;
        Settings::instance()->setValue("EquationGeneration/FitDuration", value);
//        emit fitDurationChanged(value);
    }
}

int EquationsGeneratorController::fitPopulationPeriod() const { return _fitPopulationPeriod; }

void EquationsGeneratorController::setFitPopulationPeriod(int value){
    if (_fitPopulationPeriod != value)
    {
        _fitPopulationPeriod = value;
        Settings::instance()->setValue("EquationGeneration/FitPopulationPeriod", value);
//        emit fitPopulationPeriodChanged(value);
    }
}

const equationparameters::EquationGenerationParameters &EquationsGeneratorController::equationGenerationParameters() const {
    return _equationGenerationParameters;
}

int EquationsGeneratorController::realNumberPrecision() const { return _realNumberPrecision; }


void EquationsGeneratorController::setRealNumberPrecision(int value) {
    if (_realNumberPrecision != value) {
        _realNumberPrecision = value;
        Settings::instance()->setValue("EquationGeneration/NumberPrecision", value);
        emit realNumberPrecisionChanged(value);
    }
}

int EquationsGeneratorController::equationNumber() const { return _equationGenerationParameters.equationNumber(); }

void EquationsGeneratorController::setEquationNumber(int equationNumber) {
    if (_equationGenerationParameters.equationNumber() != equationNumber) {
        _equationGenerationParameters.setEquationNumber(equationNumber);
        Settings::instance()->setValue("EquationGeneration/Population", equationNumber);
        emit equationNumberChanged(equationNumber);
    }
}

int EquationsGeneratorController::maxNode() const { return _maxNode; }

void EquationsGeneratorController::setMaxNode(int maxNode) {
    if (_maxNode != maxNode) {
        _maxNode = maxNode;
        Settings::instance()->setValue("EquationGeneration/MaxNodes", maxNode);
        emit maxNodeChanged(_maxNode);
    }
}

int EquationsGeneratorController::equationMaxDepth() const {
    return _equationGenerationParameters.equationMaxDepth();
}

void EquationsGeneratorController::setEquationMaxDepth(int equationMaxDepth) {
    if (_equationGenerationParameters.equationMaxDepth() != equationMaxDepth) {
        _equationGenerationParameters.setEquationMaxDepth(equationMaxDepth);
        Settings::instance()->setValue("EquationGeneration/MaxDepth", equationMaxDepth);
        emit equationMaxDepthChanged();
    }
}

int EquationsGeneratorController::equationsListRefreshRate() const { return _equationsListRefreshRate; }

void EquationsGeneratorController::setEquationsListRefreshRate(int value) {
    if (_equationsListRefreshRate != value) {
        _equationsListRefreshRate  = value;
        Settings::instance()->setValue("EquationListRefreshRate", value);
        emit equationsListRefreshRateChanged(value);
    }
}

void EquationsGeneratorController::onEquationGenerationRequest() {
//           _equationGenerationParameters.equationNumber(), _equationGenerationParameters.equationMaxDepth());
    emit equationGenerationRequired(_equationGenerationParameters);
}

void EquationsGeneratorController::onEquationNodeTypeChanged() {
    _equationGenerationParameters.setSelectedNodesTypes(_selectedNodeListController.selectedNodesTypes());
}

SelectedNodeListController *EquationsGeneratorController::selectedNodeListController() {
    return &_selectedNodeListController;
}

}  // namespace viewcontroller
