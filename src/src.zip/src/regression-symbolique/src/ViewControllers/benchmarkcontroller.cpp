#include "benchmarkcontroller.h"
#include <QDebug>

using namespace QtCharts;


namespace viewcontroller {


BenchmarkController::BenchmarkController(
    QObject *parent)
    : QObject(parent) {

}



void BenchmarkController::init(QAbstractSeries *equations) {

      if (equations != nullptr) {
        QAbstractBarSeries *equationSeries = static_cast<QAbstractBarSeries *>(equations);
        if(equationSeries != nullptr) {
            _equationSeries = equations;
            _benchmarkChart = equationSeries->chart();
        }
        QStackedBarSeries *series =  new QStackedBarSeries();
       _equationSeries->chart()->addSeries(series);
       auto axisY = _equationSeries->chart()->axes(Qt::Vertical)[0];
       axisY->setTitleText("Temps[ms]");
       axisY->setRange(0, 10);
       _previousSeries= series;
    }
}




void BenchmarkController::initSeries(QBarSet *crossbreeding, QBarSet *mutation, QBarSet *filter, QBarSet *pareto, QBarSet *process_clean_and_new_equation, QBarSet *signals_process, QBarSet *fitness, QBarSet *simplification) {
    _crossbreeding  =crossbreeding;
    _mutation = mutation;
    _filter = filter;
    _pareto=pareto;
    _process_clean_and_new_equation= process_clean_and_new_equation;
    _signals_process=signals_process;
    _fitness = fitness;
    _simplification = simplification;
}





void BenchmarkController::benchmarkChartUpdate(int max_time, int generationValue) {
    if(_processBenchmark){
    }
    // Delete previous series
    if(_crossbreeding->count() < gen){
        gen = _crossbreeding->count() -1;
    }
    gen = generationValue;

    _equationSeries->chart()->removeSeries( _previousSeries);
    //Create new serie
    QStackedBarSeries *series = new QStackedBarSeries();
    series->setBarWidth(1.5);

    // set series
    series->append(_crossbreeding);
    _crossbreeding->setColor("orange");
    series->append(_mutation);
    _mutation->setColor("darkturquoise");
    series->append(_filter);
    _filter->setColor("springgreen");
    series->append(_pareto);
    _pareto->setColor("tomato");
    series->append(_process_clean_and_new_equation);
    _process_clean_and_new_equation->setColor("limegreen");
    series->append(_fitness);
    _fitness->setColor("teal");
    series->append(_simplification);
    _simplification->setColor("darkslategray");
    series->append(_signals_process);
    _signals_process->setColor("mediumorchid");

    categories.append(QString::number(gen));

    QBarCategoryAxis *axisX = new QBarCategoryAxis();
    axisX->append(categories);

    _equationSeries->chart()->removeAxis(_previousX);
    _equationSeries->chart()->addAxis(axisX, Qt::AlignBottom);

    series->attachAxis(axisX);

    //_equationSeries->chart()->axisY()->setRange(0, max_time);
    _equationSeries->chart()->axes(Qt::Vertical)[0]->setRange(0, max_time);
    _equationSeries->chart()->addSeries(series);

    _previousSeries= series;
    _previousX = axisX;
    //gen++;



}


void BenchmarkController::benchmarkChartReset(){

    if(categories.length() > 1){
        gen = 0;
        categories.clear();
        _crossbreeding->remove(0, _crossbreeding->count());
        _mutation->remove(0, _mutation->count());
        _filter->remove(0, _filter->count());
        _pareto->remove(0, _pareto->count());
        _fitness->remove(0, _fitness->count());
        _process_clean_and_new_equation->remove(0, _process_clean_and_new_equation->count());
        _signals_process->remove(0, _signals_process->count() );
        _simplification->remove(0, _simplification->count() );



        _equationSeries->chart()->removeSeries( _previousSeries);
        QStackedBarSeries *series = new QStackedBarSeries();
        categories.append(QString::number(gen));

        QBarCategoryAxis *axisX = new QBarCategoryAxis();
        axisX->append(categories);

        _equationSeries->chart()->removeAxis(_previousX);
        _equationSeries->chart()->addAxis(axisX, Qt::AlignBottom);
        series->attachAxis(axisX);

         _equationSeries->chart()->addSeries(series);
         _equationSeries->chart()->axes(Qt::Vertical)[0]->setRange(0, 10);

        _previousSeries= series;
        _previousX = axisX;

    }


}


void BenchmarkController::setProcessBenchmark(bool value){
    _processBenchmark = value;
}

void BenchmarkController::setDisplaySignalsBench(bool value){
    _displaySignalsBench = value;
}

void BenchmarkController::setDisplayFitnessBench(bool value){
    _displayFitnessBench = value;
}

void BenchmarkController::receiveProcessBenchmark(bool value){
    _processBenchmark = value;
}

void BenchmarkController::receiveDisplaySignalsBench(bool value){
    _processBenchmark = value;
}

void BenchmarkController::receiveDisplayFitnessBench(bool value){
    _processBenchmark = value;
}



void BenchmarkController::setProcessBenchmark(bool value1, bool value2, bool value3){
    _processBenchmark = value1;
    _displaySignalsBench = value2;
    _displayFitnessBench = value3;
}



bool BenchmarkController::processBenchmark() const { return _processBenchmark; }


bool BenchmarkController::displaySignalsBench() const { return _displaySignalsBench; }

bool BenchmarkController::displayFitnessBench() const { return _displayFitnessBench; }







}
