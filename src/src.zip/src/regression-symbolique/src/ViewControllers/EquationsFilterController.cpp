#include "EquationsFilterController.h"

namespace viewcontroller
{
EquationsFilterController::EquationsFilterController(QObject *parent) : QObject(parent)
{
    _equationFilterParameters.setFromEquation(utils::CommandLineParser::getFilterFrom());
    int nbEquations = utils::CommandLineParser::getBasePopulation();
    _equationFilterParameters.setNumberOfEquations(nbEquations);
    int nbEquationsSelected = utils::CommandLineParser::getNumberOfEquationSelected();
    if(nbEquationsSelected > nbEquations){
        nbEquationsSelected = nbEquations;
    }
    _equationFilterParameters.setNumberOfEquationsSelected(nbEquationsSelected);
}

int EquationsFilterController::fromEquation() const { return _equationFilterParameters.fromEquation(); }

void EquationsFilterController::setFromEquation(int fromEquation)
{
    if (_equationFilterParameters.fromEquation() != fromEquation)
    {
        _equationFilterParameters.setFromEquation(fromEquation);
        Settings::instance()->setValue("EquationFilter/FilterFrom", fromEquation);
        emit fromEquationChanged();
    }
}

int EquationsFilterController::numberOfEquationsSelected() const
{
    return _equationFilterParameters.numberOfEquationsSelected();
}

void EquationsFilterController::setNumberOfEquationsSelected(int numberOfEquationsSelected)
{
    if (_equationFilterParameters.numberOfEquationsSelected() != numberOfEquationsSelected)
    {
        _equationFilterParameters.setNumberOfEquationsSelected(numberOfEquationsSelected);
        Settings::instance()->setValue("EquationFilter/SelectedEquations", numberOfEquationsSelected);
        emit numberOfEquationsSelectedChanged();
    }
}

int EquationsFilterController::numberOfEquations() const { return _equationFilterParameters.numberOfEquations(); }

void EquationsFilterController::setNumberOfEquations(int numberOfEquations)
{
    if (_equationFilterParameters.numberOfEquations() != numberOfEquations)
    {
        _equationFilterParameters.setNumberOfEquations(numberOfEquations);
        emit numberOfEquationsChanged();
    }
}

void EquationsFilterController::onEquationFilterRequest()
{
    emit equationFilterRequired(_equationFilterParameters);
}

const equationparameters::EquationFilterParameters &EquationsFilterController::equationFilterParameters() const
{
    return _equationFilterParameters;
}

equationparameters::EquationFilterParameters::EquationsFilterCriteria EquationsFilterController::equationsFilterCriteria()
    const
{
    return _equationFilterParameters.getEquationsFilterCriteria();
}

void EquationsFilterController::setEquationsFilterCriteria(
    equationparameters::EquationFilterParameters::EquationsFilterCriteria equationsFilterCriteria)
{
    QMetaEnum metaEnum = QMetaEnum::fromType<equationparameters::EquationFilterParameters::EquationsFilterCriteria>();
    Settings::instance()->setValue("EquationCrossBreeding/ParentSelectionCriteria", metaEnum.valueToKey(equationsFilterCriteria));
    _equationFilterParameters.setEquationsFilterCriteria(equationsFilterCriteria);
    emit equationsFilterCriteriaChanged();
}

}  // namespace viewcontroller
