#include "ParametersControllers.h"
#include "Utils/Settings.h"
#include "Logger_v2/Logger.h"
#include "FileReaderWriter/FileReaderWriter_global.h"

#include <QString>
#include <QtQml/QQmlEngine>

namespace viewcontroller
{
ParametersControllers::ParametersControllers(QObject *parent) : QObject(parent)

{
    QObject::connect(&_equationGenerationController, &EquationsGeneratorController::equationGenerationRequired,
                     this, &ParametersControllers::forwardInitButtonClickedEvent);

    QObject::connect(&_equationGenerationController, &EquationsGeneratorController::equationNumberChanged,
                     &_equationFilterController, &EquationsFilterController::setNumberOfEquations);

    _fitnessRefreshRate = Settings::instance()->value("FitnessRefreshRate", 1).toInt();

    _nameDisplay = Settings::instance()->value("InputData/FileName").toString();
    _targetDisplay = Settings::instance()->value("InputData/Target").toString();

}

int ParametersControllers::fitnessRefreshRate() const { return _fitnessRefreshRate; }

void ParametersControllers::setFitnessRefreshRate(int value)
{
    if (_fitnessRefreshRate != value)
    {
        _fitnessRefreshRate = value;
        Settings::instance()->setValue("FitnessRefreshRate", value);
        emit fitnessRefreshRateChanged(value);
    }
}


void ParametersControllers::forwardInitButtonClickedEvent(equationparameters::EquationGenerationParameters paramsGeneration)
{
    resetColors();
    //qInfo() << "forwardInitButtonClickedEvent";
    logs::Logger::logInfo("forwardInitButtonClickedEvent");
    emit initButtonClicked(paramsGeneration, _equationDistanceController.getEquationDistanceParameters());
}


void ParametersControllers::forwardProcessBenchmarkChanged(bool value1, bool value2, bool value3)
{
    _benchmarkController.setProcessBenchmark(value1, value2, value3);
    emit processBenchmarkChanged(value1, value2, value3);
}

void ParametersControllers::forwardContinueButtonClickedEvent()
{
    resetColors();
    emit continueButtonClicked(_generationCyclingController.infiniteGenerations(),
                               _generationCyclingController.numberOfGenerations(),
                               _generationCyclingController.distanceMinimum(),
                               _generationCyclingController.activateDistanceMin(),
                               _generationCyclingController.timeSelected(),
                               _equationFilterController.equationFilterParameters());
}

void ParametersControllers::registerQmlTypes()
{
    qmlRegisterUncreatableType<viewcontroller::EquationsGeneratorController>(
        "com.treegeneticprogramming.parameters", 1, 0, "EquationsGeneratorController",
        QStringLiteral("EquationsGeneratorController can only be created from c++"));

    qmlRegisterUncreatableType<viewcontroller::EquationsFilterController>(
        "com.treegeneticprogramming.parameters", 1, 0, "EquationsFilterController",
        QStringLiteral("EquationsFilterController can only be created from c++"));

    qmlRegisterUncreatableType<viewcontroller::EquationDistanceController>(
        "com.treegeneticprogramming.parameters", 1, 0, "EquationDistanceController",
        QStringLiteral("EquationDistanceController can only be created from c++"));

    qmlRegisterUncreatableType<viewcontroller::EquationCrossbreedingController>(
        "com.treegeneticprogramming.parameters", 1, 0, "EquationCrossbreedingController",
        QStringLiteral("EquationCrossbreedingController can only be created from c++"));

    qmlRegisterUncreatableType<viewcontroller::GenerationCyclingController>(
        "com.treegeneticprogramming.parameters", 1, 0, "GenerationCyclingController",
        QStringLiteral("GenerationCyclingController can only be created from c++"));

    qmlRegisterUncreatableType<viewcontroller::InputDataViewController>(
        "com.treegeneticprogramming.parameters", 1, 0, "InputDataViewController",
        QStringLiteral("InputDataViewController can only be created from c++"));

    qmlRegisterUncreatableType<viewcontroller::EquationMutationController>(
        "com.treegeneticprogramming.parameters", 1, 0, "EquationMutationController",
        QStringLiteral("EquationMutationController can only be created from c++"));

    qmlRegisterUncreatableType<viewcontroller::EquationParetoEfficiencyController>(
        "com.treegeneticprogramming.parameters", 1, 0, "EquationParetoEfficiencyController",
        QStringLiteral("EquationParetoEfficiencyController can only be created from c++"));

    qmlRegisterUncreatableType<viewcontroller::BenchmarkController>(
        "com.treegeneticprogramming.parameters", 1, 0, "BenchmarkController",
        QStringLiteral("BenchmarkController can only be created from c++"));


    qmlRegisterUncreatableType<equationparameters::EquationCrossbreedingParameters>(
        "com.treegeneticprogramming.parameters", 1, 0, "EquationCrossbreedingParameters",
        QStringLiteral("Only register enum of EquationCrossbreedingParameters"));

    qmlRegisterUncreatableType<equationparameters::EquationFilterParameters>(
        "com.treegeneticprogramming.parameters", 1, 0, "EquationFilterParameters",
        QStringLiteral("Only register enum of EquationFilterParameters"));

    qmlRegisterUncreatableType<equationparameters::EquationDistanceParameters>(
        "com.treegeneticprogramming.parameters", 1, 0, "EquationDistanceParameters",
        QStringLiteral("Only register enum of EquationDistanceParameters"));
}

EquationsGeneratorController *ParametersControllers::equationGenerationController()
{
    return &_equationGenerationController;
}

EquationsFilterController *ParametersControllers::equationFilterController() { return &_equationFilterController; }

EquationDistanceController *ParametersControllers::equationDistanceController() { return &_equationDistanceController; }

EquationCrossbreedingController *ParametersControllers::equationCrossbreedingController()
{
    return &_equationCrossbreedingController;
}

GenerationCyclingController *ParametersControllers::generationCyclingController()
{
    return &_generationCyclingController;
}

InputDataViewController *ParametersControllers::inputDataViewController() { return &_inputDataViewController; }

EquationMutationController *ParametersControllers::equationMutationController()
{
    return &_equationMutationController;
}

EquationParetoEfficiencyController *ParametersControllers::equationParetoEfficiencyController()
{
    return &_equationParetoEfficiencyController;
}

BenchmarkController *ParametersControllers::benchmarkController()
{
    return &_benchmarkController;
}



void ParametersControllers::forwardResetButtonClickedEvent()
{
    resetColors();
    emit resetButtonClicked();
    emit textGenerationUpdated("0");
    emit generationElapsedTimeUpdated("0 ms");
    emit resetBenchmarkChart();
}

void ParametersControllers::forwardPauseButtonClickedEvent() { emit pauseButtonClicked(); }

void ParametersControllers::refreshStartButton() { setTextStartButton("Continue"); }

void ParametersControllers::refreshTestGeneration(const QString &value) { setTextGeneration(value); }

void ParametersControllers::refreshGenerationElapsedTime(const QString &value) { setGenerationElapsedTime(value); }

void ParametersControllers::initStartButton() { setTextStartButton("Start"); }

void ParametersControllers::initTestGeneration() { setTextGeneration("0"); }

void ParametersControllers::initGenerationElapsedTime() { setGenerationElapsedTime("0 ms"); }

void ParametersControllers::redDistanceMin() { setColorDistance("red"); }

void ParametersControllers::redNumberOfGenerations() {setColorNumberOfGenerations("red"); }

void ParametersControllers::redTime() {setColorTime("red");}

QString ParametersControllers::textStartButton() const { return _textStartButton; }

QString ParametersControllers::textGeneration() const { return _textGeneration; }


QString ParametersControllers::generationElapsedTime() const { return _generationElapsedTime; }

void ParametersControllers::setTextStartButton(const QString &value)
{
    _textStartButton = value;
    emit textStartButtonUpdated(_textStartButton);
}

void ParametersControllers::setTextGeneration(const QString &value)
{
    _textGeneration = value;
    emit textGenerationUpdated(_textGeneration);
}


void ParametersControllers::setGenerationElapsedTime(const QString &value)
{
    _generationElapsedTime = value;
    emit generationElapsedTimeUpdated(_generationElapsedTime);
}


int ParametersControllers::timeSelected() const{ return _time; }
void ParametersControllers::setTimeSelected(int time)
{
    _time=time;
    emit timeSelectedChanged(_time);
}

bool ParametersControllers::isEnableButton()const{
    return (_inputDataViewController.inputDatas().size() == 0) ? false : true;
}
void ParametersControllers::setIsEnableButton(const bool& value){
    _isEnableButton = value;
    emit isEnableButtonUpdated(_isEnableButton);
}
void ParametersControllers::setColorDistance(const QString &value)
{
    _colorDistance = value;
    emit colorDistanceChanged(_colorDistance);
}
QString ParametersControllers::colorDistance() const { return _colorDistance; }

void ParametersControllers::setColorNumberOfGenerations(const QString &value)
{
    _colorNumberOfGenerations = value;
    emit colorNumberOfGenerationsChanged(_colorNumberOfGenerations);
}
QString ParametersControllers::colorNumberOfGenerations() const { return _colorNumberOfGenerations; }

void ParametersControllers::setColorTime(const QString &value)
{
    _colorTime = value;
    emit colorTimeChanged(_colorTime);
}
QString ParametersControllers::colorTime() const { return _colorTime; }

void ParametersControllers::setNameDisplay(const QString &name)
{
    QFileInfo fi(name);
    _nameDisplay = fi.absoluteFilePath();
    Settings::instance()->setValue("InputData/FileName", _nameDisplay);

    setTargetDisplay(QString(g_lineData.back().c_str()));

    emit nameDisplayChanged(_nameDisplay);
}

void ParametersControllers::setTargetDisplay(const QString &name)
{
    _targetDisplay = name;
    Settings::instance()->setValue("InputData/Target", _targetDisplay);
    emit targetDisplayChanged(_targetDisplay);
}

QString ParametersControllers::nameDisplay() const { return _nameDisplay; }

QString ParametersControllers::targetDisplay() const { return _targetDisplay; }

void ParametersControllers::forwardStartButtonClickedEvent()
{
    equationparameters::EquationGenerationCyclingParameters cyclingParams;

    cyclingParams.setNumberOfGenerations(_generationCyclingController.numberOfGenerations());
    cyclingParams.setEquationFilterParameters(_equationFilterController.equationFilterParameters());
    cyclingParams.setEquationDistanceParameters(_equationDistanceController.getEquationDistanceParameters());
    cyclingParams.setEquationCrossbreedingParameters(
        _equationCrossbreedingController.getEquationCrossBreadingParameters());
    cyclingParams.setInfiniteGenerations(_generationCyclingController.infiniteGenerations());
    cyclingParams.setDistanceMinimum(_generationCyclingController.distanceMinimum());
    cyclingParams.setActivateDistanceMinimum(_generationCyclingController.activateDistanceMin());
    cyclingParams.setMaxNode(_equationGenerationController.maxNode());
    cyclingParams.setFreshNewGeneration(_equationGenerationController.freshNewGeneration());
    cyclingParams.setTimeSelected(_generationCyclingController.timeSelected());
    resetColors();

    equationparameters::EquationMutationParameters mutationParams;
    mutationParams.setMutationRate(_equationMutationController.mutationRate());
    mutationParams.setNbMutationPossible(_equationMutationController.nbMutationPossible());
    mutationParams.setEquationGenerationParameters(_equationGenerationController.equationGenerationParameters());
    cyclingParams.setEquationMutationParameters(mutationParams);

    equationparameters::EquationFitParameters fitParams;
    fitParams.setDuration(_equationGenerationController.fitDuration());
    fitParams.setPopulationPeriod(_equationGenerationController.fitPopulationPeriod());

    cyclingParams.setEquationFitParameters(fitParams);

    emit startButtonClicked(_equationGenerationController.equationGenerationParameters(), cyclingParams);
}

void ParametersControllers::resetColors(){
    setColorDistance("black");
    setColorNumberOfGenerations("black");
    setColorTime("black");
}

}  // namespace viewcontroller
