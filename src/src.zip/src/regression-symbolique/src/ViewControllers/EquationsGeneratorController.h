
#pragma once

#include <QMap>
#include <QObject>

#include "EquationParameters/EquationFitParameters.h"
#include "EquationParameters/EquationGenerationParameters.h"
#include "SelectedNodeListController.h"
#include "Utils/CommandLineParser.h"
#include "ViewControllers_global.h"

namespace viewcontroller
{
/**
 * @brief The EquationsGeneratorController class create the link between Qml and Equation algorihtmes
 */
class EquationsGeneratorController : public QObject
{
    Q_OBJECT

    Q_PROPERTY(int equationNumber READ equationNumber WRITE setEquationNumber NOTIFY equationNumberChanged)
    Q_PROPERTY(int equationMaxDepth READ equationMaxDepth WRITE setEquationMaxDepth NOTIFY equationMaxDepthChanged)
    Q_PROPERTY(int realNumberPrecision READ realNumberPrecision WRITE setRealNumberPrecision NOTIFY
                   realNumberPrecisionChanged)
    Q_PROPERTY(int maxNode READ maxNode WRITE setMaxNode NOTIFY maxNodeChanged)
    Q_PROPERTY(int freshNewGeneration READ freshNewGeneration WRITE setFreshNewGeneration NOTIFY
                   freshNewGenerationChanged)
    Q_PROPERTY(int fitDuration READ fitDuration WRITE setFitDuration NOTIFY fitDurationChanged)
    Q_PROPERTY(int fitPopulationPeriod READ fitPopulationPeriod WRITE setFitPopulationPeriod NOTIFY fitPopulationPeriodChanged)



    Q_PROPERTY(viewcontroller::SelectedNodeListController *selectedNodeListController READ
                   selectedNodeListController CONSTANT)

    Q_PROPERTY(int equationsListRefreshRate READ equationsListRefreshRate WRITE setEquationsListRefreshRate NOTIFY
                   equationsListRefreshRateChanged)


   public:
    explicit EquationsGeneratorController(QObject *parent = nullptr);

    const equationparameters::EquationGenerationParameters &equationGenerationParameters() const;

    int realNumberPrecision() const;
    void setRealNumberPrecision(int);

    int equationNumber() const;
    void setEquationNumber(int equationNumber);

    int maxNode() const;
    void setMaxNode(int maxNode);

    int freshNewGeneration() const;
    void setFreshNewGeneration(int value);

    int fitDuration() const;
    void setFitDuration(int value);

    int fitPopulationPeriod() const;
    void setFitPopulationPeriod(int value);

    int equationMaxDepth() const;
    void setEquationMaxDepth(int equationMaxDepth);

    int equationsListRefreshRate() const;
    void setEquationsListRefreshRate(int);

    viewcontroller::SelectedNodeListController *selectedNodeListController();

   public slots:
    void onEquationGenerationRequest();

   private slots:
    void onEquationNodeTypeChanged();

   signals:
    void equationNumberChanged(int equationNumber);
    void equationMaxDepthChanged();
    void realNumberPrecisionChanged(int);
    void equationsListRefreshRateChanged(int);
    void maxNodeChanged(int);
    void freshNewGenerationChanged(int);


    void fitDurationChanged(int);
    void fitPopulationPeriodChanged(int);

    void equationGenerationRequired(equationparameters::EquationGenerationParameters equationGenerationParameters);

   private:
    Q_DISABLE_COPY_MOVE(EquationsGeneratorController)

    SelectedNodeListController _selectedNodeListController;

    equationparameters::EquationGenerationParameters _equationGenerationParameters;
    int _realNumberPrecision;
    int _equationsListRefreshRate{1};
    int _maxNode;
    int _freshNewGeneration;

    int _fitDuration = 0;
    int _fitPopulationPeriod = 1;

};
}  // namespace viewcontroller
