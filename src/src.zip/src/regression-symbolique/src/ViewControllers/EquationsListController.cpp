#include "EquationsListController.h"

#include <cmath>
#include <iostream>

#include <QApplication>
#include <QDebug>
#include <QString>
#include <QElapsedTimer>
#include "EquationEditors/EquationPrinter.h"

namespace viewcontroller
{
EquationsListController::EquationsListController(QObject *parent) : QAbstractListModel(parent) {}

QVariant EquationsListController::data(const QModelIndex &index, int role) const
{
    if (index.row() < 0 || index.row() >= rowCount())
    {
        return QVariant();
    }
    uint nbVar = 0;
    if(!_inputData.empty()){
        nbVar = _inputData.at(0).getNumberOfVariables();
    }

    switch (role)
    {
        case Identifier:
            return _datas.at(index.row()).identifier;
        case Equation:
            return QString::fromStdString(equationeditors::equationToString(_datas.at(index.row()).equation, nbVar, _precision));
        case EquationPython:
            return QString::fromStdString(equationeditors::equationToPythonString(_datas.at(index.row()).equation, nbVar, _precision));
        case EquationLatex:
            return QString::fromStdString(equationeditors::equationToLatexString(_datas.at(index.row()).equation, nbVar, _precision));
        case EquationColorLatex:
            return QString::fromStdString(equationeditors::equationToLatexColorString(_datas.at(index.row()).equation, nbVar, _precision));
        case DistanceMSE:
            return _datas.at(index.row()).distanceMSE;
        case DistanceR2:
            return _datas.at(index.row()).distanceR2;
        case Complexity:
            return _datas.at(index.row()).complexity;
        case ParetoLevel:
            return _datas.at(index.row()).paretoLevel;
        case Generation:
            return _datas.at(index.row()).generation;
        case IsSimple:
            return _datas.at(index.row()).isSimple;
        case Efficiency:
            return _datas.at(index.row()).efficiency;
        case BestEquation:
            return QString::fromStdString(equationeditors::equationToString(bestEquation.root(), nbVar, _precision));

    }

    return QVariant();
}

int EquationsListController::rowCount(const QModelIndex &parent) const
{
    Q_UNUSED(parent)
    return _datas.size();
}

void EquationsListController::updatePrecision(int precision)
{
    if (precision != _precision)
    {
        _precision = precision;
        beginResetModel();
        endResetModel();
    }
}


void EquationsListController::updateEquationsRefreshRate(int value)
{
  if(value!=_equationListUpdateRate)
  {
    _equationListUpdateRate = value;
    equationListCurrentCount = value -2;
    beginResetModel();
    endResetModel();
  }
}


void EquationsListController::setFitnessRefreshRate(int value){
    *fitnessRefreshRate = value;
    *fitnessCurrentCount = 0;
}

void EquationsListController::onBestEquationChanged(const datamodel::EquationTree equation){
    bestEquation = equation;
}

void EquationsListController::instantRefreshFitness(){
    *fitnessCurrentCount = *fitnessRefreshRate  -1 ;
}


void EquationsListController::onGenerationCountChanged(int generationNumber)
{
    this->generationNumber = generationNumber;
    emit generationNumberChanged();
    emit textGenerationUpdated(QString::number(generationNumber));
}

void EquationsListController::setDisplayEquationListControler()
{
    equationListCurrentCount = _equationListUpdateRate - 2;
}


void EquationsListController::setDisplayFitnessController()
{
    equationListCurrentCount = _equationListUpdateRate - 1;
}

void EquationsListController::instantRefreshEquationListControler()
{
    equationListCurrentCount = _equationListUpdateRate;
}

void EquationsListController::clearRefreshEquationListControler()
{
    equationListCurrentCount = _equationListUpdateRate - 1;
    endResetModel();
}





QHash<int, QByteArray> EquationsListController::roleNames() const
{
    QHash<int, QByteArray> roles;
    roles.insert(Identifier, "identifier");
    roles.insert(Equation, "equation");
    roles.insert(EquationPython, "equationPy");
    roles.insert(EquationLatex, "equationLatex");
    roles.insert(EquationColorLatex, "equationColorLatex");
    roles.insert(DistanceMSE, "distanceMSE");
    roles.insert(DistanceR2, "distanceR2");
    roles.insert(Complexity, "complexity");
    roles.insert(ParetoLevel, "paretoLevel");
    roles.insert(Generation, "generation");
    roles.insert(IsSimple, "isSimple");
    roles.insert(Efficiency, "efficiency");
    roles.insert(BestEquation, "bestEquation");
    return roles;
}

void EquationsListController::clearFitnessChart()
{
    _equationFitness.clear();
    generationNumber = 0;
    // Set Number of generation
    emit textGenerationUpdated(QString::number(generationNumber));
}

void EquationsListController::onEquationsDataChanged(const datamodel::EquationTree* equationsArray, uint equationsArraySize)
{
    //beginResetModel();
    _datas.clear();
    equationListCurrentCount++;

    int count = 0;
    std::for_each(equationsArray, equationsArray+equationsArraySize, [&count, this](const datamodel::EquationTree& equation){
        _datas.append({count, equation.root(), equation.distanceMSE(), 1. - equation.distanceR2(), equation.totalNode(), equation.paretoLevel(), equation.generation(), equation.is_simple(), equation.efficiency()});
        ++count;
    });

/*  if (_datas.size() > 0)
    {
        double totalError = 0.;
        for (auto &data : _datas)
        {
            totalError += data.distanceToData;
        }
        double meanError = totalError / _datas.size();
        auto min = std::min_element(_datas.cbegin(), _datas.cend(), [](const DataLine &a, const DataLine &b) {
            return a.distanceToData < b.distanceToData;
        });
    } */
    // Update equations list table
    if(equationListCurrentCount >= _equationListUpdateRate){
        endResetModel();
        equationListCurrentCount = 0;
    }

}

void EquationsListController::initFitnessSeries(QAbstractSeries *average,
                                                QAbstractSeries *best) {
  _equationFitness.init(average, best, fitnessRefreshRate, fitnessCurrentCount);
}

void EquationsListController::onGenerationCreated(const datamodel::EquationTree* equationsArray, uint equationsArraySize, int breedAndMutationRate)
{
    _equationFitness.addGeneration(equationsArray, equationsArraySize, breedAndMutationRate);
}

void EquationsListController::equationSelectionRequest(const int &identifier, const QString &equation,
                                                       const double &distance, const int &complexity,
                                                       const int &paretoLevel, const int &generation)
{
    datamodel::EquationTreeItem data;
    for (int i = 0; i < _datas.size(); i++)
    {
        if (_datas.value(i).identifier == identifier)
        {
            data = _datas.value(i).equation;
            break;
        }
    }

    QList<datamodel::DataPoint> datalist;
//    for (int i = -100; i <= 100; i++)
//    {
//        datamodel::DataPoint dataPoint;
//        dataPoint.setParameterValue(i);
//        dataPoint.setResult(data.value(i));
//        datalist.append(dataPoint);
//    }
    uint x = 0;
    for (datamodel::DataPoint &point : _inputData)
    {
        auto y = data.value(point.parameterList());
        if (!std::isnan(y)) {
            datamodel::DataPoint dataPoint;
            dataPoint.setParameterList(point.parameterList());
            dataPoint.setResult(y);
            datalist.append(dataPoint);
        }
        ++x;
    }
    emit sendDataList(datalist);
    emit equationSelected(data);
}


void EquationsListController::setEquationParetoEfficiency(
    EquationParetoEfficiencyController *equationParetoEfficiencyController)
{
    _equationParetoEfficiency = equationParetoEfficiencyController;
}

void EquationsListController::initParetoEfficiencySeries(QAbstractSeries *equations)
{
    _equationParetoEfficiency->init(equations);
}

void EquationsListController::initBenchmarkSeries(
    QAbstractSeries *equations) {
    _equationBenchmarkPointer = equations;
    _equationBenchmark = new BenchmarkController(this);
    _equationBenchmark->init(equations);
}

void EquationsListController::updateBenchmarkSeries( int max_time, int  generationValue) {
    _equationBenchmark->benchmarkChartUpdate(max_time, generationValue);
}

void EquationsListController::initBenchmarkSeriesPtr(QBarSet *crossbreeding, QBarSet *mutation, QBarSet *filter, QBarSet *pareto, QBarSet *process_clean_and_new_equation, QBarSet *signals_process, QBarSet *fitness, QBarSet *simplification) {
    _equationBenchmark->initSeries(crossbreeding, mutation, filter, pareto, process_clean_and_new_equation, signals_process, fitness, simplification);
}

void EquationsListController::resetBenchmarkSeries() {
    _equationBenchmark->benchmarkChartReset();
}



}  // namespace viewcontroller
