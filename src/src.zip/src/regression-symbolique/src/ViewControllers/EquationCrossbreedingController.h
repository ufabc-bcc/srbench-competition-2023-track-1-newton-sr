
#pragma once

#include <QObject>

#include "EquationParameters/EquationCrossbreedingParameters.h"

namespace viewcontroller
{
    /**
     * @brief The EquationCrossbreedingController class create the link between Qml and Equation algorihtmes
     */
    class EquationCrossbreedingController : public QObject
    {
        Q_OBJECT
        Q_PROPERTY(equationparameters::EquationCrossbreedingParameters::ParentSelectionStrategy parentSelectionStrategy READ
                       getParentSelectionStrategy WRITE setParentSelectionStrategy NOTIFY parentSelectionStrategyChanged)

        Q_PROPERTY(equationparameters::EquationCrossbreedingParameters::ParentSelectionCriteria parentSelectionCriteria READ
                       getParentSelectionCriteria WRITE setParentSelectionCriteria NOTIFY parentSelectionCriteriaChanged)

        Q_PROPERTY(int tournamentSize READ getTournamentSize WRITE setTournamentSize NOTIFY tournamentSizeChanged)

        Q_PROPERTY(double crossbreedingRate READ getCrossbreedingRate WRITE setCrossbreedingRate NOTIFY crossbreedingRateChanged)

        Q_PROPERTY(equationparameters::EquationCrossbreedingParameters::CrossbreedingMethod crossbreedingMethod READ
                       getCrossbreedingMethod WRITE setCrossbreedingMethod NOTIFY crossbreedingMethodChanged)
       public:
        /**
         * @brief Default constructor
         * @param parent used by garbage collector
         */
        explicit EquationCrossbreedingController(QObject *parent = nullptr);

        // properties getter / setter
        double getCrossbreedingRate() const;
        void setCrossbreedingRate(const double crossbreedingRate);

        equationparameters::EquationCrossbreedingParameters::ParentSelectionStrategy getParentSelectionStrategy() const;
        void setParentSelectionStrategy(const equationparameters::EquationCrossbreedingParameters::ParentSelectionStrategy &parentSelectionStrategy);

        equationparameters::EquationCrossbreedingParameters::ParentSelectionCriteria getParentSelectionCriteria() const;
        void setParentSelectionCriteria(const equationparameters::EquationCrossbreedingParameters::ParentSelectionCriteria &parentSelectionCriteria);

        int getTournamentSize() const;
        void setTournamentSize(const int &tournamentSize);

        equationparameters::EquationCrossbreedingParameters::CrossbreedingMethod getCrossbreedingMethod() const;
        void setCrossbreedingMethod(const equationparameters::EquationCrossbreedingParameters::CrossbreedingMethod &crossbreedingMethod);

        const equationparameters::EquationCrossbreedingParameters &getEquationCrossBreadingParameters() const;

       public slots:
        /**
         * @brief onEquationCrossBreedingRequest
         */
        void onEquationCrossBreedingRequest();

       signals:
        /**
         * @brief Triggered when the user launches a crossbreeding.
         * @param equationCrossBreadingParameters
         */
        void equationsCrossbreedingRequired(equationparameters::EquationCrossbreedingParameters equationCrossBreadingParameters);

        // property signals
        void crossbreedingRateChanged();
        void parentSelectionStrategyChanged();
        void parentSelectionCriteriaChanged();
        void tournamentSizeChanged();
        void crossbreedingMethodChanged();

       private:
        Q_DISABLE_COPY_MOVE(EquationCrossbreedingController)
        /**
         * @brief Crossbreeding parameters.
         */
        equationparameters::EquationCrossbreedingParameters _equationCrossBreadingParameters;
    };
}  // namespace viewcontroller
