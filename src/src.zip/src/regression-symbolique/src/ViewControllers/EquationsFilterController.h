#pragma once

#include <QObject>

#include "EquationParameters/EquationFilterParameters.h"
#include "Utils/CommandLineParser.h"
#include "ViewControllers_global.h"

namespace viewcontroller
{
/**
 * @brief The EquationsFilterController class create the link between Qml and Equation algorihtmes
 */
class EquationsFilterController : public QObject
{
    Q_OBJECT
    Q_PROPERTY(int fromEquation READ fromEquation WRITE setFromEquation NOTIFY fromEquationChanged)
    Q_PROPERTY(int numberOfEquationsSelected READ numberOfEquationsSelected WRITE setNumberOfEquationsSelected
                   NOTIFY numberOfEquationsSelectedChanged)

    Q_PROPERTY(int numberOfEquations READ numberOfEquations NOTIFY numberOfEquationsChanged)
    Q_PROPERTY(equationparameters::EquationFilterParameters::EquationsFilterCriteria equationsFilterCriteria READ
                   equationsFilterCriteria WRITE setEquationsFilterCriteria NOTIFY equationsFilterCriteriaChanged)

   public:
    explicit EquationsFilterController(QObject *parent = nullptr);

    // properties getter/setter
    int fromEquation() const;
    void setFromEquation(int fromEquation);
    int numberOfEquationsSelected() const;
    void setNumberOfEquationsSelected(int numberOfEquationsSelected);

    int numberOfEquations() const;
    void setNumberOfEquations(int numberOfEquations);

    equationparameters::EquationFilterParameters::EquationsFilterCriteria equationsFilterCriteria() const;
    void setEquationsFilterCriteria(
        equationparameters::EquationFilterParameters::EquationsFilterCriteria equationsFilterCriteria);

    const equationparameters::EquationFilterParameters &equationFilterParameters() const;

   public slots:
    void onEquationFilterRequest();

   signals:
    // properties signals
    void fromEquationChanged();
    void numberOfEquationsSelectedChanged();
    void numberOfEquationsChanged();
    void equationsFilterCriteriaChanged();

    /**
     * @brief Triggered when the user want to launch a filter
     */
    void equationFilterRequired(equationparameters::EquationFilterParameters equationFilterParameters);

   private:
    Q_DISABLE_COPY_MOVE(EquationsFilterController)

    /**
     * @brief the filter parameters
     */
    equationparameters::EquationFilterParameters _equationFilterParameters;
};
}  // namespace viewcontroller
