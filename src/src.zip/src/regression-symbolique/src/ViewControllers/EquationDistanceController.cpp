#include "EquationDistanceController.h"
#include <iostream>
#include "qmetaobject.h"
#include "Utils/CommandLineParser.h"

namespace viewcontroller
{
EquationDistanceController::EquationDistanceController(QObject *parent) : QObject(parent)
{
    std::string distance = utils::CommandLineParser::getDistanceToUse();
    if(distance == "R2") _equationDistanceParameters.setEquationDistance(equationparameters::EquationDistanceParameters::R2);
    else if(distance == "MSE") _equationDistanceParameters.setEquationDistance(equationparameters::EquationDistanceParameters::MSE);
    else std::cout << "Warning: Invalid distance, please see --help" << std::endl;
}

equationparameters::EquationDistanceParameters::EquationDistance EquationDistanceController::getEquationDistance() const
{
    return _equationDistanceParameters.getEquationDistance();
}

void EquationDistanceController::onEquationDistanceRequest()
{
    emit equationDistanceRequired(_equationDistanceParameters);
}

const equationparameters::EquationDistanceParameters &EquationDistanceController::getEquationDistanceParameters() const
{
    return _equationDistanceParameters;
}

void EquationDistanceController::setEquationDistance(
    const equationparameters::EquationDistanceParameters::EquationDistance &equationDistance)
{
    if (_equationDistanceParameters.getEquationDistance() != equationDistance)
    {
        QMetaEnum metaEnum = QMetaEnum::fromType<equationparameters::EquationDistanceParameters::EquationDistance>();
        Settings::instance()->setValue("EquationDistance/Distance", metaEnum.valueToKey(equationDistance));
        _equationDistanceParameters.setEquationDistance(equationDistance);
        emit equationDistanceChanged();
    }
}

}  // namespace viewcontroller
