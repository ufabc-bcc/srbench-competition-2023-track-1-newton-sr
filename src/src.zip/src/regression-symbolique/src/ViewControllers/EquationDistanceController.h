#pragma once

#include <QObject>

#include "EquationParameters/EquationDistanceParameters.h"

namespace viewcontroller
{
/**
 * @brief The EquationDistanceController class create the link between Qml and Equation algorihtmes
 */
class EquationDistanceController : public QObject
{
    Q_OBJECT

    Q_PROPERTY(equationparameters::EquationDistanceParameters::EquationDistance equationDistance READ
                   getEquationDistance WRITE setEquationDistance NOTIFY equationDistanceChanged)
public:
    explicit EquationDistanceController(QObject *parent = nullptr);

    equationparameters::EquationDistanceParameters::EquationDistance getEquationDistance() const;
    void setEquationDistance(const equationparameters::EquationDistanceParameters::EquationDistance &equationDistance);

    const equationparameters::EquationDistanceParameters &getEquationDistanceParameters() const;

public slots:
    void onEquationDistanceRequest();

signals:
     // properties signals
     void equationDistanceChanged();

     void equationDistanceRequired(equationparameters::EquationDistanceParameters equationDistanceParameters);

private:
 Q_DISABLE_COPY_MOVE(EquationDistanceController)

 /**
  * @brief the distance parameters
  */
 equationparameters::EquationDistanceParameters _equationDistanceParameters;

};
} // namespace viewcontroller
