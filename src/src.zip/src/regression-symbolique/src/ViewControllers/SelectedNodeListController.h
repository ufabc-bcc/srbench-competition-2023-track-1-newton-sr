
#pragma once

#include <QAbstractListModel>
#include <QMap>

#include "DataModel/EquationNode.h"
#include "Utils/CommandLineParser.h"

namespace viewcontroller
{
/**
 * @brief The SelectedNodeListController class
 */
class SelectedNodeListController : public QAbstractListModel
{
    Q_OBJECT
   public:
    enum SelectedNodesRoles
    {
        NodeName = Qt::UserRole + 1,
        NodeSelected
    };

    SelectedNodeListController(QObject *parent = nullptr);

    /// Override funtion of QAbstractListModel
    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const override;
    /// Override funtion of QAbstractListModel
    int rowCount(const QModelIndex &parent = QModelIndex()) const override;
    /// Override funtion of QAbstractListModel
    QHash<int, QByteArray> roleNames() const override;

    bool setData(const QModelIndex &index, const QVariant &value, int role = Qt::EditRole) override;

    Qt::ItemFlags flags(const QModelIndex &index) const override;

    QSet<datamodel::EquationNode::NodeType> selectedNodesTypes() const;

   signals:
    void selectedNodesTypesChanged();

   private:
    Q_DISABLE_COPY_MOVE(SelectedNodeListController)

    QMap<datamodel::EquationNode::NodeType, bool> _selectedNodeType;
};
}  // namespace viewcontroller
