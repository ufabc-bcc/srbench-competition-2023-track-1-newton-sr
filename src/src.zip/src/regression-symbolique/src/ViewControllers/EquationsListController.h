#pragma once

#include <QAbstractListModel>
#include <QtCharts/QAbstractSeries>
#include <QtCharts/QAbstractBarSeries>

#include "DataModel/DataPoint.h"
#include "DataModel/EquationTreeItem.h"
#include "EquationFitness.h"
#include "EquationParetoEfficiencyController.h"
#include "EquationPlotterController.h"
#include "ViewControllers_global.h"
#include "benchmarkcontroller.h"
#include <QObject>

using namespace QtCharts;

namespace viewcontroller
{
/**
 * @brief The EquationsListController is the equation list model for qml
 */
class EquationsListController : public QAbstractListModel
{
    Q_OBJECT
    Q_PROPERTY(QList<datamodel::DataPoint> dataList MEMBER dataList NOTIFY sendDataList)
    Q_PROPERTY(int generationNumber MEMBER generationNumber NOTIFY generationNumberChanged)


   public:
    enum EquationsRoles
    {
        Identifier = Qt::UserRole + 1,
        Equation,
        EquationPython,
        EquationLatex,
        EquationColorLatex,
        DistanceMSE,
        DistanceR2,
        Complexity,
        ParetoLevel,
        Generation,
        Age,
        IsSimple,
        Efficiency,
        BestEquation
    };

    EquationsListController(QObject *parent = nullptr);

    /// Override function of QAbstractListModel
    QVariant data(const QModelIndex &index, int role = Qt::DisplayRole) const override;
    /// Override function of QAbstractListModel
    int rowCount(const QModelIndex &parent = QModelIndex()) const override;
    /// Override funtion of QAbstractListModel
    QHash<int, QByteArray> roleNames() const override;
    /**
     * @brief clear all the data in the fitness chart
     */
    void clearFitnessChart();
    QString textStartButton()const;

   public slots:
    void onEquationsDataChanged(const datamodel::EquationTree* equationsArray, uint equationsArraySize);

    void onGenerationCreated(const datamodel::EquationTree* equationsArray, uint equationsArraySize, int breedAndMutationRate = 0);

    void equationSelectionRequest(const int &identifier, const QString &equation, const double &distance, const int &complexity, const int &paretoLevel, const int &generation);

    void initFitnessSeries(QAbstractSeries *average, QAbstractSeries *best);

    void initParetoEfficiencySeries(QAbstractSeries *equations);

    void initBenchmarkSeries(QAbstractSeries *equations);

    void updateBenchmarkSeries(int max_time, int  generationValue );

    void initBenchmarkSeriesPtr(QBarSet *crossbreeding, QBarSet *mutation, QBarSet *filter, QBarSet *pareto, QBarSet *process_clean_and_new_equation, QBarSet *signals_process, QBarSet *fitness, QBarSet *simplification);

    void resetBenchmarkSeries();

    void setEquationParetoEfficiency(EquationParetoEfficiencyController *equationParetoEfficiencyController);

    void updatePrecision(int precision);

    void updateEquationsRefreshRate(int value);

    void onGenerationCountChanged(int generationNumber);

    void setDisplayEquationListControler();

    void instantRefreshEquationListControler();

    void clearRefreshEquationListControler();

    void instantRefreshFitness();

    void setFitnessRefreshRate(int value);

    void setDisplayFitnessController();

    void onBestEquationChanged(const datamodel::EquationTree equation);


   signals:
    void sendDataList(const QList<datamodel::DataPoint> &dataList);
    void equationSelected(datamodel::EquationTreeItem equation);
    void generationNumberChanged();
    void textGenerationUpdated(const QString& value);
    void generationElapsedTimeUpdated(const QString& value);

   private:
    Q_DISABLE_COPY_MOVE(EquationsListController)

    // Helper structure to organize the data
    struct DataLine
    {
        int identifier;
        datamodel::EquationTreeItem equation;
        double distanceMSE;
        double distanceR2;
        int complexity; //actually, it is the number of nodes of equation
        int paretoLevel;
        int generation;
        //int age;
        bool isSimple;
        double efficiency;

    };

    QList<DataLine> _datas;
    DataLine previousEquationToDisplay;
    QList<datamodel::DataPoint> dataList;
    int generationNumber;
    EquationFitness _equationFitness;
    EquationParetoEfficiencyController *_equationParetoEfficiency;
    BenchmarkController *_equationBenchmark;
    QList<datamodel::DataPoint> _inputData;
    QScatterSeries* _inputDatasSeries=nullptr;
    QAbstractSeries *_equationBenchmarkPointer;

    double _xmin;
    double _ymin;
    double _xmax;
    double _ymax;
    int _precision{6};
    int _equationListUpdateRate{1};
    int equationListCurrentCount=0;
    int *fitnessRefreshRate = new int(1);
    int *fitnessCurrentCount = new int(0);
    datamodel::EquationTree bestEquation;
};
}  // namespace viewcontroller
