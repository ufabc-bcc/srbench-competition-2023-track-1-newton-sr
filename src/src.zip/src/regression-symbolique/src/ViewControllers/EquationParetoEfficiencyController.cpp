#include "EquationParetoEfficiencyController.h"
#include <QElapsedTimer>
#include <QDebug>
#include "Utils/Settings.h"
#include "Logger_v2/Logger.h"

using namespace QtCharts;

namespace viewcontroller {

EquationParetoEfficiencyController::EquationParetoEfficiencyController(
    QObject *parent)
    : QObject(parent) {
    _paretoRefreshRate = Settings::instance()->value("ParetoRefreshRate", 1).toInt();
}



int EquationParetoEfficiencyController::paretoRefreshRate() const { return _paretoRefreshRate; }

void EquationParetoEfficiencyController::setParetoRefreshRate(int value)
{
    if (_paretoRefreshRate != value)
    {
        _paretoRefreshRate = value;
        Settings::instance()->setValue("ParetoRefreshRate", value);
        emit paretoRefreshRateChanged(value);
    }
}


void EquationParetoEfficiencyController::setDisplayParetoController()
{
    paretoRefreshRateCount = _paretoRefreshRate - 2;
}

void EquationParetoEfficiencyController::updateParetoRefreshRate(int value)
{
  if(value!=_paretoRefreshRate)
  {
    _paretoRefreshRate = value;
    paretoRefreshRateCount = value -2;
  }
}


void EquationParetoEfficiencyController::init(QAbstractSeries *equations) {
  // init the chart and equations series with the pointers coming from the Qml

  if (equations != nullptr) {
    QXYSeries *equationSeries = static_cast<QXYSeries *>(equations);
    if (equationSeries != nullptr) {
      _equationSeries = equationSeries;
      _paretoChart = equationSeries->chart();

      // get the axes' pointer
      _xAxis = static_cast<QValueAxis *>(_equationSeries->attachedAxes().at(0));
      _xAxis->setTickInterval(1);
      _xAxis->setTickType(QValueAxis::TicksDynamic);

      _yAxis = _equationSeries->attachedAxes().at(1);
    }

    if (_paretoChart != nullptr && _equationSeries != nullptr) {
      _initialized = true;
    } else {
      //qWarning() << "[EquationParetoEfficiencyController] Initialization "
      //              "failed, one or more pointers are invalid or null.";
      logs::Logger::logWarning("[EquationParetoEfficiencyController] Initialization failed, one or more pointers are invalid or null."
                               ,{logs::LogTags::viewController, logs::LogTags::pareto});
    }
  }
}

void EquationParetoEfficiencyController::clear() {
    // Remove all points of the scatter series
    _equationSeries->clear();

    _pointsToDisplay.clear();
    // Remove all line series from the chart
    if (!_paretoSeriesListToDisplay.empty()) {
        for (auto &series : _paretoSeriesListToDisplay) {
            _paretoChart->removeSeries(series);
        }
        _paretoSeriesListToDisplay.clear();
    }
    _paretoSeriesList.clear();

}


void EquationParetoEfficiencyController::instantRefreshParetoControler(const datamodel::EquationTree* equationsArray, uint equationsArraySize)
{
    paretoRefreshRateCount= _paretoRefreshRate -1;
    onEquationsDataChanged(equationsArray,equationsArraySize);

}

void EquationParetoEfficiencyController::onEquationsDataChanged(
        const datamodel::EquationTree* equationsArray, uint equationsArraySize) {
    paretoRefreshRateCount ++;
  if ((_initialized && equationsArraySize !=0) && (_paretoRefreshRate== paretoRefreshRateCount)) {
    paretoRefreshRateCount =0;


    // clear chart and internal members
    if(_initialized){
        _points.clear();
        clear();
    }

    // map equations to a list of points
    mapSeriesPoints(equationsArray, equationsArraySize);

    // sort the list of points by complexity
    std::sort(_points.begin(), _points.end(),
              [](const EquationPoint a, const EquationPoint b) {
                return (a.point.x() < b.point.x());
              });

    // Append pareto points to line series
    createParetoSeries();

    // select points from the three best pareto charts
    filteredPoints();

    // update the axes' ranges
    updateAxes();

    // draw each equation to the chart
    plotPoints();
    plotSeries();
  }

}

void EquationParetoEfficiencyController::filteredPoints() {
    for (auto &pt : _points) {
       if(pt.paretoLevel < _nbParetoSeriesToDisplay)
        _pointsToDisplay.append(pt);
    }
}

void EquationParetoEfficiencyController::plotPoints() {
  // append points to the scatter series
  for (auto &pt : _pointsToDisplay) {
         _equationSeries->append(pt.point.x(), pt.point.y());
  }
}

void EquationParetoEfficiencyController::plotSeries() {
    // append dominant points from line series to the chart
    if (_paretoSeriesList.size() > 0) {
        for (int i = 0; i < _nbParetoSeriesToDisplay; i++) {
            // force each line series axes' to be the same as scatter series'
            auto series = _paretoSeriesList.at(i);
            _paretoSeriesListToDisplay.append(series);
            _paretoChart->addSeries(series);
            series->attachAxis(_xAxis);
            series->attachAxis(_yAxis);
        }
    }
}

void EquationParetoEfficiencyController::mapSeriesPoints(
    const datamodel::EquationTree* equationsArray, const uint equationsArraySize) {

  // create a list of points for each equation
  std::for_each(equationsArray, equationsArray+equationsArraySize,[this](const datamodel::EquationTree& equation){
      // Skip nan and infinite number
      if (std::isnan(equation.distance()) == false &&
          std::isinf(equation.distance()) == false) {
        // create a point
        EquationPoint pt;
        qreal distance = equation.distance();
        if(distance < SERIES_MIN_DISTANCE){
           distance = SERIES_MIN_DISTANCE;
        }else if(distance > SERIES_MAX_DISTANCE){
            distance = SERIES_MAX_DISTANCE;
        }
        pt.point = QPointF(equation.totalNode(),
                           distance);
        pt.paretoLevel = equation.paretoLevel();
        _points.append(pt);
      }
  });


}

void EquationParetoEfficiencyController::createParetoSeries() {
  // get the max pareto level
  auto max =
      std::max_element(_points.cbegin(), _points.cend(),
                       [](const EquationPoint &a, const EquationPoint &b) {
                         return a.paretoLevel < b.paretoLevel;
                       });

  // append points in line series
  for (int i = 0; i <= max->paretoLevel; i++) {
    QLineSeries *lineSeries = new QLineSeries();
    lineSeries->setName(QString("Level ") + QString::number(i));
    for (auto &pt : _points) {
      if (i == pt.paretoLevel) lineSeries->append(pt.point.x(), pt.point.y());
    }

    // append the new pareto series to the list
    if (lineSeries->count() != 0) {
      QAbstractSeries *paretoSeries = lineSeries;
      _paretoSeriesList.append(paretoSeries);
    }
  }
  _paretoSeriesSize = _paretoSeriesList.size();
  _nbParetoSeriesToDisplay = (_paretoSeriesSize < _maxParetoSeries) ? _paretoSeriesSize : _maxParetoSeries;
}

void EquationParetoEfficiencyController::updateAxes() {
  // find the minimum and maximum X and Y axes for the chart
  qreal minComplexity = std::numeric_limits<qreal>::max();
  qreal maxComplexity = std::numeric_limits<qreal>::min();

  qreal minDistance = SERIES_MAX_DISTANCE;
  qreal maxDistance = SERIES_MIN_DISTANCE;
  for(auto &pt : _pointsToDisplay){
      qreal x = pt.point.x();
      qreal y = pt.point.y();
      if(minComplexity > x)
          minComplexity = x;

      if(maxComplexity < x)
          maxComplexity = x;

      if(minDistance > y)
          minDistance = y;

      if(maxDistance < y)
          maxDistance = y;
  }

  // we update the ranges for x and y axes
  if (_xAxis != nullptr && _yAxis != nullptr) {
    _xAxis->setTickAnchor(minComplexity);
    _xAxis->setRange(minComplexity, maxComplexity);
    _yAxis->setRange(minDistance,maxDistance);
  }
}

int EquationParetoEfficiencyController::nbParetoSeries() const { return _maxParetoSeries; }

void EquationParetoEfficiencyController::setNbParetoSeries(int value)
{
    if (_maxParetoSeries != value)
    {
        Settings::instance()->setValue("Interface/MaxParetoSeries", value);
        _maxParetoSeries = value;

        //clear and update pareto chart
        if(!_points.empty()){
            updateDisplay();
        }
    }
}

void EquationParetoEfficiencyController::updateDisplay(){
    clear();
    _nbParetoSeriesToDisplay = (_paretoSeriesSize < _maxParetoSeries) ? _paretoSeriesSize : _maxParetoSeries;

    filteredPoints();
    updateAxes();

    plotPoints();
    plotSeries();
}

}  // namespace viewcontroller
