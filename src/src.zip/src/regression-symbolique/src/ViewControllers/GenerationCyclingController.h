#pragma once

#include <QObject>
#include "ViewControllers_global.h"
#include "Utils/CommandLineParser.h"

namespace viewcontroller
{
/**
 * @brief The GenerationCyclingController class create the link between Qml and Equation algorihtmes
 */
class GenerationCyclingController : public QObject
{
    Q_OBJECT
    Q_PROPERTY(int numberOfGenerations READ numberOfGenerations WRITE setNumberOfGenerations NOTIFY
                   numberOfGenerationsChanged)

    Q_PROPERTY(bool infiniteGenerations READ infiniteGenerations WRITE setInfiniteGenerations NOTIFY
    numberOfGenerationsChanged)

    Q_PROPERTY(double distanceMinimum READ distanceMinimum WRITE setDistanceMinimum NOTIFY
               distanceMinimumChanged)

    Q_PROPERTY(int activateDistanceMin READ activateDistanceMin WRITE setActivateDistanceMin NOTIFY
               activateDistanceMinChanged)

    Q_PROPERTY(int timeSelected READ timeSelected WRITE setTimeSelected NOTIFY timeSelectedChanged)

   public:
    explicit GenerationCyclingController(QObject *parent = nullptr);

    int numberOfGenerations() const;
    void setNumberOfGenerations(int numberOfGenerations);

    bool infiniteGenerations() const;
    void setInfiniteGenerations(bool value);

    [[nodiscard]] int maxNode()const;
    void setMaxNode(int maxNode);

    double distanceMinimum() const;
    void setDistanceMinimum(double distanceMinimum);

    int activateDistanceMin() const;
    void setActivateDistanceMin(int activateDistanceMin);

    int timeSelected() const;
    void setTimeSelected(int time);

   signals:
    void numberOfGenerationsChanged();
    void distanceMinimumChanged();
    void activateDistanceMinChanged();
    void maxNodeChanged(int);
    void timeSelectedChanged();

   private:
    Q_DISABLE_COPY_MOVE(GenerationCyclingController)

    bool _infiniteGenerations{false};
    int _numberOfGenerations{utils::CommandLineParser::getNumberOfGenerations()};
    double _distanceMinimum{utils::CommandLineParser::getDistanceMinimum()};
    int _activateDistanceMin{utils::CommandLineParser::getActivateDistanceMin()};
    int _timeSelected{utils::CommandLineParser::getTimeSelected()};

};
}  // namespace viewcontroller
