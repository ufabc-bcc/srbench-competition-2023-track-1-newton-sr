#include "SelectedNodeListController.h"

#include <QSet>
#include "Utils/Settings.h"

namespace viewcontroller
{
SelectedNodeListController::SelectedNodeListController(QObject *parent) : QAbstractListModel(parent) {}

QVariant SelectedNodeListController::data(const QModelIndex &index, int role) const
{
    if (index.row() < 0 || index.row() >= rowCount())
    {
        return QVariant();
    }

    datamodel::EquationNode::NodeType nodeType = datamodel::EquationNode::NodeType(index.row() + 2);

    switch (role)
    {
        case NodeName:
            return utils::CommandLineParser::nodeTypeName(nodeType);
        case NodeSelected:
            // Default value is true, every node type is by default selected even its not in the map
            bool selected =
                Settings::instance()->value("NodeDefaultSelection/" +
                                            utils::CommandLineParser::nodeTypeName(nodeType), true).toBool();
            return _selectedNodeType.value(nodeType, selected);
    }

    return QVariant();
}

int SelectedNodeListController::rowCount(const QModelIndex &parent) const
{
    Q_UNUSED(parent)
    // Excude the constant and variable type
    return datamodel::EquationNode::Last - 1;
}

QHash<int, QByteArray> SelectedNodeListController::roleNames() const
{
    QHash<int, QByteArray> roles;
    roles.insert(NodeName, "name");
    roles.insert(NodeSelected, "selected");
    return roles;
}

bool SelectedNodeListController::setData(const QModelIndex &index, const QVariant &value, int role)
{
    if (index.row() < 0 || index.row() >= rowCount())
    {
        return false;
    }

    datamodel::EquationNode::NodeType nodeType = datamodel::EquationNode::NodeType(index.row() + 2);

    if (role == NodeSelected)
    {
        _selectedNodeType[nodeType] = value.toBool();
        Settings::instance()->setValue("NodeDefaultSelection/" +
                                       utils::CommandLineParser::nodeTypeName(nodeType) , value.toString());
        emit selectedNodesTypesChanged();
        emit dataChanged(index, index, {NodeSelected});
        return true;
    }

    return false;
}

Qt::ItemFlags SelectedNodeListController::flags(const QModelIndex &index) const
{
    if (index.row() < 0 || index.row() >= rowCount())
    {
        return Qt::NoItemFlags;
    }

    return Qt::ItemIsSelectable | Qt::ItemIsEnabled | Qt::ItemIsEditable;
}

QSet<datamodel::EquationNode::NodeType> SelectedNodeListController::selectedNodesTypes() const
{
    if (utils::CommandLineParser::getStartSilent())
    {
        return utils::CommandLineParser::getOperatorsList();
    }

    QSet<datamodel::EquationNode::NodeType> selectedNodeTypes;

    for (int nodeType = 0; nodeType <= datamodel::EquationNode::Last; ++nodeType)
    {
        bool selected = Settings::instance()
                            ->value("NodeDefaultSelection/" +
                                    utils::CommandLineParser::nodeTypeName(static_cast<datamodel::EquationNode::NodeType>(nodeType)),
                                    true)
                            .toBool();
        if (_selectedNodeType.value(datamodel::EquationNode::NodeType(nodeType), selected))
        {
            selectedNodeTypes.insert(datamodel::EquationNode::NodeType(nodeType));
        }
    }

    return selectedNodeTypes;
}

}  // namespace viewcontroller
