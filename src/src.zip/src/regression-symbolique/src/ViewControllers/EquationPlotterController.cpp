#include "EquationPlotterController.h"
#include <algorithm>
#include "Utils/CommandLineParser.h"
#include "Logger_v2/Logger.h"

using namespace viewcontroller;

EquationPlotterController::EquationPlotterController(QObject* parent) : QObject(parent) {}

void EquationPlotterController::clear()
{
    if (_equationPlotterSeries) _equationPlotterSeries->clear();
    if (_bestEquationSeries) _bestEquationSeries->clear();
    if (_bestEfficiencyEquationSeries) _bestEfficiencyEquationSeries->clear();
}

void EquationPlotterController::init(QtCharts::QLineSeries* series, QtCharts::QLineSeries* bestSeries,
                                     QtCharts::QScatterSeries* inputDatasSeries, QtCharts::QLineSeries* bestEfficiencySeries)
{
    _equationPlotterSeries = series;
    _inputDatasSeries = inputDatasSeries;
    _bestEquationSeries = bestSeries;
    _bestEfficiencyEquationSeries = bestEfficiencySeries;

    // I kinda have to do that because this is called before the first onInputDataChanged
    QList<datamodel::DataPoint> inputDatas_qt(_inputDatas.begin(), _inputDatas.end());
    onInputDataChanged(inputDatas_qt);
}

void EquationPlotterController::onBestChanged(datamodel::EquationTreeItem equation)
{
    updateSeries(_bestEquationSeries, equation);
}

void EquationPlotterController::onBestEfficiencyChanged(datamodel::EquationTreeItem equation)
{
    updateSeries(_bestEfficiencyEquationSeries, equation);
}

void EquationPlotterController::onEquationSelected(datamodel::EquationTreeItem equation)
{
    updateSeries(_equationPlotterSeries, equation);
}

void EquationPlotterController::updateSeries(QtCharts::QLineSeries* series, datamodel::EquationTreeItem equation)
{
    if (utils::CommandLineParser::getStartSilent())
    {
        return;
    }

    series->clear();

    for (datamodel::DataPoint &point : _inputDatas)
    {
        //In case of multiple variables we take only the one in the first column of the file
        if (!std::isnan(point.parameterList().front())){
            auto y = equation.value(point.parameterList());
            series->append(point.parameterList().front(), y);
        }
    }
}

void EquationPlotterController::clearView()
{
    _equationPlotterSeries->clear();
    _bestEquationSeries->clear();
    _bestEfficiencyEquationSeries->clear();
}

void EquationPlotterController::updateAxes()
{
    _xmin = std::numeric_limits<double>::max();
    _xmax = std::numeric_limits<double>::min();
    _ymin = std::numeric_limits<double>::max();
    _ymax = std::numeric_limits<double>::min();

    // looping through every point of the input datas looking for
    // xmin and max
    for (const auto& point : _inputDatas)
    {
        _ymin = std::min(point.result(), _ymin);
        _ymax = std::max(point.result(), _ymax);

        //In case of multiple variables we take only the one in the first column of the file
        const double x = point.parameterList().front();
        _xmin = std::min(x, _xmin);
        _xmax = std::max(x, _xmax);
    }

    // Computing the axes margin. 10% hardcoded for now
    const auto widthMargin = (_xmax - _xmin) * 0.10;
    const auto heightMargin = (_ymax - _ymin) * 0.10;

    _xmin -= widthMargin;
    _xmax += widthMargin;

    _ymin -= heightMargin;
    _ymax += heightMargin;

    for (auto* axe : _inputDatasSeries->attachedAxes())
    {
        if (axe->objectName() == "x")
        {
            axe->setMin(_xmin);
            axe->setMax(_xmax);
        }

        else if (axe->objectName() == "y")
        {
            axe->setMin(_ymin);
            axe->setMax(_ymax);
        }
    }
}

void EquationPlotterController::updatePoints()
{
    for (const auto& point : _inputDatas)
    {
        //In case of multiple variables we take only the one in the first column of the file
        _inputDatasSeries->append(point.parameterList().front(), point.result());
    }
}

void EquationPlotterController::onInputDataChanged(const QList<datamodel::DataPoint> inputDatas)
{
    _inputDatas.clear();
    for(const auto& data: inputDatas)
        _inputDatas.push_back(data);

    if (!_inputDatasSeries)
    {
        logs::Logger::logWarning("InputDatasSeries has not been initialized in EquationPlotterController",{logs::LogTags::viewController});
        return;
    }
    _inputDatasSeries->clear();
    _equationPlotterSeries->clear();
    _bestEquationSeries->clear();
    _bestEfficiencyEquationSeries->clear();

    updateAxes();
    updatePoints();
}
