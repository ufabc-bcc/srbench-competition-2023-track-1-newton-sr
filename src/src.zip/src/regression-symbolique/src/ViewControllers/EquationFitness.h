#pragma once

#include <QDebug>
#include <QtCharts/QXYSeries>

#include "../DataModel/EquationTreeItem.h"
#include "../DataModel/EquationTree.h"

using namespace QtCharts;

namespace viewcontroller
{
/**
 * @brief The EquationFitness class handle the computation of fitness (average and best error) and provide the
 * results
 */
class EquationFitness
{
   public:
    // Helper structure to organize the data
    struct GenerationPoints
    {
        QPointF averageGenerationPoint;
        QPointF bestGenerationPoint;
    };

    /**
     * @brief clear the two series
     */
    void clear();

    /**
     * @brief Compute and add result for one generation to the series
     * @param generation The generation to add
     * @param generationSize Size of the generation array
     * @param breedAndMutationRate The number of breeded and mutated equations in the generation
     */
    void addGeneration(const datamodel::EquationTree* generation, uint generationSize, int breedAndMutationRate);

    /**
     * @brief init Initialise the fitness series
     * @param average The error average series
     * @param best The best error series
     */
    void init(QAbstractSeries* average, QAbstractSeries* best, int *fitnessRefreshRate, int *fitnessRefreshCountValue);

   private:
    /**
     * @brief computeSeriesPoints
     * @param generation
     * @param generationSize
     * @param breedAndMutationRate
     * @return
     */
    GenerationPoints computeSeriesPoints(const datamodel::EquationTree* generation, uint generationSize, int breedAndMutationRate);

    void updateAxis();

    /**
     * @brief The average error/distance series displayed into the Qml (red line)
     */
    QXYSeries* _averageSeries{nullptr};
    /**
     * @brief The best error/distance series displayed into the Qml (blue line)
     */
    QXYSeries* _bestSeries{nullptr};

    /**
     * @brief True if the series are initialized
     */
    bool _initialized{false};

    /**
     * @brief The number of generation
     */
    int _generationNumber{0};

    /**
     * @brief The maximum y axis (equal to the max distance average)
     */
    double _yMax{0};

    /**
     * @brief The minimum y axis (equal to the min distance)
     */
    double _yMin{0};

    int *fitenessRefreshRate = nullptr;
    int *fitnessCurrentCount = nullptr;
};

}  // namespace viewcontroller
