#include "GenerationCyclingController.h"

namespace viewcontroller {

GenerationCyclingController::GenerationCyclingController(QObject *parent) : QObject(parent) {}

int GenerationCyclingController::numberOfGenerations() const
{
    return _numberOfGenerations;
}

bool GenerationCyclingController::infiniteGenerations() const
{
    return _infiniteGenerations;
}

double GenerationCyclingController::distanceMinimum() const
{
    return _distanceMinimum;
}

int GenerationCyclingController::activateDistanceMin() const
{
    return _activateDistanceMin;
}

void GenerationCyclingController::setActivateDistanceMin(int activateDistanceMin)
{
    _activateDistanceMin=activateDistanceMin;
}
void GenerationCyclingController::setInfiniteGenerations(bool value)
{
    _infiniteGenerations=value;
}

void GenerationCyclingController::setNumberOfGenerations(int numberOfGenerations)
{
    if (_numberOfGenerations != numberOfGenerations) {
        _numberOfGenerations = numberOfGenerations;
        emit numberOfGenerationsChanged();
    }
}
void GenerationCyclingController::setDistanceMinimum(double distanceMinimum)
{
    _distanceMinimum = distanceMinimum;
}
void GenerationCyclingController::setTimeSelected(int time)
{
    _timeSelected = time;
}
int GenerationCyclingController::timeSelected() const
{
    return _timeSelected;
}

}
// namespace viewcontroller
