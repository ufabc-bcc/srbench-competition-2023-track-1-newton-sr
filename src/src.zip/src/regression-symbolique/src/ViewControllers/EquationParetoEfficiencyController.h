#pragma once

#include <QDebug>
#include <QPointF>
#include <QtCharts/QAbstractSeries>
#include <QtCharts/QChart>
#include <QtCharts/QChartView>
#include <QtCharts/QLineSeries>
#include <QtCharts/QLogValueAxis>
#include <QtCharts/QScatterSeries>
#include <QtCharts/QValueAxis>
#include <QtCharts/QXYSeries>
#include <algorithm>
#include <cmath>

#include "../DataModel/EquationTree.h"
#include "../DataModel/EquationTreeItem.h"
#include "ViewControllers_global.h"
#include "Utils/Settings.h"

using namespace QtCharts;

namespace viewcontroller {

/**
 * @brief Distance minimum that could be display
 */
constexpr qreal SERIES_MIN_DISTANCE = 1.E-3;

/**
 * @brief Distance maximum that could be display
 */
constexpr qreal SERIES_MAX_DISTANCE = 1.E2;

/**
 * @brief The EquationParetoEfficiencyController class handle the computation of
 * pareto efficiency (distance / complexity and pareto frontier) and provide the
 * results
 */
class EquationParetoEfficiencyController
    : public QObject {
  Q_OBJECT
   Q_PROPERTY(int nbParetoSeries READ nbParetoSeries WRITE setNbParetoSeries NOTIFY nbParetoSeriesChanged)
   Q_PROPERTY(int paretoRefreshRate READ paretoRefreshRate WRITE setParetoRefreshRate NOTIFY
                   paretoRefreshRateChanged)
 private:
  /**
   * @brief Helper structure to organize the data
   */
  struct EquationPoint {
    QPointF point;
    int paretoLevel;
  };

  /**
   * @brief A list of equation point
   */
  typedef QVector<EquationPoint> EquationsPoint;

  /**
   * @brief A list of abstract series
   */
  typedef QVector<QAbstractSeries*> ParetoSeriesList;

  /**
   * @brief The error/distance and complexity series displayed into the Qml
   * (blue points)
   */
  QXYSeries* _equationSeries{nullptr};
  /**
   * @brief The pareto chart
   */
  QChart* _paretoChart{nullptr};

  /**
   * @brief X axis pointer
   */
  QValueAxis * _xAxis{nullptr};

  /**
   * @brief Y axis pointer
   */
  QAbstractAxis* _yAxis{nullptr};

  /**
   * @brief True if the chart are initialized
   */
  bool _initialized{false};

  int _paretoRefreshRate{1};
  int paretoRefreshRateCount=0;

  /**
   * @brief A list of pareto series
   */
  ParetoSeriesList _paretoSeriesList;

  /**
  * @brief A list of pareto series
  */
  ParetoSeriesList _paretoSeriesListToDisplay;

  /**
   * @brief A list of equation points
   */
  EquationsPoint _points;

  /**
   * @brief A list of filtered equation points
   */
  EquationsPoint _pointsToDisplay;

  /**
   * @brief Number maximum of pareto series that can be displayed on a chart
   */
  int _maxParetoSeries{Settings::instance()->value("Interface/MaxParetoSeries", 3).toInt()};

  int _paretoSeriesSize;
  /**
   * @brief Number of pareto series to display
   */
  int _nbParetoSeriesToDisplay;

  /**
   * @brief Put points into chart
   */
  void plotPoints();

  /**
   * @brief Put series into chart
   */
  void plotSeries();

  /**
   * @brief Choose point with a pareto level lower than _maxParetoSeries
   */
  void filteredPoints();

  /**
   * @brief map equations distance and complexity to a Series Points
   * @param equations
   */
  void mapSeriesPoints(const datamodel::EquationTree* equationsArray, const uint equationsArraySize);

  /**
   * @brief Create line series to append to the chart
   */
  void createParetoSeries();

  /**
   * @brief Update X and Y axes scale
   */
  void updateAxes();

  /**
   * @brief Update the chart display, call when _maxParetoSeries is modified
   */
  void updateDisplay();
 public:
  explicit EquationParetoEfficiencyController(QObject* parent = nullptr);

  int paretoRefreshRate() const;
  void setParetoRefreshRate(int);

  /**
   * @brief init Initialise the fitness series
   * @param average The error average series
   * @param best The best error series
   */
  void init(QAbstractSeries* equations);

  // properties getter/setter
  int nbParetoSeries() const;
  void setNbParetoSeries(int);
  void setDisplayParetoController();
 public slots:
  /**
   * @brief Compute and add equations to the series
   * @param equations The equations to add to the chart
   * @param equationsArraySize Size of the equations array
   */

  void instantRefreshParetoControler(const datamodel::EquationTree* equationsArray, const uint equationsArraySize);
  void onEquationsDataChanged(const datamodel::EquationTree* equationsArray, const uint equationsArraySize);

  /**
   * @brief clear the chart
   */
  void clear();

  void updateParetoRefreshRate(int value);

 signals:
  // property signal
  void nbParetoSeriesChanged(int);
  void paretoRefreshRateChanged(int);

};

}  // namespace viewcontroller
