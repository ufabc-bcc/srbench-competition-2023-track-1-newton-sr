#pragma once


#include "DataModel/DataPoint.h"
#include "DataModel/EquationTreeItem.h"

#include <QAbstractListModel>

#include <QtQml/qqml.h>
#include <QtCharts/QLineSeries>
#include <QtCharts/QScatterSeries>
#include <QtCharts/QXYSeries>

namespace viewcontroller
{
using InputData = std::vector<datamodel::DataPoint>;

/**
 * @brief Manages the EquationPlotter events
 *
 */
class EquationPlotterController : public QObject
{
    Q_OBJECT
    QML_ELEMENT

   public:
    EquationPlotterController(QObject* parent);

    /**
     * @brief Clears the Series displayed by the view
     */
    void clear();

   public slots:

    /**
     * @brief   Initialize the controller with the QLineSeries
     *          displaying the selected equation and the QScatterSeries
     *          displaying the input data
     * @param splineSeries
     */
    void init(QtCharts::QLineSeries* equationPlotterSeries, QtCharts::QLineSeries* bestSeries,
              QtCharts::QScatterSeries* inputDataSeries, QtCharts::QLineSeries* bestEfficiencySeries);

    /**
     * @brief   Event raised by the EquationsListController when the user select an equation
     *          on the EquationList (raised by EquationListDisplay.qml)
     * @param equationId Id of the equation that must be displayed
     */
    void onEquationSelected(datamodel::EquationTreeItem equation);

    /**
     * @brief   Event raised by the InputFileManager inside the AlgorithmController when
     *          the input data have been updated by the user
     * @param inputDatas
     */
    void onInputDataChanged(QList<datamodel::DataPoint> inputDatas);

    /**
     * @brief onBestChanged Triggered when the best equation changed
     * @param equation
     */
    void onBestChanged(datamodel::EquationTreeItem equation);

    /**
     * @brief onBestEfficiencyChanged Triggered when the best efficiency equation changed
     * @param equation
     */
    void onBestEfficiencyChanged(datamodel::EquationTreeItem equation);

    /**
     * @brief Clears the equation displayed by the plotter
     */
    void clearView();

   private:
    /**
     * @brief Adjust the plotter's axes to the current input data
     */
    void updateAxes();

    /**
     * @brief Updates the input data point on the view
     */
    void updatePoints();

    /**
     * @brief updateSeries update the series in parameter with the equation in parameter
     * @param series
     * @param equation
     */
    void updateSeries(QtCharts::QLineSeries* series, datamodel::EquationTreeItem equation);

    /**
     * @brief QSplineSeries plotting the selected equation
     */
    QtCharts::QLineSeries* _equationPlotterSeries{nullptr};

    /**
     * @brief QSplineSeries plotting the best equation
     */
    QtCharts::QLineSeries* _bestEquationSeries{nullptr};

    /**
     * @brief QSplineSeries plotting the best efficiency equation
     */
    QtCharts::QLineSeries* _bestEfficiencyEquationSeries{nullptr};

    /**
     * @brief QScatterSeries displaying the current input data
     *
     */
    QtCharts::QScatterSeries* _inputDatasSeries{nullptr};

    InputData _inputDatas;

    double _xmin;
    double _xmax;
    double _ymin;
    double _ymax;
};
}  // namespace viewcontroller
