from regressionSymbolique import RegressionSymbolique


model = RegressionSymbolique(
    #input_path="C:/SymbolicRegression/NewToN SR++ 0.3/data/data/InputDataFile2.csv",
    #input_path="C:\RI_PHYSIC\\build-regression-symbolique-Desktop_Qt_5_15_2_MinGW_64_bit-Release\src\App\data\data\InputDataFile.csv",
    #input_path="C:\RI_PHYSIC\\regression-symbolique\python\\test\\test.csv",
    input_path="C:\RI_PHYSIC\\regression-symbolique\data\data\log(x+sqrt(power(x,2)+1)_log(x+sqrt(power(x,2)+1))_N0.csv",
    generation_amount=10
)
print("=============================================")
print("========= EXEC MODEL FROM FILE===============")
print("=============================================")

model.process()

print("====================================")
print("========= PRINT MODEL===============")
print("====================================")


print(model)

print("====================================")
print("====================================")

print(model.get_process_stdout())
print(model.get_process_returncode())

print("====================================")
print("====================================")

print(f"Best equation ===> {model.get_best_equation()}")

print("====================================")

print(f"Get equation index 1 ===> {model.get_equation_at_index_as_string(1)}")

print("====================================")

print(model.evaluate_best(0.0))
