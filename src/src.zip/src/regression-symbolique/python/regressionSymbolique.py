"""Define the RegressionSymbolique interface."""
from subprocess import PIPE, run, STDOUT
import configparser
import pandas as pd
import sympy

import os
import tempfile


LOG_BLOC_START_INDICATOR="Best equations of Generation"
BEST_EQUATION_INDICATOR= "> Equation "
BASIC_EQUATION_INDICATOR= "- Equation "


config = configparser.ConfigParser()
config.read(f"{os.path.dirname(__file__)}/configurations.ini")


EXECUTABLE= config['Application']['ExecutablePath']

class EquationInformations():
    def __init__(
        self,
        equation="",
        efficiency=None,
        complexity=None,
        r2=None,
        mse=None,
        distance=None
    ):
        self.equation=equation
        self.efficiency=efficiency
        self.complexity=complexity
        self.r2=r2
        self.mse=mse
        self.distance=distance


    def __repr__(self):
        return f"- Equation: (R2: {str(self.r2)}, MSE: {str(self.mse)}, complexity : {str(self.complexity)}, efficiency : {str(self.efficiency)}) : {str(self.equation)}"


class RegressionSymbolique():

    def __init__(
        self,
        help=None,
        help_all=None,
        version=False,
        population_size=None,
        generation_amount=None,
        crossbreeding_rate=None,
        mutation_rate=None,
        number_mutations=None,
        operations=None,
        equations_depth=None,
        input_path=None,
        tournament_size=None,
        filter_origin=None,
        start_silent=True,
        numbeof_equations=None,
        activate_distance=None,
        start_parallel=False,
        fit_duration=None,
        fit_popperiod=None,
        simp_count=None,
        number_threads=None
    ):
        self.help=help
        self.help_all=help_all
        self.version=version
        self.population_size=population_size
        self.generation_amount=generation_amount
        self.crossbreeding_rate=crossbreeding_rate
        self.mutation_rate=mutation_rate
        self.number_mutations=number_mutations
        self.operations=operations
        self.equations_depth=equations_depth
        self.input_path=input_path
        self.tournament_size=tournament_size
        self.filter_origin=filter_origin
        self.start_silent=start_silent
        self.numbeof_equations=numbeof_equations
        self.activate_distance=activate_distance
        self.start_parallel=start_parallel
        self.fit_duration=fit_duration
        self.fit_popperiod=fit_popperiod
        self.simp_count=simp_count
        self.number_threads=number_threads
        self.temporary_input_file_descriptor=None
        self.temporary_input_file_path=None
    
        self.__createCommandString()
        self.equations=[]
        self.best_equation_index=None
        self.result=None
        self.equation_parameters_names=[]
        self.inputdataframe=None

    def __del__(self):
        if self.temporary_input_file_path is not None:
            os.close(self.temporary_input_file_descriptor)
            os.remove(self.temporary_input_file_path)

    def __repr__(self):
        """
        Print all last equations fitted by the model and indicate the best one with >>.
        """
        output = "RegressionSymbolique.equations = [\n"

        output += "pick\tr2\tmse\tcomplexity\tefficiency\tequation\n"

        for i, equation in enumerate(self.equations):
            prefix=""
            if i == self.best_equation_index:
                prefix=f">> "
            output += f"{prefix}{i}\t{equation.r2}\t{equation.mse}\t{equation.complexity}\t{equation.efficiency}\t\t{equation.equation}\n"

        output += "]"
        return output

   
    def evaluate(self, index, *values_list, verbose=False, n=15):
        """Return the result of index th equation using values_list.

        Parameters
        ----------
        index : int
            Index of the equation to get.

        *values_list :
            parameters values to apply to equation for evaluation.
            Values are ordered same as csv input header or DataFrame columns
            Number of values should be same as csv input header or DataFrame columns

        verbose : boolean
            If True, set verbosity for sympy evaluation function
            Default: False

        n : int
            evaluation accuracy number of digits for sympy evaluation function
            Default: 15

        Returns
        -------
        result :
            Equation evaluation result.

        Raises:
        -------
            AttributeError: when number of values_list are not correct.

        """
        # nb element is len -1 due to last one which is the result column so not counted for equation parameters
        if len(values_list) != len(self.equation_parameters_names)-1 :
            raise AttributeError(f"values_list must have {len(self.equation_parameters_names)-1} element.")

        parameters_values = {}
        for idx in range(len(self.equation_parameters_names)-1):
            parameters_values[self.equation_parameters_names[idx]]=values_list[idx]

        return self.__evaluate(index, parameters_values, verbose=verbose, n=n)

    def evaluate_best(self, *values_list, verbose=False, n=15):
        """Return the result of best equation using values_list.

        Parameters
        ----------
        *values_list :
            parameters values to apply to equation for evaluation.
            Values are ordered same as csv input header or DataFrame columns
            Number of values should be same as csv input header or DataFrame columns

        verbose : boolean
            If True, set verbosity for sympy evaluation function
            Default: False

        n : int
            evaluation accuracy number of digits for sympy evaluation function
            Default: 15

        Returns
        -------
        result :
            Equation evaluation result.

        Raises:
        -------
            AttributeError: when an values_list is not a list.

        """
        return self.evaluate(self.best_equation_index, *values_list, verbose=verbose, n=n)

    def fit(self, X, Y):
        """ Process  symbolic regression according to provided parameters and X, Y arguments.

        
        Parameters
        ----------
        X :  list of list | ndarray | pandas.DataFrame
            list of parameters
        Y :   list | ndarray | pandas.DataFrame
            list of parameters (1 column)

        Raises:
        -------
            AttributeError: when an input_path is already provided.

        """
        if self.temporary_input_file_path is None:
            print("[ERROR] : This command need to not to have an input_path definition to be executed")
            raise AttributeError("fit command need to not to have an input_path definition to be executed.")
        
        # reset data is needed if multiple call to fit are executed with same instance
        self.__reset_datas()

        self.__store_x_y_to_dataframe(X, Y)

        self.__write_data_to_temporary_csv()
        self.result = run(self.cmd, stdout=PIPE, stderr=PIPE, text=True)
        self.__extract_and_store_equations()

    def process(self):
        """Process symbolic regression according to provided parameters.
        Using a provided csv (or tsv) file in input_path parameter

        Raises:
        -------
            AttributeError: when input_path is not provided.

        """
        if self.temporary_input_file_path is not None:
            print("[ERROR] : This command need an input_path definition to be executed")
            raise AttributeError("process command need to have an input_path definition to be executed.")

        self.__reset_datas()
        self.__read_columns_name_from_input_csv()
        self.result = run(self.cmd, stdout=PIPE, stderr=PIPE, text=True)
        self.__extract_and_store_equations()

    def get_process_stdout(self):
        """Return the processing stdout string.

        Returns
        -------
        output : str
            processing stdout string.
        """
        return self.result.stdout

    def get_process_returncode(self):
        """Return the processing return code.

        Returns
        -------
        rc : int
            processing return code.
        """
        return self.result.returncode

    def get_best_equation(self):
        """Return the processed best equation.
        If no equation present, return empty string.

        Returns
        -------
        equation : str
            Equation string.
        """
        return self.equations[self.best_equation_index].equation

    def get_equation_at_index_as_string(self, index=-1):
        """Return the Nth equation of the list.
        If the index is out of range, return empty string.
        -1 index return last equation

        Parameters
        ----------
        index : int
            Index of the equation to get.
            Default is -1

        Returns
        -------
        equation : str
            Equation string.
        """
        try:
            return self.equations[index].equation
        except IndexError:
            return ""

#### Private Function ##########

    def __add_columns_name_if_needed(self, df, basename):
        """Set columns names for the dataframe if it does not have some.

        If default name is found for a column, (i.e. column index value) the column name is set to <basemane><column index>.
        If the column has already a name, no change.

        Parameters
        ----------
        df : pandas.dataFrame
            dataframe which contains data to process.

        basename: str
            basename prefix of column name
        """
        col=list(df.columns)

        for i, elt in enumerate(col):
            if elt==i:
                col[i]=f"{basename}{i}"
        df.columns = col

    def __createCommandString(self):
        """ Create and fill command string use to run executable.

        It uses attributes of the object 
        
        """
        self.cmd=[]
        self.cmd.append(EXECUTABLE)

        if self.help is not None:
            self.cmd.append("-h")
            return
        
        if self.help_all is not None:
            self.cmd.append("--help-all")
            return

        if self.version:
            self.cmd.append("-v")
            return

        if self.population_size is not None:
            self.cmd.append("-p")
            self.cmd.append(str(self.population_size))

        if self.generation_amount is not None:
            self.cmd.append("-g")
            self.cmd.append(str(self.generation_amount))

        if self.crossbreeding_rate is not None:
            self.cmd.append("-c")
            self.cmd.append(str(self.crossbreeding_rate))

        if self.mutation_rate is not None:
            self.cmd.append("-m")
            self.cmd.append(str(self.mutation_rate))

        if self.number_mutations is not None:
            self.cmd.append("-nm")
            self.cmd.append(str(self.number_mutations))

        if self.operations is not None:
            self.cmd.append("-o")
            self.cmd.append(str(self.operations))

        if self.equations_depth is not None:
            self.cmd.append("-e")
            self.cmd.append(str(self.equations_depth))

        self.cmd.append("-i")
        if self.input_path is not None:
            self.cmd.append(str(self.input_path))
        else:
            self.temporary_input_file_descriptor, self.temporary_input_file_path = tempfile.mkstemp(suffix='.csv', text=True)
            self.cmd.append(self.temporary_input_file_path)

        if self.tournament_size is not None:
            self.cmd.append("-t")
            self.cmd.append(str(self.tournament_size))

        if self.filter_origin is not None:
            self.cmd.append("-f")
            self.cmd.append(str(self.filter_origin))

        if self.start_silent:
            self.cmd.append("-s")

        if self.numbeof_equations is not None:
            self.cmd.append("-n")
            self.cmd.append(str(self.numbeof_equations))

        if self.activate_distance is not None:
            self.cmd.append("-a")
            self.cmd.append(str(self.activate_distance))

        if self.start_parallel:
            self.cmd.append("--pl")

        if self.fit_duration is not None:
            self.cmd.append("--fd")
            self.cmd.append(str(self.fit_duration))

        if self.fit_popperiod is not None:
            self.cmd.append("--fp")
            self.cmd.append(str(self.fit_popperiod))

        if self.simp_count is not None:
            self.cmd.append("--sc")
            self.cmd.append(str(self.simp_count))

        if self.number_threads is not None:
            self.cmd.append("--nt")
            self.cmd.append(str(self.number_threads))

    def __extract_and_store_equations(self):
        """Extract and store equations informations from processing logs.

        It parses logs lines and extracts distance and pareto equations list and first equation.


        """
        if self.get_process_returncode() == 0:
            lines = self.get_process_stdout().split("\n")
            
            for line in reversed(lines):
                if LOG_BLOC_START_INDICATOR in line:
                    return
                if line.startswith(BEST_EQUATION_INDICATOR):
                    self.__extract_equation_element_from_line(line, best=True)
                if BASIC_EQUATION_INDICATOR in line:
                    self.__extract_equation_element_from_line(line, best=False)

        return "Processing not correctly ended"

    def __extract_equation_element_from_line(self, line, best=False):
        """Extract distance or paretor equation informations from log line.

        The equation informations are stored in `equations` list. If it is the best one, its index is stored in `best_equation_index`
        
        Parameters
        ----------
        line : str
            Log line string from executable logs

        best : boolean
            Indicates if the line contains the best equation
            Default: False

        """
        elts = line.split(":")
        index = elts[0].split(",")[0].split()[-1]
        r2 = elts[1].split(" ")[1][:-1]
        mse = elts[2].split(" ")[1][:-1]
        complexity = elts[3].split(" ")[1][:-1]
        efficiency = elts[4].split(" ")[1][:-1]
        equation = elts[-1].strip()


        equainfo = EquationInformations(r2=float(r2), mse=float(mse), equation=equation, complexity=float(complexity), efficiency=float(efficiency))
        self.equations = [equainfo] + self.equations
        if best:
            self.best_equation_index=int(index)

    def __evaluate(self, index, parameters_values, verbose=False, n=15):
        """Return the result of equation at index position in equation list using paremeters_values.

        Parameters
        ----------
        index : int
            Index of the equation to get.

        parameters_values : dict
            Dictionary with parameters values to apply to equation for evaluation.

        verbose : boolean
            If True, set verbosity for sympy evaluation function
            Default: False

        n : int
            evaluation accuracy number of digits for sympy evaluation function
            Default: 15

        Returns
        -------
        result :
            Equation evaluation result.

        Raises:
        -------
            AttributeError: when an parameters_values is not a dict.

        """
        if not isinstance(parameters_values, dict):
            raise AttributeError("parameters_values must be a dict.")

        ###################################
        ## FIRST SOLUTION: Use python eval
        ##
        ## LIMITATION: some big equations seems to be not well evaluated
        ## and eval is not known to be robust and secure
        ###################################
        #locals().update(parameters_values)
        #return eval(self.get_equation_at_index_as_string(index))
    
        ####################################
        ## SECOND SOLUTION: Use python sympy.N
        ##
        ## LIMITATION: more robust but still some expr 
        ## not recognized (i.e. artan should ne replaced by atan)
        ## it may have others expression not recognized
        ###################################
        return sympy.N(self.get_equation_at_index_as_string(index).replace("arctan","atan"), subs=parameters_values, verbose=verbose, n=n)

    def __read_columns_name_from_input_csv(self):
        """ Read header from input_path file and store them.


        Raises:
        -------
            AttributeError: when an input_path is not csv or tsv.

        """
        sep=";"
        _, file_extension = os.path.splitext(self.input_path)
        if file_extension == '.tsv':
            sep="\t"
        elif file_extension == '.csv':
            sep=";"
        else:
            raise AttributeError("input_path file must have .csv or .tsv extension an use ; or tab respectively as separator")

        df = pd.read_csv(self.input_path, sep=sep, header=0, nrows=0)
        self.equation_parameters_names =list(df.columns)

    def __reset_datas(self):
        """Reset data from protential previous execution.

        Clean equations lists
        """
        self.equations=[]
        self.best_equation_index=None
        self.inputdataframe=None
        self.result=None
        self.equation_parameters_names=[]

    def __store_parameters_names(self):
        self.equation_parameters_names=list(self.inputdataframe.columns)

    def __store_x_y_to_dataframe(self, X, Y):
        # Convert inputs to pandas.DataFrame to unify further processing
        if not isinstance(X, pd.DataFrame):
            dfx = pd.DataFrame(X)
        else:
            dfx = X.copy()

        if not isinstance(Y, pd.DataFrame):
            dfy = pd.DataFrame(Y)
        else:
            dfy = Y.copy()

        # check input consistency (need to be already converted to dataFrame)
        if dfx.shape[0] != dfy.shape[0]:
            raise AttributeError("X and Y must have the same numbers of rows.")

        if dfy.shape[1] != 1:
            raise AttributeError("Y must have only one column.")


        # Add columns name if needed and copy Y column to the end of X with same column name
        # if this column name already exist add 'y' in front
        self.__add_columns_name_if_needed(dfx, 'x')
        self.__add_columns_name_if_needed(dfy, 'y')
        if dfy.columns[0] in  list(dfx.columns):
            dfx[f"y{dfy.columns[0]}"]= dfy[dfy.columns[0]]
        else:
            dfx[dfy.columns[0]]= dfy[dfy.columns[0]]

        self.inputdataframe=dfx.copy()
        self.__store_parameters_names()

    def __write_data_to_temporary_csv(self):
        """Write input dataFrame datas to the temporary csv file.

        This csv file is needed when using fit function with X and Y datas sets instead of passing input_path file.
        This csv file is a ';' separated file with headers.
        """
        with open(self.temporary_input_file_path, 'w', newline = '\n') as file:
            self.inputdataframe.to_csv(file, header=True, index=False, sep=';')
