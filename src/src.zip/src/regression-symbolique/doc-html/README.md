# PHISIC documentation guide

## Introduction

La documentation du projet **PHISIC** est basée sur [Bootstrap](https://getbootstrap.com).

La version de Bootstrap actuellement utilisée est la *5.2*.

La documentation est basée sur une seule page statique créée à partir de la page *sidebars* des exemples de Bootstrap.

## Informations

La page de documentation est composée d'un menu sur la gauche.

Chaque élément du menu permet d'afficher la page associée.

La documentation est composée :

- d'un menu global ([index.html](index.html))
- d'un document destinée aux **développeurs** ([dev.html](dev.html)) appelé "Documentation de maintenance" dans le menu global
- d'un document destinée aux **utilisateurs** ([user.html](user.html)) appelé "Documentation utilisateur" dans le menu global

Chaque document est indépendant bien qu'ils partagent des espaces de ressources communs.

## Informations technique

Des commentaires dans le code HTML permettent d'avoir des exemples ainsi que la méthode pour ajouter des pages et mettre à jour le menu.

### Spécificités

Les icônes pour les alertes sont déjà disponible par défaut dans le fichier de documentation.

## Liens utiles

Bootstrap : https://getbootstrap.com

Documentation Bootstrap :

Quelques paragraphes spécifiques utiles :

- Texte : https://getbootstrap.com/docs/5.2/utilities/text/
- Espacement (entre noeuds HTML) : https://getbootstrap.com/docs/4.0/utilities/spacing/
- Liste : https://getbootstrap.com/docs/5.2/components/list-group/
- Image : https://getbootstrap.com/docs/5.2/content/images/
- Alerte : https://getbootstrap.com/docs/5.2/components/alerts/

## Axes d'améliorations et limites

- Chaque documentation est dans un seul fichier qui peut avoir une taille importante
- La multiplication d'images dans la page doit être optimisé (utilisation de vignette)
