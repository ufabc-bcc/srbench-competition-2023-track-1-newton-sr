function showContent(Id) {
  let container = document.getElementById('container');
  let pages = container.getElementsByClassName('content');
  for (let index = 0; index < pages.length; index++) {
    const element = pages[index];
    if (element.id == Id) {
      console.log("element " + Id + " found");
      element.classList.remove("d-none");
      element.classList.add("d-block");
    } else {
      element.classList.remove("d-block");
      element.classList.add("d-none");
    }
  };
}
