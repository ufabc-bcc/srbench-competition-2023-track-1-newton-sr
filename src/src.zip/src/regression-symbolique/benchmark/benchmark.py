# -*- coding: utf-8 -*-

################################################################
# Python file runs if set in the folder : Build_Folder_Name/src/
################################################################

# Import system modules
import sys, string, os, subprocess, time, logging
import glob 
import os.path
import shutil
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

from subprocess import Popen, PIPE
from pathlib import Path
from sympy import *
from datetime import datetime
import re

# Settings
# inputDataPath to the input data csv files 
inputDataFolder = "fonction/"
numberOfGen = 5# Default 100
sizeOfPopulation = 500 # Default 100
crossbreedingRate = 0.3 # Default 0.5
mutationRate = 0.3 # Default 0.5
depth = 5 # Default 5
filterOrigin = 1 # Default 1
tournamentSize = 3 #Default 5
numOfEquations = sizeOfPopulation
operationsToRemove = "max,min,absolute,arctan"
parallelOption = ""
fitDuration = 1
numberOfThreads = 6
exeName = "TreeGeneticProgramming.exe"
logFolder = "logOutput"
loopWithSameDatafile = 2

# Time Efficiency Parameter
populationIncrement = 1000
timesToken = [#"Crossbreeding",
              "ChildrenCreation",
              "FitThread",
              "ParetoThread",
              "FilterThread",
              #"updateDistanceToData",
              #"updateEquations"
              ]

# Benchmark Output Option
isDisplayingFitnessChart = False
isCreatingCSV = True
isComputingTimeEfficiency = False
isThreadTesting = False

def closeLogger(logger):
    """Close all handlers on logger object."""
    if logger is None:
        return
    for handler in list(logger.handlers):
        handler.close()
        logger.removeHandler(handler)
        
def internLogger(logger_name, level=logging.DEBUG):
    logger = logging.getLogger(logger_name)
    logger.setLevel(level)
    format_string = ("%(asctime)s — %(name)s — %(levelname)s — %(funcName)s:"
                    "%(lineno)d — %(message)s")
    log_format = logging.Formatter(format_string)
    # Creating and adding the console handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(log_format)
    logger.addHandler(console_handler)
    # Creating and adding the file handler
    file_handler = logging.FileHandler(logger_name, mode='a')
    file_handler.setFormatter(log_format)
    logger.addHandler(file_handler)
    return logger

def launchCmd (inputPathSelected, inputDataFileSelected) :
    # Parameters
    ### Remove if you don't want numOfEquations = sizeOfPopulation ###
    numOfEquations = sizeOfPopulation
    ###
    paramSilent = " -s"
    paramNbGen = " -g " + str(numberOfGen)
    paramSizePop = " -p " + str(sizeOfPopulation)
    paramCbRate = " -c " + str(crossbreedingRate)
    paramMutRate = " -m " + str(mutationRate)
    paramDepth = " -e " + str(depth)
    paramFilterOrigin = " -f " + str(filterOrigin)
    paramNumOfEquations = " -n " + str(numOfEquations)
    paramsOperations = " -o " + operationsToRemove
    paramParallel = parallelOption
    paramsFitDuration = " -fd " + str(fitDuration)
    paramsNumOfThreads = " -nt " + str(numberOfThreads)


    parametersList = paramSilent + paramNbGen + paramSizePop + paramCbRate
    parametersList += paramMutRate + paramDepth + paramFilterOrigin + paramNumOfEquations
    parametersList += paramsOperations + paramParallel + paramsFitDuration + paramsNumOfThreads
                    
    paramInputData = " -i "

    # No debug logging outpout in the application
    os.environ["QT_LOGGING_RULE"] = "*.debug=false"
    os.environ["QT_LOGGING_RULE"] = "*.warning=false"
    os.environ["QT_LOGGING_RULE"] = "*.info=false"

    commandExe = "cmd /c " + exeName + parametersList + paramInputData + inputPathSelected + inputDataFileSelected
    # 'cmd /k ' to keep open the cmd window
    # 'cmd /c ' to keep close the cmd window
    print("commandExe = " + commandExe)

    # Launch .exe + Stockage equation
    cmdOutput = subprocess.check_output(commandExe, shell=False, text=True)
    
    # print(cmdOutput)
    return cmdOutput
            

def generateOutputLog (inputDataFile, data, outputLogFile) :
    # Log File
    inputDataMessage = "\nInput Data Selected : " + str(inputDataFile) + " \n"
    inputSettingsMessage = "Settings : numberOfGen = " + str(numberOfGen) + \
        "; sizeOfPopulation = " + str(sizeOfPopulation) + \
        "; crossbreedingRate = " + str(crossbreedingRate)+ \
        "; mutationRate = " + str(mutationRate) + \
        "; filterOrigin = " + str(filterOrigin) + \
        "; tournamentSize = " + str(tournamentSize) + \
        "; numOfEquations = " + str(numOfEquations) + "\n"
    inputMessage = inputDataMessage + inputSettingsMessage
    message = inputMessage + data

    logger = internLogger(outputLogFile)
    logger.debug(message)
    closeLogger(logger)

def extractResultFromOutput(data):
    # Extract best equation
    equationToken = "=> First equation : "
    errorToken = " Distance : "
    computeTimeToken = " Compute Time : "
    generationToken = " Last Generation : "

    equationPos = data.rfind(equationToken)
    if equationPos != -1:
        errorPos = data.rfind(errorToken)
        timePos = data.rfind(computeTimeToken)
        generationPos = data.rfind(generationToken)

        equation = data[(equationPos + len(equationToken)):errorPos]
        error = data[(errorPos + len(errorToken)):timePos]

        # Convert time value in second with 3 digits
        timeValue = float(data[(timePos + len(computeTimeToken)):generationPos]) / 1000
        timeValue = float("{:.3f}".format(timeValue))

        generation = data[(generationPos + len(generationToken)):]

        return (equation, error, timeValue, generation)

def extractFitnessFromOutput(data):
    meanErrorToken = "=> Mean Error : "
    bestFitToken = " Best Fitness : "
    endToken = " MeanError <="
    
    meanErrorIndex = [_.start() for _ in re.finditer(meanErrorToken, data)]
    bestFitIndex = [_.start() for _ in re.finditer(bestFitToken, data)]
    endIndex = [_.start() for _ in re.finditer(endToken, data)] 

    meanErrorList = []
    bestFitnessList = []
    for i in range(len(meanErrorIndex)):
        meanErrorPos = meanErrorIndex[i]
        bestFitPos = bestFitIndex[i]
        endPos = endIndex[i]
        meanError = float(data[(meanErrorPos + len(meanErrorToken)):bestFitPos])
        bestFitness = float(data[(bestFitPos + len(bestFitToken)):endPos])
        if(meanError > 0):
            meanError = 1./meanError
        if(bestFitness > 0):
            bestFitness = 1./bestFitness            
        meanErrorList.append(meanError)
        bestFitnessList.append(bestFitness)
    return (meanErrorList, bestFitnessList)

def extractTimesFromLog(token, data):
    time = 0
    beginToken = "=> " + token + " : "
    endToken = " " + token + " <="

    beginIndex = [_.start() for _ in re.finditer(beginToken, data)]
    endIndex = [_.start() for _ in re.finditer(endToken, data)]

    nbIndex = len(beginIndex)
    for i in range(nbIndex):
            beginPos = beginIndex[i]
            endPos = endIndex[i]
            time += float(data[(beginPos + len(beginToken)):endPos])
    # mean time in Ms
    if nbIndex != 0:
        return (time/nbIndex)/1000000.;
    else:
        print("nbIndex nul")
        return 0;
    
def computeTimeEfficiency(data):
    timeResult = []
    for token in timesToken:
        result = extractTimesFromLog(token, data)
        timeResult.append(result)
    return timeResult

  
def plotFitnessChart(fileName, meanError, bestFitness):
    plt. clf()
    X = np.arange(start=0, stop=len(meanError))
    plt.plot(X, bestFitness, color='g', label='Best Fitness')
    plt.plot(X, meanError, color='r', label='Mean Error')

    plt.xlabel('Generation')
    plt.ylabel('Error')
    plt.yscale('symlog')
    plt.title('Fitness Chart')
    
    plt.legend()

    plt.savefig(fileName)
    plt.show()

def plotTimesChart(fileName, populationIndex, timesList):
    plt. clf()
    labels = []

    for token in (timesToken):
        labels.extend([token])
            
    if(isThreadTesting):
        for token in (timesToken):
            labels.extend([token + " with Thread"])

    for i in range(len(timesList)):       
        plt.plot(populationIndex, timesList[i], label = labels[i])

    plt.xlabel('Population Size')
    plt.ylabel('Mean Time (ms)')
    #plt.yscale('symlog')
    plt.title('Times Chart')
    
    plt.legend()
    
    plt.savefig(fileName)
    plt.show()

def createNewRowCSV(fileName,data):
    (equation, error, timeValue, lastGeneration) = extractResultFromOutput(msgLog)

    # TODO : Remove simplification when it's done in the tree_genetic_programming.exe #####
    simplifyEquation = simplify(equation)

    expandEquation = expand(simplifyEquation)
    return pd.DataFrame({'File':[inputDataFileName],
                        'Equation Original':[equation],
                        'Equation Simplify':[simplifyEquation],
                        'Equation Expand':[expandEquation],
                        'Error Value':[error],
                        'Compute Time (s)':[timeValue],
                        'Last Generation':[lastGeneration]})
     


    
if __name__ == "__main__":

    fileSynth = pd.DataFrame()

    # list of xml files in data folder
    filesInFolder = glob.glob(inputDataFolder + '\\*')

    # create folder for output log
    Path(logFolder).mkdir(parents=True, exist_ok=True)

    # create path with today date for csv output
    now = datetime.now()
    dt_string = now.strftime("%d_%m_%Y")
    cvsfile = "Synthesis" + dt_string + ".csv"
    
    for dataFile in filesInFolder:
        if os.path.splitext(dataFile)[1] == '.csv':
            inputDataFileName = os.path.basename(dataFile)
            ouputFileName = os.path.splitext(inputDataFileName)[0] + ".log"
            ouputFileName = os.path.join(logFolder,ouputFileName)

            print("Log File " + ouputFileName)
   
            # Begin
            timesList = []
            populationIndex = []
            for i in range(loopWithSameDatafile):
                
                print("Launching... \n")
                parallelOption = ""
                msgLog = launchCmd(inputDataFolder, inputDataFileName)
                generateOutputLog(inputDataFileName, msgLog, ouputFileName)

                ### CSV
                # Extract the output data for saving it to the DataFrame
                if(isCreatingCSV):
                    # Append new row to the dataFrame
                    new_row = createNewRowCSV(cvsfile,msgLog)
                    fileSynth = pd.concat([fileSynth,new_row], ignore_index=True)
                    fileSynth.to_csv(cvsfile)

                ### Time Efficiency
                if(isComputingTimeEfficiency):

                    times = computeTimeEfficiency(msgLog)
                    if(isThreadTesting):
                        print("Launching... \n")
                        parallelOption = " -pl "
                        msgLog = launchCmd(inputDataFolder, inputDataFileName)
                        generateOutputLog(inputDataFileName, msgLog, ouputFileName)

                        times += computeTimeEfficiency(msgLog)
                  
                    for j in range (len(times)):
                        if(i == 0):
                            timesList.append([times[j]])
                        else:
                            timesList[j].extend([times[j]])
                    
                    populationIndex += (i,)
                    #sizeOfPopulation += populationIncrement
        
            ### Fitness Chart
            if(isDisplayingFitnessChart):
                (meanError, bestFitness)= extractFitnessFromOutput(msgLog)
                fitnessFile = os.path.splitext("fitness_" + inputDataFileName)[0] + "_" + dt_string + ".png"
                plotFitnessChart(fitnessFile, meanError, bestFitness)
                
            if(isComputingTimeEfficiency):
                timesfile = "times_" + os.path.splitext(inputDataFileName)[0] + "_" + dt_string + ".png"
                plotTimesChart(timesfile, populationIndex,timesList,)

            print("Next... \n")
    
    print("Process done")
    




